"""Save one human-confirmed Betman-to-API team alias.

Run this only after checking the API team ID.  The resolver still verifies the
fixture's date and home/away pair, so a saved alias cannot bypass the quarantine
gate by itself.
"""

from __future__ import annotations

import argparse

from api_engine import save_confirmed_team_alias


def main() -> int:
    parser = argparse.ArgumentParser(description="Save an administrator-confirmed football team alias")
    parser.add_argument("--name", required=True, help="Betman/local team spelling")
    parser.add_argument("--team-id", required=True, type=int, help="confirmed API-Football team ID")
    parser.add_argument("--api-name", default="", help="confirmed API-Football team name")
    parser.add_argument("--note", default="admin-confirmed", help="short audit note")
    args = parser.parse_args()
    save_confirmed_team_alias(args.name, args.team_id, args.api_name, args.note)
    print(f"✅ 팀 별칭 저장: {args.name} -> {args.api_name or args.team_id} ({args.team_id})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
