import os
import json
import sqlite3
import re
import math
import time
import requests
import difflib
import unicodedata
from contextlib import contextmanager
from datetime import datetime, timezone, timedelta
from dotenv import load_dotenv
from football_model import (clean_records, train_challenger, predict_goals,
                            price_eligible, probability_price_choice, validate_price_policy,
                            wdl_centered_choice, all_evidence_choice,
                            autonomous_robot_choice, build_autonomous_robot_features,
                            build_autonomous_robot_candidates, train_autonomous_robot,
                            OFFICIAL_PICK_POLICY_VERSION,
                            AUTONOMOUS_ROBOT_POLICY_VERSION, ROBOT_MODEL_VERSION,
                            ROBOT_TARGET_ACCURACY,
                            ROBOT_FEATURE_SCHEMA_VERSION,
                            ROBOT_COMPATIBLE_FEATURE_SCHEMAS,
                            ROBOT_MEMORY_SCHEMA_VERSION,
                            ROBOT_LINEUP_SCHEMA_VERSION)

from grading_postmortem import (
    build_postmortem,
    normalize_official_stats,
    official_stats_text,
    postmortem_json,
    postmortem_text,
)

load_dotenv()

API_KEY = os.getenv("API_KEY")
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")

if not API_KEY or not GITHUB_TOKEN:
    print("🚨 [보안 경고] .env 파일에서 키를 찾을 수 없습니다! 서버 세팅을 확인하세요.")

GITHUB_REPO = "chleowhd77-ops/-"
API_HOST = "v3.football.api-sports.io"
headers = {'x-apisports-key': API_KEY}
DEFAULT_LOGO = "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d3/Soccerball.svg/120px-Soccerball.svg.png"
STRICT_REFEREES = ["Taylor", "Hernandez", "Lahoz", "Orsato", "Oliver", "Dean", "Turpin", "Makkelie"]
ANALYSIS_VERSION = "V7.13.0-proto-toto14-shared-dossier-season"
FORECAST_MODEL_VERSION = "goals-v4-full-context-coherent-v1"
CALIBRATION_VERSION = "fixture-time-full-context-wdl-projection-v1"
PICK_POLICY_VERSION = OFFICIAL_PICK_POLICY_VERSION
ROBOT_PICK_VERSION = "robot-self-learning-online-v7-value-accuracy-goal"
# R7.13 starts a new public grading season.  Earlier immutable rows remain in
# SQLite for audit/learning but are not blended into the new display totals.
PUBLIC_SCORE_VERSION = "R7.13.0-proto-toto14-new-public-season"
# 프로그램 배포 버전과 예측 모델 버전을 분리한다. 화면/수집/집계 오류를
# 고쳤다는 이유만으로 과거 예측이 다른 모델 기록처럼 분리되면 안 된다.
SYSTEM_VERSION = "R7.12.31-50-batch-world-parity-v3-sync"

# API-Football의 하루 한도를 분석 작업이 전부 소모하지 않게 보호한다.
# 기본값은 7,500회 요금제에서 라이브/채점용 1,500회를 남기는 구성이다.
API_DAILY_TOTAL_LIMIT = max(100, int(os.getenv("API_DAILY_TOTAL_LIMIT", "7500")))
API_LIVE_RESERVE = max(50, int(os.getenv("API_LIVE_RESERVE", "1500")))
API_ANALYSIS_SOFT_LIMIT = max(50, API_DAILY_TOTAL_LIMIT - API_LIVE_RESERVE)
# WORLD만의 내부 상한이 공급사 실제 잔여량보다 먼저 닫히지 않도록 한다.
# 전체 7,500회 중 최대 4,000회까지만 WORLD에 허용하며, 아래의 전체 한도와
# 1,500회 LIVE/채점 보호량 검사는 이 값보다 우선해 계속 적용된다.
API_WORLD_DAILY_LIMIT = max(10, int(os.getenv("API_WORLD_DAILY_LIMIT", "4000")))
API_WORLD_MIN_REMAINING = max(100, int(os.getenv("API_WORLD_MIN_REMAINING", "1000")))
API_PROVIDER_STATUS_TTL_SECONDS = max(
    60, min(1800, int(os.getenv("API_PROVIDER_STATUS_TTL_SECONDS", "300")))
)
API_MIN_REQUEST_INTERVAL = max(0.0, float(os.getenv("API_MIN_REQUEST_INTERVAL", "0.22")))
API_RATE_LIMIT_RETRIES = max(0, int(os.getenv("API_RATE_LIMIT_RETRIES", "2")))
_API_PROVIDER_REMAINING = None
_API_PROVIDER_DAY = None
_API_QUOTA_NOTICE_SHOWN = False
_API_LAST_REQUEST_AT = 0.0
_API_PURPOSE_OVERRIDE = None
_API_CACHE_ONLY = False

SQLITE_BUSY_TIMEOUT_MS = max(
    5000, min(60000, int(os.getenv("SQLITE_BUSY_TIMEOUT_MS", "30000")))
)
SQLITE_BUSY_RETRY_DELAYS = (0.2, 0.5, 1.0)


def valid_analysis_candidates(picks):
    """Normalize recorded candidates without inventing prices or probabilities."""
    def number(value, default=None):
        try:
            value = float(value)
            return value if math.isfinite(value) else default
        except (TypeError, ValueError):
            return default

    valid = []
    for source in picks or []:
        if not isinstance(source, dict):
            continue
        pick = dict(source)
        raw = str(pick.get("raw_pick") or pick.get("pick") or "").strip()
        probability = number(pick.get("prob", pick.get("model_probability", pick.get("probability"))))
        if not raw or probability is None or not 0 < probability <= 1:
            continue
        market = pick.get("market_key") or pick.get("market")
        if market not in {"1x2", "totals", "handicap"}:
            market = "totals" if re.search(r"언더|오버|U/O", raw) else (
                "handicap" if re.search(r"핸디|적용 후|\[[+-]?\d", raw) else "1x2")
        if not pick.get("settlement_supported", True):
            continue
        # Legacy rows may predate the explicit settlement flag. Do not treat a
        # push/half settlement as a binary win merely to fill the recommendation.
        if market == "totals":
            line = number(pick.get("totals_base"))
            if line is None:
                match = re.search(r"U/O\s*([0-9]+(?:\.[0-9]+)?)", raw)
                line = number(match.group(1)) if match else None
            if line is None or abs(line % 1 - .5) > 1e-8:
                continue
        pick.update(raw_pick=raw, market_key=market, prob=probability,
                    odd=number(pick.get("odd"), 0.0),
                    fair_prob=number(pick.get("fair_prob", pick.get("fair_probability"))),
                    robust_probability=number(pick.get("robust_probability"), probability))
        for key in ("robust_edge", "robust_ev", "balanced_score"):
            pick[key] = number(pick.get(key), 0.0)
        valid.append(pick)
    return valid


def extract_robot_pick(item):
    """Recover one frozen robot pick from every supported publication shape.

    Collector versions have published the robot alongside the card, inside
    category data, and inside the nested WORLD analysis.  The public app must
    not silently hide the same frozen answer merely because its container
    changed.  A copy is returned so display localization cannot mutate the
    saved pre-kickoff record.
    """
    if not isinstance(item, dict):
        return None
    analysis = item.get("analysis") if isinstance(item.get("analysis"), dict) else {}
    containers = [
        item.get("robot_pick"),
        (item.get("pick_categories") or {}).get("robot_independent")
        if isinstance(item.get("pick_categories"), dict) else None,
        (item.get("categories") or {}).get("robot_independent")
        if isinstance(item.get("categories"), dict) else None,
        analysis.get("robot_pick"),
        (analysis.get("categories") or {}).get("robot_independent")
        if isinstance(analysis.get("categories"), dict) else None,
        (item.get("decision") or {}).get("robot_pick")
        if isinstance(item.get("decision"), dict) else None,
        (analysis.get("decision") or {}).get("robot_pick")
        if isinstance(analysis.get("decision"), dict) else None,
    ]
    for source in containers:
        if not isinstance(source, dict):
            continue
        raw_pick = str(source.get("raw_pick") or source.get("pick") or "").strip()
        if not raw_pick:
            continue
        recovered = dict(source)
        recovered["raw_pick"] = raw_pick
        recovered["prob"] = recovered.get(
            "prob", recovered.get("probability", 0)
        )
        recovered["fair_prob"] = recovered.get(
            "fair_prob", recovered.get("fair_probability")
        )
        return recovered
    return None


def toto14_display_meta(items, source_meta=None):
    """Derive ticket cost from the visible markings, never from stale totals."""
    items = [item for item in (items or []) if isinstance(item, dict)]
    source_meta = source_meta if isinstance(source_meta, dict) else {}
    try:
        unit_price = max(1, int(source_meta.get("unit_price") or 1000))
    except (TypeError, ValueError):
        unit_price = 1000
    try:
        max_combinations = max(
            1, int(source_meta.get("max_combinations") or 8)
        )
    except (TypeError, ValueError):
        max_combinations = 8

    pick_counts = [
        len(item.get("picks") or [])
        if isinstance(item.get("picks") or [], (list, tuple, set))
        else 0
        for item in items
    ]
    unavailable_pick_count = sum(count == 0 for count in pick_counts)
    total_combinations = (
        math.prod(max(1, count) for count in pick_counts) if items else 0
    )
    ticket_complete = len(items) == 14 and unavailable_pick_count == 0
    purchase_ready_combinations = total_combinations if ticket_complete else 0
    return {
        "total_combinations": total_combinations,
        "single_pick_count": sum(count == 1 for count in pick_counts),
        "double_pick_count": sum(count == 2 for count in pick_counts),
        "unavailable_pick_count": unavailable_pick_count,
        "suppressed_double_count": sum(
            bool(item.get("double_suppressed")) for item in items
        ),
        "frozen_prediction_count": sum(
            bool(item.get("prediction_frozen")) for item in items
        ),
        "ticket_complete": ticket_complete,
        "purchase_ready_combinations": purchase_ready_combinations,
        "max_combinations": max_combinations,
        "unit_price": unit_price,
        "budget": total_combinations * unit_price,
        "purchase_ready_budget": purchase_ready_combinations * unit_price,
        "max_budget": int(
            source_meta.get("max_budget") or max_combinations * unit_price
        ),
        "cost_cap_exceeded_by_frozen": bool(
            source_meta.get("cost_cap_exceeded_by_frozen")
            or total_combinations > max_combinations
        ),
    }


def choose_analysis_fallback(picks):
    """One factual probability-first pick even when price/value is unqualified."""
    available = valid_analysis_candidates(picks)
    if not available:
        return None
    pick = dict(max(available, key=lambda p: (
        p["robust_probability"], p["prob"], p["robust_edge"], p["robust_ev"],
        p["balanced_score"], p["raw_pick"],
    )))
    priced = bool(pick["odd"] > 1 and pick.get("fair_prob") is not None
                  and 0 < pick["fair_prob"] < 1)
    warning = ("배당가치 기준 미충족 · 수익 우위 미확인" if priced
               else "배당 자료 미확인 · 배당가치 비교 불가")
    pick.update(recommendation_status="SELECTED", official_final_pick=True,
                probability_fallback=True, final_pick_grade="standard",
                value_pick_tier="not_qualified", odds_verified=priced,
                selection_warning=warning,
                selection_reason=(f"가치 조건을 통과한 후보가 없어도 픽을 비우지 않고, "
                                  f"계산 가능한 {len(available)}개 후보 중 보수확률 우선으로 선택. {warning}."))
    return pick


def _sqlite_connect(path="ai_predictions.db", timeout=None):
    """Open the shared database with one consistent multi-worker wait policy."""
    timeout_seconds = (
        float(timeout)
        if timeout is not None
        else SQLITE_BUSY_TIMEOUT_MS / 1000.0
    )
    conn = sqlite3.connect(path, timeout=max(1.0, timeout_seconds))
    conn.execute(f"PRAGMA busy_timeout = {SQLITE_BUSY_TIMEOUT_MS}")
    return conn


def _is_sqlite_busy(error):
    message = str(error or "").casefold()
    return "database is locked" in message or "database is busy" in message


class ApiQuotaUnavailable(RuntimeError):
    """일일 API 한도 보호 장치가 요청을 중단했음을 뜻한다."""


class ApiRateLimited(RuntimeError):
    """공급사의 분당/순간 요청 제한이 잠시 적용됐음을 뜻한다."""


def _response_error_text(response):
    try:
        return json.dumps(response.json().get("errors", {}), ensure_ascii=False).lower()
    except Exception:
        return ""


def _header_int(response, name):
    try:
        value = response.headers.get(name)
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _is_daily_quota_response(response, error_text=""):
    """하루 한도 소진과 일시적인 분당 제한을 구분한다.

    API-Sports는 일일 잔여량과 분당 잔여량을 서로 다른 헤더로 보낸다.
    일반적인 ``rate limit`` 문구만으로 하루 전체를 잠그면 결제 갱신 뒤에도
    최근 전적ㆍ부상자ㆍLIVE 조회가 모두 중단될 수 있다.
    """
    daily_remaining = _header_int(response, "x-ratelimit-requests-remaining")
    daily_markers = (
        "daily quota",
        "daily request",
        "requests per day",
        "request limit for the day",
        "quota for the day",
    )
    return any(marker in error_text for marker in daily_markers) or (
        daily_remaining is not None and daily_remaining <= 0
    )


def _pace_api_request():
    global _API_LAST_REQUEST_AT
    if API_MIN_REQUEST_INTERVAL > 0:
        wait_seconds = API_MIN_REQUEST_INTERVAL - (time.monotonic() - _API_LAST_REQUEST_AT)
        if wait_seconds > 0:
            time.sleep(wait_seconds)
    _API_LAST_REQUEST_AT = time.monotonic()


def _api_provider_day_key():
    """API-Sports의 일일 사용량 초기화 기준(매일 00:00 UTC)을 따른다.

    기존 버전은 한국 날짜를 사용해 공급사 초기화 시각과 최대 9시간 어긋났다.
    ``utc:`` 접두사는 과거 KST 기준으로 저장된 소진 기록과 새 기록을 분리해,
    업데이트 직후에도 오래된 0회 잔여 기록이 로봇을 막지 않게 한다.
    """
    return f"utc:{datetime.now(timezone.utc).strftime('%Y-%m-%d')}"


API_RUNTIME_DB = "api_runtime.db"  # Local only: never upload or restore from GitHub.


def _runtime_connect():
    conn = sqlite3.connect(API_RUNTIME_DB, timeout=30)
    conn.execute(f"PRAGMA busy_timeout={SQLITE_BUSY_TIMEOUT_MS}")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS api_usage_daily (
            usage_day TEXT PRIMARY KEY, calls INTEGER DEFAULT 0,
            provider_remaining INTEGER, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS api_usage_purpose_daily (
            usage_day TEXT, purpose TEXT, calls INTEGER DEFAULT 0,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(usage_day,purpose));
        CREATE TABLE IF NOT EXISTS api_endpoint_daily (
            usage_day TEXT,purpose TEXT,endpoint TEXT,calls INTEGER DEFAULT 0,
            PRIMARY KEY(usage_day,purpose,endpoint));
        CREATE TABLE IF NOT EXISTS api_runtime_metric_daily (
            usage_day TEXT,metric TEXT,purpose TEXT,endpoint TEXT,count INTEGER DEFAULT 0,
            PRIMARY KEY(usage_day,metric,purpose,endpoint));
        CREATE TABLE IF NOT EXISTS api_provider_status_daily (
            usage_day TEXT PRIMARY KEY,
            current_calls INTEGER,
            limit_day INTEGER,
            remaining INTEGER NOT NULL,
            verified_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS request_cache (
            key TEXT PRIMARY KEY, body TEXT, expires REAL DEFAULT 0, lease REAL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS general_cache (
            cache_key TEXT PRIMARY KEY,
            cache_value TEXT NOT NULL,
            updated_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS team_identity_retry_queue (
            retry_key TEXT PRIMARY KEY,
            home_name TEXT NOT NULL,
            away_name TEXT NOT NULL,
            match_time TEXT NOT NULL DEFAULT '',
            league_name TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL DEFAULT 'PENDING',
            attempts INTEGER NOT NULL DEFAULT 0,
            last_reason TEXT NOT NULL DEFAULT '',
            last_attempt_at TEXT,
            next_retry_at TEXT,
            home_team_id INTEGER NOT NULL DEFAULT 0,
            away_team_id INTEGER NOT NULL DEFAULT 0,
            home_form_ready INTEGER NOT NULL DEFAULT 0,
            away_form_ready INTEGER NOT NULL DEFAULT 0,
            resolved_at TEXT,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
        CREATE INDEX IF NOT EXISTS idx_team_identity_retry_due
            ON team_identity_retry_queue(status,next_retry_at,updated_at);
        CREATE TABLE IF NOT EXISTS team_identity_manual_aliases (
            normalized_alias TEXT PRIMARY KEY,
            local_name TEXT NOT NULL,
            api_team_id INTEGER NOT NULL,
            api_team_name TEXT NOT NULL DEFAULT '',
            approved_note TEXT NOT NULL DEFAULT '',
            approved_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS runtime_meta (key TEXT PRIMARY KEY);
    """)
    # Existing servers already have this durable queue.  Add the league hint
    # in place without clearing attempts or resolved identities.
    retry_columns = {
        str(row[1]) for row in conn.execute(
            "PRAGMA table_info(team_identity_retry_queue)"
        ).fetchall()
    }
    if "league_name" not in retry_columns:
        try:
            conn.execute(
                "ALTER TABLE team_identity_retry_queue "
                "ADD COLUMN league_name TEXT NOT NULL DEFAULT ''"
            )
            conn.commit()
        except sqlite3.OperationalError as error:
            # Another worker may have completed the same one-time migration.
            if "duplicate column" not in str(error).casefold():
                raise
    if not conn.execute("SELECT 1 FROM runtime_meta WHERE key='migrated'").fetchone():
        legacy = None
        try:
            if os.path.exists("ai_predictions.db"):
                legacy = sqlite3.connect("file:ai_predictions.db?mode=ro", uri=True, timeout=1)
                tables = {r[0] for r in legacy.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                for table in ("api_usage_daily","api_usage_purpose_daily"):
                    if table in tables:
                        conn.executemany(f"INSERT OR IGNORE INTO {table} VALUES (?,?,?,?)",
                                         legacy.execute(f"SELECT * FROM {table}").fetchall())
            conn.execute("INSERT OR IGNORE INTO runtime_meta VALUES ('migrated')")
            conn.commit()
        except Exception as error:
            conn.close()
            raise ApiQuotaUnavailable("Cannot initialize usage ledger; no request sent") from error
        finally:
            if legacy is not None:
                legacy.close()
    return conn


def _record_runtime_metric(day, metric, purpose, endpoint):
    try:
        conn = _runtime_connect()
        conn.execute("""
            INSERT INTO api_runtime_metric_daily VALUES (?,?,?,?,1)
            ON CONFLICT(usage_day,metric,purpose,endpoint)
            DO UPDATE SET count=count+1
        """, (day, str(metric), str(purpose), str(endpoint)))
        conn.commit()
        conn.close()
    except Exception:
        pass


def _reserve_api_request(day, purpose, path):
    """Atomically count BEFORE sending, including timed out/retried requests."""
    conn = None
    try:
        conn = _runtime_connect()
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT calls,provider_remaining FROM api_usage_daily WHERE usage_day=?",(day,)).fetchone()
        calls, remaining = (int(row[0]),row[1]) if row else (0,None)
        row = conn.execute("SELECT calls FROM api_usage_purpose_daily WHERE usage_day=? AND purpose=?",(day,purpose)).fetchone()
        used = int(row[0]) if row else 0
        reserve = 50 if purpose in {"live","scoring"} else API_LIVE_RESERVE
        if purpose == "world":
            reserve = max(reserve,API_WORLD_MIN_REMAINING)
        # Local preflight reservations include retries and interrupted workers.
        # They are a conservative fallback, but a fresh provider status is
        # authoritative when this local total reaches its soft wall.
        verified = conn.execute(
            "SELECT remaining,verified_at FROM api_provider_status_daily WHERE usage_day=?",
            (day,),
        ).fetchone()
        verified_remaining = None
        if verified and float(verified[1] or 0) >= time.time() - API_PROVIDER_STATUS_TTL_SECONDS:
            verified_remaining = int(verified[0] or 0)
        local_daily_brake = calls >= API_DAILY_TOTAL_LIMIT-reserve
        stored_remaining_brake = remaining is not None and int(remaining) <= reserve
        if local_daily_brake or stored_remaining_brake:
            if verified_remaining is None or verified_remaining <= reserve:
                raise ApiQuotaUnavailable("Daily reserve protected")
            conn.execute("""
                INSERT INTO api_runtime_metric_daily VALUES (?,?,?,?,1)
                ON CONFLICT(usage_day,metric,purpose,endpoint)
                DO UPDATE SET count=count+1
            """, (day, "daily_local_cap_reconciled", purpose, path))
        # Keep the short-lived verified provider snapshot conservative between
        # status refreshes too. A timeout therefore spends a local slot but can
        # never make the protected LIVE reserve appear larger than it is.
        if verified_remaining is not None:
            conn.execute(
                "UPDATE api_provider_status_daily SET remaining=MAX(0,remaining-1) "
                "WHERE usage_day=?",
                (day,),
            )
        if purpose == "world" and used >= API_WORLD_DAILY_LIMIT:
            # The purpose counter is a local preflight ledger.  It can become
            # stale after a failed worker/restart, so a fresh provider status
            # check with enough headroom is allowed to reconcile this one
            # internal brake.  The total cap and LIVE reserve above stay in
            # force for every actual request.
            provider_has_confirmed_headroom = (
                remaining is not None and int(remaining) > reserve
            )
            if not provider_has_confirmed_headroom:
                raise ApiQuotaUnavailable("World-football API safety budget reached")
            _record_runtime_metric(
                day, "world_local_cap_reconciled", purpose, path
            )
        conn.execute("""
            INSERT INTO api_usage_daily VALUES (?,1,NULL,CURRENT_TIMESTAMP)
            ON CONFLICT(usage_day) DO UPDATE SET calls=calls+1,
            provider_remaining=CASE WHEN provider_remaining IS NULL THEN NULL ELSE MAX(0,provider_remaining-1) END,
            updated_at=CURRENT_TIMESTAMP
        """,(day,))
        conn.execute("""
            INSERT INTO api_usage_purpose_daily VALUES (?,?,1,CURRENT_TIMESTAMP)
            ON CONFLICT(usage_day,purpose) DO UPDATE SET calls=calls+1,updated_at=CURRENT_TIMESTAMP
        """,(day,purpose))
        conn.execute("""
            INSERT INTO api_endpoint_daily VALUES (?,?,?,1)
            ON CONFLICT(usage_day,purpose,endpoint) DO UPDATE SET calls=calls+1
        """,(day,purpose,path))
        conn.commit()
    except ApiQuotaUnavailable:
        raise
    except Exception as error:
        raise ApiQuotaUnavailable("Usage ledger unavailable; no request sent") from error
    finally:
        if conn is not None:
            conn.close()


def _request_cache_ttl(path, params, payload=None):
    response_rows = payload.get("response") if isinstance(payload, dict) else None
    if path == "/status":
        return API_PROVIDER_STATUS_TTL_SECONDS
    # 팀/경기표의 정상 HTTP 빈 응답은 공급사 색인 지연일 수 있다. 하루 동안
    # 실패로 굳히지 않고 5분 뒤 영구 재시도 대기열이 다시 확인하게 한다.
    if path in {"/teams", "/fixtures"} and isinstance(response_rows, list) and not response_rows:
        return 300
    if path in {"/fixtures/statistics","/players/squads","/coachs","/teams"}:
        return 86400
    if path == "/standings" or (path == "/fixtures" and params.get("last")):
        return 21600
    if path == "/fixtures" and params.get("next"):
        return 3600
    return 240  # Scores/events/lineups/odds remain fresh within the 5-minute job.


def _claim_request_cache(key):
    conn = _runtime_connect()
    try:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT body,expires,lease FROM request_cache WHERE key=?",(key,)).fetchone()
        if row and row[0] is not None and row[1] > time.time():
            res = requests.Response()
            res.status_code, res._content, res.encoding = 200,row[0].encode("utf-8"),"utf-8"
            res.headers["X-DJ-Cache"] = "hit"
            return res
        if row and row[2] > time.time():
            raise ApiRateLimited("Identical request pending/cooling down; reuse saved data")
        conn.execute("INSERT INTO request_cache(key,lease) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET lease=excluded.lease",
                     (key,time.time()+300))
        conn.commit()
        return None
    finally:
        conn.close()


def _finish_request_cache(key, payload=None, ttl=0):
    conn = _runtime_connect()
    try:
        if payload is not None:
            conn.execute("UPDATE request_cache SET body=?,expires=?,lease=0 WHERE key=?",
                         (json.dumps(payload,ensure_ascii=False),time.time()+ttl,key))
        else:
            conn.execute("UPDATE request_cache SET lease=? WHERE key=?",(time.time()+60,key))
        conn.commit()
    finally:
        conn.close()


def _api_usage_today():
    day_key = _api_provider_day_key()
    try:
        conn = _runtime_connect()
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS api_usage_daily (
                usage_day TEXT PRIMARY KEY,
                calls INTEGER NOT NULL DEFAULT 0,
                provider_remaining INTEGER,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cursor.execute(
            "SELECT calls, provider_remaining FROM api_usage_daily WHERE usage_day = ?",
            (day_key,),
        )
        row = cursor.fetchone()
        conn.commit()
        conn.close()
        return day_key, int(row[0] or 0) if row else 0, (row[1] if row else None)
    except Exception:
        raise ApiQuotaUnavailable("Usage ledger unavailable; no request sent")


def _api_purpose_usage_today(day_key, purpose):
    try:
        conn = _runtime_connect()
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS api_usage_purpose_daily (
                usage_day TEXT NOT NULL,
                purpose TEXT NOT NULL,
                calls INTEGER NOT NULL DEFAULT 0,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (usage_day, purpose)
            )
        """)
        cursor.execute(
            "SELECT calls FROM api_usage_purpose_daily WHERE usage_day = ? AND purpose = ?",
            (day_key, str(purpose or "analysis")),
        )
        row = cursor.fetchone()
        conn.commit()
        conn.close()
        return int(row[0] or 0) if row else 0
    except Exception:
        raise ApiQuotaUnavailable("Purpose ledger unavailable; no request sent")


def _record_api_usage(day_key, provider_remaining=None, purpose="analysis"):
    # Preflight reservation already counted this request; only reconcile headers.
    if provider_remaining is None:
        return
    conn = _runtime_connect()
    try:
        conn.execute("""
            UPDATE api_usage_daily SET provider_remaining=
            CASE WHEN provider_remaining IS NULL THEN ? ELSE MIN(provider_remaining,?) END,
            updated_at=CURRENT_TIMESTAMP WHERE usage_day=?
        """,(provider_remaining,provider_remaining,day_key))
        conn.commit()
    finally:
        conn.close()


def _mark_api_quota_exhausted(day_key):
    """재시작 뒤에도 같은 날 소진된 API를 반복 호출하지 않게 기록한다."""
    try:
        conn = _runtime_connect()
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS api_usage_daily (
                usage_day TEXT PRIMARY KEY,
                calls INTEGER NOT NULL DEFAULT 0,
                provider_remaining INTEGER,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cursor.execute("""
            INSERT INTO api_usage_daily (usage_day, calls, provider_remaining, updated_at)
            VALUES (?, 0, 0, CURRENT_TIMESTAMP)
            ON CONFLICT(usage_day) DO UPDATE SET
                provider_remaining = 0,
                updated_at = CURRENT_TIMESTAMP
        """, (day_key,))
        conn.commit()
        conn.close()
    except Exception:
        pass


def _show_api_quota_notice(message):
    global _API_QUOTA_NOTICE_SHOWN
    if not _API_QUOTA_NOTICE_SHOWN:
        print(f"⚠️ API 한도 보호 모드: {message} (기존 캐시/베트맨 데이터로 계속 동작)")
        _API_QUOTA_NOTICE_SHOWN = True


@contextmanager
def api_cache_only_context(enabled=True):
    """Allow analysis workers to consume prefetched cache without new API calls.

    The team/prefetch worker owns external data collection. Pick-serving workers
    use this context so one slow or missing provider endpoint cannot hold every
    customer pick behind a long master cycle. Cached provider responses remain
    fully available; a cache miss returns a bounded synthetic miss response.
    """
    global _API_CACHE_ONLY
    previous = _API_CACHE_ONLY
    _API_CACHE_ONLY = bool(enabled)
    try:
        yield
    finally:
        _API_CACHE_ONLY = previous


def _cache_only_miss_response(path):
    response = requests.Response()
    response.status_code = 503
    response._content = json.dumps({
        "response": [],
        "errors": {"cache_only": f"prefetch cache miss: {path}"},
    }).encode("utf-8")
    response.encoding = "utf-8"
    response.headers["X-DJ-Cache"] = "miss-cache-only"
    return response


def _release_request_cache_lease(key):
    conn = None
    try:
        conn = _runtime_connect()
        conn.execute("UPDATE request_cache SET lease=0 WHERE key=?", (key,))
        conn.commit()
    except Exception:
        pass
    finally:
        if conn is not None:
            conn.close()


@contextmanager
def api_purpose_context(purpose):
    """Count nested helper requests under one isolated job purpose.

    Most data helpers are shared by PROTO and WORLD.  The world worker runs in
    its own process, so a short-lived process-local override lets those helpers
    keep their stable signatures while every real network request is charged
    to the WORLD safety budget.
    """
    global _API_PURPOSE_OVERRIDE
    previous = _API_PURPOSE_OVERRIDE
    _API_PURPOSE_OVERRIDE = str(purpose or "analysis").strip().lower()
    try:
        yield
    finally:
        _API_PURPOSE_OVERRIDE = previous


def api_get(path, params=None, timeout=7, purpose=None):
    """Shared cache, single-flight and persistent atomic daily protection."""
    global _API_PROVIDER_DAY, _API_PROVIDER_REMAINING, _API_QUOTA_NOTICE_SHOWN
    path = "/" + str(path).lstrip("/")
    params = params or {}
    purpose = str(purpose or _API_PURPOSE_OVERRIDE or "analysis").strip().lower()
    day = _api_provider_day_key()
    if _API_PROVIDER_DAY != day:
        _API_PROVIDER_DAY, _API_PROVIDER_REMAINING = day,None
        _API_QUOTA_NOTICE_SHOWN = False
    key = json.dumps([path,params],sort_keys=True,ensure_ascii=True)
    try:
        cached = _claim_request_cache(key)
    except ApiRateLimited:
        _record_runtime_metric(day, "singleflight_block", purpose, path)
        raise
    except Exception as error:
        raise ApiQuotaUnavailable("Cache/ledger unavailable; no request sent") from error
    if cached is not None:
        _record_runtime_metric(day, "cache_hit", purpose, path)
        return cached
    if _API_CACHE_ONLY:
        _release_request_cache_lease(key)
        _record_runtime_metric(day, "cache_only_miss", purpose, path)
        return _cache_only_miss_response(path)
    saved = False
    try:
        for attempt in range(API_RATE_LIMIT_RETRIES+1):
            try:
                _reserve_api_request(day,purpose,path)
            except ApiQuotaUnavailable as error:
                # A local total can be inflated by interrupted/retried workers.
                # Verify once against the provider before keeping this safety
                # brake; failure still leaves the request blocked.
                if str(error) != "Daily reserve protected":
                    raise
                verified = refresh_provider_usage_status()
                if verified is None:
                    raise
                _reserve_api_request(day,purpose,path)
            _pace_api_request()
            response = requests.get(f"https://{API_HOST}{path}",headers=headers,params=params,timeout=timeout)
            error_text = _response_error_text(response)
            remaining = _header_int(response,"x-ratelimit-requests-remaining")
            if remaining is not None:
                _API_PROVIDER_REMAINING = remaining
            _record_api_usage(day,remaining,purpose=purpose)
            if _is_daily_quota_response(response,error_text):
                _mark_api_quota_exhausted(day)
                _show_api_quota_notice("공급사 일일 사용량 소진")
                return response
            if response.status_code == 429 or "rate limit" in error_text:
                _record_runtime_metric(day, "rate_retry", purpose, path)
                if attempt >= API_RATE_LIMIT_RETRIES:
                    raise ApiRateLimited("Temporary provider rate limit")
                time.sleep(min(10*(attempt+1),30))
                continue
            payload = response.json()
            if response.status_code == 200 and not payload.get("errors"):
                _finish_request_cache(
                    key, payload, _request_cache_ttl(path, params, payload)
                )
                saved = True
            return response
    except ApiQuotaUnavailable:
        _show_api_quota_notice("라이브·채점 예산 보호 또는 사용량 기록 확인 필요")
        raise
    finally:
        if not saved:
            _finish_request_cache(key)


def refresh_provider_usage_status():
    """Read the provider's own daily usage before lifting a stale local brake.

    This deliberately bypasses the local request preflight because this method
    is called precisely when that preflight has become suspect. It requests
    only the provider status endpoint, caches the verified answer briefly in
    the runtime ledger, and never resets local counters or changes picks.
    """
    global _API_PROVIDER_DAY, _API_PROVIDER_REMAINING
    day = _api_provider_day_key()
    try:
        conn = _runtime_connect()
        try:
            row = conn.execute(
                "SELECT current_calls,limit_day,remaining,verified_at "
                "FROM api_provider_status_daily WHERE usage_day=?",
                (day,),
            ).fetchone()
        finally:
            conn.close()
        if row and float(row[3] or 0) >= time.time() - API_PROVIDER_STATUS_TTL_SECONDS:
            current, limit, remaining = row[:3]
            _API_PROVIDER_DAY, _API_PROVIDER_REMAINING = day, int(remaining)
            return {
                "current": int(current) if current is not None else None,
                "limit_day": int(limit) if limit is not None else None,
                "remaining": int(remaining),
            }
        if not API_KEY:
            return None
        _pace_api_request()
        response = requests.get(
            f"https://{API_HOST}/status", headers=headers, timeout=10
        )
        payload = response.json() if response.status_code == 200 else {}
        status = payload.get("response") if isinstance(payload, dict) else None
        if isinstance(status, list):
            status = status[0] if status else {}
        status = status if isinstance(status, dict) else {}
        requests_info = status.get("requests") or {}
        if not isinstance(requests_info, dict):
            return None
        current = requests_info.get("current")
        limit = requests_info.get("limit_day")
        remaining = requests_info.get("remaining")
        try:
            if remaining is None:
                remaining = int(limit) - int(current)
            remaining = max(0, int(remaining))
            current = int(current) if current is not None else None
            limit = int(limit) if limit is not None else None
        except (TypeError, ValueError):
            return None
        conn = _runtime_connect()
        try:
            conn.execute("""
                INSERT INTO api_provider_status_daily
                    (usage_day,current_calls,limit_day,remaining,verified_at)
                VALUES (?,?,?,?,?)
                ON CONFLICT(usage_day) DO UPDATE SET
                    current_calls=excluded.current_calls,
                    limit_day=excluded.limit_day,
                    remaining=excluded.remaining,
                    verified_at=excluded.verified_at
            """, (day, current, limit, remaining, time.time()))
            conn.execute(
                "INSERT INTO api_usage_daily (usage_day,calls,provider_remaining,updated_at) "
                "VALUES (?,0,?,CURRENT_TIMESTAMP) "
                "ON CONFLICT(usage_day) DO UPDATE SET "
                "provider_remaining=excluded.provider_remaining,updated_at=CURRENT_TIMESTAMP",
                (day, remaining),
            )
            conn.commit()
        finally:
            conn.close()
        _API_PROVIDER_DAY, _API_PROVIDER_REMAINING = day, remaining
        _record_runtime_metric(day, "provider_status_direct_verified", "system", "/status")
        return {"current": current, "limit_day": limit, "remaining": remaining}
    except Exception:
        return None


def get_api_usage_status():
    """수집기와 관리자 화면에 노출할 안전한 API 사용 현황."""
    day_key, local_calls, stored_remaining = _api_usage_today()
    remaining = stored_remaining
    if _API_PROVIDER_DAY == day_key and _API_PROVIDER_REMAINING is not None:
        remaining = min(stored_remaining, _API_PROVIDER_REMAINING) if stored_remaining is not None else _API_PROVIDER_REMAINING
    analysis_calls = _api_purpose_usage_today(day_key, "analysis")
    live_calls = _api_purpose_usage_today(day_key, "live")
    scoring_calls = _api_purpose_usage_today(day_key, "scoring")
    world_calls = _api_purpose_usage_today(day_key, "world")
    conn = _runtime_connect()
    try:
        endpoints = [
            {"purpose":r[0],"endpoint":r[1],"calls":r[2]}
            for r in conn.execute("SELECT purpose,endpoint,calls FROM api_endpoint_daily WHERE usage_day=? ORDER BY calls DESC LIMIT 12",(day_key,))
        ]
        runtime_metrics = [
            {"metric": r[0], "purpose": r[1], "endpoint": r[2], "count": r[3]}
            for r in conn.execute(
                "SELECT metric,purpose,endpoint,count FROM api_runtime_metric_daily "
                "WHERE usage_day=? ORDER BY count DESC LIMIT 20", (day_key,)
            )
        ]
    finally:
        conn.close()
    return {
        "top_endpoints": endpoints,
        "runtime_metrics": runtime_metrics,
        "accounting": "local-preflight-reservation-v2",
        "usage_day": day_key.removeprefix("utc:"),
        "reset_timezone": "UTC",
        "local_calls": int(local_calls or 0),
        "provider_remaining": remaining,
        "analysis_soft_limit": API_ANALYSIS_SOFT_LIMIT,
        "daily_limit": API_DAILY_TOTAL_LIMIT,
        "live_reserve": API_LIVE_RESERVE,
        "world_calls": int(world_calls or 0),
        "analysis_calls": int(analysis_calls or 0),
        "live_calls": int(live_calls or 0),
        "scoring_calls": int(scoring_calls or 0),
        "world_daily_limit": API_WORLD_DAILY_LIMIT,
        "world_min_remaining": API_WORLD_MIN_REMAINING,
        "quota_exhausted": remaining is not None and int(remaining) <= 0,
    }

# 득점/도움 순위만으로는 골키퍼ㆍ수비수ㆍ갑작스러운 로테이션을 놓칠 수 있다.
# 팀을 고정하지 않고 선수 이름만 관리한 뒤, 실제 부상 명단/소속 스쿼드에
# 등장할 때만 사용한다. 이 목록은 config.py에서도 쉽게 추가할 수 있다.
PROTECTED_STAR_PLAYERS = [
    {"name": "Son Heung-min", "aliases": ["Heung Min Son", "Heung-min Son", "손흥민"], "impact": 1.25},
    {"name": "Erling Haaland", "aliases": ["E. Haaland"], "impact": 1.25},
    {"name": "Kylian Mbappe", "aliases": ["Kylian Mbappé", "K. Mbappe"], "impact": 1.25},
    {"name": "Mohamed Salah", "aliases": ["M. Salah"], "impact": 1.20},
    {"name": "Harry Kane", "aliases": ["H. Kane"], "impact": 1.20},
    {"name": "Vinicius Junior", "aliases": ["Vinícius Júnior", "Vini Jr"], "impact": 1.15},
    {"name": "Jude Bellingham", "aliases": ["J. Bellingham"], "impact": 1.15},
    {"name": "Kevin De Bruyne", "aliases": ["K. De Bruyne"], "impact": 1.15},
    {"name": "Rodri", "aliases": ["Rodrigo Hernandez", "Rodrigo Hernández"], "impact": 1.15},
    {"name": "Bukayo Saka", "aliases": ["B. Saka"], "impact": 1.10},
    {"name": "Bruno Fernandes", "aliases": ["B. Fernandes"], "impact": 1.10},
    {"name": "Lautaro Martinez", "aliases": ["Lautaro Martínez", "L. Martinez"], "impact": 1.10},
    {"name": "Robert Lewandowski", "aliases": ["R. Lewandowski"], "impact": 1.10},
    {"name": "Victor Osimhen", "aliases": ["V. Osimhen"], "impact": 1.10},
    {"name": "Cole Palmer", "aliases": ["C. Palmer"], "impact": 1.10},
]


def _normalize_player_name(value):
    return re.sub(r"[^0-9a-z가-힣]+", "", str(value or "").casefold())


def find_protected_star(player_name):
    target = _normalize_player_name(player_name)
    if not target:
        return None
    for star in PROTECTED_STAR_PLAYERS:
        names = [star.get("name", "")] + list(star.get("aliases", []))
        for name in names:
            candidate = _normalize_player_name(name)
            if candidate and (target == candidate or (len(target) >= 6 and (target in candidate or candidate in target))):
                return star
    return None

# API-Football이 실제 엠블럼 대신 '이미지 없음' 그림을 주는 국내 구단은
# K리그 공식 엠블럼을 우선 사용한다. 팀 ID는 그대로 유지하므로 전적 조회에는
# 영향을 주지 않고 화면의 로고만 정확하게 교체된다.
OFFICIAL_TEAM_LOGOS = {
    "김포": "https://www.kleague.com/assets/images/emblem/emblem_K36%403x.png",
    "김포FC": "https://www.kleague.com/assets/images/emblem/emblem_K36%403x.png",
    "Gimpo": "https://www.kleague.com/assets/images/emblem/emblem_K36%403x.png",
    "Gimpo FC": "https://www.kleague.com/assets/images/emblem/emblem_K36%403x.png",
    "충북청주": "https://www.kleague.com/assets/images/emblem/emblem_K37%403x.png",
    "충북청주FC": "https://www.kleague.com/assets/images/emblem/emblem_K37%403x.png",
    "충북청주 프로축구단": "https://www.kleague.com/assets/images/emblem/emblem_K37%403x.png",
    "Chungbuk Cheongju": "https://www.kleague.com/assets/images/emblem/emblem_K37%403x.png",
    "화성": "https://www.kleague.com/assets/images/emblem/emblem_K39%403x.png",
    "화성FC": "https://www.kleague.com/assets/images/emblem/emblem_K39%403x.png",
    "Hwaseong": "https://www.kleague.com/assets/images/emblem/emblem_K39%403x.png",
    "Hwaseong FC": "https://www.kleague.com/assets/images/emblem/emblem_K39%403x.png",
}

OFFICIAL_TEAM_LOGOS_BY_ID = {
    10453: "https://www.kleague.com/assets/images/emblem/emblem_K36%403x.png",
    10452: "https://www.kleague.com/assets/images/emblem/emblem_K37%403x.png",
}

TEAM_NAME_MAP = {
    "광주FC": "Gwangju FC", "포항스틸": "Pohang Steelers", "포항 스틸러스": "Pohang Steelers", "제주SKFC": "Jeju United", "제주 SKFC": "Jeju United", 
    "FC안양": "FC Anyang", "FC 안양": "FC Anyang", "FC서울": "FC Seoul", "대전하나": "Daejeon Citizen", "대전 하나시티즌": "Daejeon Citizen", 
    "충북청주": "Chungbuk Cheongju", "충북청주 프로축구단": "Chungbuk Cheongju", "전남드래": "Jeonnam Dragons", "전남 드래곤즈": "Jeonnam Dragons",
    "김해FC": "Gimhae", "김해FC 2008": "Gimhae", "경남FC": "Gyeongnam FC", "수원삼성": "Suwon Samsung", "수원 삼성블루윙즈": "Suwon Samsung", "수원FC": "Suwon FC",
    "부산아이": "Busan I Park", "부산 아이파크": "Busan I Park", "화성FC": "Hwaseong", "인천유나": "Incheon United", "인천 유나이티드": "Incheon United",
    "김천상무": "Gimcheon Sangmu", "김천상무 프로축구단": "Gimcheon Sangmu", "부천FC": "Bucheon FC 1995", "부천FC 1995": "Bucheon FC 1995", 
    "전북현대": "Jeonbuk Motors", "전북 현대모터스": "Jeonbuk Motors", "울산HDFC": "Ulsan Hyundai", "울산 HDFC": "Ulsan Hyundai", "강원FC": "Gangwon FC",
    "서울이랜드": "Seoul E-Land", "서울 이랜드": "Seoul E-Land", "안산그리": "Ansan Greeners", "안산 그리너스": "Ansan Greeners", "대구FC": "Daegu FC", 
    "충남아산": "Chungnam Asan", "충남아산 프로축구단": "Chungnam Asan", "김포FC": "Gimpo FC", "천안시티": "Cheonan City", "천안 시티FC": "Cheonan City", 
    "파주프런": "Paju Citizen", "파주 프런티어": "Paju Citizen", "성남FC": "Seongnam FC", "용인FC": "Yongin",
    "맨체스C": "Manchester City", "맨체스터 시티": "Manchester City", "리버풀": "Liverpool", "뉴캐슬U": "Newcastle", "뉴캐슬 유나이티드": "Newcastle",
    "본머스": "Bournemouth", "AFC본머스": "Bournemouth", "브라이턴": "Brighton", "브라이턴&호브 앨비언": "Brighton", "A빌라": "Aston Villa", "애스턴 빌라": "Aston Villa",
    "노팅엄F": "Nottingham Forest", "노팅엄 포리스트": "Nottingham Forest", "리즈U": "Leeds", "리즈 유나이티드": "Leeds", "에버턴": "Everton",
    "크리스털": "Crystal Palace", "크리스털 팰리스": "Crystal Palace", "입스위치": "Ipswich", "입스위치 타운": "Ipswich", "선덜랜드": "Sunderland",
    "브렌트퍼": "Brentford", "브렌트퍼드": "Brentford", "토트넘": "Tottenham", "토트넘 홋스퍼": "Tottenham", "아스널": "Arsenal",
    "맨유": "Manchester United", "맨체스U": "Manchester United", "맨체스터 유나이티드": "Manchester United", "웨스트햄 유나이티드": "West Ham", "웨스트브로미치 앨비언": "West Brom", "번리": "Burnley",
    "코번트리": "Coventry", "코번트리 시티": "Coventry", "버밍엄 시티": "Birmingham", "브리스틀 시티": "Bristol City", "링컨 시티": "Lincoln", "포츠머스": "Portsmouth",
    "밀월": "Millwall", "노리치 시티": "Norwich City", "헐시티": "Hull City", "헐 시티": "Hull City", "블랙번 로버스": "Blackburn", "미들즈브러": "Middlesbrough",
    "더비 카운티": "Derby", "카디프 시티": "Cardiff City", "프레스턴 노스엔드": "Preston", "울버햄튼 원더러스": "Wolves", "울버햄튼": "Wolves",
    "퀸즈파크 레인저스": "QPR", "볼턴 원더러스": "Bolton", "사우샘프턴": "Southampton", "스토크 시티": "Stoke City", "스완지 시티": "Swansea",
    "셰필드 유나이티드": "Sheffield Utd", "찰턴 애슬레틱": "Charlton", "렉섬": "Wrexham", "왓포드": "Watford", "풀럼": "Fulham", "첼시": "Chelsea",
    "프로시노": "Frosinone", "프로시노네": "Frosinone", "유벤투스": "Juventus", "베네치아": "Venezia", "US레체": "Lecce",
    "아탈란타": "Atalanta", "아탈란타BC": "Atalanta", "사수올로": "Sassuolo", "US사수올로": "Sassuolo", "토리노": "Torino", "AC밀란": "AC Milan",
    "제노아": "Genoa", "나폴리": "Napoli", "SSC나폴리": "Napoli", "파르마": "Parma", "칼리아리": "Cagliari", "인테르나치오날레 밀라노": "Inter",
    "인테르": "Inter", "AC몬차": "Monza", "우디네세": "Udinese", "코모1907": "Como", "볼로냐": "Bologna", "라치오": "Lazio", "SS라치오": "Lazio", "AS로마": "Roma", "피오렌티": "Fiorentina", "ACF피오렌티나": "Fiorentina",
    "레알 마드리드": "Real Madrid", "바르셀로나": "Barcelona", "아틀레티코 마드리드": "Atletico Madrid", "비야레알": "Villarreal",
    "레알 베티스": "Real Betis", "레알 소시에다드": "Real Sociedad", "발렌시아": "Valencia", "RC셀타데비고": "Celta Vigo", 
    "RCD에스파뇰": "Espanyol", "헤타페": "Getafe", "라싱 산탄데르": "Racing Santander", "엘체": "Elche", "오사수나": "Osasuna", "레반테": "Levante", "말라가": "Malaga", "데포르티보 아코루냐": "Deportivo La Coruna",
    "파리 생제르맹": "Paris Saint Germain", "AS모나코": "Monaco", "올랭피크드 마르세유": "Marseille", "올랭피크 리옹": "Lyon",
    "RC스트라스부르": "Strasbourg", "RC랑스": "Lens", "AJ오세르": "Auxerre", "르망FC": "Le Mans", "스타드 브레스투아29": "Brest",
    "OGC니스": "Nice", "로리앙": "Lorient", "툴루즈": "Toulouse", "트루아AC": "Troyes", "파리FC": "Paris FC", "스타드 렌": "Rennes",
    "르아브르AC": "Le Havre", "앙제SCO": "Angers", "릴OSC": "Lille",
    "도르트문트": "Borussia Dortmund", "함부르크": "Hamburger SV", "바이에른 뮌헨": "Bayern Munich",
    "RB라이프치히": "RB Leipzig", "묀헨글라트바흐": "Borussia Monchengladbach", "FSV마인츠05": "FSV Mainz 05",
    "파더보른07": "SC Paderborn 07", "프랑크푸르트": "Eintracht Frankfurt",
    "포르튀나 시타르트": "Fortuna Sittard", "AZ알크마르": "AZ Alkmaar", "스파르타 로테르담": "Sparta Rotterdam", "위트레흐트": "Utrecht",
    "엑셀시오르 로테르담": "Excelsior", "엑셀시오르": "Excelsior",
    "SC헤이렌베인": "Heerenveen", "PEC즈볼러": "PEC Zwolle", "고어헤드 이글스": "Go Ahead Eagles", "ADO덴하흐": "ADO Den Haag",
    "PSV에인트호번": "PSV Eindhoven", "흐로닝언": "Groningen", "SC캄뷔르": "Cambuur", "페예노르트": "Feyenoord",
    "가시와 레이솔": "Kashiwa Reysol", "V바렌 나가사키": "V-Varen Nagasaki", "FC도쿄": "FC Tokyo", "제프 유나이티드": "JEF United Chiba",
    "가시마 앤틀러스": "Kashima Antlers", "아비스파 후쿠오카": "Avispa Fukuoka", "파지아노 오카야마": "Fagiano Okayama", "도쿄 베르디": "Tokyo Verdy",
    "나고야 그램퍼스": "Nagoya Grampus", "감바 오사카": "Gamba Osaka", "교토 상가FC": "Kyoto Sanga", "미토 홀리호크": "Mito Hollyhock",
    "세레소 오사카": "Cerezo Osaka", "시미즈 에스펄스": "Shimizu S-Pulse", "산프레체 히로시마": "Sanfrecce Hiroshima", "가와사키 프론탈레": "Kawasaki Frontale",
    "요코하마 F마리노스": "Yokohama F. Marinos", "비셀 고베": "Vissel Kobe", "FC마치다 젤비아": "Machida Zelvia", "우라와 레드": "Urawa Red Diamonds",
    "콘사도레 삿포로": "Consadole Sapporo", "RB오미야 아르디자": "Omiya Ardija", "오미야 아르디자": "Omiya Ardija",
    "반라우레 하치노헤FC": "Vanraure Hachinohe", "반라우레 하치노헤": "Vanraure Hachinohe", "베갈타 센다이": "Vegalta Sendai", 
    "블라우블리츠 아키타": "Blaublitz Akita", "반포레 고후": "Ventforet", "카탈레 도야마": "Kataller", 
    "FC이마바리": "Imabari", "이마바리": "Imabari", "몬테디오 야마가타": "Montedio Yamagata", "요코하마FC": "Yokohama FC", 
    "알비렉스 니가타": "Albirex Niigata", "후지에다 MYFC": "Fujieda", "주빌로 이와타": "Jubilo Iwata", 
    "도쿠시마 보르티스": "Tokushima Vortis", "사간 도스": "Sagan Tosu", "도치기 시티FC": "Tochigi", "도치기": "Tochigi",
    "오이타 트리니타": "Oita Trinita", "이와키FC": "Iwaki", "이와키": "Iwaki", "테게바자로 미야자키": "Tegevajaro", 
    "쇼난 벨마레": "Shonan Bellmare",
    "태국": "Thailand", "베트남": "Vietnam",
    "샬럿FC": "Charlotte", "DC유나이티드": "DC United", "FC신시내티": "FC Cincinnati", "시애틀 사운더스FC": "Seattle Sounders",
    "인터 마이애미CF": "Inter Miami", "토론토FC": "Toronto FC", "CF몽레알": "Montreal Impact", "LA 갤럭시": "LA Galaxy",
    "뉴욕 레드불스": "New York Red Bulls", "시카고 파이어FC": "Chicago Fire", "올랜도 시티SC": "Orlando City", "레알 솔트레이크": "Real Salt Lake",
    "오스틴FC": "Austin", "필라델피아 유니언": "Philadelphia Union", "내슈빌SC": "Nashville SC", "콜럼버스 크루": "Columbus Crew",
    "세인트루이스 시티SC": "St. Louis City", "휴스턴 다이너모FC": "Houston Dynamo", "밴쿠버 화이트캡스FC": "Vancouver Whitecaps", "FC댈러스": "FC Dallas",
    "LAFC": "Los Angeles FC", "포틀랜드 팀버스": "Portland Timbers", "샌디에이고FC": "San Diego", "콜로라도 래피즈": "Colorado Rapids",
    "새너제이 어스퀘이크스": "San Jose Earthquakes", "미네소타 유나이티드FC": "Minnesota United", "뉴잉글랜드 레벌루션": "New England Revolution",
    "뉴욕 시티FC": "New York City FC", "애틀랜타 유나이티드FC": "Atlanta United", "스포팅 캔자스시티": "Sporting Kansas City",
    "풀루미넨시": "Fluminense", "플루미넨시": "Fluminense", "CA플라텐세": "Platense", "CA 플라텐세": "Platense", "플라텐세": "Platense",
    "시드니FC": "Sydney FC", "시드니 FC": "Sydney FC", "멜버른빅토리": "Melbourne Victory", "멜버른 빅토리": "Melbourne Victory",
    "AEK아테": "AEK Athens", "L소피아": "Lokomotiv Sofia", "비킹FK": "Viking FK", "D자그레": "Dinamo Zagreb",
    "NK첼레": "NK Celje", "슬로반브": "Slovan Bratislava", "리옹": "Lyon", "페네르SK": "Fenerbahce",
    "이베리아": "Iberia 1999", "야기엘로": "Jagiellonia Bialystok", "오모니아": "Omonia Nicosia", "신트트라": "Sint-Truiden",
    "플젠": "Viktoria Plzen", "츠르베나": "Crvena Zvezda", "릴레스트": "Lillestrom", "에그나티": "Egnatia",
    "잘츠부르": "Red Bull Salzburg", "미엘뷔": "Mjallby", "카우노잘": "Kauno Zalgiris", "베식타시": "Besiktas",
    "FC툰": "FC Thun", "L포즈난": "Lech Poznan", "C소피아": "CSKA Sofia", "OFI크레": "OFI Crete",
    "페렌츠바": "Ferencvaros", "트라브존": "Trabzonspor", "안더레흐": "Anderlecht", "카이라트": "Kairat Almaty",
    "LASK": "LASK Linz", "셀틱": "Celtic"
}

MANUAL_TEAM_MAP = {
    "아라라트 아르메니아": "Ararat-Armenia", "우니베르시타테아 크라이오바": "Universitatea Craiova",
    "이베리아1999 트빌리시": "Iberia 1999", "야기엘로니아 비아위스토크": "Jagiellonia",
    "카우노 잘기리스": "Kauno Zalgiris", "레흐 포즈난": "Lech Poznan",
    "SK슬로반 브라티슬라바": "Slovan Bratislava", "레프스키 소피아": "Levski Sofia",
    "GNK디나모 자그레브": "Dinamo Zagreb", "신트 트라위던VV": "Sint-Truiden",
    "RSC안더레흐트": "Anderlecht", "비킹FK": "Viking", "OFI크레타": "OFI Crete",
    "페렌츠바로시TC": "Ferencvarosi", "트라브존스포르": "Trabzonspor",
    "카이라트 알마티": "Kairat", "미엘뷔AIF": "Mjallby", "KF에그나티아": "Egnatia",
    "AC오모니아": "Omonia", "빅토리아 플젠": "Viktoria Plzen",
    "FK츠르베나 즈베즈다": "Crvena Zvezda", "릴레스트룀SK": "Lillestrom",
    "NK첼레": "Celje", "AEK아테네": "AEK Athens", "CSKA소피아": "CSKA Sofia",
    "AGF오르후스": "Aarhus", "SL벤피카": "Benfica", "FC툰": "Thun",
    "RC셀타데비고": "Celta Vigo", "오사수나": "Osasuna", "바르셀로나": "Barcelona",
    "아틀레틱 빌바오": "Athletic Club", "레알 마드리드": "Real Madrid",
    "아틀레티코 마드리드": "Atletico Madrid", "세비야FC": "Sevilla",
    "발렌시아CF": "Valencia", "레알 소시에다드": "Real Sociedad",
    "레알 베티스": "Real Betis", "비야레알CF": "Villarreal",
    "클루브 아메리카": "Club America", "콜럼버스 크루": "Columbus Crew",
    "인터 마이애미": "Inter Miami", "맨체스터 시티": "Manchester City",
    "맨체스터 유나이티드": "Manchester United", "토트넘 홋스퍼": "Tottenham",
    "노팅엄 포레스트": "Nottingham Forest", "울버햄튼": "Wolverhampton",
    "인터 밀란": "Inter", "AC밀란": "AC Milan", "유벤투스": "Juventus",
    "파리 생제르맹": "Paris Saint Germain", "울산 HD": "Ulsan Hyundai",
    "전북 현대": "Jeonbuk Motors", "FC서울": "FC Seoul", "포항 스틸러스": "Pohang Steelers"
}

# 기획자님이 주셨던 100% 원본 딕셔너리에 + 캡처로 주신 팀만 안전하게 추가!
DIRECT_TEAM_INFO = {
    "제주 SKFC": {"id": 2977, "logo": "https://media.api-sports.io/football/teams/2977.png"},
    "제주": {"id": 2977, "logo": "https://media.api-sports.io/football/teams/2977.png"},
    "제주 유나이티드": {"id": 2977, "logo": "https://media.api-sports.io/football/teams/2977.png"},
    "울산 HDFC": {"id": 2975, "logo": "https://media.api-sports.io/football/teams/2975.png"},
    "울산HD": {"id": 2975, "logo": "https://media.api-sports.io/football/teams/2975.png"},
    "김천상무": {"id": 2978, "logo": "https://media.api-sports.io/football/teams/2978.png"},
    "김천상무 프로축구단": {"id": 2978, "logo": "https://media.api-sports.io/football/teams/2978.png"},
    "강원FC": {"id": 2972, "logo": "https://media.api-sports.io/football/teams/2972.png"},
    "포항스틸": {"id": 2974, "logo": "https://media.api-sports.io/football/teams/2974.png"},
    "포항 스틸러스": {"id": 2974, "logo": "https://media.api-sports.io/football/teams/2974.png"},
    "FC서울": {"id": 2766, "logo": "https://media.api-sports.io/football/teams/2766.png"},
    "FC 서울": {"id": 2766, "logo": "https://media.api-sports.io/football/teams/2766.png"},
    "서울FC": {"id": 2766, "logo": "https://media.api-sports.io/football/teams/2766.png"},
    "수원FC": {"id": 2980, "logo": "https://media.api-sports.io/football/teams/2980.png"},
    "광주FC": {"id": 2983, "logo": "https://media.api-sports.io/football/teams/2983.png"},
    "인천유나": {"id": 2973, "logo": "https://media.api-sports.io/football/teams/2973.png"},
    "인천 유나이티드": {"id": 2973, "logo": "https://media.api-sports.io/football/teams/2973.png"},
    "전북현대": {"id": 2971, "logo": "https://media.api-sports.io/football/teams/2971.png"},
    "전북 현대모터스": {"id": 2971, "logo": "https://media.api-sports.io/football/teams/2971.png"},
    "대전하나": {"id": 2985, "logo": "https://media.api-sports.io/football/teams/2985.png"},
    "대전 하나시티즌": {"id": 2985, "logo": "https://media.api-sports.io/football/teams/2985.png"},
    "FC안양": {"id": 2986, "logo": "https://media.api-sports.io/football/teams/2986.png"},
    "FC 안양": {"id": 2986, "logo": "https://media.api-sports.io/football/teams/2986.png"},
    "전남드래": {"id": 2988, "logo": "https://media.api-sports.io/football/teams/2988.png"},
    "전남 드래곤즈": {"id": 2988, "logo": "https://media.api-sports.io/football/teams/2988.png"},
    "서울이랜드": {"id": 2987, "logo": "https://media.api-sports.io/football/teams/2987.png"},
    "서울 이랜드": {"id": 2987, "logo": "https://media.api-sports.io/football/teams/2987.png"},
    "수원삼성": {"id": 2976, "logo": "https://media.api-sports.io/football/teams/2976.png"},
    "수원 삼성블루윙즈": {"id": 2976, "logo": "https://media.api-sports.io/football/teams/2976.png"},
    "부산아이": {"id": 2990, "logo": "https://media.api-sports.io/football/teams/2990.png"},
    "부산 아이파크": {"id": 2990, "logo": "https://media.api-sports.io/football/teams/2990.png"},
    "부천FC": {"id": 2984, "logo": "https://media.api-sports.io/football/teams/2984.png"},
    "부천FC 1995": {"id": 2984, "logo": "https://media.api-sports.io/football/teams/2984.png"},
    "김포FC": {"id": 10453, "logo": "https://media.api-sports.io/football/teams/10453.png"},
    "충남아산": {"id": 3155, "logo": "https://media.api-sports.io/football/teams/3155.png"},
    "충남아산 프로축구단": {"id": 3155, "logo": "https://media.api-sports.io/football/teams/3155.png"},
    "충북청주": {"id": 10452, "logo": "https://media.api-sports.io/football/teams/10452.png"},
    "충북청주 프로축구단": {"id": 10452, "logo": "https://media.api-sports.io/football/teams/10452.png"},
    "안산그리": {"id": 2989, "logo": "https://media.api-sports.io/football/teams/2989.png"},
    "안산 그리너스": {"id": 2989, "logo": "https://media.api-sports.io/football/teams/2989.png"},
    "경남FC": {"id": 2981, "logo": "https://media.api-sports.io/football/teams/2981.png"},
    "천안시티": {"id": 3410, "logo": "https://media.api-sports.io/football/teams/3410.png"},
    "천안 시티FC": {"id": 3410, "logo": "https://media.api-sports.io/football/teams/3410.png"},
    "베트남": {"id": 24, "logo": "https://media.api-sports.io/football/teams/24.png"},
    "태국": {"id": 25, "logo": "https://media.api-sports.io/football/teams/25.png"},
    "프레스턴 라이온스": {"id": 15001, "logo": DEFAULT_LOGO},
    "사우스 멜버른": {"id": 6542, "logo": "https://media.api-sports.io/football/teams/6542.png"},
    "인디펜디엔테 델바예": {"id": 1133, "logo": "https://media.api-sports.io/football/teams/1133.png"},
    "데포르테스 톨리마": {"id": 1184, "logo": "https://media.api-sports.io/football/teams/1184.png"},
    "발렌시아": {"id": 532, "logo": "https://media.api-sports.io/football/teams/532.png"},
    "레알 베티스": {"id": 543, "logo": "https://media.api-sports.io/football/teams/543.png"},
    "버밍엄 시티": {"id": 33, "logo": "https://media.api-sports.io/football/teams/33.png"},
    "브렌트퍼드": {"id": 55, "logo": "https://media.api-sports.io/football/teams/55.png"},
    "노팅엄 포리스트": {"id": 65, "logo": "https://media.api-sports.io/football/teams/65.png"},
    "리즈 유나이티드": {"id": 63, "logo": "https://media.api-sports.io/football/teams/63.png"},
    "LASK": {"id": 649, "logo": "https://media.api-sports.io/football/teams/649.png"},
    "셀틱": {"id": 247, "logo": "https://media.api-sports.io/football/teams/247.png"},
    "FK보되 글림트": {"id": 353, "logo": "https://media.api-sports.io/football/teams/353.png"},
    "NEC네이메헌": {"id": 417, "logo": "https://media.api-sports.io/football/teams/417.png"},
    "블랙번 로버스": {"id": 43, "logo": "https://media.api-sports.io/football/teams/43.png"},
    "셰필드 유나이티드": {"id": 62, "logo": "https://media.api-sports.io/football/teams/62.png"},
    "사우샘프턴": {"id": 41, "logo": "https://media.api-sports.io/football/teams/41.png"},
    "웨스트햄 유나이티드": {"id": 48, "logo": "https://media.api-sports.io/football/teams/48.png"},
    "스토크 시티": {"id": 68, "logo": "https://media.api-sports.io/football/teams/68.png"},
    "헐 시티": {"id": 66, "logo": "https://media.api-sports.io/football/teams/66.png"},
    "CF몬테레이": {"id": 2284, "logo": "https://media.api-sports.io/football/teams/2284.png"},
    "클루브 레온": {"id": 2288, "logo": "https://media.api-sports.io/football/teams/2288.png"},
    "마카비 하이파": {"id": 4440, "logo": "https://media.api-sports.io/football/teams/4440.png"},
    "시카고 파이어FC": {"id": 254, "logo": "https://media.api-sports.io/football/teams/254.png"},
    "레알 솔트레이크": {"id": 257, "logo": "https://media.api-sports.io/football/teams/257.png"},
    "사바FK": {"id": 20456, "logo": "https://media.api-sports.io/football/teams/20456.png"},
    "하포엘 베르셰바": {"id": 4443, "logo": "https://media.api-sports.io/football/teams/4443.png"},
    "야기엘로": {"id": 336, "logo": "https://media.api-sports.io/football/teams/336.png"},
    "신트트라": {"id": 738, "logo": "https://media.api-sports.io/football/teams/738.png"},
    "퀸즐랜드 라이온스": {"id": 6516, "logo": "https://media.api-sports.io/football/teams/6516.png"},
    "아라라트 아르메니아": {"id": 5934, "logo": "https://tmssl.akamaized.net/images/wappen/head/53453.png"},
    "신트 트라위던vv": {"id": 738, "logo": "https://media.api-sports.io/football/teams/738.png"},
    "잘츠부르크": {"id": 571, "logo": "https://media.api-sports.io/football/teams/571.png"},
    "OFI크레타": {"id": 249, "logo": "https://media.api-sports.io/football/teams/249.png"},
    "데포르티보 톨루카": {"id": 2282, "logo": "https://media.api-sports.io/football/teams/2282.png"},
    "신트 트라위던VV": {"id": 738, "logo": "https://media.api-sports.io/football/teams/738.png"},
    "FC툰": {"id": 1012, "logo": "https://media.api-sports.io/football/teams/1012.png"},
    "FC 툰": {"id": 1012, "logo": "https://media.api-sports.io/football/teams/1012.png"},
    "미들즈브러": {"id": 61, "logo": "https://media.api-sports.io/football/teams/61.png"},
    "웨스트브로미치 앨비언": {"id": 60, "logo": "https://media.api-sports.io/football/teams/60.png"},
    "포츠머스": {"id": 67, "logo": "https://media.api-sports.io/football/teams/67.png"},
    "카디프 시티": {"id": 64, "logo": "https://media.api-sports.io/football/teams/64.png"},
    "우니온 베를린": {"id": 182, "logo": "https://media.api-sports.io/football/teams/182.png"},
    "장크트 파울리": {"id": 186, "logo": "https://media.api-sports.io/football/teams/186.png"},
    "쾰른": {"id": 192, "logo": "https://media.api-sports.io/football/teams/192.png"},
    "TSG1899 호펜하임": {"id": 167, "logo": "https://media.api-sports.io/football/teams/167.png"},
    "엘버스베르크": {"id": 3514, "logo": "https://media.api-sports.io/football/teams/3514.png"},
    "바이어04 레버쿠젠": {"id": 168, "logo": "https://media.api-sports.io/football/teams/168.png"}
}

# API-Football의 고정 팀 ID가 검증된 구단은 검색 API가 느리거나 한도에
# 걸려도 엠블럼과 경기 연결이 끊기지 않도록 직접 연결한다.
DIRECT_TEAM_INFO.update({
    # 세리에A 팀은 검색 결과의 동명이인/유소년 팀 오연결을 막기 위해
    # API-Football의 검증된 1군 팀 ID를 직접 사용합니다.
    "AS로마": {"id": 100, "logo": "https://media.api-sports.io/football/teams/100.png"},
    "AS 로마": {"id": 100, "logo": "https://media.api-sports.io/football/teams/100.png"},
    "로마": {"id": 100, "logo": "https://media.api-sports.io/football/teams/100.png"},
    "AS Roma": {"id": 100, "logo": "https://media.api-sports.io/football/teams/100.png"},
    "US레체": {"id": 867, "logo": "https://media.api-sports.io/football/teams/867.png"},
    "US 레체": {"id": 867, "logo": "https://media.api-sports.io/football/teams/867.png"},
    "레체": {"id": 867, "logo": "https://media.api-sports.io/football/teams/867.png"},
    "Lecce": {"id": 867, "logo": "https://media.api-sports.io/football/teams/867.png"},
    "RB라이프치히": {"id": 173, "logo": "https://media.api-sports.io/football/teams/173.png"},
    "묀헨글라트바흐": {"id": 163, "logo": "https://media.api-sports.io/football/teams/163.png"},
    "FSV마인츠05": {"id": 164, "logo": "https://media.api-sports.io/football/teams/164.png"},
    "파더보른07": {"id": 185, "logo": "https://media.api-sports.io/football/teams/185.png"},
    "프랑크푸르트": {"id": 169, "logo": "https://media.api-sports.io/football/teams/169.png"},
    "함부르크": {"id": 175, "logo": "https://media.api-sports.io/football/teams/175.png"},
    # 베트맨의 짧은 표기와 프로토의 전체 표기를 같은 1군 팀으로 고정한다.
    "산프히로": {"id": 282, "logo": "https://media.api-sports.io/football/teams/282.png"},
    "산프레체 히로시마": {"id": 282, "logo": "https://media.api-sports.io/football/teams/282.png"},
    "Sanfrecce Hiroshima": {"id": 282, "logo": "https://media.api-sports.io/football/teams/282.png"},
})

def init_cache_db():
    try:
        conn = _sqlite_connect()
        # WAL lets the isolated LIVE/score/master/world workers read while one
        # short write is committing. Existing data and table contents are kept.
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA synchronous = NORMAL")
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE IF NOT EXISTS db_meta (version INTEGER)")
        cursor.execute("SELECT version FROM db_meta")
        row = cursor.fetchone()
        if not row or row[0] < 3:
            cursor.execute("DROP TABLE IF EXISTS predictions")
            cursor.execute("DELETE FROM db_meta")
            cursor.execute("INSERT INTO db_meta (version) VALUES (3)")
            conn.commit()
        cursor.execute("CREATE TABLE IF NOT EXISTS api_cache (cache_key TEXT PRIMARY KEY, cache_value TEXT, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS predictions (
                id INTEGER PRIMARY KEY AUTOINCREMENT, match_id TEXT UNIQUE, league TEXT, home_team TEXT, away_team TEXT,
                prob_pick TEXT, prob_pick_prob REAL,
                ev_pick TEXT, ev_pick_prob REAL,
                odd_h REAL, odd_d REAL, odd_a REAL,
                actual_score TEXT DEFAULT '-:-', actual_result TEXT DEFAULT 'PENDING', 
                is_correct_prob INTEGER DEFAULT 0, is_correct_ev INTEGER DEFAULT 0,
                ai_note TEXT DEFAULT '', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
                is_toto14 INTEGER DEFAULT 0, api_fixture_id INTEGER DEFAULT 0, match_time TEXT DEFAULT '',
                analysis_version TEXT DEFAULT '', postmortem_json TEXT DEFAULT '{}'
            )
        """)
        prediction_columns = {
            str(column[1]) for column in cursor.execute("PRAGMA table_info(predictions)")
        }
        if "analysis_version" not in prediction_columns:
            cursor.execute(
                "ALTER TABLE predictions ADD COLUMN analysis_version TEXT DEFAULT ''"
            )
        if "postmortem_json" not in prediction_columns:
            cursor.execute(
                "ALTER TABLE predictions ADD COLUMN postmortem_json TEXT DEFAULT '{}'"
            )
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS prediction_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                match_id TEXT NOT NULL,
                analysis_version TEXT NOT NULL,
                stage TEXT NOT NULL,
                confidence REAL DEFAULT 0,
                prob_pick TEXT,
                prob_pick_prob REAL,
                ev_pick TEXT,
                ev_pick_prob REAL,
                odd_h REAL,
                odd_d REAL,
                odd_a REAL,
                api_fixture_id INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_prediction_snapshots_match ON prediction_snapshots(match_id, created_at)")
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS prediction_analysis (
                match_id TEXT PRIMARY KEY,
                analysis_version TEXT DEFAULT '',
                stage TEXT DEFAULT '',
                odds_source TEXT DEFAULT '',
                selected_market TEXT,
                selected_pick TEXT,
                model_probability REAL,
                fair_probability REAL,
                edge REAL,
                confidence REAL,
                error_margin REAL,
                probability_low REAL,
                probability_high REAL,
                evidence_json TEXT DEFAULT '[]',
                markets_json TEXT DEFAULT '[]',
                categories_json TEXT DEFAULT '{}',
                decision_json TEXT DEFAULT '{}',
                report_text TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS prediction_analysis_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                match_id TEXT NOT NULL,
                analysis_version TEXT NOT NULL,
                stage TEXT NOT NULL,
                odds_source TEXT DEFAULT '',
                confidence REAL DEFAULT 0,
                selected_market TEXT,
                selected_pick TEXT,
                candidate_count INTEGER DEFAULT 0,
                evidence_json TEXT DEFAULT '[]',
                candidates_json TEXT DEFAULT '[]',
                categories_json TEXT DEFAULT '{}',
                decision_json TEXT DEFAULT '{}',
                report_text TEXT DEFAULT '',
                fingerprint TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(match_id, analysis_version, stage, fingerprint)
            )
        """)
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_analysis_snapshots_match "
            "ON prediction_analysis_snapshots(match_id, id)"
        )
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS prediction_candidate_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                match_id TEXT NOT NULL,
                analysis_snapshot_id INTEGER NOT NULL,
                analysis_version TEXT NOT NULL,
                stage TEXT NOT NULL,
                market_key TEXT NOT NULL,
                raw_pick TEXT NOT NULL,
                model_probability REAL DEFAULT 0,
                fair_probability REAL,
                odd REAL DEFAULT 0,
                selection_rank INTEGER,
                market_rank INTEGER,
                selected_as TEXT DEFAULT '',
                is_correct INTEGER NOT NULL,
                actual_score TEXT NOT NULL,
                graded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(analysis_snapshot_id, market_key, raw_pick)
            )
        """)
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_candidate_results_match "
            "ON prediction_candidate_results(match_id, analysis_version)"
        )
        conn.commit()
        conn.close()
    except Exception as e: print(f"❌ [DB 에러] 초기화 실패: {e}")

def _get_runtime_general_cache(key, ttl_hours):
    conn = None
    try:
        conn = _runtime_connect()
        row = conn.execute(
            "SELECT cache_value, updated_at FROM general_cache WHERE cache_key = ?",
            (key,),
        ).fetchone()
        if not row:
            return None
        encoded, updated_at = row
        if time.time() - float(updated_at or 0) >= float(ttl_hours) * 3600:
            return None
        return json.loads(encoded)
    finally:
        if conn is not None:
            conn.close()


def _get_legacy_main_db_cache(key, ttl_hours):
    """Read old cache rows without writing to the production predictions DB."""
    conn = None
    try:
        if not os.path.exists("ai_predictions.db"):
            return None
        conn = sqlite3.connect(
            "file:ai_predictions.db?mode=ro", uri=True, timeout=2
        )
        conn.execute("PRAGMA busy_timeout=2000")
        row = conn.execute(
            "SELECT cache_value, updated_at FROM api_cache WHERE cache_key = ?",
            (key,),
        ).fetchone()
        if not row:
            return None
        encoded, updated_at = row
        updated_time = datetime.strptime(
            updated_at, "%Y-%m-%d %H:%M:%S"
        ).replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) - updated_time >= timedelta(hours=ttl_hours):
            return None
        return json.loads(encoded)
    except (sqlite3.OperationalError, ValueError, TypeError, json.JSONDecodeError):
        return None
    finally:
        if conn is not None:
            conn.close()


def get_db_cache(key, ttl_hours):
    # API/team/model cache churn belongs in the small local runtime database.
    # Old main-DB rows remain readable during the transition, but are never
    # deleted or rewritten here.
    for attempt in range(len(SQLITE_BUSY_RETRY_DELAYS) + 1):
        try:
            cached = _get_runtime_general_cache(key, ttl_hours)
            if cached is not None:
                return cached
            legacy = _get_legacy_main_db_cache(key, ttl_hours)
            if legacy is not None:
                set_db_cache(key, legacy)
            return legacy
        except sqlite3.OperationalError as error:
            if _is_sqlite_busy(error) and attempt < len(SQLITE_BUSY_RETRY_DELAYS):
                time.sleep(SQLITE_BUSY_RETRY_DELAYS[attempt])
                continue
            print(f"⚠️ [관제 봇 떡밥] DB 캐시 읽기 실패 ({key}): {error}")
            return None
        except Exception as error:
            print(f"⚠️ [관제 봇 떡밥] DB 캐시 읽기 실패 ({key}): {error}")
            return None
    return None


def extract_official_pick(item):
    """Recover the saved official pick without recalculating the fixture."""
    if not isinstance(item, dict):
        return None
    analysis = item.get("analysis") if isinstance(item.get("analysis"), dict) else {}
    containers = [
        item.get("selected"),
        (item.get("pick_categories") or {}).get("high_probability")
        if isinstance(item.get("pick_categories"), dict) else None,
        (item.get("categories") or {}).get("high_probability")
        if isinstance(item.get("categories"), dict) else None,
        analysis.get("selected"),
        (analysis.get("categories") or {}).get("high_probability")
        if isinstance(analysis.get("categories"), dict) else None,
        (item.get("decision") or {}).get("selected")
        if isinstance(item.get("decision"), dict) else None,
        (analysis.get("decision") or {}).get("selected")
        if isinstance(analysis.get("decision"), dict) else None,
    ]
    for source in containers:
        if not isinstance(source, dict):
            continue
        raw_pick = str(source.get("raw_pick") or source.get("pick") or "").strip()
        if not raw_pick or source.get("display_only"):
            continue
        if str(source.get("recommendation_status") or "").upper() == "WITHHELD":
            continue
        recovered = dict(source)
        recovered["raw_pick"] = raw_pick
        recovered["prob"] = recovered.get(
            "prob", recovered.get("probability", 0)
        )
        recovered["fair_prob"] = recovered.get(
            "fair_prob", recovered.get("fair_probability")
        )
        return recovered
    return None


def _shortlist_match(item):
    match = item.get("match") if isinstance(item.get("match"), dict) else item
    identity = str(
        item.get("api_fixture_id") or match.get("api_fixture_id")
        or match.get("fixture_id") or match.get("id") or ""
    ).strip()
    return match, identity


def _shortlist_number(value, default=0.0):
    try:
        value = float(value)
        if math.isfinite(value):
            return value
    except (TypeError, ValueError):
        pass
    try:
        default = float(default)
        return default if math.isfinite(default) else 0.0
    except (TypeError, ValueError):
        return 0.0


def _manager_value_rank(probability, learned_score, odd, edge, expected_value, market_key):
    """Compare confidence and real price by conservative expected log growth.

    There is no fixed odds, market, favourite/underdog or 70%-display quota.
    Seventy percent is the future scorecard goal, not a number that may be
    manufactured on screen.  A row is investable only when the lower of the
    analyser's model probability and its learned goal score still has positive
    expected value at the saved decimal price.  A quarter-Kelly log-growth
    score then balances hit probability and payout without forcing 5-10 rows.
    """
    probability = max(0.0, min(1.0, _shortlist_number(probability)))
    learned_score = max(0.0, min(1.0, _shortlist_number(learned_score, probability)))
    odd = _shortlist_number(odd)
    edge = _shortlist_number(edge)
    saved_expected_value = _shortlist_number(
        expected_value, probability * odd if odd > 1.0 else 0.0
    )
    if saved_expected_value <= 0 and odd > 1.0:
        saved_expected_value = probability * odd
    confidence = min(probability, learned_score)
    # Never let stale/synthetic EV metadata make a candidate look investable.
    # The current conservative probability must independently support the price.
    confidence_ev = confidence * odd if odd > 1.0 else 0.0
    expected_value = min(saved_expected_value, confidence_ev)
    neutral = .5 if str(market_key or "") == "totals" else 1.0 / 3.0
    full_kelly = (
        max(0.0, min(1.0, (expected_value - 1.0) / max(odd - 1.0, 1e-9)))
        if odd > 1.0 else 0.0
    )
    stake_fraction = full_kelly * .25
    expected_log_growth = (
        confidence * math.log1p(stake_fraction * (odd - 1.0))
        + (1.0 - confidence) * math.log(max(1e-9, 1.0 - stake_fraction))
        if stake_fraction > 0 else 0.0
    )
    qualified = bool(
        odd > 1.0 and confidence > neutral and expected_value > 1.0
        and expected_log_growth > 0.0
    )
    price_score = max(0.0, min(1.0, math.log(max(1.0, odd), 6.0)))
    growth_score = max(0.0, min(1.0, expected_log_growth / .05))
    value_score = max(-1.0, min(1.0, (expected_value - 1.0) / .35))
    edge_score = max(-1.0, min(1.0, edge / .12))
    score = (
        confidence * .50
        + growth_score * .25
        + price_score * .15
        + max(0.0, value_score) * .07
        + max(0.0, edge_score) * .03
    )
    return {
        "qualified": qualified,
        "score": round(score, 8),
        "expected_value": expected_value,
        "conservative_probability": confidence,
        "full_kelly": round(full_kelly, 8),
        "stake_fraction": round(stake_fraction, 8),
        "expected_log_growth": round(expected_log_growth, 8),
        "neutral_probability": neutral,
        "policy": "independent-positive-log-growth-no-forced-fill-v3",
    }


def _manager_candidate_pool(item, analyst):
    """Return one analyst's auditable all-market candidates for a fixture."""
    if analyst == "robot":
        candidates = item.get("robot_candidates") or []
        fallback = extract_robot_pick(item)
    else:
        candidates = item.get("display_candidates") or item.get("ev_sorted_picks") or []
        fallback = extract_official_pick(item)
    pool = [dict(row) for row in candidates if isinstance(row, dict)]
    if not pool and isinstance(fallback, dict):
        pool = [dict(fallback)]
    return pool


def _manager_candidate_metrics(candidate, analyst):
    if analyst == "robot":
        probability = _shortlist_number(
            candidate.get("robot_probability"),
            candidate.get("prob", candidate.get("probability")),
        )
        goal_score = _shortlist_number(
            candidate.get("robot_goal_score"), probability
        )
        edge = _shortlist_number(
            candidate.get("robot_edge"), candidate.get("robust_edge")
        )
        expected_value = _shortlist_number(
            candidate.get("robot_ev"), candidate.get("robust_ev")
        )
    else:
        probability = _shortlist_number(
            candidate.get("robust_probability"),
            candidate.get("model_probability", candidate.get("prob")),
        )
        goal_score = _shortlist_number(
            candidate.get("official_goal_score"),
            candidate.get("official_learned_probability", probability),
        )
        edge = _shortlist_number(
            candidate.get("robust_edge"), candidate.get("edge")
        )
        expected_value = _shortlist_number(candidate.get("robust_ev"))
    odd = _shortlist_number(candidate.get("odd"))
    if expected_value <= 0 and odd > 1.0:
        expected_value = probability * odd
    return probability, goal_score, odd, edge, expected_value


def build_official_daily_shortlist(items, minimum_target=5, maximum_target=10):
    """Build a private Codex investment list independently of customer picks.

    Every saved pre-kickoff 1X2/handicap/totals candidate competes.  Selecting
    an administrator candidate never rewrites the customer-facing official
    answer, its probability, its price or its later grade.
    """
    try:
        minimum_target = max(1, int(minimum_target))
        maximum_target = max(minimum_target, min(20, int(maximum_target)))
    except (TypeError, ValueError):
        minimum_target, maximum_target = 5, 10
    ranked, seen = [], set()
    for item in items or []:
        if not isinstance(item, dict):
            continue
        match, identity = _shortlist_match(item)
        if not identity or identity in seen:
            continue
        fixture_candidates = []
        for official in _manager_candidate_pool(item, "official"):
            raw_pick = str(official.get("raw_pick") or official.get("pick") or "").strip()
            if not raw_pick or official.get("display_only"):
                continue
            if str(official.get("recommendation_status") or "").upper() == "WITHHELD":
                continue
            probability, learned_score, odd, edge, expected_value = (
                _manager_candidate_metrics(official, "official")
            )
            if not 0 < probability <= 1 or not 0 < learned_score <= 1:
                continue
            market_key = str(official.get("market_key") or "")
            value_rank = _manager_value_rank(
                probability, learned_score, odd, edge, expected_value, market_key
            )
            if not value_rank["qualified"]:
                continue
            fixture_candidates.append((
                (
                    value_rank["score"],
                    value_rank["expected_log_growth"], learned_score,
                    value_rank["expected_value"], odd, probability, raw_pick,
                ),
                official, raw_pick, market_key, probability, learned_score,
                odd, edge, value_rank,
            ))
        if not fixture_candidates:
            continue
        (
            fixture_score, official, raw_pick, market_key, probability,
            learned_score, odd, edge, value_rank,
        ) = max(fixture_candidates, key=lambda entry: entry[0])
        seen.add(identity)
        ranked.append((
            fixture_score,
            {
                "fixture_id": identity,
                "home": str(match.get("home") or item.get("home_team") or ""),
                "away": str(match.get("away") or item.get("away_team") or ""),
                "league": str(match.get("league") or item.get("league") or ""),
                "match_time": str(
                    item.get("final_match_time") or match.get("match_time")
                    or match.get("time") or ""
                ),
                "pick": raw_pick,
                "market_key": market_key,
                "probability": round(probability, 8),
                "goal_score": round(learned_score, 8),
                "conservative_probability": round(
                    value_rank["conservative_probability"], 8
                ),
                "manager_value_score": value_rank["score"],
                "odd": round(odd, 4),
                "edge": round(edge, 8),
                "expected_value": round(value_rank["expected_value"], 8),
                "expected_log_growth": value_rank["expected_log_growth"],
                "suggested_fraction": value_rank["stake_fraction"],
                "learning_active": bool(
                    official.get("official_learning_active")
                ),
                "learning_samples": int(
                    official.get("official_learning_samples") or 0
                ),
                "validation_accuracy": official.get(
                    "official_learning_validation_accuracy"
                ),
                "validation_baseline_accuracy": official.get(
                    "official_learning_baseline_accuracy"
                ),
                "validation_promoted": bool(
                    official.get("official_learning_active")
                ),
                "tier": "Codex 관리자 투자후보",
                "independent_from_customer_pick": bool(
                    raw_pick != str((extract_official_pick(item) or {}).get("raw_pick") or "")
                ),
                "accuracy_target": .70,
                "target_is_guarantee": False,
                "analysis_version": str(
                    item.get("analysis_version") or ANALYSIS_VERSION
                ),
            },
        ))
    ordered = sorted(ranked, key=lambda entry: entry[0], reverse=True)
    selected = [row for _score, row in ordered[:maximum_target]]
    return {
        "schema_version": "official-daily-shortlist.v4",
        "policy": "independent-all-market-positive-log-growth-v3",
        "accuracy_target": .70,
        "target_is_guarantee": False,
        "minimum_target": minimum_target,
        "maximum_target": maximum_target,
        "qualified_count": len(ranked),
        "selected_count": len(selected),
        "target_range_reached": minimum_target <= len(selected) <= maximum_target,
        "forced_fill": False,
        "picks": selected,
    }


def build_robot_daily_shortlist(items, minimum_target=5, maximum_target=10):
    """Rank independent robot picks for the administrator's daily shortlist.

    Every robot-owned saved candidate may compete.  The private investment
    answer can differ from the robot's one public comparison pick, while both
    remain frozen pre-kickoff audit rows.  There is no human 70%-probability
    gate, odds floor, market quota or favourite/underdog quota.
    """
    try:
        minimum_target = max(1, int(minimum_target))
        maximum_target = max(minimum_target, min(20, int(maximum_target)))
    except (TypeError, ValueError):
        minimum_target, maximum_target = 5, 10
    ranked = []
    seen = set()
    for item in items or []:
        if not isinstance(item, dict):
            continue
        match, identity = _shortlist_match(item)
        if not identity or identity in seen:
            continue
        fixture_candidates = []
        for robot in _manager_candidate_pool(item, "robot"):
            pick_version = str(
                robot.get("robot_pick_version")
                or (extract_robot_pick(item) or {}).get("robot_pick_version")
                or ROBOT_PICK_VERSION
            )
            if pick_version != ROBOT_PICK_VERSION:
                continue
            raw_pick = str(robot.get("raw_pick") or robot.get("pick") or "").strip()
            if not raw_pick:
                continue
            probability, goal_score, odd, edge, expected_value = (
                _manager_candidate_metrics(robot, "robot")
            )
            if not 0 < probability <= 1 or not 0 < goal_score <= 1:
                continue
            market_key = str(robot.get("market_key") or "")
            value_rank = _manager_value_rank(
                probability, goal_score, odd, edge, expected_value, market_key
            )
            if not value_rank["qualified"]:
                continue
            fixture_candidates.append((
                (
                    value_rank["score"],
                    value_rank["expected_log_growth"], goal_score,
                    value_rank["expected_value"], odd, probability, raw_pick,
                ),
                robot, raw_pick, market_key, probability, goal_score,
                odd, edge, value_rank,
            ))
        if not fixture_candidates:
            continue
        (
            fixture_score, robot, raw_pick, market_key, probability,
            goal_score, odd, edge, value_rank,
        ) = max(fixture_candidates, key=lambda entry: entry[0])
        true_underdog = bool(robot.get("is_true_underdog"))
        high_price = bool(odd >= 2.35)
        tier = "자율 로봇 자신픽"
        seen.add(identity)
        ranked.append((
            fixture_score,
            {
                "fixture_id": identity,
                "home": str(match.get("home") or item.get("home_team") or ""),
                "away": str(match.get("away") or item.get("away_team") or ""),
                "league": str(match.get("league") or item.get("league") or ""),
                "match_time": str(
                    item.get("final_match_time") or match.get("match_time")
                    or match.get("time") or ""
                ),
                "pick": raw_pick,
                "market_key": market_key,
                "probability": round(probability, 8),
                "goal_score": round(goal_score, 8),
                "conservative_probability": round(
                    value_rank["conservative_probability"], 8
                ),
                "manager_value_score": value_rank["score"],
                "odd": round(odd, 4),
                "edge": round(edge, 8),
                "expected_value": round(value_rank["expected_value"], 8),
                "expected_log_growth": value_rank["expected_log_growth"],
                "suggested_fraction": value_rank["stake_fraction"],
                "is_underdog": true_underdog,
                "is_high_price": high_price,
                "tier": tier,
                "independent_from_robot_public_pick": bool(
                    raw_pick != str((extract_robot_pick(item) or {}).get("raw_pick") or "")
                ),
                "accuracy_target": ROBOT_TARGET_ACCURACY,
                "target_is_guarantee": False,
                "robot_pick_version": ROBOT_PICK_VERSION,
                "robot_model_version": str(robot.get("robot_model_version") or ""),
                "validation_accuracy": robot.get(
                    "robot_goal_validation_accuracy"
                ),
                "validation_promoted": bool(
                    robot.get("robot_goal_target_reached")
                ),
            },
        ))
    ordered = sorted(ranked, key=lambda entry: entry[0], reverse=True)
    selected = [row for _score, row in ordered[:maximum_target]]
    qualified_high_price = [
        row for _score, row in ordered
        if row.get("is_high_price") and not row.get("is_underdog")
    ]
    return {
        "schema_version": "robot-daily-shortlist.v5",
        "policy": "robot-independent-all-market-positive-log-growth-v3",
        "accuracy_goal": ROBOT_TARGET_ACCURACY,
        "target_is_guarantee": False,
        "minimum_target": minimum_target,
        "maximum_target": maximum_target,
        "qualified_count": len(ranked),
        "selected_count": len(selected),
        "target_range_reached": minimum_target <= len(selected) <= maximum_target,
        "forced_fill": False,
        "qualified_high_price_count": len(qualified_high_price),
        "high_price_included": any(row.get("is_high_price") for row in selected),
        "picks": selected,
    }


def set_db_cache(key, value):
    encoded = json.dumps(value, ensure_ascii=False)
    for attempt in range(len(SQLITE_BUSY_RETRY_DELAYS) + 1):
        conn = None
        try:
            conn = _runtime_connect()
            conn.execute(
                "INSERT OR REPLACE INTO general_cache "
                "(cache_key, cache_value, updated_at) VALUES (?, ?, ?)",
                (key, encoded, time.time()),
            )
            conn.commit()
            return True
        except sqlite3.OperationalError as error:
            if conn is not None:
                conn.rollback()
            if _is_sqlite_busy(error) and attempt < len(SQLITE_BUSY_RETRY_DELAYS):
                time.sleep(SQLITE_BUSY_RETRY_DELAYS[attempt])
                continue
            print(f"⚠️ [관제 봇 떡밥] DB 캐시 쓰기 실패 ({key}): {error}")
            return False
        except Exception as error:
            if conn is not None:
                conn.rollback()
            print(f"⚠️ [관제 봇 떡밥] DB 캐시 쓰기 실패 ({key}): {error}")
            return False
        finally:
            if conn is not None:
                conn.close()
    return False

# ==============================================================
# 🔥 [V4 엔진 업그레이드] 탐지 함수 및 메커니즘 영역
# ==============================================================

SMART_MAPPING_FILE = "smart_mapping.json"
TEAM_INFO_MEMORY_CACHE = {}
TEAM_INFO_FAILURE_RETRY_AT = {}

# 베트맨/국내 표기와 API-FOOTBALL 영문 팀명을 연결한다.
# 여기서 찾은 동일 팀 ID를 팀 마크와 최근 전적 조회에 함께 사용한다.
BUILTIN_TEAM_ALIASES = {
    # 베트맨 화면의 짧은 팀명도 같은 공식 API 팀으로 연결합니다.
    "풀루미넨시": "Fluminense",
    "플루미넨시": "Fluminense",
    "CA플라텐세": "Platense",
    "CA 플라텐세": "Platense",
    "플라텐세": "Platense",
    "시드니FC": "Sydney FC",
    "시드니 FC": "Sydney FC",
    "멜버른빅토리": "Melbourne Victory",
    "멜버른 빅토리": "Melbourne Victory",
    "포츠머스": "Portsmouth",
    "더비카운": "Derby",
    "더비카운티": "Derby",
    "프레스턴": "Preston",
    "프레스턴 노스엔드": "Preston",
    "브리스C": "Bristol City",
    "셰필드U": "Sheffield Utd",
    "볼턴W": "Bolton",
    "스완지C": "Swansea",
    "웨스트햄": "West Ham",
    "사우샘프": "Southampton",
    "버밍엄C": "Birmingham",
    "스토크C": "Stoke City",
    "노리치C": "Norwich City",
    "도쿄베르": "Tokyo Verdy",
    "비셀고베": "Vissel Kobe",
    "마치다Z": "Machida Zelvia",
    "가와사키": "Kawasaki Frontale",
    "시미즈S": "Shimizu S-Pulse",
    "산프히로": "Sanfrecce Hiroshima",
    "후쿠오카": "Avispa Fukuoka",
    "C오사카": "Cerezo Osaka",
    "오사카C": "Cerezo Osaka",
    "가시와R": "Kashiwa Reysol",
    "삿포로": "Consadole Sapporo",
    "나고야G": "Nagoya Grampus",
    "우라와R": "Urawa Red Diamonds",
    "G오사카": "Gamba Osaka",
    "오사카G": "Gamba Osaka",
    "데포르티보 라코루냐": "Deportivo La Coruna",
    "시미즈 에스펄스": "Shimizu S-Pulse",
    "시미즈S펄스": "Shimizu S-Pulse",
    "V바렌 나가사키": "V-Varen Nagasaki",
    "V-바렌 나가사키": "V-Varen Nagasaki",
    "V바렌나가사키": "V-Varen Nagasaki",
    "V바렌나": "V-Varen Nagasaki",
    "요코하마 F 마리노스": "Yokohama F. Marinos",
    "요코하마F마리노스": "Yokohama F. Marinos",
    "빌럼II": "Willem II",
    "빌럼2": "Willem II",
    "SC헤이렌베인": "Heerenveen",
    "헤이렌베인": "Heerenveen",
    "SC프라이부르크": "SC Freiburg",
    "프라이부르크": "SC Freiburg",
    "베르더브레멘": "Werder Bremen",
    "베르더 브레멘": "Werder Bremen",
    "텔스타": "Telstar",
    "AFC아약스": "Ajax",
    "아약스": "Ajax",
    "아우크스부르크": "FC Augsburg",
    "샬케04": "FC Schalke 04",
    "샬케 04": "FC Schalke 04",
    "SC캄뷔르": "Cambuur",
    "캄뷔르": "Cambuur",
    "트벤테": "Twente",
    "PSV에인트호번": "PSV Eindhoven",
    "PSV 에인트호번": "PSV Eindhoven",
    "위트레흐트": "Utrecht",
    "페예노르트": "Feyenoord",
    "묀헨글라트바흐": "Borussia Monchengladbach",
    "RB라이프치히": "RB Leipzig",
    "레버쿠젠": "Bayer Leverkusen",
    "도르트문트": "Borussia Dortmund",
    "브라이턴": "Brighton",
    "브라이튼": "Brighton",
    "헐시티": "Hull City",
    "헐 시티": "Hull City",
    "코벤트리": "Coventry City",
    "코번트리": "Coventry City",
    "맨체스터U": "Manchester United",
    "맨유": "Manchester United",
    "리버풀": "Liverpool",
    "칼리아리": "Cagliari",
    "인터밀란": "Inter",
    "AS로마": "Roma",
    "AS 로마": "Roma",
    "로마": "Roma",
    "US레체": "Lecce",
    "US 레체": "Lecce",
    "레체": "Lecce",
    "SSC나폴리": "Napoli",
    "나폴리": "Napoli",
    "코모1907": "Como",
    "광주FC": "Gwangju FC",
    "FC서울": "FC Seoul",
    # 2026-09-10 승무패14 공식 경기표에서 확인하는 양 팀 이름.
    # ID를 고정하지 않고 같은 날짜·시각의 공식 홈/원정 쌍으로 최종 검증한다.
    "스포르팅CP": "Sporting CP",
    "스포르팅 CP": "Sporting CP",
    "갈라타사라이": "Galatasaray",
    "SE파우메이라스": "Palmeiras",
    "파우메이라스": "Palmeiras",
    "에스투디안테스데 라플라타": "Estudiantes L.P.",
    "에스투디안테스 데 라플라타": "Estudiantes L.P.",
    "SC코린티안스": "Corinthians",
    "코린티안스": "Corinthians",
    "페네르바흐체SK": "Fenerbahce",
    "페네르바흐체": "Fenerbahce",
    "페네르SK": "Fenerbahce",
    "CR플라멩구": "Flamengo",
    "플라멩구": "Flamengo",
}


def _builtin_team_alias_key(value):
    return re.sub(r"[^0-9a-z가-힣]+", "", str(value or "").lower())


BUILTIN_TEAM_ALIAS_INDEX = {
    _builtin_team_alias_key(local_name): api_name
    for local_name, api_name in BUILTIN_TEAM_ALIASES.items()
}


def _lookup_builtin_team_alias(team_name):
    return BUILTIN_TEAM_ALIAS_INDEX.get(_builtin_team_alias_key(team_name))

def _sanitize_team_search(value):
    """API-Football 검색 규칙(영문/숫자/공백만 허용)에 맞춘다."""
    return re.sub(r'\s+', ' ', re.sub(r'[^A-Za-z0-9 ]+', ' ', str(value or ''))).strip()

def _team_search_candidates(translated_name, saved_name=None):
    """정확한 이름부터 안전한 별칭까지 중복 없이 검색 후보를 만든다."""
    candidates = []

    def add(value):
        value = _sanitize_team_search(value)
        if len(value) >= 3 and value.casefold() not in {item.casefold() for item in candidates}:
            candidates.append(value)

    add(saved_name)
    add(translated_name)
    # New Betman spellings often arrive only as Hangul.  Keep a deterministic
    # romanized candidate so the provider search is not called with an empty
    # string such as "SC" forever.  Pair verification below still decides
    # whether the returned identity is safe to store.
    add(_hangul_romanize(saved_name or translated_name))

    sanitized = _sanitize_team_search(saved_name or translated_name)
    # API에서 자주 쓰지 않는 창단연도와 구단 접두/접미어를 제거한 후보.
    without_year = re.sub(r'\b(?:19|20)\d{2}\b', ' ', sanitized)
    without_club_words = re.sub(
        r'\b(?:FC|AFC|CF|SC|AC|AS|RC|RSC|SK|FK|SV|GNK|KF|AGF|CSKA|TC|AIF|NK|UD|CD)\b',
        ' ',
        without_year,
        flags=re.IGNORECASE,
    )
    add(without_year)
    add(without_club_words)

    # 공식 API가 별칭을 빼고 도시명으로만 등록한 대표 사례들.
    add(re.sub(r'\b(?:Red Diamonds|Antlers)\b$', ' ', without_club_words, flags=re.IGNORECASE))

    # 전체 구단명 검색이 비어 있을 때 핵심 단어로 한 번 더 찾는다.
    # 예: Shimizu S-Pulse -> Pulse/Shimizu,
    #     V-Varen Nagasaki -> Nagasaki/Varen,
    #     Yokohama F. Marinos -> Marinos/Yokohama
    # 너무 짧은 약자는 오검색 위험이 커서 제외하고 호출 수 또한 최대 2회로 제한한다.
    key_tokens = [token for token in without_club_words.split() if len(token) >= 5]
    if key_tokens:
        add(key_tokens[-1])
        add(key_tokens[0])
    return candidates

def _normalize_team_alias(value):
    return re.sub(r'[^0-9A-Za-z가-힣]+', '', str(value or '')).casefold()


def _country_alias_key(value):
    normalized = unicodedata.normalize("NFKD", str(value or ""))
    normalized = "".join(
        character for character in normalized
        if not unicodedata.combining(character)
    )
    normalized = unicodedata.normalize("NFC", normalized)
    return re.sub(r"[^0-9A-Za-z가-힣]+", "", normalized).casefold()


# National-team cards should use a country's flag when the provider has no
# usable crest.  The mapping is deliberately local and deterministic: no
# unaudited image search or additional paid sports request is made at render
# time.  Aliases are exact country names, so clubs that merely contain a city
# or country word are not mistaken for national teams.
_COUNTRY_FLAG_ROWS = (
    ("af", "Afghanistan", "아프가니스탄"),
    ("al", "Albania", "알바니아"),
    ("dz", "Algeria", "알제리"),
    ("ad", "Andorra", "안도라"),
    ("ao", "Angola", "앙골라"),
    ("ag", "Antigua and Barbuda", "Antigua Barbuda", "앤티가 바부다"),
    ("ar", "Argentina", "아르헨티나"),
    ("am", "Armenia", "아르메니아"),
    ("au", "Australia", "호주", "오스트레일리아"),
    ("at", "Austria", "오스트리아"),
    ("az", "Azerbaijan", "아제르바이잔"),
    ("bs", "Bahamas", "바하마"),
    ("bh", "Bahrain", "바레인"),
    ("bd", "Bangladesh", "방글라데시"),
    ("bb", "Barbados", "바베이도스"),
    ("by", "Belarus", "벨라루스"),
    ("be", "Belgium", "벨기에"),
    ("bz", "Belize", "벨리즈"),
    ("bj", "Benin", "베냉"),
    ("bt", "Bhutan", "부탄"),
    ("bo", "Bolivia", "볼리비아"),
    ("ba", "Bosnia and Herzegovina", "Bosnia-Herzegovina", "보스니아 헤르체고비나"),
    ("bw", "Botswana", "보츠와나"),
    ("br", "Brazil", "브라질"),
    ("bn", "Brunei", "Brunei Darussalam", "브루나이"),
    ("bg", "Bulgaria", "불가리아"),
    ("bf", "Burkina Faso", "부르키나파소"),
    ("bi", "Burundi", "부룬디"),
    ("kh", "Cambodia", "캄보디아"),
    ("cm", "Cameroon", "카메룬"),
    ("ca", "Canada", "캐나다"),
    ("cv", "Cape Verde", "Cabo Verde", "카보베르데"),
    ("cf", "Central African Republic", "중앙아프리카공화국"),
    ("td", "Chad", "차드"),
    ("cl", "Chile", "칠레"),
    ("cn", "China", "China PR", "중국"),
    ("tw", "Chinese Taipei", "Taiwan", "대만", "차이니스 타이베이"),
    ("co", "Colombia", "콜롬비아"),
    ("km", "Comoros", "코모로"),
    ("cg", "Congo", "Congo Republic", "콩고"),
    ("cd", "DR Congo", "Congo DR", "Democratic Republic of the Congo", "콩고민주공화국"),
    ("cr", "Costa Rica", "코스타리카"),
    ("hr", "Croatia", "크로아티아"),
    ("cu", "Cuba", "쿠바"),
    ("cw", "Curacao", "Curaçao", "퀴라소"),
    ("cy", "Cyprus", "키프로스"),
    ("cz", "Czech Republic", "Czechia", "체코"),
    ("dk", "Denmark", "덴마크"),
    ("dj", "Djibouti", "지부티"),
    ("dm", "Dominica", "도미니카 연방"),
    ("do", "Dominican Republic", "도미니카공화국"),
    ("ec", "Ecuador", "에콰도르"),
    ("eg", "Egypt", "이집트"),
    ("sv", "El Salvador", "엘살바도르"),
    ("gb-eng", "England", "잉글랜드"),
    ("gq", "Equatorial Guinea", "적도기니"),
    ("er", "Eritrea", "에리트레아"),
    ("ee", "Estonia", "에스토니아"),
    ("sz", "Eswatini", "Swaziland", "에스와티니"),
    ("et", "Ethiopia", "에티오피아"),
    ("fo", "Faroe Islands", "페로 제도"),
    ("fj", "Fiji", "피지"),
    ("fi", "Finland", "핀란드"),
    ("fr", "France", "프랑스"),
    ("ga", "Gabon", "가봉"),
    ("gm", "Gambia", "감비아"),
    ("ge", "Georgia", "조지아"),
    ("de", "Germany", "독일"),
    ("gi", "Gibraltar", "지브롤터"),
    ("gh", "Ghana", "가나"),
    ("gr", "Greece", "그리스"),
    ("gd", "Grenada", "그레나다"),
    ("gt", "Guatemala", "과테말라"),
    ("gn", "Guinea", "기니"),
    ("gw", "Guinea-Bissau", "Guinea Bissau", "기니비사우"),
    ("gy", "Guyana", "가이아나"),
    ("ht", "Haiti", "아이티"),
    ("hn", "Honduras", "온두라스"),
    ("hk", "Hong Kong", "Hong Kong SAR", "홍콩"),
    ("hu", "Hungary", "헝가리"),
    ("is", "Iceland", "아이슬란드"),
    ("in", "India", "인도"),
    ("id", "Indonesia", "인도네시아"),
    ("ir", "Iran", "Iran Islamic Republic", "이란"),
    ("iq", "Iraq", "이라크"),
    ("ie", "Republic of Ireland", "Ireland", "아일랜드"),
    ("il", "Israel", "이스라엘"),
    ("it", "Italy", "이탈리아"),
    ("ci", "Ivory Coast", "Cote d'Ivoire", "Côte d'Ivoire", "코트디부아르"),
    ("jm", "Jamaica", "자메이카"),
    ("jp", "Japan", "일본"),
    ("jo", "Jordan", "요르단"),
    ("kz", "Kazakhstan", "카자흐스탄"),
    ("ke", "Kenya", "케냐"),
    ("xk", "Kosovo", "코소보"),
    ("kw", "Kuwait", "쿠웨이트"),
    ("kg", "Kyrgyzstan", "Kyrgyz Republic", "키르기스스탄"),
    ("la", "Laos", "Lao PDR", "라오스"),
    ("lv", "Latvia", "라트비아"),
    ("lb", "Lebanon", "레바논"),
    ("ls", "Lesotho", "레소토"),
    ("lr", "Liberia", "라이베리아"),
    ("ly", "Libya", "리비아"),
    ("li", "Liechtenstein", "리히텐슈타인"),
    ("lt", "Lithuania", "리투아니아"),
    ("lu", "Luxembourg", "룩셈부르크"),
    ("mo", "Macau", "Macao", "마카오"),
    ("mg", "Madagascar", "마다가스카르"),
    ("mw", "Malawi", "말라위"),
    ("my", "Malaysia", "말레이시아"),
    ("mv", "Maldives", "몰디브"),
    ("ml", "Mali", "말리"),
    ("mt", "Malta", "몰타"),
    ("mr", "Mauritania", "모리타니"),
    ("mu", "Mauritius", "모리셔스"),
    ("mx", "Mexico", "멕시코"),
    ("md", "Moldova", "몰도바"),
    ("mn", "Mongolia", "몽골"),
    ("me", "Montenegro", "몬테네그로"),
    ("ma", "Morocco", "모로코"),
    ("mz", "Mozambique", "모잠비크"),
    ("mm", "Myanmar", "미얀마"),
    ("na", "Namibia", "나미비아"),
    ("np", "Nepal", "네팔"),
    ("nl", "Netherlands", "Holland", "네덜란드"),
    ("nc", "New Caledonia", "뉴칼레도니아"),
    ("nz", "New Zealand", "뉴질랜드"),
    ("ni", "Nicaragua", "니카라과"),
    ("ne", "Niger", "니제르"),
    ("ng", "Nigeria", "나이지리아"),
    ("mk", "North Macedonia", "Macedonia FYR", "북마케도니아"),
    ("gb-nir", "Northern Ireland", "북아일랜드"),
    ("kp", "North Korea", "Korea DPR", "북한"),
    ("no", "Norway", "노르웨이"),
    ("om", "Oman", "오만"),
    ("pk", "Pakistan", "파키스탄"),
    ("ps", "Palestine", "팔레스타인"),
    ("pa", "Panama", "파나마"),
    ("pg", "Papua New Guinea", "파푸아뉴기니"),
    ("py", "Paraguay", "파라과이"),
    ("pe", "Peru", "페루"),
    ("ph", "Philippines", "필리핀"),
    ("pl", "Poland", "폴란드"),
    ("pt", "Portugal", "포르투갈"),
    ("pr", "Puerto Rico", "푸에르토리코"),
    ("qa", "Qatar", "카타르"),
    ("ro", "Romania", "루마니아"),
    ("ru", "Russia", "러시아"),
    ("rw", "Rwanda", "르완다"),
    ("ws", "Samoa", "사모아"),
    ("sm", "San Marino", "산마리노"),
    ("sa", "Saudi Arabia", "사우디아라비아", "사우디"),
    ("gb-sct", "Scotland", "스코틀랜드"),
    ("sn", "Senegal", "세네갈"),
    ("rs", "Serbia", "세르비아"),
    ("sl", "Sierra Leone", "시에라리온"),
    ("sg", "Singapore", "싱가포르"),
    ("sk", "Slovakia", "슬로바키아"),
    ("si", "Slovenia", "슬로베니아"),
    ("sb", "Solomon Islands", "솔로몬 제도"),
    ("so", "Somalia", "소말리아"),
    ("za", "South Africa", "남아프리카공화국", "남아공"),
    ("kr", "South Korea", "Korea Republic", "대한민국", "한국"),
    ("ss", "South Sudan", "남수단"),
    ("es", "Spain", "스페인"),
    ("lk", "Sri Lanka", "스리랑카"),
    ("sd", "Sudan", "수단"),
    ("sr", "Suriname", "수리남"),
    ("se", "Sweden", "스웨덴"),
    ("ch", "Switzerland", "스위스"),
    ("sy", "Syria", "시리아"),
    ("tj", "Tajikistan", "타지키스탄"),
    ("tz", "Tanzania", "탄자니아"),
    ("th", "Thailand", "태국"),
    ("tl", "Timor-Leste", "East Timor", "동티모르"),
    ("tg", "Togo", "토고"),
    ("to", "Tonga", "통가"),
    ("tt", "Trinidad and Tobago", "트리니다드 토바고"),
    ("tn", "Tunisia", "튀니지"),
    ("tr", "Turkey", "Turkiye", "Türkiye", "튀르키예", "터키"),
    ("tm", "Turkmenistan", "투르크메니스탄"),
    ("ug", "Uganda", "우간다"),
    ("ua", "Ukraine", "우크라이나"),
    ("ae", "United Arab Emirates", "UAE", "아랍에미리트"),
    ("us", "United States", "USA", "United States of America", "미국"),
    ("uy", "Uruguay", "우루과이"),
    ("uz", "Uzbekistan", "우즈베키스탄"),
    ("ve", "Venezuela", "베네수엘라"),
    ("vn", "Vietnam", "Viet Nam", "베트남"),
    ("gb-wls", "Wales", "웨일스"),
    ("ye", "Yemen", "예멘"),
    ("zm", "Zambia", "잠비아"),
    ("zw", "Zimbabwe", "짐바브웨"),
)

COUNTRY_FLAG_ISO_BY_ALIAS = {}
COUNTRY_FLAG_NAME_BY_ISO = {}
for _flag_iso, _flag_english, *_flag_aliases in _COUNTRY_FLAG_ROWS:
    COUNTRY_FLAG_NAME_BY_ISO.setdefault(_flag_iso, _flag_english)
    for _flag_alias in (_flag_english, *_flag_aliases):
        _flag_alias_key = _country_alias_key(_flag_alias)
        if _flag_alias_key:
            COUNTRY_FLAG_ISO_BY_ALIAS[_flag_alias_key] = _flag_iso

_NATIONAL_TEAM_SUFFIX_RE = re.compile(
    r"^(?:(?:women|womens|woman|ladies|female|men|mens|male|national|nationalteam|"
    r"olympic|youth|u\d{1,2}|under\d{1,2}|bteam|b)|(?:여자|여성|남자|남성|"
    r"국가대표|대표팀|대표|올림픽|청소년|유스|\d{1,2}세이하))+$",
    re.IGNORECASE,
)


def _national_team_country_code(team_name, api_team=None):
    """Return a flag code only for an explicit national-team identity."""
    api_team = api_team if isinstance(api_team, dict) else {}
    api_national = api_team.get("national") is True
    values = [team_name]
    if api_national:
        values.extend((api_team.get("country"), api_team.get("name")))

    aliases = sorted(
        COUNTRY_FLAG_ISO_BY_ALIAS.items(), key=lambda item: len(item[0]), reverse=True
    )
    for value in values:
        key = _country_alias_key(value)
        if not key:
            continue
        direct = COUNTRY_FLAG_ISO_BY_ALIAS.get(key)
        if direct:
            return direct
        for alias_key, iso_code in aliases:
            if not key.startswith(alias_key):
                continue
            suffix = key[len(alias_key):]
            if suffix and _NATIONAL_TEAM_SUFFIX_RE.fullmatch(suffix):
                return iso_code
    return ""


def _national_team_flag_url(team_name, api_team=None):
    iso_code = _national_team_country_code(team_name, api_team)
    return f"https://flagcdn.com/w160/{iso_code}.png" if iso_code else ""


def _national_team_english_name(team_name):
    iso_code = _national_team_country_code(team_name)
    return COUNTRY_FLAG_NAME_BY_ISO.get(iso_code, "")

def _resolve_team_logo(team_name, team_id=0, api_logo=None, api_team=None):
    """Use verified crests and deterministic flags before the generic ball."""
    try:
        direct_logo = OFFICIAL_TEAM_LOGOS_BY_ID.get(int(team_id or 0))
        if direct_logo:
            return direct_logo
    except (TypeError, ValueError):
        pass

    normalized_name = _normalize_team_alias(team_name)
    for mapped_name, official_logo in OFFICIAL_TEAM_LOGOS.items():
        if normalized_name == _normalize_team_alias(mapped_name):
            return official_logo
    for mapped_name, mapped in DIRECT_TEAM_INFO.items():
        if normalized_name != _normalize_team_alias(mapped_name):
            continue
        mapped_logo = str((mapped or {}).get("logo") or "").strip()
        if mapped_logo and mapped_logo != DEFAULT_LOGO:
            return mapped_logo
    national_flag = _national_team_flag_url(team_name, api_team)
    if national_flag:
        return national_flag
    return api_logo or DEFAULT_LOGO

def _team_id_from_resolved_logo(team_name):
    """이미 확인된 팀 로고와 같은 API 팀 ID를 돌려줍니다."""
    resolved_logo = _resolve_team_logo(team_name, 0, DEFAULT_LOGO)
    if not resolved_logo or resolved_logo == DEFAULT_LOGO:
        return 0

    clean_logo = str(resolved_logo).split("?", 1)[0]

    for known_id, known_logo in OFFICIAL_TEAM_LOGOS_BY_ID.items():
        if str(known_logo).split("?", 1)[0] == clean_logo:
            try:
                return int(known_id)
            except (TypeError, ValueError):
                pass

    match = re.search(r"/teams/(\d+)\.(?:png|webp|svg)$", clean_logo, re.IGNORECASE)
    if match:
        return int(match.group(1))
    return 0


def _resolve_translated_team_name(team_name):
    """베트맨의 띄어쓰기/축약 차이를 기존 한영 사전에 안전하게 연결한다."""
    national_name = _national_team_english_name(team_name)
    if national_name:
        return national_name
    builtin_alias = _lookup_builtin_team_alias(team_name)
    if builtin_alias:
        return builtin_alias
    if team_name in MANUAL_TEAM_MAP:
        return MANUAL_TEAM_MAP[team_name]
    if team_name in TEAM_NAME_MAP:
        return TEAM_NAME_MAP[team_name]

    normalized = _normalize_team_alias(team_name)
    if len(normalized) < 3:
        return team_name

    alias_candidates = []
    combined_mapping = {**TEAM_NAME_MAP, **MANUAL_TEAM_MAP}
    for korean_name, english_name in combined_mapping.items():
        normalized_key = _normalize_team_alias(korean_name)
        if normalized == normalized_key:
            return english_name
        # '코번트리' ↔ '코번트리 시티', '라치오' ↔ 'SS라치오'처럼
        # 한쪽이 다른 쪽에 완전히 포함될 때만 허용해 엉뚱한 팀 연결을 막는다.
        if normalized in normalized_key or normalized_key in normalized:
            alias_candidates.append((abs(len(normalized_key) - len(normalized)), english_name))

    if alias_candidates:
        alias_candidates.sort(key=lambda item: item[0])
        best_distance = alias_candidates[0][0]
        best_names = {name for distance, name in alias_candidates if distance == best_distance}
        if len(best_names) == 1:
            return next(iter(best_names))
    return team_name


def _verified_team_cache_key(team_name):
    return f"team_info_v7_verified_{_normalize_team_alias(team_name)}"


def _load_verified_team_info(team_name):
    """경기표의 홈·원정 한 쌍으로 검증된 팀 정보만 불러온다."""
    cached = get_db_cache(_verified_team_cache_key(team_name), 24 * 365)
    if not isinstance(cached, dict) or not int(cached.get("id") or 0):
        return None
    cached = dict(cached)
    cached["logo"] = _resolve_team_logo(
        team_name, cached.get("id"), cached.get("logo"), cached
    )
    return cached


def _remember_verified_team(team_name, api_team):
    """실제 경기표에서 확인한 ID·로고를 모든 수집 단계의 기준으로 저장한다."""
    result = dict(api_team or {})
    team_id = int(result.get("id") or 0)
    if not team_id:
        return None
    result["logo"] = _resolve_team_logo(
        team_name,
        team_id,
        result.get("logo") or f"https://media.api-sports.io/football/teams/{team_id}.png",
        result,
    )
    result["verified_pair"] = True
    identity_key = _normalize_team_alias(team_name)
    TEAM_INFO_MEMORY_CACHE[team_name] = result
    if identity_key:
        TEAM_INFO_MEMORY_CACHE[identity_key] = result
    set_db_cache(_verified_team_cache_key(team_name), result)
    return result


def _team_identity_retry_key(home_name, away_name, match_time=""):
    return "|".join((
        _normalize_team_alias(home_name),
        _normalize_team_alias(away_name),
        str(match_time or "").strip(),
    ))


def list_team_identity_review_queue(limit=40):
    """Return unresolved pairs for an administrator review screen.

    This function deliberately returns only evidence already collected by the
    worker.  It does not make a paid API request and it never suggests a team
    identity as if it were confirmed.
    """
    try:
        conn = _runtime_connect()
        rows = conn.execute(
            """
            SELECT home_name,away_name,match_time,league_name,attempts,last_reason,
                   home_team_id,away_team_id,updated_at
            FROM team_identity_retry_queue
            WHERE status!='RESOLVED'
            ORDER BY updated_at DESC,retry_key ASC LIMIT ?
            """,
            (max(1, min(int(limit or 40), 200)),),
        ).fetchall()
        conn.close()
        return [
            {
                "home_name": str(row[0] or ""), "away_name": str(row[1] or ""),
                "match_time": str(row[2] or ""), "league_name": str(row[3] or ""),
                "attempts": int(row[4] or 0), "reason": str(row[5] or ""),
                "observed_home_team_id": int(row[6] or 0),
                "observed_away_team_id": int(row[7] or 0),
                "updated_at": str(row[8] or ""),
            }
            for row in rows
        ]
    except Exception:
        return []


def save_confirmed_team_alias(local_name, api_team_id, api_team_name="", note=""):
    """Persist one administrator-confirmed alias; no automatic guesses.

    The pair resolver still verifies date, home/away order and fixture before
    publication.  A mapping therefore helps name matching only and cannot by
    itself turn an unrelated fixture into an issued pick.
    """
    local_name = str(local_name or "").strip()
    normalized = _normalize_team_alias(local_name)
    try:
        api_team_id = int(api_team_id or 0)
    except (TypeError, ValueError):
        api_team_id = 0
    if not normalized or api_team_id <= 0:
        raise ValueError("local_name and a positive api_team_id are required")
    conn = _runtime_connect()
    try:
        conn.execute(
            """
            INSERT INTO team_identity_manual_aliases
                (normalized_alias,local_name,api_team_id,api_team_name,approved_note,approved_at)
            VALUES (?,?,?,?,?,?)
            ON CONFLICT(normalized_alias) DO UPDATE SET
                local_name=excluded.local_name,api_team_id=excluded.api_team_id,
                api_team_name=excluded.api_team_name,approved_note=excluded.approved_note,
                approved_at=excluded.approved_at
            """,
            (normalized, local_name, api_team_id, str(api_team_name or "").strip(),
             str(note or "").strip()[:300], datetime.now(timezone.utc).isoformat(timespec="seconds")),
        )
        conn.commit()
    finally:
        conn.close()


def _manual_team_alias(team_name):
    normalized = _normalize_team_alias(team_name)
    if not normalized:
        return None
    try:
        conn = _runtime_connect()
        row = conn.execute(
            "SELECT api_team_id,api_team_name FROM team_identity_manual_aliases WHERE normalized_alias=?",
            (normalized,),
        ).fetchone()
        conn.close()
        if row and int(row[0] or 0) > 0:
            return {"id": int(row[0]), "name": str(row[1] or "")}
    except Exception:
        return None
    return None


def queue_team_identity_retry(
    home_name, away_name, match_time="", reason="unresolved", league_name=""
):
    """Save unresolved IDs/logos/forms until they are genuinely completed."""
    home_name = str(home_name or "").strip()
    away_name = str(away_name or "").strip()
    league_name = str(league_name or "").strip()
    if not home_name or not away_name:
        return False
    retry_key = _team_identity_retry_key(home_name, away_name, match_time)
    now_iso = datetime.now(timezone.utc).isoformat(timespec="seconds")
    conn = None
    try:
        conn = _runtime_connect()
        conn.execute("BEGIN IMMEDIATE")
        conn.execute(
            """
            INSERT OR IGNORE INTO team_identity_retry_queue (
                retry_key,home_name,away_name,match_time,league_name,status,attempts,
                last_reason,next_retry_at,updated_at
            ) VALUES (?,?,?,?,?, 'PENDING',0,?,?,CURRENT_TIMESTAMP)
            """,
            (retry_key, home_name, away_name, str(match_time or ""), league_name,
             str(reason or "unresolved")[:300], now_iso),
        )
        conn.execute(
            """
            UPDATE team_identity_retry_queue
            SET home_name=?,away_name=?,match_time=?,
                league_name=CASE WHEN ?!='' THEN ? ELSE league_name END,
                last_reason=CASE
                    WHEN status='RESOLVED' OR last_reason='' THEN ?
                    ELSE last_reason END,
                attempts=CASE WHEN status='RESOLVED' THEN 0 ELSE attempts END,
                status='PENDING',
                resolved_at=NULL,
                next_retry_at=CASE
                    WHEN status='RESOLVED' THEN ?
                    WHEN next_retry_at IS NULL THEN ?
                    ELSE next_retry_at END,
                updated_at=CURRENT_TIMESTAMP
            WHERE retry_key=?
            """,
            (home_name, away_name, str(match_time or ""), league_name, league_name,
             str(reason or "unresolved")[:300], now_iso, now_iso, retry_key),
        )
        conn.commit()
        return True
    except Exception as error:
        if conn is not None:
            conn.rollback()
        print(f"⚠️ 팀 재탐색 대기열 저장 실패: {error}")
        return False
    finally:
        if conn is not None:
            conn.close()


def _complete_team_identity_retry(home_name, away_name, match_time, home_id, away_id):
    retry_key = _team_identity_retry_key(home_name, away_name, match_time)
    conn = _runtime_connect()
    try:
        conn.execute(
            """
            UPDATE team_identity_retry_queue
            SET status='RESOLVED',home_team_id=?,away_team_id=?,
                home_form_ready=1,away_form_ready=1,resolved_at=?,next_retry_at=NULL,
                last_reason='identity_logo_form_ready',updated_at=CURRENT_TIMESTAMP
            WHERE retry_key=?
            """,
            (int(home_id), int(away_id),
             datetime.now(timezone.utc).isoformat(timespec="seconds"), retry_key),
        )
        conn.commit()
    finally:
        conn.close()


def get_team_identity_retry_status():
    try:
        conn = _runtime_connect()
        rows = conn.execute(
            "SELECT status,COUNT(*) FROM team_identity_retry_queue GROUP BY status"
        ).fetchall()
        due = conn.execute(
            """SELECT COUNT(*) FROM team_identity_retry_queue
               WHERE status!='RESOLVED' AND (next_retry_at IS NULL OR next_retry_at<=?)""",
            (datetime.now(timezone.utc).isoformat(timespec="seconds"),),
        ).fetchone()[0]
        conn.close()
        counts = {str(status): int(count) for status, count in rows}
        return {
            "pending": sum(count for status, count in counts.items() if status != "RESOLVED"),
            "due": int(due or 0),
            "resolved": int(counts.get("RESOLVED", 0)),
        }
    except Exception:
        return {"pending": 0, "due": 0, "resolved": 0}


def process_team_identity_retry_queue(limit=4):
    """Retry forever across service restarts, while bounding only one cycle."""
    now = datetime.now(timezone.utc)
    now_iso = now.isoformat(timespec="seconds")
    conn = _runtime_connect()
    try:
        rows = conn.execute(
            """
            SELECT retry_key,home_name,away_name,match_time,league_name,attempts
            FROM team_identity_retry_queue
            WHERE status!='RESOLVED' AND (next_retry_at IS NULL OR next_retry_at<=?)
            ORDER BY COALESCE(next_retry_at,''),updated_at,retry_key LIMIT ?
            """,
            (now_iso, max(1, int(limit or 1))),
        ).fetchall()
    finally:
        conn.close()

    processed = resolved = 0
    for retry_key, home_name, away_name, match_time, league_name, prior_attempts in rows:
        processed += 1
        attempts = int(prior_attempts or 0) + 1
        reason = "team_identity_unresolved"
        home_id = away_id = 0
        home_form_ready = away_form_ready = False
        try:
            with api_purpose_context("analysis"):
                home_info, away_info, _ = resolve_match_team_pair(
                    home_name, away_name, match_time, ttl_h=0.2,
                    league_name=league_name,
                )
                home_id = int((home_info or {}).get("id") or 0)
                away_id = int((away_info or {}).get("id") or 0)
                if home_id and away_id and home_id != away_id:
                    home_form_ready = bool(fetch_team_form_api(home_id, 0.2))
                    away_form_ready = bool(fetch_team_form_api(away_id, 0.2))
                    logos_ready = bool(
                        (home_info or {}).get("logo") not in (None, "", DEFAULT_LOGO)
                        and (away_info or {}).get("logo") not in (None, "", DEFAULT_LOGO)
                    )
                    if logos_ready and home_form_ready and away_form_ready:
                        _complete_team_identity_retry(
                            home_name, away_name, match_time, home_id, away_id
                        )
                        resolved += 1
                        print(
                            f"✅ 팀 자료 재탐색 완료: {home_name}({home_id}) vs "
                            f"{away_name}({away_id}) · 마크/최근 전적 확인"
                        )
                        continue
                    reason = "identity_ready_profile_pending"
        except (ApiQuotaUnavailable, ApiRateLimited) as error:
            reason = f"provider_wait:{error}"
        except Exception as error:
            reason = f"{type(error).__name__}:{error}"

        delay_minutes = min(120, 5 * (2 ** min(max(0, attempts - 1), 4)))
        next_retry = (now + timedelta(minutes=delay_minutes)).isoformat(timespec="seconds")
        conn = _runtime_connect()
        try:
            conn.execute(
                """
                UPDATE team_identity_retry_queue
                SET status='PENDING',attempts=?,last_reason=?,last_attempt_at=?,
                    next_retry_at=?,home_team_id=?,away_team_id=?,
                    home_form_ready=?,away_form_ready=?,updated_at=CURRENT_TIMESTAMP
                WHERE retry_key=?
                """,
                (attempts, str(reason)[:300], now_iso, next_retry, home_id, away_id,
                 int(home_form_ready), int(away_form_ready), retry_key),
            )
            conn.commit()
        finally:
            conn.close()
    return {"processed": processed, "resolved": resolved, **get_team_identity_retry_status()}


def _latin_team_key(value):
    """악센트·구두점·FC 표기 차이를 제거한 영문 팀 비교 키."""
    normalized = unicodedata.normalize("NFKD", str(value or ""))
    ascii_value = normalized.encode("ascii", "ignore").decode("ascii").casefold()
    return re.sub(r"[^0-9a-z]+", "", ascii_value)


_HANGUL_INITIALS = (
    "g", "kk", "n", "d", "tt", "r", "m", "b", "pp", "s", "ss", "",
    "j", "jj", "ch", "k", "t", "p", "h",
)
_HANGUL_VOWELS = (
    "a", "ae", "ya", "yae", "eo", "e", "yeo", "ye", "o", "wa", "wae",
    "oe", "yo", "u", "wo", "we", "wi", "yu", "eu", "ui", "i",
)
_HANGUL_FINALS = (
    "", "k", "k", "ks", "n", "nj", "nh", "t", "l", "lk", "lm", "lp",
    "ls", "lt", "lp", "lh", "m", "p", "ps", "t", "t", "ng", "t", "t",
    "k", "t", "p", "h",
)


def _hangul_romanize(value):
    """Romanize Hangul deterministically without a network translator."""
    parts = []
    for character in str(value or ""):
        codepoint = ord(character)
        if 0xAC00 <= codepoint <= 0xD7A3:
            syllable = codepoint - 0xAC00
            initial = syllable // 588
            vowel = (syllable % 588) // 28
            final = syllable % 28
            parts.append(
                _HANGUL_INITIALS[initial]
                + _HANGUL_VOWELS[vowel]
                + _HANGUL_FINALS[final]
            )
        elif character.isascii() and character.isalnum():
            parts.append(character.casefold())
        else:
            parts.append(" ")
    return re.sub(r"\s+", " ", "".join(parts)).strip()


def _romanized_team_key(value):
    value = _hangul_romanize(value)
    value = unicodedata.normalize("NFKD", value)
    value = value.encode("ascii", "ignore").decode("ascii").casefold()
    # Korean loanword vowels (eu/eo) are commonly absent or simplified in the
    # provider's Latin spelling.  Normalize only for comparison, never for the
    # public team name.
    value = value.replace("eu", "").replace("eo", "o")
    value = value.replace("ae", "e").replace("oe", "e").replace("ui", "i")
    value = re.sub(
        r"\b(?:footballclub|football|club|association|afc|fc|sc|cf|ac)\b",
        " ", value,
    )
    value = re.sub(r"[^0-9a-z]+", "", value)
    return re.sub(r"(?:footballclub|afc|fc|sc|cf)$", "", value)


def _team_phonetic_key(value):
    """Build a conservative consonant key for Korean/Latin spelling gaps."""
    value = _romanized_team_key(value)
    if not value:
        return ""
    substitutions = (
        (r"tch|tsch|ch|dj|zh|j", "j"),
        (r"ph|f|v|p|b", "p"),
        (r"kh|q|g|k|c", "k"),
        (r"th|d|t", "t"),
        (r"sh|s|z|x", "s"),
        (r"r|l", "l"),
    )
    for pattern, replacement in substitutions:
        value = re.sub(pattern, replacement, value)
    value = re.sub(r"[aeiouy]", "", value)
    return re.sub(r"(.)\1+", r"\1", value)


def known_team_id(team_name):
    """베트맨 이름으로 이미 검증된 API 팀 ID를 반환한다."""
    # 같은 프로세스에서 이미 찾은 팀과 DB에 저장된 정상 팀을 모두 같은
    # 대표 ID로 사용한다. 로고ㆍ최근 전적ㆍ라이브ㆍ채점이 서로 다른 팀을
    # 가리키지 않도록 하는 단일 팀 신원 기준이다.
    target = _normalize_team_alias(team_name)
    remembered = TEAM_INFO_MEMORY_CACHE.get(team_name) or TEAM_INFO_MEMORY_CACHE.get(target)
    if isinstance(remembered, dict) and int(remembered.get("id") or 0):
        return int(remembered["id"])

    verified = _load_verified_team_info(team_name)
    if verified:
        return int(verified["id"])

    direct = DIRECT_TEAM_INFO.get(team_name)
    if direct:
        return int(direct.get("id") or 0)
    for mapped_name, mapped in DIRECT_TEAM_INFO.items():
        if target and target == _normalize_team_alias(mapped_name):
            return int(mapped.get("id") or 0)
    return 0


def team_matches_api(local_name, api_name, api_team_id=0):
    """베트맨 팀과 API 팀이 같은 팀인지 보수적으로 판정한다.

    검증된 팀 ID를 최우선으로 사용하고, ID가 아직 없는 팀에 한해서만
    영문 변환 이름의 정확 일치·포함·높은 유사도를 허용한다.
    """
    expected_id = known_team_id(local_name)
    try:
        candidate_id = int(api_team_id or 0)
    except (TypeError, ValueError):
        candidate_id = 0
    if expected_id and candidate_id:
        return expected_id == candidate_id

    translated = _resolve_translated_team_name(local_name)
    local_keys = {
        _latin_team_key(local_name),
        _latin_team_key(translated),
    }
    local_keys.discard("")
    api_key = _latin_team_key(api_name)
    if not api_key or not local_keys:
        return False

    for local_key in local_keys:
        if local_key == api_key:
            return True
        if min(len(local_key), len(api_key)) >= 6 and (
            local_key in api_key or api_key in local_key
        ):
            return True
        if difflib.SequenceMatcher(None, local_key, api_key).ratio() >= 0.78:
            return True
    return False

def load_smart_mapping():
    if os.path.exists(SMART_MAPPING_FILE):
        try:
            with open(SMART_MAPPING_FILE, "r", encoding="utf-8") as f: return json.load(f)
        except: pass
    return {}

def save_smart_mapping(mapping):
    try:
        with open(SMART_MAPPING_FILE, "w", encoding="utf-8") as f:
            json.dump(mapping, f, ensure_ascii=False, indent=4)
    except: pass

def fetch_team_info_api(team_name):
    identity_key = _normalize_team_alias(team_name)
    fallback_res = {
        "id": 0,
        "name": team_name,
        "logo": _resolve_team_logo(team_name, 0, DEFAULT_LOGO),
    }
    remembered = TEAM_INFO_MEMORY_CACHE.get(team_name) or TEAM_INFO_MEMORY_CACHE.get(identity_key)
    # A successful identity is safe to reuse for the process lifetime.  An
    # id=0 result is only a transient failure and must never turn the permanent
    # retry queue into a loop that returns the same failure without searching.
    if remembered and int((remembered or {}).get("id") or 0):
        return remembered
    retry_at = TEAM_INFO_FAILURE_RETRY_AT.get(team_name)
    if retry_at and datetime.now(timezone.utc) < retry_at:
        return fallback_res
    TEAM_INFO_MEMORY_CACHE.pop(team_name, None)
    if identity_key:
        TEAM_INFO_MEMORY_CACHE.pop(identity_key, None)

    def remember(result):
        TEAM_INFO_MEMORY_CACHE[team_name] = result
        if identity_key:
            TEAM_INFO_MEMORY_CACHE[identity_key] = result
        return result

    verified = _load_verified_team_info(team_name)
    if verified:
        return remember(verified)

    if team_name in DIRECT_TEAM_INFO:
        direct = DIRECT_TEAM_INFO[team_name]
        result = {
            "id": direct["id"],
            "name": team_name,
            "logo": _resolve_team_logo(team_name, direct["id"], direct.get("logo")),
        }
        return remember(result)

    canonical_id = known_team_id(team_name)
    if canonical_id:
        result = {
            "id": canonical_id,
            "name": _resolve_translated_team_name(team_name) or team_name,
            "logo": _resolve_team_logo(
                team_name,
                canonical_id,
                f"https://media.api-sports.io/football/teams/{canonical_id}.png",
            ),
        }
        set_db_cache(f"team_info_v7_search_{team_name}", result)
        return remember(result)

    # 수동/공식 로고가 이미 확인된 팀은 그 로고의 API 팀 ID를 그대로 사용합니다.
    # 이 ID가 최근 전적, 경기 매칭, 라이브 스코어 조회에 공통으로 전달됩니다.
    resolved_logo = _resolve_team_logo(team_name, 0, DEFAULT_LOGO)
    logo_team_id = _team_id_from_resolved_logo(team_name)
    if logo_team_id:
        result = {
            "id": logo_team_id,
            "name": _resolve_translated_team_name(team_name) or team_name,
            "logo": resolved_logo,
        }
        set_db_cache(f"team_info_v7_search_{team_name}", result)
        return remember(result)

    # 이전 버전은 검색 실패(id=0)까지 1년 캐시해 복구를 막았다. 버전을
    # 올리고 실제 팀을 찾은 결과만 장기 캐시한다.
    cache_key = f"team_info_v7_search_{team_name}"
    cached_data = get_db_cache(cache_key, 8760)
    if cached_data and cached_data.get("id"):
        cached_data["logo"] = _resolve_team_logo(
            team_name, cached_data.get("id"), cached_data.get("logo"), cached_data
        )
        set_db_cache(cache_key, cached_data)
        return remember(cached_data)

    translated_name = _resolve_translated_team_name(team_name)
    smart_mapping = load_smart_mapping()
    search_name = smart_mapping.get(translated_name, translated_name)
    candidates = _team_search_candidates(translated_name, search_name)

    if not candidates:
        print(f"⚠️ API 팀 검색용 영문 이름이 없음: {team_name}")
        TEAM_INFO_FAILURE_RETRY_AT[team_name] = (
            datetime.now(timezone.utc) + timedelta(minutes=5)
        )
        return fallback_res

    try:
        comparison_name = _sanitize_team_search(translated_name).casefold()
        last_error = None
        had_api_error = False
        for candidate in candidates:
            res = api_get(
                "/teams",
                params={"search": candidate},
                timeout=8,
            )
            if res.status_code != 200:
                last_error = f"HTTP {res.status_code}"
                had_api_error = True
                # 제한 초과나 인증 오류일 때 후보를 연달아 호출하지 않는다.
                if res.status_code in (401, 403, 429):
                    break
                continue

            payload = res.json()
            if payload.get("errors"):
                last_error = str(payload.get("errors"))
                had_api_error = True
                continue

            data = payload.get("response", [])
            if not data:
                continue

            def similarity(entry):
                api_name = _sanitize_team_search(entry.get("team", {}).get("name", "")).casefold()
                return max(
                    difflib.SequenceMatcher(None, comparison_name, api_name).ratio(),
                    difflib.SequenceMatcher(None, candidate.casefold(), api_name).ratio(),
                )

            best_entry = max(data, key=similarity)
            # 핵심/로마자 검색 결과가 다른 팀이면 저장하지 않는다.  The old
            # 0.15 floor could permanently attach an unrelated club merely
            # because the provider returned one fuzzy result.
            # 잘못 저장된 팀 ID는 로고·최근 전적·채점까지 모두 오염시키기 때문이다.
            if similarity(best_entry) < 0.55:
                continue
            result = dict(best_entry.get('team', {}) or {})
            if not result.get("id"):
                continue

            # Preserve the provider's verified home venue when it is included
            # in the same team-search response.  The autonomous robot can then
            # compare a future match city/country with the club base without
            # making a separate paid request or inventing a distance.
            venue = best_entry.get("venue") or {}
            if isinstance(venue, dict) and venue:
                result["venue"] = {
                    "id": int(venue.get("id") or 0),
                    "name": str(venue.get("name") or ""),
                    "city": str(venue.get("city") or ""),
                    "address": str(venue.get("address") or ""),
                    "capacity": int(venue.get("capacity") or 0),
                    "surface": str(venue.get("surface") or ""),
                }

            result["logo"] = _resolve_team_logo(
                team_name, result.get("id"), result.get("logo"), result
            )

            if candidate.casefold() != candidates[0].casefold():
                print(
                    f"✅ 팀 자동 대체 검색 성공: {team_name} -> "
                    f"{result.get('name', team_name)} (핵심 검색어: {candidate})"
                )
            smart_mapping[translated_name] = candidate
            save_smart_mapping(smart_mapping)
            set_db_cache(cache_key, result)
            remember(result)
            TEAM_INFO_FAILURE_RETRY_AT.pop(team_name, None)
            return result

        if last_error:
            print(f"⚠️ 팀 검색 API 오류({team_name}): {last_error}")
        else:
            print(f"⚠️ API에서 팀을 찾지 못함: {team_name} (검색 후보: {', '.join(candidates)})")
        # API 시간 초과/서버 오류는 실패로 고정하지 않고 다음 20분 주기에 재시도한다.
        if had_api_error:
            TEAM_INFO_FAILURE_RETRY_AT[team_name] = datetime.now(timezone.utc) + timedelta(seconds=15)
        else:
            TEAM_INFO_FAILURE_RETRY_AT[team_name] = (
                datetime.now(timezone.utc) + timedelta(minutes=5)
            )
        return fallback_res

    except Exception as e:
        print(f"⚠️ 팀 검색 통신 오류({team_name}): {e}")
        TEAM_INFO_FAILURE_RETRY_AT[team_name] = datetime.now(timezone.utc) + timedelta(seconds=15)
        return fallback_res


def get_cached_team_display_profile(team_name, form_ttl_h=24):
    """Return verified ID/logo/form without making a new provider request.

    Published picks remain immutable, but identity decoration is operational
    metadata and may be completed later.  This reads durable verified/search
    caches so a retry worker can repair an already-published card immediately.
    """
    team_name = str(team_name or "").strip()
    if not team_name:
        return {"id": 0, "name": "", "logo": DEFAULT_LOGO, "form": ""}

    identity_key = _normalize_team_alias(team_name)
    info = _load_verified_team_info(team_name)
    if not info:
        remembered = (
            TEAM_INFO_MEMORY_CACHE.get(team_name)
            or TEAM_INFO_MEMORY_CACHE.get(identity_key)
        )
        if isinstance(remembered, dict) and int(remembered.get("id") or 0):
            info = dict(remembered)
    if not info:
        cached = get_db_cache(f"team_info_v7_search_{team_name}", 24 * 365)
        if isinstance(cached, dict) and int(cached.get("id") or 0):
            info = dict(cached)
    if not info:
        team_id = known_team_id(team_name)
        if team_id:
            info = {
                "id": team_id,
                "name": _resolve_translated_team_name(team_name) or team_name,
                "logo": f"https://media.api-sports.io/football/teams/{team_id}.png",
            }

    info = dict(info or {})
    team_id = int(info.get("id") or 0)
    logo = _resolve_team_logo(team_name, team_id, info.get("logo"), info)
    form = ""
    if team_id:
        cached_form = get_db_cache(
            f"form_v5_regulation_{team_id}", max(0.2, float(form_ttl_h or 24))
        )
        if isinstance(cached_form, str):
            form = cached_form.strip()
    return {
        **info,
        "id": team_id,
        "name": str(info.get("name") or team_name),
        "logo": logo or DEFAULT_LOGO,
        "form": form,
    }

def parse_match_time(match_time_str):
    now = datetime.now(timezone(timedelta(hours=9)))
    if not match_time_str or match_time_str in ["시간 미정", "마감/진행중"]:
        return now - timedelta(hours=3)
    try:
        m_match = re.search(
            r'(?:(\d{2,4})\.)?(\d{2})\.(\d{2}).*?(\d{2}):(\d{2})',
            str(match_time_str),
        )
        if m_match:
            year_text, mo, d, h, m = m_match.groups()
            mo, d, h, m = map(int, (mo, d, h, m))
            if year_text:
                year = int(year_text)
                if year < 100:
                    year += 2000
                return datetime(
                    year, mo, d, h, m,
                    tzinfo=timezone(timedelta(hours=9)),
                )
            candidates = [
                datetime(year, mo, d, h, m, tzinfo=timezone(timedelta(hours=9)))
                for year in (now.year - 1, now.year, now.year + 1)
            ]
            return min(candidates, key=lambda value: abs((value - now).total_seconds()))
    except Exception as e:
        print(f"⚠️ [관제 봇 떡밥] 경기 시간 파싱 실패: {e}")
    return now - timedelta(hours=3)


def _team_name_match_score(local_name, api_name):
    """고정 ID를 배제하고 이름만으로 동일 팀 신뢰도를 계산한다."""
    translated = _resolve_translated_team_name(local_name)
    national_name = _national_team_english_name(local_name)
    api_key = _romanized_team_key(api_name)
    if not api_key:
        return 0.0

    scores = []
    compared = set()
    for candidate in (translated, national_name, local_name, _hangul_romanize(local_name)):
        local_key = _romanized_team_key(candidate)
        if local_key in compared:
            continue
        compared.add(local_key)
        if not local_key:
            continue
        if local_key == api_key:
            scores.append(1.0)
            continue
        if min(len(local_key), len(api_key)) >= 5 and (
            local_key in api_key or api_key in local_key
        ):
            scores.append(0.96)
            continue
        scores.append(difflib.SequenceMatcher(None, local_key, api_key).ratio())

        local_phonetic = _team_phonetic_key(candidate)
        api_phonetic = _team_phonetic_key(api_name)
        if min(len(local_phonetic), len(api_phonetic)) >= 4:
            phonetic_ratio = difflib.SequenceMatcher(
                None, local_phonetic, api_phonetic
            ).ratio()
            length_coverage = min(len(local_phonetic), len(api_phonetic)) / max(
                len(local_phonetic), len(api_phonetic)
            )
            if length_coverage >= 0.55:
                scores.append(0.90 * phonetic_ratio)
    return max(scores, default=0.0)


def _league_name_match_score(local_league, api_league):
    """Compare a Betman league hint without requiring a manual team entry."""
    local_key = _latin_team_key(local_league)
    api_key = _latin_team_key(api_league)
    if not local_key or not api_key:
        return 0.0
    if local_key == api_key:
        return 1.0
    if min(len(local_key), len(api_key)) >= 4 and (
        local_key in api_key or api_key in local_key
    ):
        return 0.96

    # Official competition abbreviations displayed by Betman.
    if local_key in {"acl2", "afccl2"} and (
        "afcchampionsleaguetwo" in api_key or "afccup" in api_key
    ):
        return 1.0
    if local_key in {"acle", "afccle"} and "afcchampionsleagueelite" in api_key:
        return 1.0
    if local_key in {"acl", "afccl"} and "afcchampionsleague" in api_key:
        return 0.96

    number_words = {"one": "1", "two": "2", "three": "3"}
    api_tokens = re.findall(r"[a-z]+|\d+", str(api_league or "").casefold())
    acronym = "".join(number_words.get(token, token[:1]) for token in api_tokens)
    if local_key == acronym or (len(local_key) >= 3 and local_key in acronym):
        return 0.90
    return difflib.SequenceMatcher(None, local_key, api_key).ratio()


def _fetch_date_fixtures_api(date_str, ttl_h=2, purpose="analysis"):
    """한 날짜 경기표를 한 번만 받아 팀 신원·경기 ID가 함께 사용한다."""
    cache_key = f"fixtures_by_date_v2_{date_str}"
    cached = get_db_cache(cache_key, min(max(float(ttl_h or 0), 0.2), 2))
    if cached is not None:
        return cached
    try:
        response = api_get(
            "/fixtures",
            params={"date": date_str, "timezone": "Asia/Seoul"},
            timeout=12,
            purpose=purpose,
        )
        if response.status_code != 200:
            print(f"⚠️ 실제 경기표 조회 실패({date_str}): HTTP {response.status_code}")
            return None
        payload = response.json()
        if payload.get("errors"):
            print(f"⚠️ 실제 경기표 API 오류({date_str}): {payload.get('errors')}")
            return None
        fixtures = payload.get("response", [])
        set_db_cache(cache_key, fixtures)
        return fixtures
    except Exception as error:
        print(f"⚠️ 실제 경기표 조회 오류({date_str}): {error}")
        return None


def _fixture_team_payload(fixture_data, side):
    team = dict(fixture_data.get("teams", {}).get(side, {}) or {})
    team.pop("winner", None)
    team_id = int(team.get("id") or 0)
    if team_id and not team.get("logo"):
        team["logo"] = f"https://media.api-sports.io/football/teams/{team_id}.png"
    return team


def resolve_match_team_pair(
    home_name, away_name, match_time_str, ttl_h=2, league_name=""
):
    """실제 날짜별 경기표에서 홈·원정 두 팀을 동시에 확정한다.

    한 팀씩 검색하면 동명이인이나 오래된 잘못된 캐시가 상대 팀까지 오염시킬
    수 있다. 이 함수는 같은 경기의 양쪽 이름과 킥오프 시간을 함께 대조하고,
    서로 다른 두 팀에 같은 ID가 배정되는 결과를 절대 반환하지 않는다.
    """
    home_name = str(home_name or "").strip()
    away_name = str(away_name or "").strip()
    league_name = str(league_name or "").strip()
    different_teams = _normalize_team_alias(home_name) != _normalize_team_alias(away_name)
    # A manual alias is an administrator-confirmed name-to-ID hint only.  It
    # must still agree with the date-board fixture and home/away order below.
    manual_home = _manual_team_alias(home_name)
    manual_away = _manual_team_alias(away_name)

    # A stored team ID alone is never enough for a scheduled pick.  Cached
    # aliases can be stale or ambiguous; when kickoff is known the two names,
    # their home/away order and the date-board fixture must agree together.
    known_home = known_team_id(home_name)
    known_away = known_team_id(away_name)
    no_scheduled_time = match_time_str in (None, "", "시간 미정", "마감/진행중")
    if (
        no_scheduled_time
        and known_home and known_away
        and (not different_teams or known_home != known_away)
    ):
        return fetch_team_info_api(home_name), fetch_team_info_api(away_name), None

    if not no_scheduled_time:
        match_dt = parse_match_time(match_time_str)
        date_str = match_dt.strftime("%Y-%m-%d")
        fixtures = _fetch_date_fixtures_api(date_str, ttl_h)
        if fixtures is not None:
            candidates = []
            for fixture_data in fixtures:
                home_api = _fixture_team_payload(fixture_data, "home")
                away_api = _fixture_team_payload(fixture_data, "away")
                home_id = int(home_api.get("id") or 0)
                away_id = int(away_api.get("id") or 0)
                if not home_id or not away_id or (different_teams and home_id == away_id):
                    continue
                home_score = _team_name_match_score(home_name, home_api.get("name"))
                away_score = _team_name_match_score(away_name, away_api.get("name"))
                if manual_home:
                    home_score = 1.0 if int(home_api.get("id") or 0) == manual_home["id"] else -1.0
                if manual_away:
                    away_score = 1.0 if int(away_api.get("id") or 0) == manual_away["id"] else -1.0
                timestamp = int(fixture_data.get("fixture", {}).get("timestamp") or 0)
                time_delta = (
                    abs(timestamp - int(match_dt.timestamp())) / 3600.0
                    if timestamp
                    else 99.0
                )
                time_bonus = max(0.0, 0.18 - min(time_delta, 12.0) * 0.015)
                league_score = _league_name_match_score(
                    league_name, fixture_data.get("league", {}).get("name")
                )
                league_bonus = 0.24 * league_score if league_name else 0.0
                candidates.append(
                    (home_score + away_score + time_bonus + league_bonus,
                     home_score, away_score, time_delta, fixture_data,
                     home_api, away_api, league_score)
                )

            candidates.sort(key=lambda item: item[0], reverse=True)
            selected = None
            if candidates:
                best = candidates[0]
                different_runner_up = (
                    len(candidates) > 1
                    and (
                        int(candidates[1][5].get("id") or 0),
                        int(candidates[1][6].get("id") or 0),
                    ) != (
                        int(best[5].get("id") or 0),
                        int(best[6].get("id") or 0),
                    )
                )
                ambiguous = bool(
                    different_runner_up and best[0] - candidates[1][0] < 0.10
                )
                if (
                    min(best[1], best[2]) >= 0.72
                    and best[1] + best[2] >= 1.52
                    and not ambiguous
                ):
                    selected = best
                elif ambiguous:
                    print(
                        f"[팀검증 격리] 후보 팀쌍이 비슷해 분석 차단: "
                        f"{home_name} vs {away_name} ({date_str})"
                    )
                    queue_team_identity_retry(
                        home_name, away_name, match_time_str,
                        reason="ambiguous_fixture_pair", league_name=league_name,
                    )

            # Korean phonetic matching is intentionally allowed only when the
            # kickoff is tight, both names still have useful evidence and a
            # supplied competition hint agrees.  A close runner-up blocks the
            # write so an identity mistake cannot contaminate form/live data.
            if selected is None and league_name:
                phonetic_candidates = [
                    item for item in candidates
                    if item[3] <= 0.35 and item[7] >= 0.85
                    and min(item[1], item[2]) >= 0.52
                    and item[1] + item[2] >= 1.22
                ]
                unique_phonetic_pairs = {
                    (int(item[5].get("id") or 0), int(item[6].get("id") or 0))
                    for item in phonetic_candidates
                }
                if len(unique_phonetic_pairs) == 1 and phonetic_candidates:
                    phonetic_candidates.sort(key=lambda item: item[0], reverse=True)
                    selected = phonetic_candidates[0]

            # 베트맨의 새 축약명이 사전에 아직 없더라도, 한쪽 팀이 정확하고
            # 같은 시각 후보가 하나뿐이면 실제 상대 팀을 경기표에서 역확정한다.
            if selected is None:
                partner_candidates = [
                    item for item in candidates
                    if (
                        max(item[1], item[2]) >= 0.90 and item[3] <= 2.5
                    ) or (
                        bool(league_name) and item[7] >= 0.90
                        and max(item[1], item[2]) >= 0.80
                        and min(item[1], item[2]) >= 0.20
                        and item[3] <= 0.35
                    )
                ]
                unique_pairs = {
                    (int(item[5].get("id") or 0), int(item[6].get("id") or 0))
                    for item in partner_candidates
                }
                if len(unique_pairs) == 1 and partner_candidates:
                    selected = max(partner_candidates, key=lambda item: item[0])

            if selected is not None:
                _, home_score, away_score, _, fixture_data, home_api, away_api = selected[:7]
                verified_home = _remember_verified_team(home_name, home_api)
                verified_away = _remember_verified_team(away_name, away_api)
                if (
                    verified_home
                    and verified_away
                    and int(verified_home["id"]) != int(verified_away["id"])
                ):
                    print(
                        f"[팀검증 성공] 실제 경기표 팀 확정: {home_name}({verified_home['id']}) vs "
                        f"{away_name}({verified_away['id']}) "
                        f"[이름 점수 {home_score:.2f}/{away_score:.2f}]"
                    )
                    return verified_home, verified_away, fixture_data

            print(
                f"[팀검증 재시도] 실제 경기표에서 팀 쌍을 확정하지 못함: "
                f"{home_name} vs {away_name} ({date_str})"
            )

            # API-Football의 date 필터는 공급사 기준일/UTC 경계 때문에 한국
            # 자정 근처 경기가 전날 또는 다음날 목록에 들어갈 수 있다. 같은
            # 날짜에서 실패한 경우에만 인접 이틀을 캐시 조회하고, 양 팀 이름과
            # 실제 timestamp가 모두 엄격히 맞는 한 쌍만 채택한다.
            for offset in (-1, 1):
                adjacent_date = (match_dt + timedelta(days=offset)).strftime("%Y-%m-%d")
                adjacent_fixtures = _fetch_date_fixtures_api(adjacent_date, ttl_h)
                if adjacent_fixtures is None:
                    continue
                adjacent_candidates = []
                for fixture_data in adjacent_fixtures:
                    home_api = _fixture_team_payload(fixture_data, "home")
                    away_api = _fixture_team_payload(fixture_data, "away")
                    home_id = int(home_api.get("id") or 0)
                    away_id = int(away_api.get("id") or 0)
                    if not home_id or not away_id or (different_teams and home_id == away_id):
                        continue
                    home_score = _team_name_match_score(home_name, home_api.get("name"))
                    away_score = _team_name_match_score(away_name, away_api.get("name"))
                    if manual_home:
                        home_score = 1.0 if int(home_api.get("id") or 0) == manual_home["id"] else -1.0
                    if manual_away:
                        away_score = 1.0 if int(away_api.get("id") or 0) == manual_away["id"] else -1.0
                    timestamp = int(fixture_data.get("fixture", {}).get("timestamp") or 0)
                    time_delta = (
                        abs(timestamp - int(match_dt.timestamp())) / 3600.0
                        if timestamp else 99.0
                    )
                    time_bonus = max(0.0, 0.18 - min(time_delta, 12.0) * 0.015)
                    league_score = _league_name_match_score(
                        league_name, fixture_data.get("league", {}).get("name")
                    )
                    league_bonus = 0.24 * league_score if league_name else 0.0
                    adjacent_candidates.append((
                        home_score + away_score + time_bonus + league_bonus,
                        home_score, away_score, time_delta,
                        fixture_data, home_api, away_api, league_score,
                    ))
                adjacent_candidates.sort(key=lambda item: item[0], reverse=True)
                if not adjacent_candidates:
                    continue
                best = adjacent_candidates[0]
                different_runner_up = (
                    len(adjacent_candidates) > 1
                    and (
                        int(adjacent_candidates[1][5].get("id") or 0),
                        int(adjacent_candidates[1][6].get("id") or 0),
                    ) != (
                        int(best[5].get("id") or 0),
                        int(best[6].get("id") or 0),
                    )
                )
                ambiguous = bool(
                    different_runner_up
                    and best[0] - adjacent_candidates[1][0] < 0.08
                )
                if (
                    min(best[1], best[2]) < 0.72
                    or best[1] + best[2] < 1.52
                    or best[3] > 4.5
                    or (league_name and best[7] < 0.70)
                    or ambiguous
                ):
                    continue
                _, home_score, away_score, _, fixture_data, home_api, away_api = best[:7]
                verified_home = _remember_verified_team(home_name, home_api)
                verified_away = _remember_verified_team(away_name, away_api)
                if (
                    verified_home and verified_away
                    and int(verified_home["id"]) != int(verified_away["id"])
                ):
                    print(
                        f"[팀검증 성공] 인접 날짜 경기표 팀 확정: "
                        f"{home_name}({verified_home['id']}) vs "
                        f"{away_name}({verified_away['id']}) "
                        f"[{adjacent_date}, 이름 점수 {home_score:.2f}/{away_score:.2f}]"
                    )
                    return verified_home, verified_away, fixture_data

    # A known kickoff without one verified date-board pair is a quarantine,
    # not permission to guess each team independently.  This is the final
    # guard that prevents a same-name club or stale alias from reaching any
    # analyst with a wrong opponent.
    if not no_scheduled_time:
        queue_team_identity_retry(
            home_name, away_name, match_time_str,
            reason="fixture_pair_not_verified", league_name=league_name,
        )
        return (
            {"id": 0, "name": home_name, "logo": None, "identity_error": "fixture_pair_not_verified"},
            {"id": 0, "name": away_name, "logo": None, "identity_error": "fixture_pair_not_verified"},
            None,
        )

    # 날짜 정보가 없거나 공급사 경기표가 잠시 실패하면 기존 개별 검색을
    # 사용하되, 서로 다른 팀이 같은 ID가 되는 순간 결과를 폐기한다.
    home_info = fetch_team_info_api(home_name)
    away_info = fetch_team_info_api(away_name)
    home_id = int(home_info.get("id") or 0)
    away_id = int(away_info.get("id") or 0)
    if different_teams and home_id and home_id == away_id:
        print(
            f"[팀검증 차단] 중복 팀 ID: {home_name}와 {away_name}가 모두 {home_id}번으로 "
            "연결되어 해당 결과를 사용하지 않습니다."
        )
        queue_team_identity_retry(
            home_name, away_name, match_time_str, reason="duplicate_team_id",
            league_name=league_name,
        )
        return (
            {"id": 0, "name": home_name, "logo": None, "identity_error": "duplicate_id"},
            {"id": 0, "name": away_name, "logo": None, "identity_error": "duplicate_id"},
            None,
        )
    if not home_id or not away_id:
        missing_sides = "/".join(
            side for side, value in (("home", home_id), ("away", away_id)) if not value
        )
        queue_team_identity_retry(
            home_name, away_name, match_time_str,
            reason=f"missing_team_id:{missing_sides or 'unknown'}",
            league_name=league_name,
        )
    return home_info, away_info, None

def fetch_weather_details_api(city_name, ttl_h):
    default = {"available": False, "condition": "Unknown", "city": str(city_name or "")}
    if not city_name:
        return default
    clean_city = city_name.split(',')[0].strip()
    cache_key = f"weather_details_v2_{clean_city}"
    cached_data = get_db_cache(cache_key, ttl_h)
    if isinstance(cached_data, dict):
        return cached_data
    if _API_CACHE_ONLY:
        return default
    try:
        res = requests.get(f"https://wttr.in/{clean_city}?format=j1", timeout=4)
        data = res.json()
        current = (data.get("current_condition") or [{}])[0]
        raw_condition = str(
            ((current.get("weatherDesc") or [{}])[0]).get("value") or ""
        ).strip()
        condition_text = raw_condition.casefold()
        if any(word in condition_text for word in ("rain", "shower", "drizzle")):
            condition = "Rain"
        elif any(word in condition_text for word in ("snow", "blizzard")):
            condition = "Snow"
        else:
            condition = "Clear"
        result = {
            "available": True,
            "city": clean_city,
            "condition": condition,
            "description": raw_condition,
            "temperature_c": current.get("temp_C"),
            "feels_like_c": current.get("FeelsLikeC"),
            "humidity_pct": current.get("humidity"),
            "wind_speed_kmph": current.get("windspeedKmph"),
            "wind_direction": current.get("winddir16Point"),
            "precipitation_mm": current.get("precipMM"),
            "cloud_cover_pct": current.get("cloudcover"),
            "visibility_km": current.get("visibility"),
            "pressure_hpa": current.get("pressure"),
            "uv_index": current.get("uvIndex"),
            "observation_time": current.get("localObsDateTime") or current.get("observation_time"),
        }
        set_db_cache(cache_key, result)
        return result
    except Exception:
        return default


def fetch_weather_api(city_name, ttl_h):
    details = fetch_weather_details_api(city_name, ttl_h)
    # Preserve the existing public-analysis fallback while the robot receives
    # the explicit available=False flag and never learns a failed call as sun.
    return str(details.get("condition") or "Clear") if details.get("available") else "Clear"

def _extract_match_winner_odds(odds_data):
    """Return median 1X2 odds across bookmakers with complete prices."""
    samples = {"odd_h": [], "odd_d": [], "odd_a": []}
    complete_bookmakers = 0
    for odds_row in odds_data or []:
        for bookmaker in odds_row.get("bookmakers", []) or []:
            bookmaker_values = {}
            for bet in bookmaker.get("bets", []) or []:
                if str(bet.get("name", "")).strip().casefold() not in {
                    "match winner", "1x2"
                }:
                    continue
                for value in bet.get("values", []) or []:
                    label = str(value.get("value", "")).strip().casefold()
                    key = {"home": "odd_h", "draw": "odd_d", "away": "odd_a"}.get(label)
                    try:
                        odd = float(value.get("odd") or 0)
                    except (TypeError, ValueError):
                        continue
                    if key and odd > 1.0:
                        bookmaker_values[key] = odd
            if all(key in bookmaker_values for key in samples):
                complete_bookmakers += 1
                for key in samples:
                    samples[key].append(bookmaker_values[key])

    if not complete_bookmakers:
        return None

    result = {"bookmaker_count": complete_bookmakers}
    for key, values in samples.items():
        ordered = sorted(values)
        middle = len(ordered) // 2
        median = (
            ordered[middle]
            if len(ordered) % 2
            else (ordered[middle - 1] + ordered[middle]) / 2.0
        )
        result[key] = round(median, 3)
    return result


def fetch_overseas_odds_and_fixture_api(
    home_id, away_id, ttl_h, match_time_str="시간 미정", include_odds=False
):
    """두 팀과 경기 날짜가 모두 일치하는 API fixture만 반환한다.

    예전 코드는 홈 팀의 다음/이전 경기로 대체해 다른 경기 점수가 LIVE로
    붙을 수 있었다. 정확히 일치하지 않으면 fixture_id를 만들지 않는다.
    """
    if not home_id or not away_id or match_time_str in ["시간 미정", "마감/진행중"]:
        return None

    m_dt = parse_match_time(match_time_str)
    date_str = m_dt.strftime('%Y-%m-%d')
    odds_requested = bool(include_odds or os.getenv("ENABLE_OVERSEAS_ODDS", "0") == "1")
    cache_key = f"odds_fixture_v13_{home_id}_{away_id}_{date_str}_{int(odds_requested)}"
    cached_data = get_db_cache(cache_key, ttl_h)
    if cached_data: return cached_data
    try:
        # 팀 신원을 확정할 때 받은 같은 날짜 경기표를 그대로 재사용한다.
        date_fixtures = _fetch_date_fixtures_api(date_str, ttl_h)
        if date_fixtures is None:
            return None

        exact_matches = []
        for fixture_data in date_fixtures:
            teams = fixture_data.get("teams", {})
            if (int(teams.get("home", {}).get("id") or 0) == int(home_id)
                    and int(teams.get("away", {}).get("id") or 0) == int(away_id)
                    and abs(float(fixture_data.get("fixture", {}).get("timestamp") or 0)-m_dt.timestamp()) <= 3*3600):
                exact_matches.append(fixture_data)

        if exact_matches and len({item["fixture"]["id"] for item in exact_matches}) == 1:
            match_data = min(
                exact_matches,
                key=lambda item: abs(
                    int(item.get("fixture", {}).get("timestamp", 0)) - int(m_dt.timestamp())
                ),
            )
            fix_id = match_data["fixture"]["id"]
            referee_name = match_data["fixture"].get("referee")
            city_name = match_data["fixture"].get("venue", {}).get("city")
            res_val = {
                "fixture_id": fix_id,
                "home_team_id": int(home_id), "away_team_id": int(away_id),
                "kickoff_timestamp": match_data["fixture"].get("timestamp"),
                "league_id": (match_data.get("league") or {}).get("id"),
                "league_name": (match_data.get("league") or {}).get("name"),
                "season": (match_data.get("league") or {}).get("season"),
                "odd_h": None,
                "odd_d": None,
                "odd_a": None,
                "referee": referee_name,
                "city": city_name,
                "fetched_at": datetime.now(timezone.utc).isoformat(),
            }

            # 베트맨 배당이 없을 때만 호출자가 해외배당을 명시적으로 요청한다.
            # 여러 북메이커 중 한 곳을 임의 선택하지 않고 완전한 1X2 세트의
            # 중앙값을 사용해 한 업체의 튀는 배당 영향을 줄인다.
            if odds_requested:
                try:
                    odds_res = api_get("/odds", params={"fixture": fix_id}, timeout=5)
                    odds_payload = odds_res.json() if odds_res.status_code == 200 else {}
                    odds_data = odds_payload.get("response", []) if not odds_payload.get("errors") else []
                    res_val["odds_response"] = odds_data
                    extracted = _extract_match_winner_odds(odds_data)
                    if extracted:
                        res_val.update(extracted)
                        res_val["odds_source"] = "overseas_median"
                except Exception as odds_error:
                    print(f"⚠️ 해외배당 조회 실패({fix_id}): {odds_error}")
            set_db_cache(cache_key, res_val)
            return res_val
        print(f"⚠️ 두 팀이 정확히 일치하는 경기 ID 없음: {home_id} vs {away_id} ({date_str})")
    except Exception as e:
        print(f"⚠️ 경기 ID/해외배당 조회 오류({home_id}-{away_id}): {e}")
    return None

def fetch_fixture_details_api(home_id, away_id, ttl_h):
    default_res = {
        "match_time": None, "last_h2h_date": "-", "h_wins": 0,
        "draws": 0, "a_wins": 0, "total": 0,
        "weighted_h_wins": 0.0, "weighted_draws": 0.0,
        "weighted_a_wins": 0.0, "weight_total": 0.0,
        "home_venue_h_wins": 0, "home_venue_draws": 0,
        "home_venue_a_wins": 0, "home_venue_total": 0,
        "weighting": "two-year-half-life",
    }
    if not home_id or not away_id: return default_res
    cache_key = f"app_h2h_v2_{home_id}_{away_id}"
    cached_data = get_db_cache(cache_key, ttl_h)
    if cached_data: return cached_data
    try:
        response = api_get("/fixtures/headtohead", params={"h2h": f"{home_id}-{away_id}"}, timeout=5)
        matches = response.json().get("response", [])
        selected = matches[:10]
        timestamps = [
            int((m.get("fixture") or {}).get("timestamp") or 0)
            for m in selected
            if int((m.get("fixture") or {}).get("timestamp") or 0) > 0
        ]
        latest_timestamp = max(timestamps, default=0)
        h_wins, draws, a_wins = 0, 0, 0
        weighted_h, weighted_draw, weighted_a, weight_total = 0.0, 0.0, 0.0, 0.0
        venue_h, venue_draw, venue_a, venue_total = 0, 0, 0, 0
        last_h2h_date = "-"
        fixture_ids = []
        for m in selected:
            fixture = m.get("fixture") or {}
            timestamp = int(fixture.get("timestamp") or 0)
            if timestamp and timestamp == latest_timestamp:
                last_h2h_date = str(fixture.get("date") or "-")[:10]
            fixture_id = fixture.get("id")
            if fixture_id:
                fixture_ids.append(int(fixture_id))
            age_seconds = max(0, latest_timestamp - timestamp) if timestamp else 0
            weight = 2 ** (-age_seconds / (730.0 * 86400.0)) if timestamp else 0.5
            outcome = "draw"
            if m.get("teams", {}).get("home", {}).get("winner"):
                outcome = "home" if m.get("teams", {}).get("home", {}).get("id") == home_id else "away"
            elif m.get("teams", {}).get("away", {}).get("winner"):
                outcome = "away" if m.get("teams", {}).get("home", {}).get("id") == home_id else "home"
            if outcome == "home":
                h_wins += 1
                weighted_h += weight
            elif outcome == "away":
                a_wins += 1
                weighted_a += weight
            else:
                draws += 1
                weighted_draw += weight
            weight_total += weight
            if m.get("teams", {}).get("home", {}).get("id") == home_id:
                venue_total += 1
                if outcome == "home": venue_h += 1
                elif outcome == "away": venue_a += 1
                else: venue_draw += 1
        res_val = {
            "match_time": None, "last_h2h_date": last_h2h_date,
            "h_wins": h_wins, "draws": draws, "a_wins": a_wins,
            "total": len(selected),
            "weighted_h_wins": round(weighted_h, 6),
            "weighted_draws": round(weighted_draw, 6),
            "weighted_a_wins": round(weighted_a, 6),
            "weight_total": round(weight_total, 6),
            "home_venue_h_wins": venue_h,
            "home_venue_draws": venue_draw,
            "home_venue_a_wins": venue_a,
            "home_venue_total": venue_total,
            "sample_fixture_ids": fixture_ids,
            "weighting": "two-year-half-life",
        }
        set_db_cache(cache_key, res_val)
        return res_val
    except: return default_res

def _validate_recent_fixtures(matches, team_id):
    """종료되고 해당 팀이 실제 참가한 경기만 중복 없이 시간순으로 정리한다."""
    validated = {}
    for match in matches or []:
        fixture = match.get("fixture", {})
        teams = match.get("teams", {})
        home_id = teams.get("home", {}).get("id")
        away_id = teams.get("away", {}).get("id")
        status = fixture.get("status", {}).get("short")
        fixture_id = fixture.get("id")
        timestamp = int(fixture.get("timestamp") or 0)
        goals = match.get("goals", {})

        if status not in {"FT", "AET", "PEN"}:
            continue
        if team_id not in {home_id, away_id} or not fixture_id or timestamp <= 0:
            continue
        if goals.get("home") is None or goals.get("away") is None:
            continue
        validated[int(fixture_id)] = match

    return sorted(
        validated.values(),
        key=lambda match: int(match.get("fixture", {}).get("timestamp") or 0),
    )[-40:]


def fetch_team_recent_fixtures_api(team_id, ttl_h):
    """최근 경기 원본을 팀당 한 번만 받아 전적/휴식/장기지표가 함께 쓴다."""
    if not team_id:
        return []
    cache_key = f"recent_fixtures_v2_{team_id}"
    cached_data = get_db_cache(cache_key, ttl_h)
    if cached_data is not None:
        return cached_data
    # 일시적인 API 장애 때 웹의 전적이 사라지지 않도록 마지막 정상본을 보존한다.
    stale_data = get_db_cache(cache_key, 24 * 365 * 5)
    try:
        response = api_get(
            "/fixtures",
            params={"team": team_id, "last": 40, "timezone": "Asia/Seoul"},
            timeout=12,
        )
        if response.status_code != 200:
            print(f"⚠️ 최근 경기 조회 실패({team_id}): HTTP {response.status_code}")
            return stale_data or []
        payload = response.json()
        if payload.get("errors"):
            print(f"⚠️ 최근 경기 API 오류({team_id}): {payload.get('errors')}")
            return stale_data or []
        data = _validate_recent_fixtures(payload.get("response", []), team_id)
        if data:
            set_db_cache(cache_key, data)
            return data
        print(f"⚠️ 완료된 최근 경기가 없음({team_id}) - 마지막 정상 기록을 사용합니다.")
        return stale_data or []
    except Exception as e:
        print(f"⚠️ 최근 경기 조회 오류({team_id}): {e}")
        return stale_data or []


def regulation_score(fixture):
    """Never train a 90-minute market on extra-time or shootout goals."""
    status = str(fixture.get("fixture", {}).get("status", {}).get("short") or "")
    full = fixture.get("score", {}).get("fulltime") or {}
    if full.get("home") is not None and full.get("away") is not None:
        return int(full["home"]), int(full["away"])
    goals = fixture.get("goals") or {}
    if status == "FT" and goals.get("home") is not None and goals.get("away") is not None:
        return int(goals["home"]), int(goals["away"])
    return None


def fetch_team_form_api(team_id, ttl_h):
    if not team_id: return ""
    cache_key = f"form_v5_regulation_{team_id}"
    cached_data = get_db_cache(cache_key, ttl_h)
    if cached_data is not None: return cached_data
    try:
        data = fetch_team_recent_fixtures_api(team_id, ttl_h)[-5:]
        form_list = []
        for m in data:
            home_id = m["teams"]["home"]["id"]
            score = regulation_score(m)
            if score is None:
                continue
            home_win, away_win = score[0] > score[1], score[1] > score[0]
            if home_id == team_id:
                if home_win is True: form_list.append("승")
                elif home_win is False and away_win is True: form_list.append("패")
                else: form_list.append("무")
            else:
                if away_win is True: form_list.append("승")
                elif away_win is False and home_win is True: form_list.append("패")
                else: form_list.append("무")
        res = "-".join(form_list) if form_list else ""
        # 빈 문자열은 장기 저장하지 않아 다음 수집 주기에 다시 시도한다.
        if res:
            set_db_cache(cache_key, res)
        return res
    except Exception as e:
        print(f"⚠️ 최근 전적 조회 오류({team_id}): {e}")
        return ""

def fetch_team_long_term_stats_api(team_id, ttl_h):
    default_res = {"home_wins": 0, "home_total": 0, "home_gf": 0, "home_ga": 0, "away_wins": 0, "away_total": 0, "away_gf": 0, "away_ga": 0}
    if not team_id: return default_res
    cache_key = f"stats_v5_regulation_{team_id}"
    cached_data = get_db_cache(cache_key, ttl_h)
    if cached_data: return cached_data
    try:
        data = fetch_team_recent_fixtures_api(team_id, ttl_h)
        for m in data:
            home_id = m["teams"]["home"]["id"]
            away_id = m["teams"]["away"]["id"]
            score = regulation_score(m)
            if score is None:
                continue
            gh, ga = score
            winner_home, winner_away = gh > ga, ga > gh
            if home_id == team_id:
                default_res["home_total"] += 1
                default_res["home_gf"] += gh
                default_res["home_ga"] += ga
                if winner_home is True: default_res["home_wins"] += 1
            elif away_id == team_id:
                default_res["away_total"] += 1
                default_res["away_gf"] += ga
                default_res["away_ga"] += gh
                if winner_away is True: default_res["away_wins"] += 1
        set_db_cache(cache_key, default_res)
        return default_res
    except: return default_res

def _parse_standings_team_map(data, target_league_id=None, target_season=None):
    """Convert one standings response into a cacheable team-id -> row map."""
    team_map = {}
    for league_data in data or []:
        league = league_data.get("league", {}) or {}
        league_id = league.get("id")
        season = league.get("season")
        if target_league_id and int(league_id or 0) != int(target_league_id):
            continue
        if target_season and int(season or 0) != int(target_season):
            continue
        standings_list = league.get("standings", []) or []
        for group in standings_list:
            group = [row for row in (group or []) if isinstance(row, dict)]
            rank_rows = {}
            relegation_ranks = []
            for table_row in group:
                try:
                    table_rank = int(table_row.get("rank") or 0)
                    table_points = int(table_row.get("points") or 0)
                except (TypeError, ValueError):
                    continue
                if table_rank <= 0:
                    continue
                rank_rows[table_rank] = table_points
                description = str(table_row.get("description") or "").casefold()
                if any(keyword in description for keyword in (
                    "relegat", "descenso", "rebaixamento", "abstieg",
                    "retrocessione", "降格", "강등",
                )):
                    relegation_ranks.append(table_rank)
            total_teams = len(rank_rows)
            if relegation_ranks:
                relegation_start_rank = min(relegation_ranks)
                zone_source = "official_description"
            elif total_teams >= 18:
                relegation_start_rank = total_teams - 2
                zone_source = "league_size_fallback"
            elif total_teams >= 8:
                relegation_start_rank = total_teams - 1
                zone_source = "league_size_fallback"
            else:
                relegation_start_rank = None
                zone_source = "none"
            safety_rank = (
                relegation_start_rank - 1
                if relegation_start_rank and relegation_start_rank > 1
                else None
            )
            safety_points = rank_rows.get(safety_rank)
            relegation_cut_points = rank_rows.get(relegation_start_rank)
            for row in group:
                try:
                    team_id = int((row.get("team", {}) or {}).get("id") or 0)
                    rank = int(row.get("rank") or 99)
                    points = int(row.get("points") or 0)
                except (TypeError, ValueError):
                    continue
                if team_id <= 0:
                    continue
                played = int((row.get("all", {}) or {}).get("played") or 0)
                team_goals = int((((row.get("all", {}) or {}).get("goals") or {}).get("for")) or 0)
                points_to_safety = (
                    max(0, int(safety_points) - points)
                    if safety_points is not None and relegation_start_rank and rank >= relegation_start_rank
                    else None
                )
                points_above_zone = (
                    max(0, points - int(relegation_cut_points))
                    if relegation_cut_points is not None and relegation_start_rank and rank < relegation_start_rank
                    else None
                )
                team_map[str(team_id)] = {
                    "rank": rank, "points": points, "played": played,
                    "league_id": league_id, "season": season,
                    "total_teams": total_teams, "team_goals": team_goals,
                    "description": str(row.get("description") or ""),
                    "relegation_start_rank": relegation_start_rank,
                    "safety_rank": safety_rank,
                    "safety_points": safety_points,
                    "relegation_cut_points": relegation_cut_points,
                    "points_to_safety": points_to_safety,
                    "points_above_zone": points_above_zone,
                    "relegation_zone_source": zone_source,
                }
    return team_map


def fetch_league_standings_table_api(league_id, season, ttl_h=24):
    """Fetch one league table once and let every team share that cached response."""
    try:
        league_id = int(league_id or 0)
        season = int(season or 0)
    except (TypeError, ValueError):
        return {}
    if league_id <= 0 or season <= 0:
        return {}
    cache_key = f"standings_table_v1_{league_id}_{season}"
    cached = get_db_cache(cache_key, ttl_h)
    if isinstance(cached, dict):
        return cached
    try:
        res = api_get(
            "/standings", params={"league": league_id, "season": season}, timeout=5
        )
        payload = res.json() if res.status_code == 200 else {}
        if payload.get("errors"):
            return {}
        table = _parse_standings_team_map(
            payload.get("response", []), league_id, season
        )
        if table:
            set_db_cache(cache_key, table)
        return table
    except Exception as error:
        print(f"⚠️ 리그 순위표 일괄 조회 오류({league_id}/{season}): {error}")
        return {}


def fetch_team_standing_api(team_id, ttl_h, target_league_id=None, target_season=None):
    default_res = {
        "rank": 99, "points": 0, "played": 0, "league_id": None,
        "season": None, "total_teams": 0, "team_goals": 0,
        "description": "", "relegation_start_rank": None,
        "safety_rank": None, "safety_points": None,
        "relegation_cut_points": None, "points_to_safety": None,
        "points_above_zone": None, "relegation_zone_source": "none",
    }
    if not team_id:
        return default_res
    cache_key = (f"standing_v7_{team_id}_{target_league_id}_{target_season}"
                 if target_league_id else f"standing_v5_survival_{team_id}")
    cached_data = get_db_cache(cache_key, ttl_h)
    if cached_data:
        return cached_data
    try:
        year = int(target_season or datetime.now().year)
        if target_league_id:
            table = fetch_league_standings_table_api(target_league_id, year, ttl_h)
            found = table.get(str(int(team_id))) if isinstance(table, dict) else None
            if isinstance(found, dict):
                set_db_cache(cache_key, found)
                return found
            if not target_season:
                table = fetch_league_standings_table_api(target_league_id, year - 1, ttl_h)
                found = table.get(str(int(team_id))) if isinstance(table, dict) else None
                if isinstance(found, dict):
                    set_db_cache(cache_key, found)
                    return found
            return default_res

        # Legacy path used when a fixture has not supplied its competition yet.
        for candidate_year in (year, year - 1):
            res = api_get(
                "/standings", params={"team": int(team_id), "season": candidate_year}, timeout=5
            )
            payload = res.json() if res.status_code == 200 else {}
            table = _parse_standings_team_map(payload.get("response", []))
            found = table.get(str(int(team_id))) if isinstance(table, dict) else None
            if isinstance(found, dict):
                set_db_cache(cache_key, found)
                return found
            if target_season:
                break
    except Exception:
        pass
    set_db_cache(cache_key, default_res)
    return default_res

def fetch_league_key_players(league_id, season):
    if not league_id or not season: return {}
    cache_key = f"keyplayers_v4_{league_id}_{season}"
    cached_data = get_db_cache(cache_key, 168)
    if cached_data: return cached_data
    
    key_players = {}
    try:
        res_s = api_get("/players/topscorers", params={"league": league_id, "season": season}, timeout=5)
        data_s = res_s.json().get("response", [])
        for p in data_s:
            name = p.get("player", {}).get("name", "")
            stats = (p.get("statistics") or [{}])[0]
            goals = stats.get("goals", {}).get("total", 0) or 0
            team_id = stats.get("team", {}).get("id")
            if name and goals:
                key_players[name] = {"goals": goals, "assists": 0, "team_id": team_id}
            
        res_a = api_get("/players/topassists", params={"league": league_id, "season": season}, timeout=5)
        data_a = res_a.json().get("response", [])
        for p in data_a:
            name = p.get("player", {}).get("name", "")
            stats = (p.get("statistics") or [{}])[0]
            assists = stats.get("goals", {}).get("assists", 0) or 0
            team_id = stats.get("team", {}).get("id")
            if not name:
                continue
            if name not in key_players:
                key_players[name] = {"goals": 0, "assists": assists, "team_id": team_id}
            else:
                key_players[name]["assists"] = assists
                key_players[name]["team_id"] = key_players[name].get("team_id") or team_id
            
        set_db_cache(cache_key, key_players)
        return key_players
    except: return {}

def fetch_fixture_injuries_api(fixture_id, ttl_h=6):
    """Fetch a fixture injury feed once; both teams reuse the same cached rows."""
    try:
        fixture_id = int(fixture_id or 0)
    except (TypeError, ValueError):
        return None
    if fixture_id <= 0:
        return None
    cache_key = f"fixture_injuries_v1_{fixture_id}"
    cached = get_db_cache(cache_key, ttl_h)
    if isinstance(cached, list):
        return cached
    stale = get_db_cache(cache_key, max(72, ttl_h))
    try:
        res = api_get("/injuries", params={"fixture": fixture_id}, timeout=8)
        payload = res.json() if res.status_code == 200 else {}
        if res.status_code != 200 or payload.get("errors"):
            return stale if isinstance(stale, list) else None
        rows = payload.get("response", []) or []
        if isinstance(rows, list):
            set_db_cache(cache_key, rows)
            return rows
    except Exception as error:
        print(f"⚠️ 경기 부상자 일괄 조회 오류({fixture_id}): {error}")
    return stale if isinstance(stale, list) else None


def fetch_team_injuries_api(team_id, league_id, season, ttl_h, fixture_id=0):
    default_res = {
        "count": 0, "ace_missing": False, "ace_names": [],
        "all_names": [], "missing_goals": 0, "records": [],
        "available": False, "source": "none",
    }
    if not team_id: return default_res
    cache_key = f"inj_v6_all_names_{team_id}_{league_id}_{season}_{int(fixture_id or 0)}"
    cached_data = get_db_cache(cache_key, ttl_h)
    if cached_data is not None: return cached_data
    # 당일 API가 소진돼도 직전 정상 부상자 자료를 버리지 않는다.
    stale_data = get_db_cache(cache_key, max(72, ttl_h))

    def stale_or_default():
        if isinstance(stale_data, dict):
            preserved = dict(stale_data)
            preserved["available"] = True
            preserved["source"] = "stale_cache"
            return preserved
        return default_res

    try:
        if fixture_id:
            source = "target_fixture"
            inj_data = fetch_fixture_injuries_api(int(fixture_id), ttl_h)
            if inj_data is None:
                return stale_or_default()
        elif league_id and season:
            source = "team_season"
            inj_res = api_get(
                "/injuries",
                params={"team": int(team_id), "league": int(league_id), "season": int(season)},
                timeout=8,
            )
            payload = inj_res.json() if inj_res.status_code == 200 else {}
            if inj_res.status_code != 200 or payload.get("errors"):
                return stale_or_default()
            inj_data = payload.get("response", [])
        else:
            return default_res
        injured_names = sorted({
            x.get("player", {}).get("name", "").strip()
            for x in inj_data
            if x.get("team", {}).get("id") == team_id and x.get("player", {}).get("name")
        })
        injury_records = []
        for row in inj_data:
            if int((row.get("team") or {}).get("id") or 0) != int(team_id):
                continue
            player = row.get("player") or {}
            name = str(player.get("name") or "").strip()
            if name:
                injury_records.append({
                    "player_id": int(player.get("id") or 0),
                    "name": name,
                    "type": str(player.get("type") or "").strip(),
                    "reason": str(player.get("reason") or "").strip(),
                })
        count = len(injured_names)
        ace_names = []
        missing_goals_total = 0
        key_players = fetch_league_key_players(league_id, season) if league_id and season else {}

        for name in injured_names:
            normalized = _normalize_player_name(name)
            matched = None
            for kp_name, kp_stats in key_players.items():
                if kp_stats.get("team_id") not in (None, team_id):
                    continue
                candidate = _normalize_player_name(kp_name)
                if normalized == candidate or (len(normalized) >= 6 and (normalized in candidate or candidate in normalized)):
                    matched = kp_stats
                    break
            protected = find_protected_star(name)
            if matched or protected:
                ace_names.append(name)
                if matched:
                    missing_goals_total += int(matched.get("goals", 0) or 0)

        res_val = {
            "count": count,
            "ace_missing": bool(ace_names),
            "ace_names": sorted(set(ace_names)),
            # Keep the complete confirmed unavailable list for starting-XI
            # prediction. Strength penalties still use ace_names separately.
            "all_names": injured_names,
            "records": injury_records,
            "missing_goals": missing_goals_total,
            "available": True,
            "source": source,
        }
        set_db_cache(cache_key, res_val)
        return res_val
    except Exception as error:
        print(f"⚠️ 부상자 조회 오류({team_id}): {error}")
        return stale_or_default()

def fetch_new_manager_status(team_id, ttl_h):
    default_res = {"is_new_manager": False, "days_since_hired": 999}
    if not team_id: return default_res
    cache_key = f"coach_v4_{team_id}"
    cached_data = get_db_cache(cache_key, ttl_h)
    if cached_data: return cached_data
    try:
        res = api_get("/coachs", params={"team": team_id}, timeout=5)
        data = res.json().get("response", [])
        if data:
            for coach in data:
                career = coach.get("career", [])
                for stint in career:
                    if stint.get("team", {}).get("id") == team_id and stint.get("end") is None:
                        start_date = stint.get("start")
                        if start_date:
                            start_dt = datetime.strptime(start_date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
                            days_since = (datetime.now(timezone.utc) - start_dt).days
                            is_new = days_since <= 21 
                            res_val = {"is_new_manager": is_new, "days_since_hired": days_since}
                            set_db_cache(cache_key, res_val)
                            return res_val
        return default_res
    except: return default_res

KNOWN_DERBIES = [
    {"Manchester United", "Manchester City"}, {"Tottenham", "Arsenal"}, 
    {"Real Madrid", "Barcelona"}, {"Atletico Madrid", "Real Madrid"},
    {"AC Milan", "Inter"}, {"Lazio", "Roma"}, {"Juventus", "Torino"},
    {"Liverpool", "Everton"}, {"FC Seoul", "Suwon Samsung"}, 
    {"Ulsan Hyundai", "Pohang Steelers"}, {"Bayern Munich", "Borussia Dortmund"}, 
    {"Paris Saint Germain", "Marseille"}
]

def check_derby_match(home_name, away_name):
    h_name = MANUAL_TEAM_MAP.get(home_name, TEAM_NAME_MAP.get(home_name, home_name))
    a_name = MANUAL_TEAM_MAP.get(away_name, TEAM_NAME_MAP.get(away_name, away_name))
    for derby in KNOWN_DERBIES:
        if h_name in derby and a_name in derby:
            return True
    return False

def fetch_lineups_api(fixture_id, ttl_h, purpose="analysis"):
    default_res = {"home": [], "away": [], "confirmed": False, "details": {}}
    if not fixture_id: return default_res
    cache_key = f"lineups_v2_detailed_{fixture_id}"
    cached_data = get_db_cache(cache_key, ttl_h)
    if cached_data: return cached_data
    try:
        res = api_get(
            "/fixtures/lineups", params={"fixture": fixture_id}, timeout=5,
            purpose=purpose,
        )
        data = res.json().get("response", [])
        res_val = {"home": [], "away": [], "confirmed": False, "details": {}}
        if data and len(data) == 2:
            for t in data:
                team = t.get("team") or {}
                t_id = int(team.get("id") or 0)
                starter_rows = []
                for row in t.get("startXI", []) or []:
                    player = row.get("player") or {}
                    starter_rows.append({
                        "player_id": int(player.get("id") or 0),
                        "name": str(player.get("name") or "").strip(),
                        "number": player.get("number"),
                        "position": str(player.get("pos") or "").strip(),
                        "grid": str(player.get("grid") or "").strip(),
                    })
                starters = [row["name"] for row in starter_rows if row["name"]]
                res_val[str(t_id)] = starters
                res_val["details"][str(t_id)] = {
                    "team": {"id": t_id, "name": str(team.get("name") or "").strip()},
                    "formation": str(t.get("formation") or "").strip(),
                    "coach": {
                        "id": int((t.get("coach") or {}).get("id") or 0),
                        "name": str((t.get("coach") or {}).get("name") or "").strip(),
                    },
                    "start_xi": starter_rows,
                    "substitutes": [
                        {
                            "player_id": int((row.get("player") or {}).get("id") or 0),
                            "name": str((row.get("player") or {}).get("name") or "").strip(),
                            "number": (row.get("player") or {}).get("number"),
                            "position": str((row.get("player") or {}).get("pos") or "").strip(),
                        }
                        for row in (t.get("substitutes") or [])
                        if str((row.get("player") or {}).get("name") or "").strip()
                    ],
                }
            res_val["confirmed"] = all(len(res_val.get(str(t.get("team", {}).get("id")), [])) >= 11 for t in data)
        # 발표 전 빈 명단은 저장하지 않아 다음 5분 주기에 다시 확인한다.
        if res_val["confirmed"]:
            set_db_cache(cache_key, res_val)
        return res_val
    except: pass
    return default_res

def fetch_team_last_match_date_api(team_id, ttl_h):
    default_res = {"date": None, "is_extreme_fatigue": False}
    if not team_id: return default_res
    cache_key = f"last_match_v5_{team_id}"
    cached_data = get_db_cache(cache_key, ttl_h)
    if cached_data: return cached_data
    try:
        data = fetch_team_recent_fixtures_api(team_id, ttl_h)[-1:]
        if data:
            match = data[0]
            date_val = match["fixture"]["date"]
            league_name = match["league"]["name"]
            is_away = match["teams"]["away"]["id"] == team_id
            continental_kws = ["Champions League", "Europa", "Conference", "Libertadores", "Sudamericana", "AFC", "World Cup"]
            is_continental = any(kw.lower() in league_name.lower() for kw in continental_kws)
            res_val = {"date": date_val, "is_extreme_fatigue": is_away and is_continental}
            set_db_cache(cache_key, res_val)
            return res_val
    except: pass
    return default_res

def fetch_team_next_fixture_api(team_id, ttl_h):
    default_res = {"days_until_next": 99, "is_important": False, "league_name": ""}
    if not team_id: return default_res
    cache_key = f"next_fix_v5_{team_id}"
    cached_data = get_db_cache(cache_key, ttl_h)
    if cached_data: return cached_data
    try:
        current_season = datetime.now().year
        res = api_get("/fixtures", params={"team": team_id, "season": current_season, "next": 3}, timeout=5)
        data = res.json().get("response", [])
        for next_fix in data:
            next_date_str = next_fix["fixture"]["date"]
            league_name = next_fix["league"]["name"]
            next_dt = datetime.fromisoformat(next_date_str.replace('Z', '+00:00'))
            now = datetime.now(timezone(timedelta(hours=9)))
            diff_hours = (next_dt - now).total_seconds() / 3600.0
            if diff_hours > 40:
                days_until = max(1, int(diff_hours / 24))
                important_keywords = ["Champions League", "Europa", "Cup", "Copa", "Sudamericana", "Libertadores", "AFC", "FA Cup"]
                is_important = any(kw.lower() in league_name.lower() for kw in important_keywords)
                res_val = {"days_until_next": days_until, "is_important": is_important, "league_name": league_name}
                set_db_cache(cache_key, res_val)
                return res_val
    except: pass
    return default_res

def fetch_recent_team_stats_api(team_id, ttl_h):
    default_res = {
        "possession": 50, "shots_on_goal": 4.0, "corners": 4.5,
        "yellow_cards": 1.5, "sample_size": 0, "xg": None,
        "xg_sample_size": 0, "xga": None, "xga_sample_size": 0,
        "field_samples": {}, "source_fixture_ids": [],
    }
    if not team_id: return default_res
    cache_key = f"recent_stats_v3_{team_id}"
    cached_data = get_db_cache(cache_key, ttl_h)
    if cached_data: return cached_data
    try:
        fixtures = fetch_team_recent_fixtures_api(team_id, ttl_h)[-2:]
        values = {key: [] for key in ("possession", "shots_on_goal", "corners", "yellow_cards", "xg", "xga")}
        fields = {"Ball Possession": "possession", "Shots on Goal": "shots_on_goal",
                  "Corner Kicks": "corners", "Yellow Cards": "yellow_cards",
                  "expected_goals": "xg", "Expected Goals": "xg", "expected goals": "xg", "xG": "xg"}
        source_ids = []
        for f in fixtures:
            fix_id = f["fixture"]["id"]
            fixture_cache_key = f"completed_fixture_stats_v1_{fix_id}"
            stats_data = get_db_cache(fixture_cache_key, 24 * 30)
            if stats_data is None:
                stat_res = api_get("/fixtures/statistics", params={"fixture": fix_id}, timeout=5)
                payload = stat_res.json() if stat_res.status_code == 200 else {}
                if not payload or payload.get("errors"):
                    continue
                stats_data = payload.get("response", [])
                if stats_data and any(t.get("statistics") for t in stats_data):
                    set_db_cache(fixture_cache_key, stats_data)
            for team_stat in stats_data:
                own = str(team_stat.get("team", {}).get("id")) == str(team_id)
                parsed = {}
                for s in team_stat.get("statistics", []):
                    key = fields.get(s.get("type"))
                    if not key or s.get("value") in (None, ""):
                        continue
                    try:
                        value = float(str(s["value"]).replace("%", ""))
                    except (TypeError, ValueError):
                        continue
                    if math.isfinite(value) and value >= 0:
                        parsed[key] = value  # Zero is an observation, never a default.
                if own and parsed:
                    source_ids.append(fix_id)
                    for key, value in parsed.items():
                        values[key].append(value)
                elif not own and "xg" in parsed:
                    values["xga"].append(parsed["xg"])
        res_val = dict(default_res)
        for key, samples in values.items():
            if samples:
                res_val[key] = round(sum(samples) / len(samples), 3)
        res_val.update(sample_size=len(set(source_ids)), xg_sample_size=len(values["xg"]),
                       xga_sample_size=len(values["xga"]),
                       field_samples={key: len(samples) for key, samples in values.items()},
                       source_fixture_ids=sorted(set(source_ids)),
                       observed_at=datetime.now(timezone.utc).isoformat())
        if res_val["sample_size"]:
            set_db_cache(cache_key, res_val)
        return res_val
    except: pass
    return default_res


def fetch_team_recent_form_metrics(team_id, ttl_h):
    """추가 API 호출 없이 최근 5경기의 득실ㆍ승점을 작은 보정값으로 만든다."""
    default_res = {"matches": 0, "ppg": 1.33, "gf_pg": 1.2, "ga_pg": 1.2, "strength": 0.0}
    if not team_id:
        return default_res
    try:
        fixtures = fetch_team_recent_fixtures_api(team_id, ttl_h)[-5:]
        points = goals_for = goals_against = count = 0
        for match in fixtures:
            is_home = match.get("teams", {}).get("home", {}).get("id") == team_id
            score = regulation_score(match)
            if score is None:
                continue
            gh, ga = score
            count += 1
            own, opp = (gh, ga) if is_home else (ga, gh)
            goals_for += own
            goals_against += opp
            points += 3 if own > opp else (1 if own == opp else 0)
        if not count:
            return default_res
        ppg = points / count
        gf_pg = goals_for / count
        ga_pg = goals_against / count
        strength = max(-0.12, min(0.12, ((ppg - 1.33) * 0.05) + ((gf_pg - ga_pg) * 0.035)))
        return {"matches": count, "ppg": round(ppg, 2), "gf_pg": round(gf_pg, 2), "ga_pg": round(ga_pg, 2), "strength": round(strength, 4)}
    except Exception:
        return default_res

def calculate_rest_days(last_date_iso, match_time_str):
    if not last_date_iso or not match_time_str or match_time_str in ["시간 미정", "마감/진행중"]: return 99
    try:
        last_dt = datetime.fromisoformat(last_date_iso.replace('Z', '+00:00'))
        m_dt = parse_match_time(match_time_str)
        diff = m_dt - last_dt
        return max(0, diff.days)
    except: pass
    return 99

def get_league_averages(league_name):
    name = league_name.lower() if league_name else ""
    if "프리미어" in name or "epl" in name or "premier league" in name: return 1.60, 1.35
    if "분데스리가" in name or "bundesliga" in name: return 1.65, 1.45
    if "에레디비시" in name or "eredivisie" in name: return 1.75, 1.45
    if "라리가" in name or "스페인" in name or "la liga" in name: return 1.45, 1.20
    if "세리에" in name or "이탈리아" in name or "serie a" in name: return 1.40, 1.15
    if "k1" in name or "k리그1" in name: return 1.35, 1.20 
    if "k2" in name or "k리그2" in name: return 1.30, 1.15
    if "j1" in name or "j리그" in name: return 1.40, 1.25 
    if "메이저리그" in name or "mls" in name: return 1.60, 1.30
    if "챔피언스" in name or "유로파" in name: return 1.55, 1.25
    return 1.50, 1.20

def build_score_matrix(exp_h, exp_a, rho=-0.15):
    """Dixon-Coles with fitted-or-fallback rho and a bounded Poisson tail."""
    exp_h, exp_a, rho = float(exp_h), float(exp_a), float(rho)
    if not all(math.isfinite(x) for x in (exp_h, exp_a, rho)) or not (0 < exp_h <= 20 and 0 < exp_a <= 20):
        raise ValueError("expected goals must be finite and in (0, 20]")
    rho = max(-1.0 / max(exp_h, exp_a) + 1e-12,
              min(rho, 1.0, 1.0 / (exp_h * exp_a)))

    def poisson(rate):
        values = [math.exp(-rate)]
        while len(values) < 100 and (len(values) < 2 or 1.0 - sum(values) > 1e-12):
            values.append(values[-1] * rate / len(values))
        return values

    hp, ap = poisson(exp_h), poisson(exp_a)
    matrix = [[ph * pa for pa in ap] for ph in hp]
    matrix[0][0] *= 1.0 - exp_h * exp_a * rho
    matrix[1][0] *= 1.0 + exp_a * rho
    matrix[0][1] *= 1.0 + exp_h * rho
    matrix[1][1] *= 1.0 - rho
    total = sum(map(sum, matrix))
    return [[p / total for p in row] for row in matrix]


def calculate_poisson_probs(exp_h, exp_a, handi_val=1.0, uo_base=2.5, matrix=None):
    matrix = build_score_matrix(exp_h, exp_a) if matrix is None else matrix
    h_win, draw, a_win, prob_u, prob_o = 0.0, 0.0, 0.0, 0.0, 0.0
    prob_handi_h, prob_handi_d, prob_handi_a = 0.0, 0.0, 0.0
    for h, row in enumerate(matrix):
        for a, p in enumerate(row):
            if h > a: h_win += p
            elif h == a: draw += p
            else: a_win += p
            if (h + a) < uo_base: prob_u += p
            elif (h + a) > uo_base: prob_o += p
            if (h + handi_val) > a: prob_handi_h += p
            elif (h + handi_val) == a: prob_handi_d += p
            elif (h + handi_val) < a: prob_handi_a += p
            
    return h_win, draw, a_win, prob_u, prob_o, prob_handi_h, prob_handi_d, prob_handi_a


def project_score_matrix_wdl(matrix, target):
    """Reweight disjoint W/D/L cells, preserving their conditional score shape."""
    masses = [0.0, 0.0, 0.0]
    for h, row in enumerate(matrix):
        for a, p in enumerate(row):
            masses[0 if h > a else 1 if h == a else 2] += p
    if len(target) != 3 or any(not math.isfinite(float(p)) or p < 0 for p in target):
        raise ValueError("invalid WDL target")
    if abs(sum(target) - 1) > 1e-8:
        raise ValueError("WDL target must sum to one")
    if any(m <= 0 and p > 0 for m, p in zip(masses, target)):
        raise ValueError("cannot assign probability to an impossible event")
    factors = [p/m if m else 0 for p, m in zip(target, masses)]
    return [[p * factors[0 if h > a else 1 if h == a else 2]
             for a, p in enumerate(row)] for h, row in enumerate(matrix)]


def integrate_pre_match_context(exp_h, exp_a, context, goal_audit=None):
    """Apply every usable pre-match factor once and return an auditable signal.

    Goal-shaped information changes expected goals. Directional information
    such as rank and head-to-head changes the W/D/L weights later, preserving
    one coherent score distribution for W/D/L, handicap and totals. Context
    with no honest goal or result direction (for example only a referee name)
    is explicitly recorded as neutral instead of being fabricated.
    """
    context = context if isinstance(context, dict) else {}
    audit = dict(goal_audit or {})

    def number(value, default=0.0):
        try:
            value = float(value)
            return value if math.isfinite(value) else default
        except (TypeError, ValueError):
            return default

    components = []
    neutral = []
    home_goal_delta = 0.0
    away_goal_delta = 0.0
    home_score = 0.0
    draw_score = 0.0
    away_score = 0.0

    def goal_component(name, home_delta, away_delta, source):
        nonlocal home_goal_delta, away_goal_delta
        home_goal_delta += home_delta
        away_goal_delta += away_delta
        components.append({
            "name": name, "mode": "expected_goals", "home": round(home_delta, 6),
            "away": round(away_delta, 6), "source": source,
        })

    def result_component(name, home_value, draw_value, away_value, source):
        nonlocal home_score, draw_score, away_score
        home_score += home_value
        draw_score += draw_value
        away_score += away_value
        components.append({
            "name": name, "mode": "wdl_log_weight", "home": round(home_value, 6),
            "draw": round(draw_value, 6), "away": round(away_value, 6),
            "source": source,
        })

    home_absence = max(0.0, min(.30, number(context.get("home_absence"))))
    away_absence = max(0.0, min(.30, number(context.get("away_absence"))))
    goal_component(
        "opponent_availability",
        min(.12, away_absence * .35), min(.12, home_absence * .35),
        "confirmed injury/lineup/fatigue penalty cross-effect",
    )

    home_survival = context.get("home_survival") or {}
    away_survival = context.get("away_survival") or {}
    goal_component(
        "survival_motivation",
        max(0.0, number(home_survival.get("attack_boost")))
        + max(0.0, number(away_survival.get("opponent_risk_boost"))),
        max(0.0, number(away_survival.get("attack_boost")))
        + max(0.0, number(home_survival.get("opponent_risk_boost"))),
        "standings zone and season progress",
    )

    home_title = max(0.0, min(.08, number(context.get("home_title"))))
    away_title = max(0.0, min(.08, number(context.get("away_title"))))
    home_manager = max(0.0, min(.08, number(context.get("home_manager"))))
    away_manager = max(0.0, min(.08, number(context.get("away_manager"))))
    home_vacation = max(0.0, min(.12, number(context.get("home_vacation"))))
    away_vacation = max(0.0, min(.12, number(context.get("away_vacation"))))
    goal_component(
        "motivation_and_manager",
        home_title * .65 + home_manager * .45 - home_vacation,
        away_title * .65 + away_manager * .45 - away_vacation,
        "title race/new manager/mid-table late-season state",
    )

    weather = str(context.get("weather") or "").casefold()
    weather_multiplier = .94 if any(token in weather for token in ("rain", "snow", "비", "눈")) else 1.0
    if weather_multiplier < 1.0:
        before_h = exp_h + home_goal_delta
        before_a = exp_a + away_goal_delta
        goal_component(
            "weather_total",
            before_h * (weather_multiplier - 1.0),
            before_a * (weather_multiplier - 1.0),
            str(context.get("weather") or "weather"),
        )
    elif context.get("weather"):
        neutral.append({"name": "weather", "reason": "normal condition; no extra direction"})

    h2h = context.get("h2h") or {}
    total = max(0, int(number(h2h.get("total"))))
    weight_total = max(0.0, number(h2h.get("weight_total")))
    weighted_h = number(h2h.get("weighted_h_wins"), number(h2h.get("h_wins")))
    weighted_a = number(h2h.get("weighted_a_wins"), number(h2h.get("a_wins")))
    weighted_d = number(h2h.get("weighted_draws"), number(h2h.get("draws")))
    effective_total = weight_total if weight_total > 0 else float(total)
    if total >= 3 and effective_total > 0:
        dominance = (weighted_h - weighted_a) / effective_total
        reliability = min(1.0, total / 8.0)
        dominance_score = max(-.52, min(.52, dominance * .70 * reliability))
        smoothed_draw = (weighted_d + .75) / (effective_total + 2.25)
        draw_context = max(-.12, min(.12, (smoothed_draw - .27) * .90 * reliability))
        result_component(
            "head_to_head",
            dominance_score, draw_context, -dominance_score,
            f"{int(h2h.get('h_wins') or 0)}-{int(h2h.get('draws') or 0)}-{int(h2h.get('a_wins') or 0)}; {h2h.get('weighting') or 'unweighted'}",
        )
    else:
        neutral.append({"name": "head_to_head", "reason": "fewer than 3 verified meetings"})

    home_rank = int(number(context.get("home_rank"), 99))
    away_rank = int(number(context.get("away_rank"), 99))
    if 0 < home_rank < 99 and 0 < away_rank < 99:
        rank_score = max(-.18, min(.18, (away_rank - home_rank) * .018))
        result_component("league_rank", rank_score, 0.0, -rank_score,
                         f"home {home_rank}, away {away_rank}")
    else:
        neutral.append({"name": "league_rank", "reason": "rank unavailable"})

    recent_diff = number(context.get("home_recent_strength")) - number(context.get("away_recent_strength"))
    if context.get("recent_available", True):
        recent_score = max(-.12, min(.12, recent_diff * .30))
        result_component("recent_points_form", recent_score, 0.0, -recent_score,
                         "bounded recent strength difference")

    home_market = max(0.0, min(.08, number(context.get("home_market"))))
    away_market = max(0.0, min(.08, number(context.get("away_market"))))
    if home_market or away_market:
        result_component("verified_market_movement", home_market, 0.0, away_market,
                         "multi-snapshot bookmaker direction")
    else:
        neutral.append({"name": "market_movement", "reason": "no verified directional move"})

    if context.get("is_derby"):
        result_component("derby_variance", -.025, .05, -.025,
                         "verified rivalry; draw uncertainty only")
    referee = str(context.get("referee") or "").strip()
    if referee:
        neutral.append({
            "name": "referee", "reason": "identified but no validated WDL/goal direction",
            "value": referee,
        })

    adjusted_h = round(max(.30, min(3.40, exp_h + home_goal_delta)), 4)
    adjusted_a = round(max(.30, min(3.40, exp_a + away_goal_delta)), 4)
    home_score = max(-.85, min(.85, home_score))
    draw_score = max(-.20, min(.20, draw_score))
    away_score = max(-.85, min(.85, away_score))
    context_audit = {
        "version": "full-pre-match-context-v1",
        "base_expected_goals": {"home": round(exp_h, 4), "away": round(exp_a, 4)},
        "adjusted_expected_goals": {"home": adjusted_h, "away": adjusted_a},
        "wdl_log_adjustment": [round(home_score, 6), round(draw_score, 6), round(away_score, 6)],
        "side_alignment": {
            "home": round(home_score - away_score, 6),
            "draw": round(draw_score - (home_score + away_score) / 2.0, 6),
            "away": round(away_score - home_score, 6),
        },
        "components": components,
        "neutral_components": neutral,
        "home_advantage": "embedded_once_in_venue_goal_model",
        "recent_goals_xg": "embedded_once_in_base_goal_model",
        "availability_rest_lineup": "embedded_once_in_penalty_plus_opponent_cross_effect",
    }
    audit["context_integration"] = context_audit
    audit["expected_goals"] = {"home": adjusted_h, "away": adjusted_a}
    return adjusted_h, adjusted_a, context_audit, audit


def coherent_match_forecast(exp_h, exp_a, handicap, total, odds, confidence,
                            history=None, rho=-.15, movement_adjustment=None,
                            context_adjustment=None):
    """All markets and refund contracts come from ONE final score distribution.

    Only WDL is market/learning calibrated. Independent handicap/totals
    calibration would contradict the same score events. Market prices for
    those markets remain available for value comparison, not extra goal boosts.
    """
    matrix = build_score_matrix(exp_h, exp_a, rho)
    wdl = list(calculate_poisson_probs(exp_h, exp_a, matrix=matrix)[:3])
    valid_odds = len(odds or []) == 3 and all(
        math.isfinite(float(o or 0)) and float(o or 0) > 1 for o in odds)
    target = calibrate_three_way_probabilities(wdl, odds if valid_odds else [], confidence)
    movement_adjustment = list(movement_adjustment or [0.0, 0.0, 0.0])
    if len(movement_adjustment) != 3:
        movement_adjustment = [0.0, 0.0, 0.0]
    movement_adjustment = [max(-.05, min(.05, float(value or 0))) for value in movement_adjustment]
    movement_applied = any(abs(value) > 1e-12 for value in movement_adjustment)
    if movement_applied:
        target = normalize_probabilities([
            max(1e-9, probability + adjustment)
            for probability, adjustment in zip(target, movement_adjustment)
        ])
    context_adjustment = list(context_adjustment or [0.0, 0.0, 0.0])
    if len(context_adjustment) != 3:
        context_adjustment = [0.0, 0.0, 0.0]
    context_adjustment = [
        max(-.85, min(.85, float(value or 0))) for value in context_adjustment
    ]
    context_applied = any(abs(value) > 1e-12 for value in context_adjustment)
    if context_applied:
        # Log weighting lets a strong, repeated directional signal overcome a
        # marginal market/model favourite without creating invalid probabilities.
        target = normalize_probabilities([
            max(1e-9, probability * math.exp(adjustment))
            for probability, adjustment in zip(target, context_adjustment)
        ])
    matrix = project_score_matrix_wdl(matrix, target)
    before = calculate_poisson_probs(exp_h, exp_a, handicap, total, matrix)
    history = history or {}
    corrected, weights, counts = [], [], []
    for p in target:
        cohort = history.get("calibration_bins", {}).get(str(min(9, int(p*10))), {})
        n = int(cohort.get("samples") or 0)
        weight = min(.18, n/(n+30.0)*.18) if history.get("calibration_validated") and n else 0.0
        error = float(cohort.get("error_sum") or 0)/n if n else 0.0
        corrected.append(max(0.0, min(1.0, p+weight*error)))
        weights.append(weight)
        counts.append(n)
    matrix = project_score_matrix_wdl(matrix, normalize_probabilities(corrected))
    probabilities = calculate_poisson_probs(exp_h, exp_a, handicap, total, matrix)
    audit = {
        "coherent_score_distribution": True,
        "forecast_model_version": FORECAST_MODEL_VERSION,
        "calibration_version": CALIBRATION_VERSION,
        "pick_policy_version": PICK_POLICY_VERSION,
        "raw_market_probabilities": list(before),
        "final_market_probabilities": list(probabilities),
        "wdl_learning_weights": weights, "wdl_learning_samples": counts,
        "calibration_active": any(weights),
        "validation_fixtures": int(history.get("validation_fixtures") or 0),
        "market_blend": "wdl_only" if valid_odds else "none",
        "rho": rho,
        "rho_source": "learned" if abs(float(rho) + .15) > 1e-9 else "validated_fallback",
        "movement_adjustment": movement_adjustment,
        "movement_learning_active": movement_applied,
        "context_adjustment": context_adjustment,
        "context_integration_active": context_applied,
    }
    # Matrix is transient; only the small audit is persisted for each candidate.
    return probabilities, audit, matrix


def estimate_match_goals(h_long, a_long, h_recent, a_recent, h_stats, a_stats,
                         league_name, home_penalty=0.0, away_penalty=0.0):
    """Shared, auditable pre-match goal model; no extra API or market-as-goals.

    Five pseudo-matches shrink noisy venue rates toward league priors. These
    are declared regularization assumptions, not validated optimal parameters.
    xG replaces part of the goal estimate; shots/possession do not multiply it
    again. Venue priors already include home advantage.
    """
    avg_h, avg_a = get_league_averages(league_name)

    def number(value, default=0.0):
        try:
            value = float(value)
            return value if math.isfinite(value) and value >= 0 else default
        except (TypeError, ValueError):
            return default

    def rate(stats, venue, metric, prior):
        n = number(stats.get(venue + "_total"))
        return (number(stats.get(venue + "_" + metric)) + 5.0 * prior) / (n + 5.0)

    base_h = rate(h_long, "home", "gf", avg_h) * rate(a_long, "away", "ga", avg_h) / avg_h
    base_a = rate(a_long, "away", "gf", avg_a) * rate(h_long, "home", "ga", avg_a) / avg_a
    audit = {"model": "shrunk-venue-goals-v1", "prior_matches": 5,
             "league_prior": [avg_h, avg_a], "venue_goals": [base_h, base_a],
             "market_in_goal_formula": False, "home_advantage_applied_once": True,
             "parameters_fitted": False, "sides": {}}

    def side(base, recent, own_stats, other_stats, penalty, name):
        n = number(recent.get("matches"))
        recent_weight = min(0.25, n / (n + 10.0))
        # Form points and goal difference are correlated with goals: use GF
        # once, with a bounded blend, not another strength multiplier.
        recent_gf = number(recent.get("gf_pg"), base)
        formed = base * (1 - recent_weight) + recent_gf * recent_weight
        xg_inputs = []
        for stats, field, count_field in ((own_stats, "xg", "xg_sample_size"),
                                          (other_stats, "xga", "xga_sample_size")):
            count = number(stats.get(count_field))
            if stats.get(field) is not None and count > 0:
                value = number(stats.get(field), -1)
                if value >= 0:
                    xg_inputs.append((value, count))
        xg_n = min((count for _, count in xg_inputs), default=0)
        xg_weight = min(0.25, xg_n / (xg_n + 8.0))
        xg_rate = sum(v for v, _ in xg_inputs) / len(xg_inputs) if xg_inputs else formed
        adjusted = formed * (1 - xg_weight) + xg_rate * xg_weight
        penalty = min(0.30, number(penalty))
        final = max(0.3, min(3.2, adjusted * (1 - penalty)))
        audit["sides"][name] = {"venue": round(base, 6), "recent_weight": recent_weight,
                                "recent_goal_rate": recent_gf, "xg_inputs": xg_inputs,
                                "stats_fixture_ids": list(own_stats.get("source_fixture_ids") or []),
                                "xg_weight": xg_weight, "xg_samples": xg_n,
                                "availability_penalty": penalty,
                                "clipped": final != adjusted * (1 - penalty)}
        return round(final, 4)

    eh = side(base_h, h_recent, h_stats, a_stats, home_penalty, "home")
    ea = side(base_a, a_recent, a_stats, h_stats, away_penalty, "away")
    audit["expected_goals"] = {"home": eh, "away": ea}
    return eh, ea, audit


_FIT_MEMORY = {}


def apply_cached_opponent_model(exp_h, exp_a, audit, home_id, away_id, league_id, kickoff,
                                home_penalty=0.0, away_penalty=0.0):
    """Read cached fixtures only; never spend an API request to train/check.

    A stale/missing/failed challenger leaves the auditable baseline untouched.
    The fitted goal model deliberately replaces, rather than multiplies, the
    baseline's recent-form and xG components. Absence adjustment is applied once.
    """
    audit = dict(audit)
    now = datetime.now(timezone.utc).timestamp()
    cutoff = min(now, kickoff.timestamp()) if kickoff is not None else now
    inactive = {"active": False, "parameters_fitted": False, "samples": 0,
                "reason": "경기·대회 신원 미확인"}
    if not all((home_id, away_id, league_id)) or int(home_id) == int(away_id) or cutoff < now-60:
        audit["opponent_model"] = inactive
        return exp_h, exp_a, audit
    # The v2 key deliberately prevents a cached fixed-rho R7.6 artifact from
    # being mistaken for the learned-rho model introduced in R7.7.
    key = f"opponent_fit_v2_{int(league_id)}_{int(cutoff//21600)}"
    artifact = _FIT_MEMORY.get(key) or get_db_cache(key, 6)
    if not artifact and _API_CACHE_ONLY:
        audit["opponent_model"] = {
            **inactive,
            "reason": "서빙 경로에서 학습 산출물 미준비 · 기초모형 즉시 사용",
            "serving_only": True,
        }
        return exp_h, exp_a, audit
    if not artifact:
        fixtures = []
        conn = None
        try:
            conn = sqlite3.connect("file:ai_predictions.db?mode=ro", uri=True, timeout=2)
            rows = conn.execute("SELECT cache_value FROM api_cache WHERE cache_key LIKE 'recent_fixtures_v2_%' "
                                "AND updated_at >= datetime('now','-7 days') ORDER BY updated_at DESC LIMIT 1500").fetchall()
            for (value,) in rows:
                try:
                    payload = json.loads(value)
                    if isinstance(payload, list):
                        fixtures.extend(payload)
                except (ValueError, TypeError):
                    continue
            records = clean_records(fixtures, league_id, cutoff)
            priors = audit.get("league_prior") or {"home": 1.5, "away": 1.2}
            if isinstance(priors, dict):
                priors = (priors.get("home", 1.5), priors.get("away", 1.2))
            artifact = train_challenger(records, priors, calculate_poisson_probs)
            artifact["trained_at"] = cutoff
        except (sqlite3.Error, ValueError, TypeError, KeyError) as error:
            artifact = dict(inactive, reason="저장 훈련자료 읽기 실패 · 기초모형 유지", error_type=type(error).__name__)
        finally:
            if conn is not None:
                conn.close()
        set_db_cache(key, artifact)
    _FIT_MEMORY[key] = artifact
    # Keep memory bounded as the daily collector spans many leagues.
    if len(_FIT_MEMORY) > 256:
        _FIT_MEMORY.pop(next(iter(_FIT_MEMORY)))
    public = {k: v for k, v in artifact.items() if k != "parameters"}
    parameters = artifact.get("parameters") or {}
    sufficient_teams = min(parameters.get("team_samples", {}).get(str(team), 0) for team in (home_id, away_id)) >= 8
    active = bool(artifact.get("active") and sufficient_teams
                  and float(artifact.get("available_after") or 0) <= cutoff
                  and float(artifact.get("trained_at") or 0) <= cutoff)
    public["active"] = active
    if artifact.get("active") and not sufficient_teams:
        public["reason"] = "해당 팀 종료 표본 8경기 미만 · 기초모형 유지"
    audit["opponent_model"] = public
    if active:
        eh, ea = predict_goals(parameters, home_id, away_id)
        exp_h, exp_a = [round(max(.3, min(3.2, g*(1-max(0, min(.3, float(p or 0)))))), 4)
                        for g, p in ((eh, home_penalty), (ea, away_penalty))]
        audit.update(model=artifact["model_version"], parameters_fitted=True, rho=parameters["rho"],
                     expected_goals={"home": exp_h, "away": exp_a},
                     active_features="time_weighted_opponent_attack_defence_and_single_availability_penalty")
    return exp_h, exp_a, audit


def combine_availability_penalties(injury, lineup, goal_dependency, fatigue, rotation, depth=1.0):
    """Same missing player must not incur injury+lineup+goal-share penalties."""
    absence = max(float(injury or 0), float(lineup or 0), float(goal_dependency or 0))
    schedule = max(float(fatigue or 0), float(rotation or 0))
    return min(0.10, max(0.0, (1 - (1-absence) * (1-schedule)) * float(depth or 1)))


def total_settlement_probabilities(exp_h, exp_a, line, side, matrix=None):
    """Asian totals: distinguish winning stake, refunded stake and loss.

    Three-way handicaps are deliberately NOT treated as Asian handicaps.
    """
    line = float(line)
    if side not in {"under", "over"} or not math.isfinite(line) or line < 0 or abs(line*4-round(line*4)) > 1e-8:
        raise ValueError("unsupported totals contract")
    lines = [line] if abs(line*2-round(line*2)) < 1e-8 else [line-.25, line+.25]
    states = {"win": 0.0, "half_win": 0.0, "push": 0.0, "half_loss": 0.0, "loss": 0.0}
    for h, row in enumerate(build_score_matrix(exp_h, exp_a) if matrix is None else matrix):
        for a, p in enumerate(row):
            results = [(1 if h+a < boundary else -1 if h+a > boundary else 0) * (1 if side == "under" else -1)
                       for boundary in lines]
            result = sum(results) / len(results)
            states[{1: "win", .5: "half_win", 0: "push", -.5: "half_loss", -1: "loss"}[result]] += p
    win_weight = states["win"] + .5 * states["half_win"]
    loss_weight = states["loss"] + .5 * states["half_loss"]
    states.update(win_weight=win_weight, loss_weight=loss_weight,
                  refund_weight=1-win_weight-loss_weight,
                  profit_probability=states["win"]+states["half_win"],
                  fair_decimal_odds=1+loss_weight/win_weight if win_weight > 0 else None)
    return states


def normalize_probabilities(values):
    cleaned = [max(0.0, float(value or 0.0)) for value in values]
    total = sum(cleaned)
    if total <= 0:
        return [1.0 / len(cleaned)] * len(cleaned)
    return [value / total for value in cleaned]


def _temperature_scale(values, temperature):
    normalized = normalize_probabilities(values)
    powered = [value ** (1.0 / max(1.0, temperature)) if value > 0 else 0.0 for value in normalized]
    return normalize_probabilities(powered)


def _cap_probabilities(values, cap):
    values = normalize_probabilities(values)
    for _ in range(len(values) + 2):
        highest = max(range(len(values)), key=values.__getitem__)
        if values[highest] <= cap + 1e-12:
            break
        excess = values[highest] - cap
        values[highest] = cap
        other_total = sum(values[index] for index in range(len(values)) if index != highest)
        for index in range(len(values)):
            if index != highest:
                values[index] += excess * (values[index] / other_total if other_total else 1.0 / (len(values) - 1))
    return normalize_probabilities(values)


def calibrate_three_way_probabilities(model_probs, odds, confidence):
    """모델 과신을 낮추고 실제 배당의 마진 제거 확률을 일부 혼합한다."""
    confidence = max(0.35, min(0.95, float(confidence or 0.35)))
    temperature = 1.55 - (0.45 * confidence)
    model = _temperature_scale(model_probs, temperature)
    valid_odds = len(odds) == 3 and all(float(odd or 0) > 1.0 for odd in odds)
    if valid_odds:
        market = normalize_probabilities([1.0 / float(odd) for odd in odds])
        market_weight = 0.45 - (0.18 * confidence)
        model = [(1.0 - market_weight) * m + market_weight * q for m, q in zip(model, market)]
    # A fractional three-way handicap has no draw. Calibration must not turn
    # an impossible outcome into a positive-probability candidate.
    model = [p if float(raw) > 0 else 0.0 for p, raw in zip(model, model_probs)]
    return _cap_probabilities(model, 0.80)


def calibrate_two_way_probabilities(model_probs, odds, confidence):
    confidence = max(0.35, min(0.95, float(confidence or 0.35)))
    model = _temperature_scale(model_probs, 1.45 - (0.35 * confidence))
    valid_odds = len(odds) == 2 and all(float(odd or 0) > 1.0 for odd in odds)
    if valid_odds:
        market = normalize_probabilities([1.0 / float(odd) for odd in odds])
        market_weight = 0.42 - (0.15 * confidence)
        model = [(1.0 - market_weight) * m + market_weight * q for m, q in zip(model, market)]
    return _cap_probabilities(model, 0.82)

def generate_match_story(best_prob_pick, best_ev_pick, math_exp_h, math_exp_a, prob_h, prob_d, prob_a, h2h_h, h2h_a, home, away, odd_h, odd_a, h_form, a_form, h_long, a_long, h_inj_data, a_inj_data, h_rest, a_rest, h_next, a_next, h_rank, a_rank, h_market, a_market, h_stats, a_stats, referee, weather, h_extreme, a_extreme, h_lineup_msg, a_lineup_msg):
    story_parts = []
    story_parts.append(f"📈 [딕슨-콜스 모델] 양 팀의 공격/수비 지수를 환산한 결과, 예상 정규시간 득점은 {home} <b style='color:#00F2FE;'>{math_exp_h:.1f}골</b>, {away} <b style='color:#EF4444;'>{math_exp_a:.1f}골</b>로 산출되었습니다.")
    if referee and any(sr.lower() in referee.lower() for sr in STRICT_REFEREES): 
        story_parts.append(f"🟨 [카드 캡처 주의] 악명 높은 엄격한 성향의 주심({referee})이 배정되었습니다. 예기치 않은 변수에 주의하세요.")
    if weather in ["Rain", "Snow"]:
        w_ko = "폭우" if weather == "Rain" else "폭설"
        story_parts.append(f"⛈️ [기상 악화 특보] 경기장 현지에 {w_ko}가 예보되어 늪축구 양상(언더)이 예상됩니다.")
    if h_extreme: story_parts.append(f"✈️ {home}은(는) 대륙간 장거리 원정으로 극심한 피로 누적이 우려됩니다.")
    if a_extreme: story_parts.append(f"✈️ 원정팀 {away}은(는) 대륙간 장거리 원정 직후라 체력 방전이 뚜렷합니다.")
     
    if h_next["is_important"] and h_next["days_until_next"] <= 4: story_parts.append(f"⚠️ [조기 경보] {home}은(는) {h_next['days_until_next']}일 뒤 챔스/컵 일정이 겹쳐 있어, 정상 전력 가동이 불투명합니다. (배팅 시 로테이션 주의!)")
    if a_next["is_important"] and a_next["days_until_next"] <= 4: story_parts.append(f"⚠️ [조기 경보] {away} 측은 {a_next['days_until_next']}일 뒤 중요 일정 탓에 선발 명단 변동 확률이 매우 높습니다.")
     
    if h_market > 0: story_parts.append(f"💸 [마켓 알럿] 글로벌 도박사들의 자금이 {home} 쪽으로 집중되며 정배 흐름이 강해지고 있습니다.")
    elif a_market > 0: story_parts.append(f"💸 [마켓 알럿] 해외 시장에서 {away} 승리(역배)에 스마트머니가 쏠리며 가치가 급상승 중입니다!")
     
    if h_lineup_msg: story_parts.append(h_lineup_msg)
    elif h_inj_data['ace_missing']: story_parts.append(f"🚨 [선제 타격] {home} 핵심 에이스({', '.join(h_inj_data['ace_names'])}) 결장 의심! 전력 누수가 치명적입니다.")
    if a_lineup_msg: story_parts.append(a_lineup_msg)
    elif a_inj_data['ace_missing']: story_parts.append(f"🚨 [선제 타격] 원정팀 {away} 핵심 자원({', '.join(a_inj_data['ace_names'])}) 결장 의심으로 공격 전 창의성이 떨어질 전망입니다.")
     
    if best_prob_pick == best_ev_pick:
        story_parts.append(f"🤖 현재 확보된 데이터에서 확률과 배당 가치가 함께 우세한 후보는 **[{best_prob_pick}]**입니다. 경기 직전 선발 변동에 따라 최종 판단이 달라질 수 있습니다.")
    else:
        story_parts.append(f"🤖 현재 모델의 **상대적으로 안정적인 후보는 [{best_prob_pick}]**이며, 배당 대비 확률 차이가 있는 **가치 후보는 [{best_ev_pick}]**입니다. 두 항목 모두 적중을 보장하지 않습니다.")
         
    return " ".join(story_parts)

def evaluate_single_pick(pick_str, h_team, a_team, goals_h, goals_a):
    pick_str = str(pick_str or "").upper()
    h_team = str(h_team or "").upper()
    a_team = str(a_team or "").upper()
    picks = [p.strip() for p in pick_str.split(",")]
    
    for pick in picks:
        if "핸디" in pick or "적용 후" in pick:
            # 핸디캡은 팀명이 들어 있는지만 보면 안 된다. 예를 들어
            # "[+1.0] 파주 핸디패"는 홈팀 이름을 포함하지만, +1 적용 뒤
            # 홈팀이 앞서면 명백한 미적중이다. 문구에 선언된 승/무/패와
            # 실제 조정 점수를 직접 비교한다.
            m_handi = re.search(r'\[\s*([+-]?\d+(?:\.\d+)?)\s*\]', pick)
            if not m_handi:
                m_handi = re.search(
                    r'([+-]?\d+(?:\.\d+)?)\s*(?:적용\s*후|HANDICAP)', pick
                )
            if m_handi:
                h_base = float(m_handi.group(1))
                adjusted_home = float(goals_h) + h_base
                actual = (
                    "승" if adjusted_home > float(goals_a)
                    else "패" if adjusted_home < float(goals_a)
                    else "무"
                )
                expected_match = re.search(
                    r'(?:핸디|적용\s*후)\s*(승|무|패)', pick
                )
                if expected_match and expected_match.group(1) == actual:
                    return 1
            continue

        if ("무승부" in pick or pick == "무" or "DRAW" in pick):
            if goals_h == goals_a: return 1
        if "승" in pick or "WIN" in pick:
            if a_team and a_team in pick:
                if goals_h < goals_a: return 1
            elif goals_h > goals_a and (not h_team or h_team in pick or pick == "승"):
                return 1
        if pick == "패" and goals_h < goals_a:
            return 1
                
        if "언더" in pick or "오버" in pick:
            m_uo = re.search(r'(\d+(?:\.\d+)?)', pick)
            if m_uo:
                uo_base = float(m_uo.group(1))
                if "언더" in pick and (goals_h + goals_a) < uo_base: return 1
                if "오버" in pick and (goals_h + goals_a) > uo_base: return 1
                
    return 0

def generate_real_ai_note(
    fixture_id, goals_h, goals_a, is_correct_prob, is_correct_ev, has_ev_pick=True,
    home_team="", away_team="", prob_pick="", ev_pick="", event_timeline=None,
    return_postmortem=False, fetch_official_stats=True,
):
    """Record verified score, official facts, and deterministic miss reasons."""
    normalized_stats = []
    try:
        if fetch_official_stats:
            stat_res = api_get("/fixtures/statistics", params={"fixture": fixture_id}, timeout=5, purpose="scoring")
            raw_stats = stat_res.json().get("response", []) if stat_res.status_code == 200 else []
            normalized_stats = normalize_official_stats(raw_stats)
    except Exception:
        normalized_stats = []

    result_parts = [
        f"최종 추천픽 {'적중' if is_correct_prob == 1 else '미적중'}",
        (
            f"기존 배당형 대안픽 {'적중' if is_correct_ev == 1 else '미적중'}"
            if has_ev_pick else "공식 예측은 최종 추천픽 1개"
        ),
    ]
    payload = build_postmortem(
        home_team=home_team,
        away_team=away_team,
        prob_pick=prob_pick,
        ev_pick=ev_pick,
        goals_h=int(goals_h),
        goals_a=int(goals_a),
        is_correct_prob=is_correct_prob,
        is_correct_ev=is_correct_ev,
        has_ev_pick=has_ev_pick,
        official_stats=normalized_stats,
        event_timeline=event_timeline or [],
    )
    note_parts = [
        f"[채점 결과] {' · '.join(result_parts)}.",
        f"[최종 점수] {int(goals_h)}:{int(goals_a)}.",
    ]
    stats_text = official_stats_text(normalized_stats)
    if stats_text:
        note_parts.append(f"[공식 경기 통계] {stats_text}.")
    review_text = postmortem_text(payload)
    if review_text:
        note_parts.append(review_text)
    note = "\n\n".join(note_parts)
    encoded = postmortem_json(payload)
    return (note, encoded) if return_postmortem else note
