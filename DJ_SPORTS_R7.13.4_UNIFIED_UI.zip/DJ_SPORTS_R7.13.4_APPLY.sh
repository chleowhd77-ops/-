#!/usr/bin/env bash
# R7.13.4 unified UI / grading / confirmed-alias deployment.
# Run from /home/ubuntu after uploading the ZIP to /tmp.
set -euo pipefail

ARCHIVE="${1:?usage: bash DJ_SPORTS_R7.13.4_APPLY.sh /tmp/DJ_SPORTS_R7.13.4_UNIFIED_UI.zip}"
APP_ROOT="/home/ubuntu"
STAGE_DIR="$(mktemp -d /tmp/dj-r7134.XXXXXX)"
STAMP="$(date +%Y%m%d_%H%M%S)"

cleanup() { rm -rf "$STAGE_DIR"; }
trap cleanup EXIT

unzip -q "$ARCHIVE" -d "$STAGE_DIR"
for file in app.py collector.py api_engine.py manager_investment_autopilot.py team_alias_admin.py; do
  test -f "$STAGE_DIR/$file"
done

python3 -m py_compile \
  "$STAGE_DIR/app.py" "$STAGE_DIR/collector.py" "$STAGE_DIR/api_engine.py" \
  "$STAGE_DIR/manager_investment_autopilot.py" "$STAGE_DIR/team_alias_admin.py"

BACKUP_DIR="$APP_ROOT/backup_r7134_$STAMP"
mkdir -p "$BACKUP_DIR"
for file in app.py collector.py api_engine.py manager_investment_autopilot.py team_alias_admin.py; do
  test ! -f "$APP_ROOT/$file" || cp -a "$APP_ROOT/$file" "$BACKUP_DIR/$file"
  install -m 0644 "$STAGE_DIR/$file" "$APP_ROOT/$file"
done
chmod 0755 "$APP_ROOT/team_alias_admin.py"

# Database files are intentionally never copied, removed, reset, or restored.
sudo systemctl restart dj-collector.service
sudo systemctl is-active dj-collector.service
echo "R7.13.4 적용 완료 · 소스 백업: $BACKUP_DIR · DB 보존"
