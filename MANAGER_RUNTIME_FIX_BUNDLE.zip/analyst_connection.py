"""Lightweight connectivity checks; never sends a model request or credentials."""
import http.client
from analyst_codex_generator import MethodWaiting


def require_connection():
    connection = http.client.HTTPSConnection('chatgpt.com', timeout=5)
    try:
        connection.request('HEAD','/')
        connection.getresponse().close()
    except (OSError, http.client.HTTPException) as error:
        raise MethodWaiting('WAITING_NETWORK', '인터넷 연결 확인 실패: 자동 재요청 없이 중단. 연결 복구 후 직접 재개 필요') from error
    finally:
        connection.close()
