"""Shared CLI preflight and private failure receipts; no analysis retry."""
import hashlib
import json
import os
from pathlib import Path
import re
from threading import Lock
import time
import traceback


def redact(text):
    text=re.sub(r'(?i)(bearer\s+)[^\s"\']+',r'\1[REDACTED]',str(text))
    text=re.sub(r'\b(?:sk-|oaistb_)[A-Za-z0-9_.-]+','[REDACTED]',text)
    return re.sub(r'(?i)((?:access_token|refresh_token|api_key|authorization)["\']?\s*[:=]\s*["\']?)[^\s,"\'}]+',r'\1[REDACTED]',text)


def save(path,value):
    raw=value if isinstance(value,str) else json.dumps(value,ensure_ascii=False,indent=2)
    with Path(path).open('x',encoding='utf-8') as f:
        os.chmod(path,0o600)
        f.write(raw)


def attach_diagnostics(client,state):
    original=client._command
    def command(argv,cwd,payload=None,timeout=15):
        if payload is None:return original(argv,cwd,payload,timeout)
        # Receipts are private. Original prompts/answers and request IDs stay unchanged.
        root=Path(state)/'diagnostics'
        root.mkdir(parents=True,exist_ok=True,mode=0o700)
        folder=root/(str(time.time_ns())+'-'+hashlib.sha256(payload).hexdigest()[:12])
        folder.mkdir(mode=0o700)
        save(folder/'started.json',{'input_bytes':len(payload),'input_sha256':hashlib.sha256(payload).hexdigest(),
             'timeout_seconds':timeout,'automatic_retry':False})
        try:
            code,out,err=original(argv,cwd,payload,timeout)
        except BaseException as error:
            save(folder/'failure.json',{'type':type(error).__name__,'error':redact(str(error)),
                'traceback':redact(traceback.format_exc()),'automatic_retry':False})
            raise
        # Keep returned events before the original response validator can reject them.
        save(folder/'events.log',redact(out))
        save(folder/'stderr.log',redact(err))
        save(folder/'finished.json',{'exit_code':code,'automatic_retry':False})
        return code,out,err
    client._command=command


class SharedPreflight:
    def __init__(self):
        self.lock=Lock()
        self.executable=None
        self.error=None

    def ensure(self,client):
        with self.lock:
            if self.error is not None:raise self.error
            if self.executable is not None:
                client.executable=self.executable
                return
            original=client._command
            def check_command(argv,cwd,payload=None,timeout=15):
                if payload is not None or argv[1:] not in (['exec','--help'],['login','status']):
                    raise ValueError('실행 확인 중 예상하지 않은 요청 차단')
                return original(argv,cwd,payload,60)
            print('공통 실행·로그인 확인 시작 (각 단계 최대 60초)',flush=True)
            client._command=check_command
            try:
                client.check()
                self.executable=client.executable
            except Exception as error:
                self.error=error
                raise
            finally:client._command=original
            print('공통 실행·로그인 확인 완료',flush=True)
