"""Validate current weather observations without inventing a kickoff forecast."""
from copy import deepcopy


def condition_from_description(description):
    text = str(description or '').strip().casefold()
    for words, condition in (
        (('thunder',), 'Thunderstorm'),
        (('snow', 'blizzard', 'sleet', 'ice pellet'), 'Snow'),
        (('rain', 'shower', 'drizzle'), 'Rain'),
        (('fog',), 'Fog'),
        (('mist', 'haze'), 'Mist'),
        (('cloud', 'overcast'), 'Cloudy'),
        (('sunny', 'clear'), 'Clear'),
    ):
        if any(word in text for word in words):
            return condition
    return 'Unknown'


def normalize_observation(details):
    result = deepcopy(details) if isinstance(details, dict) else {}
    condition = condition_from_description(result.get('description'))
    available = result.get('available') is True and condition != 'Unknown'
    result.update(
        available=available, condition=condition if available else 'Unknown',
        data_kind='current_observation', kickoff_forecast_available=False,
        interpretation='수집 당시 관측 날씨입니다. 경기 시작 시각의 예보로 사용하지 마세요.'
                       if available else '날씨 미확인. 맑음이나 기상 영향 없음으로 해석하지 마세요.',
    )
    return result


def correct_evidence_weather(evidence):
    result = deepcopy(evidence)
    environment = result.get('environment')
    if isinstance(environment, dict):
        details = normalize_observation(environment.get('weather_details'))
        environment['weather_details'] = details
        environment['weather'] = details['condition']
    return result
