from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,threading,time
from analyst_codex_generator import MethodWaiting
ROOT=Path(__file__).resolve().parent
RUN=ROOT/'runtime';DATA=ROOT/'data';STATUS=ROOT/'results/status.json'
STOP=RUN/'STOP';LIMIT=0;DEADLINE=0;CODEX_COMMAND=None
LOCK=threading.RLock()
def update_status():pass
def encode(v):
    return json.dumps(v, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)

def digest(v):
    return hashlib.sha256(encode(v).encode()).hexdigest()

def load(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def atomic(p, v):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + '.tmp-' + str(threading.get_ident()))
    tmp.write_text(encode(v), encoding='utf-8')
    os.replace(tmp, p)

def once(p, v):
    p = Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        if load(p) != v:
            raise ValueError('Refusing to replace a frozen record: ' + p.name)
        return
    with p.open('x', encoding='utf-8') as f:
        f.write(encode(v)); f.flush(); os.fsync(f.fileno())

def event(engine, phase, **details):
    with LOCK:
        p = RUN / 'events.jsonl'
        with p.open('a', encoding='utf-8') as f:
            f.write(encode({'at':datetime.now(timezone.utc).isoformat(), 'analyst':engine,
                          'phase':phase, **details}) + '\n')
        update_status()
    print(engine, phase, encode(details), flush=True)

def object_schema(properties):
    return {'type':'object', 'additionalProperties':False, 'properties':properties,
            'required':list(properties)}

def guarded_client(author, engine):
    original = author.client._command
    def command(command, cwd, payload=None, timeout=15):
        if payload is not None:
            with LOCK:
                if STOP.exists() or time.time() >= DEADLINE:
                    raise MethodWaiting('WAITING_STOP','Night study stopped or deadline reached')
                budget = load(RUN/'request-budget.json')
                if budget['requests'] >= LIMIT:
                    raise MethodWaiting('WAITING_BUDGET','Bounded request limit reached')
                budget['requests'] += 1
                atomic(RUN/'request-budget.json', budget)
                event(engine, 'model_request_started', count=budget['requests'])
            command = list(command)
            command[-1:-1] = ['-c', 'features.code_mode.enabled=false']
        return original(command, cwd, payload, timeout)
    author.client._command = command

def validate_portfolio(ids, expected):
    if not isinstance(ids,list) or not 1 <= len(ids) <= min(10,len(expected)) or len(ids)!=len(set(ids)) or not set(ids)<=set(expected):
        raise ValueError('Portfolio must contain 1 to 10 distinct original case IDs')

def grade(cases, answers, selected):
    by_id = {c['case_id']:c for c in cases}
    rows = []
    for cid in selected:
        c = by_id[cid]; answer = answers[cid]
        option = next(o for o in c['question']['options'] if o['option_id']==answer['selected_id'])
        hit = bool(c['answers'][answer['selected_id']])
        rows.append({'case_id':cid,'selected_id':answer['selected_id'],'odd':option['odd'],
            'probability':answer['scores'][answer['selected_id']], 'hit':hit,
            'net_units':option['odd']*int(hit)-1})
    profit = sum(r['net_units'] for r in rows)
    return {'picked':len(rows),'hits':sum(r['hit'] for r in rows),
        'hit_rate':sum(r['hit'] for r in rows)/len(rows), 'net_units':profit,
        'unit_stake_each':1,'ROI':profit/len(rows),'rows':rows,
        'definition':'retrospective first answers; outcomes hidden until portfolio frozen'}
