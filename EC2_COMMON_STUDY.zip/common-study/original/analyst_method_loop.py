"""Open source-code revision, own-answer review and persistent per-analyst memory.

No list of learner families or teacher-authored football feature weights.
Missing generation/isolation is reported explicitly; never relabel the old
closed model selector as successful autonomous method revision.
"""
import argparse
import ast
import copy
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import sqlite3
import subprocess
import tempfile
import time

from learning_state import atomic_json, digest, now_iso, read_json
from analyst_codex_generator import CodexSubscriptionGenerator, MethodWaiting

ENGINES = ('official', 'robot_proto', 'robot_toto14', 'v2', 'v3')
ANSWER_KEYS = {'actual_result', 'actual_score', 'actual_home_goals', 'actual_away_goals',
               'is_correct', 'outcome', 'result_known_at', 'result_known_timestamp',
               'postmortem_json', 'candidate_results_json', 'robot_pick_correct'}
FORECAST_KEYS = {'prob', 'probability', 'model_probability', 'raw_model_probability',
                 'robust_probability', 'robot_probability', 'v3_probability',
                 'school_probability', 'robot_pick', 'model_context',
                 'goal_model_audit', 'context_audit', 'derived_signals'}


def clean_question(value):
    if isinstance(value, dict):
        return {k: clean_question(v) for k, v in value.items()
                if k not in ANSWER_KEYS | FORECAST_KEYS}
    if isinstance(value, list):
        return [clean_question(v) for v in value]
    return value


def option_id(row):
    def line(value):
        return float(value) if value is not None else None
    return digest([row.get('market_key'), row.get('selection_side'),
                   line(row.get('handicap_base')),line(row.get('totals_base')),row.get('raw_pick')])


def observed_evidence(evidence, cutoff):
    """Quarantine explicit future observations; this is not a complete source audit."""
    from scorecard_core import epoch
    excluded = []
    def walk(node, path='evidence'):
        if isinstance(node,list):
            return [value for i,item in enumerate(node)
                    if (value:=walk(item,path+'.'+str(i))) is not None]
        if not isinstance(node,dict):
            return node
        for field in ('observed_at','known_at','updated_at'):
            if field in node and epoch(node[field]) > cutoff:
                excluded.append(path+': '+field+' after capture')
                return None
        if node.get('last_h2h_date'):
            day = epoch(node['last_h2h_date'])
            if not day or int(day//86400) >= int(cutoff//86400):
                excluded.append(path+': h2h observation not verified before capture')
                return None
        result = {}
        for key,value in node.items():
            item = walk(value,path+'.'+key)
            if item is not None:
                result[key]=item
        return result
    return walk(clean_question(evidence)) or {}, excluded


def question(evidence, candidates, identity, objective='manager', captured_at=None):
    from manager_learning_goal import manager_target
    options = []
    for candidate in candidates:
        try:
            odd = float(candidate.get('odd') or 0)
        except (ValueError, TypeError):
            continue
        if not math.isfinite(odd) or odd <= 1:
            continue
        if objective == 'manager' and not manager_target(candidate, candidates):
            continue
        if objective == 'toto14' and candidate.get('market_key') != '1x2':
            continue
        options.append({**clean_question(candidate), 'option_id': option_id(candidate)})
    unique = {o['option_id']:o for o in options}
    cutoff = captured_at if captured_at is not None else min(time.time(),identity['kickoff'])
    clean,excluded = observed_evidence(evidence,cutoff)
    return {'identity': identity, 'evidence': clean, 'input_exclusions':excluded,
            'all_market_quotes': clean_question(candidates), 'options': list(unique.values()),
            'objective': objective}


def correct_options(q, home_goals, away_goals):
    result = {}
    for o in q['options']:
        difference = home_goals - away_goals
        if o['market_key'] == 'handicap':
            difference += float(o['handicap_base'])
        if o['market_key'] == 'totals':
            total = home_goals + away_goals
            line = float(o['totals_base'])
            if total == line:
                raise ValueError('push settlement is not a binary answer')
            hit = total > line if o['selection_side'] == 'over' else total < line
        else:
            side = 'home' if difference > 0 else 'away' if difference < 0 else 'draw'
            hit = side == o['selection_side']
        result[o['option_id']] = int(hit)
    return result


def load_cases(root, objective='manager', engine='official'):
    """Use the same full pre-match packets for all four analysts, with own picks.

    Identity includes fixture, teams AND kickoff, not abbreviated team names.
    Merge observed prices only within that identity and before that capture.
    """
    path = Path(root) / 'ai_predictions.db'
    with sqlite3.connect(f'file:{path.resolve()}?mode=ro', uri=True) as db:
        db.row_factory = sqlite3.Row
        tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if 'robot_learning_samples' not in tables:
            return []
        columns = {r[1] for r in db.execute('PRAGMA table_info(robot_learning_samples)')}
        needed = {'full_evidence_json', 'candidates_json', 'kickoff_timestamp',
                  'captured_timestamp', 'result_known_timestamp', 'api_fixture_id',
                  'home_team', 'away_team', 'actual_home_goals', 'actual_away_goals'}
        if not needed <= columns:
            raise MethodWaiting('WAITING_DATA', '공통 원본 분석자료·시각 컬럼 확인 필요')
        cases = {}
        for row in db.execute('''SELECT * FROM robot_learning_samples
            WHERE actual_home_goals IS NOT NULL AND actual_away_goals IS NOT NULL
              AND captured_timestamp > 0 AND captured_timestamp < kickoff_timestamp
              AND kickoff_timestamp < result_known_timestamp
              AND api_fixture_id > 0 ORDER BY captured_timestamp,id'''):
            identity = {'fixture_id': row['api_fixture_id'], 'home': row['home_team'],
                        'away': row['away_team'], 'kickoff': row['kickoff_timestamp']}
            key = digest(identity)
            try:
                evidence = json.loads(row['full_evidence_json'] or '{}')
                candidates = json.loads(row['candidates_json'] or '[]')
                if not isinstance(evidence, dict) or not evidence:
                    continue
                # Later zero-priced Toto observations must not erase observed Proto prices.
                old = cases.get(key)
                quoted = {option_id(c): c for c in (old or {}).get('quotes', [])}
                for c in candidates:
                    if float(c.get('odd') or 0) > 1:
                        quoted[option_id(c)] = c
                quotes = list(quoted.values())
                q = question(evidence,quotes,identity,objective,captured_at=row['captured_timestamp'])
                if not q['options']:
                    continue
                hg, ag = int(row['actual_home_goals']), int(row['actual_away_goals'])
                if old and old['score'] != [hg, ag]:
                    raise ValueError('conflicting final result')
                cases[key] = {'case_id': key, 'question': q, 'quotes': quotes,
                              'match_id':row['match_id'],
                              'observed_at': row['captured_timestamp'],
                              'known_at': row['result_known_timestamp'], 'score': [hg, ag],
                              'answers': correct_options(q, hg, ag)}
            except (ValueError, TypeError, KeyError):
                # Malformed packets are not relabelled as valid training material.
                continue
        # Bootstrapping uses each analyst's actually saved answer, never a later reconstruction.
        own = {}
        if 'three_engine_pick_snapshots' in tables:
            name = 'robot' if engine.startswith('robot_') else engine
            for r in db.execute('''SELECT api_fixture_id,home_team,away_team,kickoff_timestamp,
                captured_timestamp,market_key,selection_side,raw_pick,pick_json
                FROM three_engine_pick_snapshots WHERE engine_key=?
                  AND captured_timestamp>0 AND captured_timestamp<kickoff_timestamp
                ORDER BY captured_timestamp,id''', (name,)):
                ident = {'fixture_id': r[0], 'home': r[1], 'away': r[2], 'kickoff': r[3]}
                c = cases.get(digest(ident))
                if c and r[4] <= c['observed_at']:
                    raw = json.loads(r[8] or '{}')
                    raw.update(market_key=r[5], selection_side=r[6], raw_pick=r[7])
                    own[c['case_id']] = option_id(raw)
        # V3's original publication ledger is distinct from three_engine snapshots.
        if engine == 'v3':
            ledger = read_json(Path(root)/'v3_learning_picks.json').get('picks') or {}
            for v in ledger.values():
                if isinstance(v, dict):
                    from scorecard_core import epoch
                    frozen = epoch(v.get('frozen_at'))
                    if not 0 < frozen:
                        continue
                    # Older V3 files omit teams/fixture/side. Require the original
                    # snapshot joined to the same fixture, teams AND kickoff.
                    if 'prediction_analysis_snapshots' not in tables or 'predictions' not in tables:
                        continue
                    linked = db.execute('''SELECT p.api_fixture_id,p.home_team,p.away_team,p.match_time
                        FROM prediction_analysis_snapshots s JOIN predictions p ON p.match_id=s.match_id
                        WHERE s.id=? AND s.match_id=?''',
                        (v.get('source_snapshot_id'),v.get('match_id'))).fetchone()
                    from scorecard_core import KST
                    if not linked:
                        continue
                    ident = {'fixture_id':linked[0],'home':linked[1],'away':linked[2],
                             'kickoff':epoch(linked[3],KST)}
                    c = cases.get(digest(ident))
                    if not c or frozen > c['observed_at']:
                        continue
                    matches = [o for o in c['question']['options']
                               if o.get('market_key') == v.get('market_key')
                               and o.get('raw_pick') == v.get('raw_pick')]
                    if len(matches) == 1:
                        own[c['case_id']] = matches[0]['option_id']
        for c in cases.values():
            c['saved_own_selection'] = own.get(c['case_id'])
            c.pop('quotes')
        return sorted(cases.values(), key=lambda c: c['question']['identity']['kickoff'])


def review_case(case, result, version):
    selected = result['selected_id']
    options = {o['option_id']: o for o in case['question']['options']}
    if selected not in options:
        raise ValueError('answer is not an available option')
    return {'case_id': case['case_id'], 'question': case['question'],
            'own_selected_id': selected, 'own_probabilities': result.get('scores', {}),
            'actual_score': case['score'], 'correct_options': case['answers'],
            'was_correct': bool(case['answers'][selected]), 'model_version': version,
            'known_at': case['known_at'],
            'review_state': 'CORRECT' if case['answers'][selected] else 'AWAITING_REFLECTION',
            'causal_notice': '최종 결과만으로 원인을 단정하지 않고 원자료로 검증할 가설을 기록함'}


def validate_results(questions, results):
    if not isinstance(results, list) or len(results) != len(questions):
        raise ValueError('method must answer every submitted question')
    for q, r in zip(questions, results):
        ids = {o['option_id'] for o in q['options']}
        if not isinstance(r, dict) or r.get('selected_id') not in ids:
            raise ValueError('method selected a missing option')
        scores = r.get('scores')
        if not isinstance(scores, dict) or set(scores) != ids:
            raise ValueError('method must score every available option')
        if any(not isinstance(v, (float, int)) or isinstance(v, bool)
               or not math.isfinite(v) or not 0 <= v <= 1 for v in scores.values()):
            raise ValueError('invalid method probability')
    return results


def configured_generator(settings):
    if not settings.get('generator_enabled'):
        raise MethodWaiting('WAITING_GENERATOR','자동 분석 코드 수정 연결을 아직 활성화하지 않음')
    if settings.get('generator_kind') != 'codex_subscription' or settings.get('generator_url'):
        raise MethodWaiting('WAITING_GENERATOR','ChatGPT 구독 연결만 허용: 기존 유료 API 설정을 전환해야 함')
    generator = CodexSubscriptionGenerator(settings)
    generator.check()
    return generator


class ContainerExecutor:
    """Generated code sees only the packet/state, no DB, credentials or network."""
    def __init__(self, config):
        self.config = config

    def check(self):
        if not shutil.which('docker'):
            raise MethodWaiting('WAITING_ISOLATION', '분석 코드 격리 실행용 Docker 미설치')
        image = self.config.get('image','dj-analyst-python:local')
        try:
            check = subprocess.run(['docker','image','inspect',image],stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL,timeout=10)
        except (OSError,subprocess.TimeoutExpired):
            raise MethodWaiting('WAITING_ISOLATION','격리 실행용 Docker 상태 확인 필요')
        if check.returncode:
            raise MethodWaiting('WAITING_ISOLATION','격리 실행용 Docker 이미지 준비 필요')

    def run(self, source, packet):
        size = int(self.config.get('prediction_batch_size', 0))
        if packet.get('action') == 'predict' and size > 0 and len(packet['questions']) > size:
            results = []
            questions = packet['questions']
            for start in range(0, len(questions), size):
                batch = questions[start:start + size]
                answer = self._run_once(source, {**packet, 'questions':batch})
                if not isinstance(answer, list) or len(answer) != len(batch):
                    raise ValueError('Prediction batch returned the wrong number of answers')
                results.extend(answer)
                print(f'PC 경기 계산: {len(results)}/{len(questions)}', flush=True)
            return results
        return self._run_once(source, packet)

    def _run_once(self, source, packet):
        self.check()
        with tempfile.TemporaryDirectory(prefix='dj-analyst-') as folder:
            path = Path(folder)
            (path/'program.py').write_text(source)
            shutil.copyfile(Path(__file__).with_name('analyst_program_runner.py'), path/'runner.py')
            os.chmod(path, 0o755)
            for child in path.iterdir():
                os.chmod(child, 0o444)
            name = 'dj-method-' + digest([time.time_ns(), os.getpid()])[:16]
            command = ['docker', 'run', '--rm', '-i', '--name', name, '--network=none',
                       '--read-only', '--cap-drop=ALL', '--security-opt=no-new-privileges',
                       '--user=65534:65534', '--pids-limit=64', '--cpus=1',
                       '--memory='+str(self.config.get('memory', '1g')),
                       '--tmpfs=/tmp:rw,noexec,nosuid,size=128m',
                       '-v', str(path)+':/method:ro',
                       self.config.get('image', 'dj-analyst-python:local'),
                       'python', '-B', '/method/runner.py']
            with tempfile.TemporaryFile() as output, tempfile.TemporaryFile() as errors:
                process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=output, stderr=errors)
                try:
                    process.communicate(json.dumps(packet, allow_nan=False).encode(),
                                        timeout=int(self.config.get('execution_timeout', 60)))
                except subprocess.TimeoutExpired:
                    subprocess.run(['docker','rm','-f',name], stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL, timeout=10)
                    process.kill(); process.wait()
                    raise RuntimeError('analyst method execution timed out')
                if process.returncode:
                    raise RuntimeError('isolated analyst method failed; exit '+str(process.returncode))
                output.seek(0)
                data = output.read(int(self.config.get('max_output_bytes', 8*1024*1024))+1)
                if len(data) > int(self.config.get('max_output_bytes', 8*1024*1024)):
                    raise RuntimeError('analyst method output too large')
                return json.loads(data)


def check_source(source):
    if not isinstance(source, str) or not source.strip():
        raise ValueError('generator did not supply analysis source')
    tree = ast.parse(source)
    functions = {n.name for n in tree.body if isinstance(n, ast.FunctionDef)}
    if not {'learn', 'predict'} <= functions:
        raise ValueError('method must define learn(cases,memory) and predict(question,state,memory)')


def measure(cases, results):
    validate_results([c['question'] for c in cases], results)
    hits = 0; gross = 0
    for c, r in zip(cases, results):
        selected = r['selected_id']
        hit = c['answers'][selected]
        odd = next(o['odd'] for o in c['question']['options'] if o['option_id'] == selected)
        hits += hit; gross += hit * odd
    n = len(cases)
    return {'matches': n, 'hits': hits, 'accuracy': hits/n, 'unit_roi': gross/n-1}


def config(root):
    return read_json(Path(root)/'analyst_method_config.json')


def course_engines(root):
    robot = 'robot_toto14' if config(root).get('objective')=='toto14' else 'robot_proto'
    return ('official',robot,'v2','v3')


def folder_for(root, engine):
    if engine not in ENGINES:
        raise ValueError('unknown analyst')
    return Path(root)/'analyst_method_memory'/engine


def collect_own_reviews(root, engine, cases):
    """Grade saved own answers even while source generation is unavailable."""
    folder = folder_for(root,engine)
    memory = read_json(folder/'memory.json', {'cases':{},'revisions':[]})
    by_identity = {digest(c['question']['identity']):c for c in cases}
    for case in cases:
        selected = case.get('saved_own_selection')
        if case['case_id'] not in memory['cases'] and selected in case['answers']:
            memory['cases'][case['case_id']] = review_case(case,{'selected_id':selected},'saved-pre-match-answer')
    for path in (folder/'pending').glob('*.json'):
        receipt = read_json(path)
        q = receipt.get('question') or {}
        case = by_identity.get(digest(q.get('identity')))
        if not case or digest(receipt) in memory.get('graded_receipts',[]):
            continue
        from scorecard_core import epoch
        captured = epoch(receipt.get('captured_at'))
        if not 0 < captured < case['question']['identity']['kickoff']:
            continue
        frozen = {**case,'question':q,'answers':correct_options(q,*case['score'])}
        validated = validate_results([q],[receipt['answer']])[0]
        memory['cases'][case['case_id']] = review_case(frozen,validated,receipt['version'])
        memory.setdefault('graded_receipts',[]).append(digest(receipt))
    atomic_json(folder/'memory.json',memory)
    return memory


def _learn(root, engine, cases, generator, executor, settings):
    folder = folder_for(root, engine)
    folder.mkdir(parents=True, exist_ok=True)
    memory = read_json(folder/'memory.json', {'cases': {}, 'revisions': []})
    if ((settings.get('continuous_manager') or settings.get('conditional_mistake_corrections')) and settings.get('objective') == 'manager'
            and any(r.get('objective') == 'manager' for r in memory['revisions'])):
        from analyst_repeated_study import advance
        return advance(root,engine,cases,generator,executor,settings)
    prior = read_json(folder/'candidate.json') or read_json(folder/'active.json')
    if not prior and engine=='robot_toto14':
        prior = read_json(folder_for(root,'robot_proto')/'active.json')
    references = []
    if settings.get('include_historical_csv') and cases:
        from analyst_historical_material import load_historical_material
        references = load_historical_material(root, min(c['question']['identity']['kickoff'] for c in cases))
    signature = digest([[[c['case_id'],c['known_at'],c['answers'],c['question'],
                          c.get('saved_own_selection')] for c in cases], references])
    # One material revision is attempted once; config changes explicitly permit retry.
    fingerprint = digest([signature, settings, prior.get('version')])
    status = read_json(folder/'status.json')
    if status.get('attempt_fingerprint') == fingerprint and status.get('status') in ('READY','CANDIDATE_NOT_PASSED'):
        return status
    if len(cases) < 5:
        raise MethodWaiting('WAITING_DATA', '서로 다른 시간의 학습·복기·시험 경기 5건 이상 필요')
    times = sorted({c['question']['identity']['kickoff'] for c in cases})
    if len(times) < 3:
        raise MethodWaiting('WAITING_DATA', '학습·복기·미학습 시험 시각 분리 필요')
    review_time = times[max(1, int(len(times)*.6))]
    exam_time = times[min(len(times)-1, max(2, int(len(times)*.8)))]
    initial = [c for c in cases if c['known_at'] < review_time]
    review = [c for c in cases if review_time <= c['question']['identity']['kickoff'] < exam_time
              and c['known_at'] < exam_time]
    exam = [c for c in cases if c['question']['identity']['kickoff'] >= exam_time]
    if not initial or not review or not exam:
        raise MethodWaiting('WAITING_DATA', '결과 확인 시각까지 분리하면 학습·복기·시험 표본 부족')
    learned = initial + review
    allowed_ids = {c['case_id'] for c in learned}
    # Past memories whose results were unknown at this exam boundary are excluded.
    remembered = {k:v for k,v in memory['cases'].items()
                  if k in allowed_ids and v['known_at'] < exam_time}
    source = prior.get('source', '')
    active = read_json(folder/'active.json')
    compatible_prior = (prior and prior.get('objective')==settings.get('objective','manager')
                        and float(prior.get('learned_through', float('inf'))) < review_time)
    if compatible_prior:
        results = validate_results([c['question'] for c in review], executor.run(source,
            {'action':'predict','questions':[c['question'] for c in review],
             'state':prior['state'],'memory':prior['memory'] if settings.get('conditional_mistake_corrections') else remembered}))
        for c,r in zip(review,results):
            remembered[c['case_id']] = review_case(c,r,prior['version'])
    else:
        for c in learned:
            selected = c.get('saved_own_selection')
            if selected in c['answers']:
                remembered[c['case_id']] = review_case(c, {'selected_id':selected}, 'saved-pre-match-answer')
    bootstrap = None
    prior_reflections = {}
    author_cases = references + learned
    author_memory = remembered
    if not compatible_prior and (settings.get('bootstrap_paper_review') or settings.get('conditional_mistake_corrections')):
        # The first method studies only the early period, then makes its own
        # paper picks on the review period before seeing those answers.
        from analyst_batch_study import BatchedMethodAuthor
        initial_ids = {c['case_id'] for c in initial}
        early_memory = {k:v for k,v in remembered.items() if k in initial_ids}
        early_packet = {
            'protocol':'analyst-method-bootstrap.v1', 'analyst':engine,
            'objective':settings.get('objective','manager'), 'previous_source':'',
            'previous_learned_state':None, 'training_cases':references+initial,
            'own_error_memory':early_memory,
            'interface':{'learn':'learn(cases,memory) returns JSON state',
                         'predict':'predict(question,state,memory) returns {scores:{option_id:probability},selected_id:option_id}'},
            'instructions':'Develop your own method from every supplied raw study record. CSV reference_only records have study_answer and prior_match_reference_ids, not options; learn from their historical scores and conditions without treating final match stats as pre-match features. Ordinary cases have question/options and answers. Do not impose a fixed algorithm family, use old prediction probabilities, invent absent data, or memorize match IDs. Return source, change_summary and reflections for every supplied own mistake. Review-period and exam-period questions and answers are both withheld.'}
        boot_key = digest([early_packet,settings])
        boot_path = folder/'study_bootstrap'/f'{boot_key}.json'
        bootstrap = read_json(boot_path)
        if not bootstrap:
            early_proposal = BatchedMethodAuthor(generator,folder/'study_bootstrap',settings).propose(early_packet)
            check_source(early_proposal['source'])
            early_state = executor.run(early_proposal['source'],
                {'action':'learn','cases':references+initial,'memory':early_memory})
            bootstrap = {'source':early_proposal['source'],'state':early_state,'memory':early_memory,
                         'version':engine+'-bootstrap-'+digest([early_proposal['source'],early_state,boot_key]),
                         'learned_through':max(c['known_at'] for c in initial),
                         'proposal':early_proposal,'objective':settings.get('objective','manager')}
            atomic_json(boot_path,bootstrap)
        paper_results = validate_results([c['question'] for c in review],executor.run(bootstrap['source'],
            {'action':'predict','questions':[c['question'] for c in review],
             'state':bootstrap['state'],'memory':bootstrap['memory']}))
        bootstrap['paper_review_score'] = measure(review,paper_results)
        for c,r in zip(review,paper_results):
            remembered[c['case_id']] = review_case(c,r,bootstrap['version'])
        prior_reflections = bootstrap['proposal']['reflections']
        source = bootstrap['source']
        # The author already received every early/reference case in the saved
        # bootstrap. Only the next chronological review period is new here.
        # The final numerical learn still receives the entire study corpus.
        author_cases = review
        review_ids = {c['case_id'] for c in review}
        author_memory = {k:v for k,v in remembered.items() if k in review_ids}
    if settings.get('conditional_mistake_corrections') and settings.get('objective') == 'manager':
        # All four analysts enter the same conditional path immediately after
        # their own first exam. Never fall through to legacy whole-source edits.
        from analyst_conditional_method import register_initial_reference
        from analyst_repeated_study import advance
        register_initial_reference(folder,engine,bootstrap or prior,initial,review,remembered,exam_time)
        return advance(root,engine,cases,generator,executor,settings)
    if settings.get('study_before_exam'):
        if not (bootstrap or compatible_prior):
            raise MethodWaiting('WAITING_FIRST_EXAM', '분석법 수정 전에 기존 분석법의 첫 모의시험 필요')
        author_cases = [c for c in review if not remembered[c['case_id']]['was_correct']]
        author_memory = {c['case_id']:remembered[c['case_id']] for c in author_cases}
    memory['cases'].update(remembered)
    atomic_json(folder/'memory.json', memory)
    atomic_json(folder/'study_progress.json',{
        'stage':'author_revision', 'historical_reference_samples':len(references),
        'training_samples':len(learned), 'exam_reserved_samples':len(exam),
        'paper_review_score':bootstrap.get('paper_review_score') if bootstrap else None,
        'updated_at':now_iso(), 'learning_completed':False})
    # Held-out questions/answers never go to the method author or to learn().
    packet = {'protocol':'analyst-method-revision.v1','analyst':engine,
              'objective':settings.get('objective','manager'), 'previous_source':source,
              'previous_learned_state':bootstrap['state'] if bootstrap else prior.get('state'),
              'previous_study_lessons':bootstrap['proposal']['change_summary'] if bootstrap else '',
              'training_cases': author_cases, 'own_error_memory': author_memory,
              'historical_reference_contract': 'Cases with reference_only=true are earlier CSV study records. They have study_answer.original_csv_row and date-strict prior_match_reference_ids; no invented observation timestamps or handicap odds. Learn from these alongside the ordinary question/options/answers records. All original CSV fields are retained in study_answer. Reference-only rows are not counted as a certified unseen exam or executable investment quote. Never use a target match outcome as its own pre-match feature.',
              'interface': {'learn':'learn(cases, memory) returns JSON state',
                            'predict':'predict(question, state, memory) returns {scores:{option_id:probability},selected_id:option_id}'},
              'instructions': 'Use all supplied raw conditions. Review your own wrong answers; explain testable hypotheses and change the analysis method itself. Choose your own algorithm, features and selection method. Persist lessons in returned state. No teacher-assigned football weights or required learner family. Return source, change_summary, and reflections keyed by case_id. Never assert a final result proves a causal reason.'}
    unchanged_allowed = bool(settings.get('study_before_exam') and not author_cases)
    if unchanged_allowed:
        proposal = {'source':source,'change_summary':'복기 시험에 오답이 없어 기존 분석법 유지',
                    'reflections':{},'study_delivery':{'all_cases_delivered':True}}
    elif settings.get('study_delivery') == 'chronological_batches':
        from analyst_batch_study import BatchedMethodAuthor
        proposal = BatchedMethodAuthor(generator, folder, settings).propose(packet)
    else:
        proposal = generator.propose(packet)
    if bootstrap:
        proposal['reflections'] = {**prior_reflections,**proposal.get('reflections',{})}
        proposal['study_delivery'] = {'bootstrap':bootstrap['proposal'].get('study_delivery'),
                                     'revision':proposal.get('study_delivery'),
                                     'all_cases_delivered':bool(bootstrap['proposal'].get('study_delivery',{}).get('all_cases_delivered')
                                         and proposal.get('study_delivery',{}).get('all_cases_delivered'))}
    check_source(proposal.get('source'))
    if not proposal.get('change_summary'):
        raise ValueError('method revision lacks an explanation')
    if source and not unchanged_allowed and ast.dump(ast.parse(proposal['source']), include_attributes=False) == ast.dump(ast.parse(source), include_attributes=False):
        raise ValueError('generator returned the unchanged analysis method')
    reflections = proposal.get('reflections') or {}
    errors = {k for k,v in (author_memory if settings.get('study_before_exam') else remembered).items() if not v['was_correct']}
    if any(not isinstance(reflections.get(k), str) or not reflections[k].strip() for k in errors):
        raise ValueError('every own wrong answer needs a recorded reflection')
    for key in errors:
        remembered[key] = {**remembered[key], 'reflection': reflections[key],
                           'review_state':'REFLECTED', 'method_change':proposal['change_summary']}
    new_source = proposal['source']
    learned_state = executor.run(new_source, {'action':'learn','cases':references+learned,'memory':remembered})
    version = engine+'-method-'+digest([new_source, learned_state, signature])[:20]
    candidate = {'engine':engine,'version':version,'source':new_source,'state':learned_state,
                 'objective':settings.get('objective','manager'), 'memory':remembered,
                 'parent_version':prior.get('version'), 'change_summary':proposal['change_summary'],
                 'generation_usage':proposal.get('generation_usage',{}),
                 'generation_backend':proposal.get('generation_backend'),
                 'generation_model_requested':proposal.get('generation_model_requested'),
                 'study_delivery':proposal.get('study_delivery'),
                 'learned_through':max(c['known_at'] for c in learned), 'created_at':now_iso()}
    # These scores are explicitly training-set results, not unseen exams.
    training_score = measure(learned, executor.run(new_source,
        {'action':'predict','questions':[c['question'] for c in learned],
         'state':learned_state,'memory':remembered}))
    questions = [c['question'] for c in exam]
    results = executor.run(new_source, {'action':'predict','questions':questions,
                                      'state':learned_state,'memory':remembered})
    score = measure(exam, results)
    # Re-read the saved program/state in a fresh isolated process; this is the serving form.
    atomic_json(folder/'candidate.json', candidate)
    saved = read_json(folder/'candidate.json')
    replay = executor.run(saved['source'], {'action':'predict','questions':questions,
                         'state':saved['state'],'memory':saved['memory']})
    if results != replay:
        raise ValueError('saved method does not reproduce tested predictions')
    baseline = None
    if active and active['learned_through'] < exam_time and active['objective']==candidate['objective']:
        old_results = executor.run(active['source'], {'action':'predict','questions':questions,
                                   'state':active['state'],'memory':active['memory']})
        baseline = measure(exam, old_results)
    elif bootstrap:
        baseline = measure(exam,executor.run(bootstrap['source'],
            {'action':'predict','questions':questions,'state':bootstrap['state'],'memory':bootstrap['memory']}))
    if candidate['objective'] == 'manager':
        passed = score['unit_roi'] >= .70 and (not baseline or score['unit_roi'] >= baseline['unit_roi'])
    else:
        passed = score['accuracy'] >= .70 and (not baseline or score['accuracy'] >= baseline['accuracy'])
    if passed:
        atomic_json(folder/'active.json', candidate)
    # Exam results become future lessons only AFTER the immutable exam was graded.
    for c,r in zip(exam,results):
        memory['cases'][c['case_id']] = review_case(c,r,version)
    memory['cases'].update(remembered)
    revision = {'version':version,'parent':candidate['parent_version'],'exam':score,
                'training_score':training_score,
                'paper_review_score':bootstrap.get('paper_review_score') if bootstrap else None,
                'study_delivery':proposal.get('study_delivery'),
                'objective':candidate['objective'],
                'baseline':baseline, 'passed':passed,'change_summary':proposal['change_summary'],
                'training_case_ids':sorted(allowed_ids),'exam_case_ids':[c['case_id'] for c in exam],
                'source_sha256':hashlib.sha256(new_source.encode()).hexdigest(),
                'saved_prediction_replay':True,'created_at':now_iso()}
    memory['revisions'].append(revision)
    atomic_json(folder/(version+'.json'), candidate)
    atomic_json(folder/'memory.json', memory)
    status = {'status':'READY' if passed else 'CANDIDATE_NOT_PASSED',
              'reason':'새 분석 방법 시험 통과' if passed else '분석 방법 수정·저장 완료, 관리자 투자 목표 미통과',
              'method_version':version,'active_method_version':read_json(folder/'active.json').get('version'),
              'attempt_fingerprint':digest([signature,settings,version]),
              'training_samples':len(learned),'own_error_reviews':len(errors),'exam':score,
              'historical_reference_samples':len(references),
              'paper_review_score':bootstrap.get('paper_review_score') if bootstrap else None,
              'training_score':training_score,'study_delivery':proposal.get('study_delivery'),
              'baseline_exam':baseline,'updated_at':now_iso()}
    atomic_json(folder/'status.json', status)
    return status


def learn_engine(root, engine, cases=None, generator=None, executor=None):
    settings = config(root)
    folder = folder_for(root, engine)
    folder.mkdir(parents=True, exist_ok=True)
    with (folder/'worker.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            if cases is None:
                cases = load_cases(root,settings.get('objective','manager'),engine)
            memory = collect_own_reviews(root,engine,cases)
            objective = settings.get('objective','manager')
            required = 'manager' if objective == 'proto' else 'proto' if objective == 'toto14' else None
            course_memory = read_json(folder_for(root,'robot_proto')/'memory.json') if engine=='robot_toto14' else memory
            if required and not any(r.get('objective')==required and r.get('passed')
                                    for r in course_memory.get('revisions',[])):
                raise MethodWaiting('WAITING_PREVIOUS_COURSE',required+' 모의시험 성공 후 다음 단계 진행')
            generator = generator or configured_generator(settings)
            executor = executor or ContainerExecutor(settings)
            executor.check()
            return _learn(root,engine,cases,generator,executor,settings)
        except MethodWaiting as wait:
            result = {'status':wait.status,'reason':str(wait),'updated_at':now_iso(),
                      'saved_reviews':len(locals().get('memory',{}).get('cases',{})),
                      'active_method_version':read_json(folder/'active.json').get('version')}
            atomic_json(folder/'status.json',result)
            return result
        except Exception as error:
            atomic_json(folder/'status.json',{'status':'ERROR','reason':type(error).__name__+': '+str(error),
                        'updated_at':now_iso(),'active_method_version':read_json(folder/'active.json').get('version')})
            raise


def predict_engine(root, engine, q, executor=None, now=None):
    active = read_json(folder_for(root,engine)/'active.json')
    if not active:
        return None
    now = time.time() if now is None else now
    if q['identity']['kickoff'] <= max(now, active['learned_through']):
        return None
    if q['objective'] != active['objective']:
        return None
    runner = executor or ContainerExecutor(config(root))
    result = validate_results([q], runner.run(active['source'],
        {'action':'predict','questions':[q],'state':active['state'],'memory':active['memory']}))[0]
    # Persist each original answer before kickoff for the next own-error review.
    if q['identity']['kickoff'] <= time.time() and now > 1_000_000_000:
        return None
    receipt = {'question':q,'answer':result,'version':active['version'],'captured_at':now_iso()}
    path = folder_for(root,engine)/'pending'
    path.mkdir(exist_ok=True)
    atomic_json(path/(digest([q['identity'],active['version']])+'.json'),receipt)
    return {**result,'model_version':active['version']}


def apply_dashboard(root, dashboard, executor=None):
    """Collector-only: reuse saved code/state, retain started answers, no UI work."""
    from scorecard_core import epoch, KST
    registry = {e:read_json(folder_for(root,e)/'active.json') for e in ENGINES}
    if not any(registry.values()):
        return {'active':False,'reason':'시험 통과한 새 분석 방법 없음'}
    counts = {'updated':0,'started_preserved':0,'waiting':0}
    for collection in ('proto','toto14'):
        for card in dashboard.get(collection,[]):
            match = card.get('match') or {}
            kickoff = epoch(match.get('match_time'),KST)
            if kickoff <= time.time():
                counts['started_preserved'] += 1
                continue
            if card.get('public_pick_block_reason') or not card.get('robot_full_evidence'):
                counts['waiting'] += 1
                continue
            originals = card.get('display_candidates') or card.get('robot_candidates') or []
            identity = {'fixture_id':int(card.get('api_fixture_id') or 0),
                        'home':match.get('home'),'away':match.get('away'),'kickoff':kickoff}
            if not identity['fixture_id'] or not identity['home'] or not identity['away']:
                counts['waiting'] += 1
                continue
            for label in ('official','robot','v2','v3'):
                engine = ('robot_toto14' if collection=='toto14' else 'robot_proto') if label=='robot' else label
                active = registry[engine]
                if not active:
                    continue
                objective = active['objective']
                if objective == 'proto' and collection != 'proto':
                    continue
                if objective == 'toto14' and collection != 'toto14':
                    continue
                q = question(card['robot_full_evidence'],originals,identity,objective)
                if not q['options']:
                    continue
                try:
                    result = predict_engine(root,engine,q,executor)
                    if not result:
                        continue
                    options = [{**o,'prob':result['scores'][o['option_id']],
                                'probability':result['scores'][o['option_id']],
                                'model_probability':result['scores'][o['option_id']],
                                'robot_probability':result['scores'][o['option_id']],
                                'v3_probability':result['scores'][o['option_id']],
                                'model_version':result['model_version'],
                                'analysis_method':active['change_summary']}
                               for o in q['options']]
                    pick = next(o for o in options if o['option_id']==result['selected_id'])
                    if kickoff <= time.time():
                        continue
                    if objective == 'manager':
                        # Preserve the analyst's selection instead of reselecting
                        # a different answer from the method's probabilities.
                        card.setdefault('case_manager_candidates',{})[label] = [pick]
                    else:
                        if label == 'official':
                            card['display_candidates'] = options
                            card.setdefault('pick_categories',{})['high_probability'] = pick
                            card['official_comparison_pick'] = pick
                        elif label == 'robot':
                            card['robot_candidates'] = options; card['robot_pick'] = pick
                        elif label == 'v2':
                            card['v2_market_candidates'] = options; card['v2_market_pick'] = pick
                            wdl = [o for o in options if o['market_key']=='1x2']
                            if pick['market_key']=='1x2':
                                card['alphago_pick'] = {**pick,'status':'ready',
                                    'code':{'home':'H','draw':'D','away':'A'}[pick['selection_side']],
                                    'probabilities':{o['selection_side']:o['probability'] for o in wdl}}
                        else:
                            card['v3_learning_pick'] = pick
                        if collection=='toto14':
                            card.setdefault('analyst_toto14_marks',{})[label] = {
                                'marks':[{'home':'승','draw':'무','away':'패'}[pick['selection_side']]],'available':True}
                    card.setdefault('analysis_method_versions',{})[label] = result['model_version']
                    from learning_state import CAMPAIGN
                    card['learning_campaign'] = CAMPAIGN
                    counts['updated'] += 1
                except (ValueError, RuntimeError, OSError, KeyError, TypeError, MethodWaiting) as error:
                    card.setdefault('analysis_method_wait_reasons',{})[label] = str(error)
                    counts['waiting'] += 1
    by_id = {str((c.get('match') or {}).get('id')):c for c in dashboard.get('proto',[])}
    for card in dashboard.get('top3',[]):
        source = by_id.get(str((card.get('match') or {}).get('id')))
        if source and source.get('analysis_method_versions'):
            for key in ('display_candidates','pick_categories','robot_candidates','robot_pick',
                        'v2_market_candidates','v2_market_pick','alphago_pick','v3_learning_pick',
                        'analysis_method_versions'):
                if key in source:
                    card[key] = copy.deepcopy(source[key])
    dashboard['analysis_method_learning'] = counts
    return counts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', default=str(Path(__file__).resolve().parent))
    args = parser.parse_args()
    for engine in course_engines(args.root):
        result = learn_engine(args.root,engine)
        print(engine, result['status'], result['reason'], flush=True)


if __name__ == '__main__':
    main()
