"""Shared manager curriculum and serving eligibility; no probability weights."""
import math

POLICY_VERSION = 'manager-underdog-goal-margin-v1'


def manager_target(candidate, candidates):
    market = candidate.get('market_key')
    side = candidate.get('selection_side')
    if market == '1x2' and side in ('home', 'away'):
        quotes = {}
        for row in candidates:
            if row.get('market_key') != '1x2':
                continue
            try:
                odd = float(row.get('odd') or 0)
            except (ValueError, TypeError):
                continue
            if math.isfinite(odd) and odd > 1:
                quotes[row.get('selection_side')] = odd
        opposite = 'away' if side == 'home' else 'home'
        return side in quotes and opposite in quotes and quotes[side] > quotes[opposite]
    if market == 'handicap':
        try:
            line = float(candidate['handicap_base'])
        except (KeyError, ValueError, TypeError):
            return False
        return bool(math.isfinite(line) and line.is_integer() and line != 0
                    and (side == 'draw' or (line < 0 and side == 'home')
                         or (line > 0 and side == 'away')))
    return False
