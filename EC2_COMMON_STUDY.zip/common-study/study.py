"""Bounded portable coordinator; analysis and learning remain in the original engine."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import concurrent.futures
import fcntl
import hashlib
import json
import os
import shutil
import sys
import tempfile

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'original'))
import common_engine as engine
import study_storage as storage

def find_codex(explicit=None):
    found=shutil.which(explicit or 'codex')
    if not found and explicit is None:
        found=shutil.which(str(Path.home()/'.local/bin/codex'))
    return found

def verify_bundle():
    manifest=storage.load(ROOT/'bundle-manifest.json')
    for rel,wanted in manifest['sha256'].items():
        target=(ROOT/rel).resolve()
        if not target.is_relative_to(ROOT.resolve()) or hashlib.sha256(target.read_bytes()).hexdigest()!=wanted:
            raise ValueError('Package source/data differs: '+rel)
    papers=storage.load(ROOT/'data/papers.json')
    memories={e:storage.load(ROOT/'data'/f'{e}-memory.json') for e in engine.ENGINES}
    engine.verify_materials(papers,memories)
    if [p['number'] for p in papers]!=[14,15,16]:
        raise ValueError('Expected the remaining original common papers only')
    return manifest,papers,memories

def check_pending(root):
    for pending in root.glob('**/*.pending.json'):
        raw=pending.with_name(pending.name.replace('.pending.json','.json'))
        if not raw.exists():
            raise ValueError('Unfinished request preserved; no automatic retry: '+str(pending.relative_to(root)))
        if storage.load(raw)['request_id']!=storage.load(pending)['request_id']:
            raise ValueError('Saved request identity differs: '+pending.name)

def configure(args,papers):
    engine.DATA=ROOT/'data';engine.RUN=ROOT/'runtime'
    storage.ROOT=ROOT;storage.DATA=engine.DATA;storage.RUN=engine.RUN
    storage.STOP=engine.RUN/'STOP';storage.STATUS=ROOT/'results/status.json'
    storage.LIMIT=args.max_new_requests
    storage.DEADLINE=datetime.fromisoformat(args.stop_at).timestamp()
    storage.CODEX_COMMAND=find_codex(args.codex_command)
    if not storage.CODEX_COMMAND:
        raise ValueError('Existing ChatGPT Codex CLI is required on this host')
    def status():
        budget=storage.load(engine.RUN/'request-budget.json') if (engine.RUN/'request-budget.json').exists() else {'requests':0}
        completed={};actors={}
        for e in engine.ENGINES:
            actors[e]=[]
            for paper in papers:
                folder=engine.RUN/e/f"paper-{paper['number']:02}"
                checkpoint=folder/'own-next-memory.json'
                if checkpoint.exists():
                    actors[e].append({'paper':paper['number'],
                        'selected':storage.load(folder/'first-selected-score.json'),
                        'all_ten':storage.load(folder/'first-all-ten-score.json'),
                        'own_review_saved':True})
        for paper in papers:
            if all(any(s['paper']==paper['number'] for s in actors[e]) for e in engine.ENGINES):
                completed[str(paper['number'])]=10
        storage.atomic(storage.STATUS,{'updated_at':datetime.now(timezone.utc).isoformat(),
            'phase':'stopped_preserving_records' if storage.STOP.exists() else 'running',
            'planned_remaining_common_matches':30,'completed_remaining_common_matches':sum(completed.values()),
            'new_model_requests':budget['requests'],'max_new_requests':storage.LIMIT,
            'stop_at':args.stop_at,'analysts':actors,'football_API_requests':0,
            'server_serving_changed':False,'auto_applied_to_live_analysts':False,
            'same_common_papers':True,'original_bias_notice':papers[0]['definition']})
    storage.update_status=status
    return status

def main(argv=None):
    parser=argparse.ArgumentParser()
    parser.add_argument('--run',action='store_true')
    parser.add_argument('--check',action='store_true')
    parser.add_argument('--max-new-requests',type=int,default=0)
    parser.add_argument('--stop-at',help='Explicit timezone-aware ISO date/time')
    parser.add_argument('--codex-command')
    parser.add_argument('--accept-external-transfer',action='store_true')
    args=parser.parse_args(argv)
    manifest,papers,memories=verify_bundle()
    if not args.run:
        result={'phase':'prepared_only','remaining_common_matches':30,
            'same_papers_for_four':True,'completed_paper_13_memory_preserved':True,
            'completed_model_answers_reused':manifest['cached_answers'],
            'previous_total_requests_preserved':32,
            'new_requests_allowed_by_default':0,'AI_requests':0,'football_API_requests':0,
            'server_serving_changed':False,'bundle_id':manifest['bundle_id'],
            'codex_command_available':bool(find_codex(args.codex_command))}
        print(json.dumps(result,ensure_ascii=False))
        return 0
    if args.max_new_requests<=0 or not args.stop_at or not args.accept_external_transfer:
        parser.error('Run requires an explicit new-request cap, stop-at time and accepted external transfer')
    deadline=datetime.fromisoformat(args.stop_at)
    if deadline.tzinfo is None or deadline.timestamp()<=datetime.now(timezone.utc).timestamp():
        parser.error('stop-at must include a timezone and be in the future')
    update=configure(args,papers)
    engine.RUN.mkdir(exist_ok=True)
    with (engine.RUN/'worker.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        if storage.STOP.exists():raise ValueError('STOP preserved; no automatic restart')
        budget_path=engine.RUN/'request-budget.json'
        if budget_path.exists():
            saved=storage.load(engine.RUN/'execution-plan.json')
            if saved['max_new_requests']!=args.max_new_requests or saved['stop_at']!=args.stop_at:
                raise ValueError('Do not reset the existing request cap or stop time')
            check_pending(engine.RUN)
        else:
            for seed in (ROOT/'seed').rglob('*.json'):
                destination=engine.RUN/seed.relative_to(ROOT/'seed')
                destination.parent.mkdir(parents=True,exist_ok=True)
                storage.once(destination,storage.load(seed))
            check_pending(engine.RUN)
            storage.once(engine.RUN/'execution-plan.json',{'max_new_requests':args.max_new_requests,
                'stop_at':args.stop_at,'prior_requests':32,'bundle_id':manifest['bundle_id'],
                'host':os.uname().nodename,'created_at':datetime.now(timezone.utc).isoformat()})
            storage.once(budget_path,{'requests':0,'limit':args.max_new_requests})
        (engine.RUN/'tmp').mkdir(exist_ok=True);tempfile.tempdir=str(engine.RUN/'tmp')
        storage.event('runner','portable_common_study_started',pid=os.getpid())
        for paper in papers:
            if storage.STOP.exists():break
            completed={};jobs={}
            for e in engine.ENGINES:
                checkpoint=engine.RUN/e/f"paper-{paper['number']:02}"/'own-next-memory.json'
                if checkpoint.exists():completed[e]=storage.load(checkpoint)
            with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
                for e in engine.ENGINES:
                    if e not in completed:jobs[e]=pool.submit(engine.guarded_worker,e,paper,memories[e])
                completed.update({e:job.result() for e,job in jobs.items()})
            if any(v is None for v in completed.values()):break
            memories.update(completed)
            storage.event('runner','common_paper_completed_by_all_four',paper=paper['number'])
        update()
        status=storage.load(storage.STATUS)
        status['phase']='completed' if status['completed_remaining_common_matches']==30 else 'partial_stopped'
        storage.atomic(storage.STATUS,status)
        storage.atomic(ROOT/'results/final.json',status)
        return 0 if status['phase']=='completed' else 2

if __name__=='__main__':raise SystemExit(main())
