#!/usr/bin/env bash
# R7.13.6 — scorecard reconnect + fast Streamlit scorecard interaction.
# The archive must be placed on EC2 first, for example /tmp/DJ_SPORTS_R7.13.6_FIX.zip.
set -euo pipefail

ARCHIVE="${1:?usage: bash DJ_SPORTS_R7.13.6_APPLY.sh /tmp/DJ_SPORTS_R7.13.6_FIX.zip}"
APP_ROOT="/home/ubuntu"
STAGE_DIR="$(mktemp -d /tmp/dj-r7136.XXXXXX)"
STAMP="$(date +%Y%m%d_%H%M%S)"

cleanup() { rm -rf "$STAGE_DIR"; }
trap cleanup EXIT

unzip -q "$ARCHIVE" -d "$STAGE_DIR"
for file in app.py collector.py; do
  test -f "$STAGE_DIR/$file"
done

grep -Fq 'R7.13.6-scorecard-reconnect-fragment' "$STAGE_DIR/collector.py"
python3 -m py_compile "$STAGE_DIR/app.py" "$STAGE_DIR/collector.py"

BACKUP_DIR="$APP_ROOT/backup_r7136_$STAMP"
mkdir -p "$BACKUP_DIR"
for file in app.py collector.py; do
  test ! -f "$APP_ROOT/$file" || cp -a "$APP_ROOT/$file" "$BACKUP_DIR/$file"
  install -m 0644 "$STAGE_DIR/$file" "$APP_ROOT/$file"
done

# The database and all frozen pick/result records are deliberately untouched.
sudo systemctl restart dj-collector.service
sudo systemctl is-active dj-collector.service
echo "R7.13.6 적용 완료 · 채점 답안 재연결 시작 · DB/동결픽 보존 · 백업: $BACKUP_DIR"
