#!/usr/bin/env bash
# R7.13.5 — UI error/latency, Toto14 full view, cumulative frozen grading.
# Run from /home/ubuntu after downloading the ZIP to /tmp.
set -euo pipefail

ARCHIVE="${1:?usage: bash DJ_SPORTS_R7.13.5_APPLY.sh /tmp/DJ_SPORTS_R7.13.5_FIX.zip}"
APP_ROOT="/home/ubuntu"
STAGE_DIR="$(mktemp -d /tmp/dj-r7135.XXXXXX)"
STAMP="$(date +%Y%m%d_%H%M%S)"

cleanup() { rm -rf "$STAGE_DIR"; }
trap cleanup EXIT

unzip -q "$ARCHIVE" -d "$STAGE_DIR"
for file in app.py collector.py; do
  test -f "$STAGE_DIR/$file"
done

grep -Fq 'R7.13.5-ui-grade-history-v2-status' "$STAGE_DIR/collector.py"
python3 -m py_compile "$STAGE_DIR/app.py" "$STAGE_DIR/collector.py"

BACKUP_DIR="$APP_ROOT/backup_r7135_$STAMP"
mkdir -p "$BACKUP_DIR"
for file in app.py collector.py; do
  test ! -f "$APP_ROOT/$file" || cp -a "$APP_ROOT/$file" "$BACKUP_DIR/$file"
  install -m 0644 "$STAGE_DIR/$file" "$APP_ROOT/$file"
done

# Never replace, delete, or reset ai_predictions.db or any frozen-pick file.
sudo systemctl restart dj-collector.service
sudo systemctl is-active dj-collector.service
echo "R7.13.5 적용 완료 · 소스 백업: $BACKUP_DIR · DB/동결픽 보존"
