import argparse
import base64
import hashlib
import json
import math
import os
import re
import shutil
import signal
import sqlite3
import subprocess
import sys
import tempfile
import time
import traceback
from collections import Counter
from contextlib import contextmanager
from datetime import datetime, timezone, timedelta
from html import unescape as html_unescape
from pathlib import Path
from urllib.parse import urljoin

import requests
import schedule
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.edge.options import Options as EdgeOptions
from selenium.webdriver.edge.service import Service as EdgeService
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

try:
    from webdriver_manager.chrome import ChromeDriverManager
except Exception:
    ChromeDriverManager = None

try:
    from webdriver_manager.microsoft import EdgeChromiumDriverManager
except Exception:
    EdgeChromiumDriverManager = None

from config import *
from api_engine import *
from api_engine import _fetch_date_fixtures_api, _normalize_player_name, _team_name_match_score
from grading_postmortem import (
    build_postmortem,
    events_from_note,
    postmortem_json,
    postmortem_text,
    stats_from_note,
)


APP_DIR = Path(__file__).resolve().parent
STATUS_FILE = APP_DIR / "collector_status.json"
WORLD_DASHBOARD_FILE = APP_DIR / "world_dashboard.json"
WORLD_PUBLICATION_FILE = APP_DIR / ".world_dashboard.public.json"
DB_BACKUP_REQUEST_FILE = APP_DIR / ".db-backup-requested.json"
KST = timezone(timedelta(hours=9))
COLLECTOR_PATCH_VERSION = "R7.13.5-ui-grade-history-v2-status"
# 상용화 전에는 프로토 LIVE와 승무패14에만 API·서버 자원을 사용한다.
# WORLD 코드는 삭제하지 않으며, 추후 별도 API 예산으로 재개하는 별도 배포에서만
# 이 값을 바꾼다.  기존 서버 환경변수에 1이 남아 있어도 현재는 절대 재가동하지 않는다.
WORLD_FEATURE_ENABLED = False
UNDERDOG_GATE_VERSION = "U3-alternative-pick-20260902"
PICK_AUDIT_SCHEMA_VERSION = "pick-audit.v2"
# GitHub Contents API cannot accept an arbitrarily large object.  Leave a
# little headroom below the repository file ceiling and retry a deferred DB
# backup slowly instead of rebuilding/base64-encoding it in every worker.
GITHUB_DB_SNAPSHOT_MAX_BYTES = min(
    95 * 1024 * 1024,
    max(1024 * 1024, int(os.getenv("GITHUB_DB_SNAPSHOT_MAX_BYTES", str(95 * 1024 * 1024)))),
)
DB_BACKUP_DEFER_HOURS = max(
    1, min(24, int(os.getenv("DB_BACKUP_DEFER_HOURS", "6")))
)
DB_BACKUP_INTERVAL_MINUTES = max(
    30, min(1440, int(os.getenv("DB_BACKUP_INTERVAL_MINUTES", "360")))
)
# 종료 상태는 화면 표시용이 아니라 중복 추적 방지용 내부 캐시로만 잠시 보존합니다.
LIVE_RETENTION_HOURS = max(1, int(os.getenv("LIVE_RETENTION_HOURS", "2")))
LIVE_LOOKAROUND_HOURS = max(2, int(os.getenv("LIVE_LOOKAROUND_HOURS", "6")))
SQUAD_CACHE_TTL_HOURS = max(24, min(720, int(os.getenv("SQUAD_CACHE_TTL_HOURS", "168"))))
FIXTURE_IDENTITY_CACHE_HOURS = max(
    1, min(24, int(os.getenv("FIXTURE_IDENTITY_CACHE_HOURS", "6")))
)
FIXTURE_IDENTITY_RETRY_HOURS = max(
    1, min(6, int(os.getenv("FIXTURE_IDENTITY_RETRY_HOURS", "1")))
)
PROTO_MIN_SCRAPE_ROWS = max(1, int(os.getenv("PROTO_MIN_SCRAPE_ROWS", "3")))
# Betman often exposes more than one saleable round at once.  Keep a tiny,
# bounded retry set so the collector can fall forward when its first round
# metadata row points to a not-yet-populated future board.
BETMAN_ROUND_CANDIDATE_LIMIT = max(
    1, min(3, int(os.getenv("BETMAN_ROUND_CANDIDATE_LIMIT", "3")))
)
BETMAN_SALE_END_GRACE_SECONDS = max(
    0, min(6 * 3600, int(os.getenv("BETMAN_SALE_END_GRACE_SECONDS", "900")))
)
# 승무패 14는 소액 참고 조합으로 운영한다. 서버 환경변수에 예전 64가
# 남아 있어도 8조합(8,000원)을 넘지 않도록 상한을 강제한다.
TOTO14_MAX_COMBINATIONS = max(1, min(8, int(os.getenv("TOTO14_MAX_COMBINATIONS", "8"))))
TOTO14_UNIT_PRICE = max(100, int(os.getenv("TOTO14_UNIT_PRICE", "1000")))
# A full Betman board can contain well over one hundred matches. Publish and
# resume before the master worker's hard timeout instead of waiting for every
# heavy enrichment call to finish. This limits one cycle, never a match's total
# learning lifetime.
MASTER_ANALYSIS_SOFT_SECONDS = max(
    180, min(720, int(os.getenv("MASTER_ANALYSIS_SOFT_SECONDS", "300")))
)
# R7.12.31: 12 was an emergency recovery batch, not a product limit.  Allow
# up to 50 nearest-kickoff matches in one pass, but the time/memory brakes
# below can yield earlier and the next scheduler turn resumes the remainder.
MASTER_ANALYSIS_NEW_MATCHES_PER_PASS = 50
ANALYSIS_PASS_MIN_AVAILABLE_MEMORY_MB = max(
    96, min(512, int(os.getenv("ANALYSIS_PASS_MIN_AVAILABLE_MEMORY_MB", "200")))
)
TEAM_IDENTITY_RETRY_BATCH = max(
    2, min(50, int(os.getenv("TEAM_IDENTITY_RETRY_BATCH", "30")))
)
# Fetch reusable team/fixture evidence before the heavy pick engines run.
# The team worker warms the shared SQLite cache; official/robot/V2/V3 then
# consume the same evidence without repeating overseas API work.
DATA_PREFETCH_MATCH_LIMIT = max(
    50, min(80, int(os.getenv("DATA_PREFETCH_MATCH_LIMIT", "50")))
)
# The close-to-kickoff pass refreshes volatile evidence (market, injuries and
# lineup).  A separate earlier pass below starts building the shared, stable
# team dossier before then, so a 30-hour boundary cannot leave a future card
# with no material at all.
DATA_PREFETCH_HORIZON_HOURS = max(
    6, min(48, int(os.getenv("DATA_PREFETCH_HORIZON_HOURS", "30")))
)
DATA_PREFETCH_EARLY_HORIZON_HOURS = max(
    DATA_PREFETCH_HORIZON_HOURS,
    min(96, int(os.getenv("DATA_PREFETCH_EARLY_HORIZON_HOURS", "72")))
)
DATA_PREFETCH_TEAM_TTL_HOURS = max(
    4, min(24, int(os.getenv("DATA_PREFETCH_TEAM_TTL_HOURS", "12")))
)
# A completed core dossier is only a queue marker; the underlying provider
# caches retain their own endpoint-specific TTLs.  Keeping this marker through
# the 72-hour preparation window prevents the same first 50 fixtures from
# monopolising every five-minute prefetch pass.
DATA_PREFETCH_COMPLETION_TTL_HOURS = max(
    DATA_PREFETCH_EARLY_HORIZON_HOURS,
    min(120, int(os.getenv("DATA_PREFETCH_COMPLETION_TTL_HOURS", "84")))
)
# This is deliberately a local, reusable evidence record rather than another
# provider job.  The team worker writes it after its normal cache warming pass;
# every PROTO/TOTO14 analyst reads the same record and keeps its own pick logic.
SHARED_DOSSIER_TTL_HOURS = max(
    DATA_PREFETCH_EARLY_HORIZON_HOURS,
    min(120, int(os.getenv("SHARED_DOSSIER_TTL_HOURS", "84")))
)
DATA_PREFETCH_CRITICAL_HOURS = max(
    1, min(6, int(os.getenv("DATA_PREFETCH_CRITICAL_HOURS", "2")))
)
MASTER_CACHE_ONLY_SERVING = os.getenv("MASTER_CACHE_ONLY_SERVING", "1") != "0"
MASTER_MARKET_POLICY_CACHE_HOURS = max(
    6, min(168, int(os.getenv("MASTER_MARKET_POLICY_CACHE_HOURS", "72")))
)
MASTER_PROTO_CHECKPOINT_UPLOAD = os.getenv("MASTER_PROTO_CHECKPOINT_UPLOAD", "1") != "0"
MASTER_SKIP_TOTO_WHILE_PROTO_BACKLOG = os.getenv(
    "MASTER_SKIP_TOTO_WHILE_PROTO_BACKLOG", "1"
) != "0"
MASTER_INLINE_TEAM_RETRY = os.getenv("MASTER_INLINE_TEAM_RETRY", "0") == "1"
# Score owns current results first; historical learning repair remains bounded
# so old backlog can never monopolize the single production DB slot.
SCORE_POSTMORTEM_BACKFILL_BATCH = max(1, min(100, int(
    os.getenv("SCORE_POSTMORTEM_BACKFILL_BATCH", "20")
)))
SCORE_CANDIDATE_BACKFILL_BATCH = max(1, min(80, int(
    os.getenv("SCORE_CANDIDATE_BACKFILL_BATCH", "12")
)))
SCORE_LINEUP_RECHECK_BATCH = max(1, min(6, int(
    os.getenv("SCORE_LINEUP_RECHECK_BATCH", "2")
)))

# A decimal quote must exceed 1. No arbitrary minimum price sacrifices a
# higher-probability candidate; actual conservative return remains required.
FINAL_PICK_MIN_ODDS = 1.0
LIVE_STATUSES = {'1H', 'HT', '2H', 'ET', 'BT', 'P', 'SUSP', 'INT', 'LIVE'}
TERMINAL_STATUSES = {'FT', 'AET', 'PEN'}
CANCELED_STATUSES = {'CANC', 'ABD', 'AWD', 'WO'}
POSTPONED_STATUSES = {'PST', 'PSTP'}

# 이 목록은 번역·리그 평균값을 위한 우선 리그 표이지 분석 허용 목록이 아니다.
# 전체경기 대상은 아래 표에 없는 리그라도 실제 정규시간 배당이 있으면 포함한다.
WORLD_LEAGUES = {
    39: {"name": "잉글랜드 프리미어리그", "tier": 1},
    140: {"name": "스페인 라리가", "tier": 1},
    135: {"name": "이탈리아 세리에 A", "tier": 1},
    78: {"name": "독일 분데스리가", "tier": 1},
    61: {"name": "프랑스 리그 1", "tier": 1},
    88: {"name": "네덜란드 에레디비시", "tier": 1},
    94: {"name": "포르투갈 프리메이라리가", "tier": 1},
    292: {"name": "대한민국 K리그1", "tier": 1},
    98: {"name": "일본 J1리그", "tier": 1},
    253: {"name": "미국 MLS", "tier": 1},
    71: {"name": "브라질 세리에 A", "tier": 1},
}
# Schedule discovery is cheap and must start early enough for the shared team
# cache to warm before a WORLD fixture reaches the detailed-analysis window.
WORLD_SCHEDULE_DAYS = max(1, min(3, int(os.getenv("WORLD_SCHEDULE_DAYS", "3"))))
WORLD_MAX_SCHEDULE_MATCHES = max(
    20, min(300, int(os.getenv("WORLD_MAX_SCHEDULE_MATCHES", "160")))
)
# WORLD 공개 목록에 실은 경기는 특정 리그나 앞의 30경기만 상세분석하고
# 나머지를 시장 프리뷰에 남겨두지 않는다. 실제 공급사 호출은 공통 일일
# 예산/보호 잔량에서 계속 중단되며 다음 주기에 킥오프순으로 재개된다.
WORLD_MAX_DEEP_ANALYSES_DAILY = max(
    WORLD_MAX_SCHEDULE_MATCHES,
    min(300, int(os.getenv("WORLD_MAX_DEEP_ANALYSES_DAILY", str(WORLD_MAX_SCHEDULE_MATCHES)))),
)
WORLD_MAX_DEEP_ANALYSES_PER_LEAGUE = max(
    WORLD_MAX_SCHEDULE_MATCHES,
    min(300, int(os.getenv("WORLD_MAX_DEEP_ANALYSES_PER_LEAGUE", str(WORLD_MAX_SCHEDULE_MATCHES)))),
)
WORLD_ANALYSIS_HORIZON_HOURS = max(
    WORLD_SCHEDULE_DAYS * 24,
    min(72, int(os.getenv("WORLD_ANALYSIS_HORIZON_HOURS", str(WORLD_SCHEDULE_DAYS * 24)))),
)
WORLD_SCHEDULE_REFRESH_HOURS = max(
    2, min(12, int(os.getenv("WORLD_SCHEDULE_REFRESH_HOURS", "6")))
)
WORLD_ANALYSIS_INTERVAL_MINUTES = max(
    5, min(60, int(os.getenv("WORLD_ANALYSIS_INTERVAL_MINUTES", "5")))
)
WORLD_ANALYSIS_SOFT_SECONDS = max(
    180, min(720, int(os.getenv("WORLD_ANALYSIS_SOFT_SECONDS", "300")))
)
WORLD_ANALYSIS_NEW_MATCHES_PER_PASS = 50
# WORLD는 분석이 끝난 뒤에만 화면을 갱신하면, 첫 5~10경기 분석이 오래
# 걸리는 동안 웹이 이전 날짜의 빈 목록을 계속 보여준다. 한 경기 단위로
# 공개본 체크포인트를 남겨서 관리자 화면은 즉시 진행 상태를 받고, 고객
# 화면은 기존의 시작 전·최종픽 조건을 그대로 통과한 카드만 보게 한다.
WORLD_ANALYSIS_CHECKPOINT_EVERY = max(
    1, min(20, int(os.getenv("WORLD_ANALYSIS_CHECKPOINT_EVERY", "1")))
)
WORLD_MARKET_WATCH_HORIZON_HOURS = max(
    3, min(48, int(os.getenv("WORLD_MARKET_WATCH_HORIZON_HOURS", "24")))
)
WORLD_ODDS_MAX_PAGES_PER_DAY = max(
    10, min(100, int(os.getenv("WORLD_ODDS_MAX_PAGES_PER_DAY", "100")))
)
# The full local WORLD document intentionally retains complete robot/audit
# evidence. The GitHub/Streamlit copy only needs display fields, so keep a
# separate public object below the size that previously caused HTTP 422.
WORLD_PUBLIC_DASHBOARD_MAX_BYTES = max(
    2 * 1024 * 1024,
    min(
        20 * 1024 * 1024,
        int(os.getenv("WORLD_PUBLIC_DASHBOARD_MAX_BYTES", str(12 * 1024 * 1024))),
    ),
)
# PROTO와 WORLD는 출처만 다르고 분석 정책/버전은 동일하게 유지한다.
# 같은 fixture는 PROTO 결과를 그대로 재사용하고, 비중복 WORLD도 같은
# full-context 입력과 동일 ANALYSIS_VERSION으로 계산한다.
WORLD_ANALYSIS_VERSION = ANALYSIS_VERSION
WORLD_MARKET_PREVIEW_VERSION = f"{ANALYSIS_VERSION}-world-market-preview-v1"
WORLD_TEAM_NAME_KO_OVERRIDES = {
    "Bucheon FC 1995": "부천 FC 1995",
    "Daejeon Citizen": "대전 하나시티즌",
    "Jeju United FC": "제주 SK FC",
    "Ulsan Hyundai FC": "울산 HD FC",
    "Jeonbuk Motors": "전북 현대 모터스",
    "Pohang Steelers": "포항 스틸러스",
    "Newcastle": "뉴캐슬 유나이티드",
    "Bournemouth": "본머스",

    "Lyon": "올랭피크 리옹",
    "Auxerre": "AJ오세르",
    "Sparta Rotterdam": "스파르타 로테르담",
    "PEC Zwolle": "PEC즈볼러",
    "VfB Stuttgart": "VfB 슈투트가르트",
    "1. FC Köln": "쾰른",
    "FC Koln": "쾰른",
}
WORLD_REJECTION_LABELS = {
    "INVALID_LEAGUE_ID": "공식 리그 ID 없음",
    "NO_VALID_MARKET": "사설 배팅용 정규시간 배당 없음",
    "INVALID_FIXTURE_ID": "공식 경기 ID 없음",
    "INVALID_TEAM_ID": "홈·원정 팀 ID 확인 실패",
    "DUPLICATE_TEAM_ID": "홈·원정 팀 ID가 동일함",
    "TEAM_TBD": "출전 팀 미정",
    "KICKOFF_TBD": "킥오프 시간 미정",
    "UNSUPPORTED_STATUS": "분석 전 일정 상태가 아님",
    "ALREADY_STARTED": "수집 전에 이미 시작 또는 종료",
    "CANCELED_OR_POSTPONED": "취소·연기·중단 경기",
    "DUPLICATE_FIXTURE": "중복 경기 ID",
    "SCHEDULE_CAP": "세계 일정 안전 상한 초과",
}


def _world_team_display_name(api_name, team_id=0):
    """Return a verified Korean-first label without changing API identity."""
    api_name = str(api_name or "").strip()
    team_id = int(team_id or 0)
    if api_name in WORLD_TEAM_NAME_KO_OVERRIDES:
        return WORLD_TEAM_NAME_KO_OVERRIDES[api_name]

    def normalized(value):
        return re.sub(r"[^a-z0-9]+", "", str(value or "").casefold())

    def has_hangul(value):
        return bool(re.search(r"[가-힣]", str(value or "")))

    target = normalized(api_name)
    candidates = []
    for korean_name, english_name in {**TEAM_NAME_MAP, **MANUAL_TEAM_MAP}.items():
        if target and normalized(english_name) == target and has_hangul(korean_name):
            candidates.append((1, str(korean_name).strip()))
    if team_id > 0:
        for korean_name, info in DIRECT_TEAM_INFO.items():
            if (
                isinstance(info, dict)
                and int(info.get("id") or 0) == team_id
                and has_hangul(korean_name)
            ):
                candidates.append((2, str(korean_name).strip()))
    if not candidates:
        return api_name
    # 검증된 ID 이름을 우선하고, 축약명보다 설명력이 높은 전체 이름을 쓴다.
    return max(candidates, key=lambda row: (row[0], len(row[1])))[1]


def _refresh_world_source_meta(payload):
    """Rebuild counters from matches so schedule refresh cannot reset them."""
    if not isinstance(payload, dict):
        return payload
    matches = [item for item in payload.get("matches", []) or [] if isinstance(item, dict)]
    eligible = [
        item for item in matches
        if str(item.get("visibility_status") or "SHADOW").upper() != "QUARANTINED"
    ]
    analyzed = [
        item for item in eligible
        if item.get("analysis")
        or str(item.get("analysis_status") or "").upper() in {
            "ANALYZED_SHADOW", "FROZEN_SHADOW"
        }
    ]
    market_previews = [
        item for item in eligible
        if str(
            ((item.get("analysis") or {}).get("analysis_stage")
             or item.get("analysis_stage") or "")
        ) == "market-preview"
    ]
    detailed = [
        item for item in eligible
        if item.get("analysis")
        and str(
            ((item.get("analysis") or {}).get("analysis_stage")
             or item.get("analysis_stage") or "")
        ) not in {"", "market-preview"}
        and str((item.get("analysis") or {}).get("canonical_source") or "") != "PROTO"
    ]
    source_meta = payload.setdefault("source_meta", {})
    source_meta.update({
        "eligible_shadow_count": len(eligible),
        "analyzed_shadow_count": len(analyzed),
        "market_preview_count": len(market_previews),
        "detailed_analysis_count": len(detailed),
        "frozen_shadow_count": sum(
            1 for item in eligible
            if item.get("frozen_at")
            or str(item.get("analysis_status") or "").upper() == "FROZEN_SHADOW"
        ),
        "analysis_error_count": sum(
            1 for item in eligible
            if str(item.get("analysis_status") or "").upper() == "ANALYSIS_ERROR"
        ),
        "public_count": sum(
            1 for item in eligible
            if str(item.get("visibility_status") or "").upper() == "PUBLIC"
        ),
        "analysis_started": bool(analyzed),
        "analysis_version": WORLD_ANALYSIS_VERSION,
        "system_version": SYSTEM_VERSION,
    })
    return payload


WORLD_PUBLIC_CANDIDATE_FIELDS = (
    "engine", "engine_version", "code", "pre_match_only",
    "market_key", "label", "raw_pick", "selection_side", "handicap_base",
    "totals_base", "sort_id", "prob", "probability", "model_probability",
    "fair_prob", "fair_probability", "odd", "edge", "robust_probability",
    "robust_edge", "robust_ev", "recommendation_score", "data_confidence",
    "error_margin", "probability_interval", "is_true_underdog",
    "is_qualified_underdog", "support_signals", "independent_support_count",
    "selected_as", "selection_reason", "selection_warning",
    "recommendation_status", "settlement_supported", "final_pick_grade",
    "learning_robot", "official_policy_version", "official_score",
    "value_pick_tier", "public_pick_frozen", "official_final_pick",
    "probability_fallback", "context_alignment", "robot_probability",
    "robot_expected_goals", "robot_model_active", "robot_model_version",
    "robot_training_samples", "robot_validation_fixtures",
    "robot_learning_revision",
    "robot_decision_reason", "robot_selection_axis",
    "robot_grading_experience_samples", "robot_grading_calibration_samples",
    "robot_grading_calibration_weight", "robot_minimum_sample_gate",
    "robot_accuracy_goal", "robot_accuracy_goal_policy_version",
    "robot_goal_score", "robot_goal_market_samples",
    "robot_goal_market_accuracy", "robot_goal_market_weight",
    "robot_price_skill_segment", "robot_price_skill_samples",
    "robot_price_skill_accuracy", "robot_price_skill_weight",
    "robot_goal_price_segment", "robot_goal_price_samples",
    "robot_goal_price_accuracy", "robot_goal_price_roi",
    "robot_goal_price_weight", "robot_goal_price_roi_adjustment",
    "robot_goal_is_market_quota", "robot_edge", "robot_ev",
    "legacy_v4_policy_version", "legacy_v4_expected_goals",
)
WORLD_PUBLIC_INPUT_FIELDS = (
    "recent", "standings", "injuries", "lineups", "lineup_learning",
    "rest_days",
)
WORLD_PUBLIC_DECISION_FIELDS = (
    "analysis_version", "schema_version", "data_confidence", "selected_market",
    "selected_pick", "selection_reason", "selection_warning", "final_pick_grade",
    "value_badge", "probability_fallback", "market_candidate_counts",
    "missing_markets", "alphago_pick",
)
WORLD_PUBLIC_ANALYSIS_FIELDS = (
    "analysis_version", "system_version", "analysis_stage", "analyzed_at",
    "frozen_at", "data_quality_score", "data_quality_grade", "missing_data",
    "lineup_confirmed", "odds_snapshot", "odds_movement", "evidence",
    "categories", "selected", "legacy_v4_pick", "robot_pick", "alphago_pick",
    "robot_wdl_probabilities", "alternative", "learning_robot", "report",
    "public_pick_frozen", "public_pick_frozen_at",
    "public_pick_analysis_version", "public_pick_analysis_stage",
    "public_pick_snapshot_id", "canonical_source", "canonical_match_id",
)


def _compact_world_public_candidate(candidate):
    """Keep only candidate fields the website can display as a fallback."""
    if not isinstance(candidate, dict):
        return {}
    return {
        key: candidate.get(key)
        for key in WORLD_PUBLIC_CANDIDATE_FIELDS
        if key in candidate
    }


def _compact_world_public_analysis(analysis):
    """Build a display-complete copy without removing local learning memory."""
    if not isinstance(analysis, dict):
        return {}
    public = {
        key: analysis.get(key)
        for key in WORLD_PUBLIC_ANALYSIS_FIELDS
        if key in analysis
    }
    inputs = analysis.get("inputs_snapshot") or {}
    if isinstance(inputs, dict):
        public["inputs_snapshot"] = {
            key: inputs.get(key)
            for key in WORLD_PUBLIC_INPUT_FIELDS
            if key in inputs
        }
    categories = analysis.get("categories") or {}
    if isinstance(categories, dict):
        public["categories"] = {
            key: (
                _compact_world_public_candidate(candidate)
                if isinstance(candidate, dict) else None
            )
            for key, candidate in categories.items()
        }
    for key in ("selected", "legacy_v4_pick", "robot_pick", "alphago_pick", "alternative"):
        if isinstance(analysis.get(key), dict):
            public[key] = _compact_world_public_candidate(analysis[key])
    public["candidates"] = [
        compact
        for compact in (
            _compact_world_public_candidate(candidate)
            for candidate in analysis.get("candidates", []) or []
        )
        if compact
    ]
    decision = analysis.get("decision") or {}
    if isinstance(decision, dict):
        public["decision"] = {
            key: decision.get(key)
            for key in WORLD_PUBLIC_DECISION_FIELDS
            if key in decision
        }
    public["publication_compacted"] = True
    return public


def _build_world_publication_payload(payload):
    """Separate web payload; the caller's full local payload is never mutated."""
    if not isinstance(payload, dict) or not isinstance(payload.get("matches"), list):
        return None
    public = {
        key: value for key, value in payload.items()
        if key != "matches"
    }
    public_matches = []
    for item in payload.get("matches", []) or []:
        if not isinstance(item, dict):
            continue
        row = {key: value for key, value in item.items() if key != "analysis"}
        if isinstance(item.get("analysis"), dict):
            row["analysis"] = _compact_world_public_analysis(item["analysis"])
        public_matches.append(row)
    public["matches"] = public_matches
    public["publication_schema_version"] = "world-public.v1"
    source_meta = dict(public.get("source_meta") or {})
    source_meta.update({
        "publication_compacted": True,
        "publication_match_count": len(public_matches),
        "publication_system_version": SYSTEM_VERSION,
    })
    public["source_meta"] = source_meta
    return public


def _write_world_publication_file():
    """Write the compact GitHub/web copy while preserving the full local file."""
    payload = _read_json(WORLD_DASHBOARD_FILE, {})
    public = _build_world_publication_payload(payload)
    if public is None:
        print("❌ WORLD 공개본 생성 실패: 로컬 정상 분석 파일이 없습니다.")
        return None
    _atomic_write_json(WORLD_PUBLICATION_FILE, public)
    try:
        public_bytes = WORLD_PUBLICATION_FILE.stat().st_size
        full_bytes = WORLD_DASHBOARD_FILE.stat().st_size
    except OSError as error:
        print(f"❌ WORLD 공개본 크기 확인 실패: {error}")
        return None
    if public_bytes > WORLD_PUBLIC_DASHBOARD_MAX_BYTES:
        print(
            "❌ WORLD 공개본 안전 상한 초과: "
            f"{public_bytes}바이트 / {WORLD_PUBLIC_DASHBOARD_MAX_BYTES}바이트"
        )
        return None
    print(
        "✅ WORLD 웹 게시본 압축 완료: "
        f"{full_bytes}바이트 → {public_bytes}바이트 "
        "(로컬 전체 학습·감사자료 보존)"
    )
    return WORLD_PUBLICATION_FILE


def _publish_world_dashboard(reason=""):
    """Publish the compact WORLD feed without coupling it to a long analysis pass.

    The local full document remains the audit/learning source.  This only
    replaces the compact Streamlit copy after it has been written and size
    checked, so an upload failure never erases a prior public board.
    """
    publication_file = _write_world_publication_file()
    if publication_file is None:
        return False
    if not upload_to_github(
        publication_file, remote_path=WORLD_DASHBOARD_FILE.name
    ):
        return False
    if reason:
        print(f"⚡ WORLD 웹 게시 완료: {reason}")
    return True


def _exclude_proto_overlaps(payload, proto_by_fixture=None):
    """Remove verified Proto fixtures from WORLD without deleting stored history."""
    if not isinstance(payload, dict):
        return 0
    proto_by_fixture = (
        proto_by_fixture if isinstance(proto_by_fixture, dict)
        else _dashboard_proto_by_fixture()
    )
    proto_fixture_ids = set()
    for raw_fixture_id in proto_by_fixture:
        try:
            fixture_id = int(raw_fixture_id or 0)
        except (TypeError, ValueError):
            continue
        if fixture_id > 0:
            proto_fixture_ids.add(fixture_id)
    if not proto_fixture_ids:
        return 0
    kept = []
    removed = 0
    for item in payload.get("matches", []) or []:
        if not isinstance(item, dict):
            continue
        try:
            fixture_id = int(
                item.get("api_fixture_id")
                or (item.get("match") or {}).get("fixture_id")
                or 0
            )
        except (TypeError, ValueError):
            fixture_id = 0
        if fixture_id in proto_fixture_ids:
            removed += 1
            continue
        kept.append(item)
    if removed:
        payload["matches"] = kept
    source_meta = payload.setdefault("source_meta", {})
    source_meta["proto_overlap_excluded_count"] = int(
        source_meta.get("proto_overlap_excluded_count") or 0
    ) + removed
    return removed


def _local_path(path):
    path = Path(path)
    return path if path.is_absolute() else APP_DIR / path


def _read_json(path, default=None):
    try:
        with open(_local_path(path), "r", encoding="utf-8") as file:
            return json.load(file)
    except Exception:
        return {} if default is None else default


def _atomic_write_bytes(path, payload):
    """Write in the destination directory and replace only after fsync succeeds."""
    final_path = _local_path(path)
    final_path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = final_path.with_name(
        f".{final_path.name}.{os.getpid()}.{time.time_ns()}.tmp"
    )
    try:
        with open(temp_path, "wb") as file:
            file.write(payload)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temp_path, final_path)
    finally:
        try:
            temp_path.unlink(missing_ok=True)
        except Exception:
            pass


def _atomic_write_json(path, value, indent=None):
    payload = json.dumps(value, ensure_ascii=False, indent=indent).encode("utf-8")
    _atomic_write_bytes(path, payload)


def _pid_is_running(pid):
    try:
        pid = int(pid)
        if pid <= 0:
            return False
        if os.name == "nt":
            # On Windows os.kill(pid, 0) calls TerminateProcess rather than the
            # POSIX-style existence probe.  Query the handle without mutating it.
            import ctypes
            from ctypes import wintypes

            process_query_limited_information = 0x1000
            still_active = 259
            kernel32 = ctypes.windll.kernel32
            kernel32.OpenProcess.argtypes = (
                wintypes.DWORD, wintypes.BOOL, wintypes.DWORD
            )
            kernel32.OpenProcess.restype = wintypes.HANDLE
            kernel32.GetExitCodeProcess.argtypes = (
                wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)
            )
            kernel32.GetExitCodeProcess.restype = wintypes.BOOL
            kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
            kernel32.CloseHandle.restype = wintypes.BOOL
            handle = kernel32.OpenProcess(
                process_query_limited_information, False, pid
            )
            if not handle:
                # Access denied still proves that the process exists.
                return int(kernel32.GetLastError()) == 5
            try:
                exit_code = wintypes.DWORD()
                queried = kernel32.GetExitCodeProcess(
                    handle, ctypes.byref(exit_code)
                )
                return bool(queried and exit_code.value == still_active)
            finally:
                kernel32.CloseHandle(handle)
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError, TypeError, ValueError):
        return False


def _try_acquire_lock(name, stale_after=3600, wait_seconds=0):
    lock_path = APP_DIR / f".collector-{name}.lock"
    deadline = time.monotonic() + max(0, wait_seconds)
    while True:
        try:
            fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            lock_data = json.dumps({"pid": os.getpid(), "created_at": time.time()}).encode()
            os.write(fd, lock_data)
            os.fsync(fd)
            return fd, lock_path
        except FileExistsError:
            existing = _read_json(lock_path, {})
            lock_pid = existing.get("pid") if isinstance(existing, dict) else None
            try:
                created_at = float(existing.get("created_at", 0) or 0) if isinstance(existing, dict) else 0
            except (TypeError, ValueError):
                created_at = 0
            # A slow but healthy worker must never lose its lock merely because a
            # wall-clock timeout elapsed.  The scheduler owns hard timeouts and
            # terminates the worker first; here we only reap locks whose PID is
            # demonstrably gone (or whose malformed payload never acquired one).
            stale = not _pid_is_running(lock_pid)
            if lock_pid is None and created_at:
                stale = time.time() - created_at > min(stale_after, 5)
            if stale:
                try:
                    lock_path.unlink(missing_ok=True)
                    continue
                except Exception:
                    pass
            if time.monotonic() >= deadline:
                return None, lock_path
            time.sleep(0.05)


def _release_lock(fd, lock_path):
    if fd is not None:
        try:
            os.close(fd)
        except Exception:
            pass
    try:
        Path(lock_path).unlink(missing_ok=True)
    except Exception:
        pass


@contextmanager
def _job_lock(name, stale_after):
    fd, lock_path = _try_acquire_lock(name, stale_after=stale_after)
    if fd is None:
        yield False
        return
    try:
        yield True
    finally:
        _release_lock(fd, lock_path)


def _utc_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


_STATUS_HISTORY_FIELDS = {
    "last_success_at", "last_failure_at", "last_success_duration_seconds",
    "last_failure_duration_seconds",
}


def _update_collector_status(job_name, state, **details):
    fd, lock_path = _try_acquire_lock("status", stale_after=30, wait_seconds=2)
    if fd is None:
        return
    try:
        new_run = bool(details.pop("_new_run", False))
        status = _read_json(STATUS_FILE, {})
        if not isinstance(status, dict):
            status = {}
        jobs = status.setdefault("jobs", {})
        previous = jobs.get(job_name, {}) if isinstance(jobs.get(job_name), dict) else {}
        if new_run:
            # A new worker must not inherit counters/stages from an older run.
            # Keep only explicit historical timestamps and durations.
            entry = {
                key: previous[key]
                for key in _STATUS_HISTORY_FIELDS
                if key in previous
            }
        else:
            entry = dict(previous)
        entry.update(details)
        entry["state"] = state
        entry["heartbeat_at"] = _utc_iso()
        entry["pid"] = os.getpid()
        if state == "running":
            if new_run or previous.get("state") != "running" or not entry.get("last_started_at"):
                entry["last_started_at"] = entry["heartbeat_at"]
        elif state == "success":
            entry["last_success_at"] = entry["heartbeat_at"]
            if "duration_seconds" in entry:
                entry["last_success_duration_seconds"] = entry["duration_seconds"]
            entry.pop("last_error", None)
        elif state == "failed":
            entry["last_failure_at"] = entry["heartbeat_at"]
            if "duration_seconds" in entry:
                entry["last_failure_duration_seconds"] = entry["duration_seconds"]
        jobs[job_name] = entry
        status["updated_at"] = entry["heartbeat_at"]
        status["version"] = 2
        if state in {"success", "failed"}:
            try:
                status["api_usage"] = get_api_usage_status()
            except Exception:
                status["api_accounting_error"] = "사용량 원장 읽기 실패 · 새 API 호출 차단"
        _atomic_write_json(STATUS_FILE, status, indent=2)
        return True
    except Exception as error:
        print(f"⚠️ collector_status.json 갱신 실패: {error}")
        return False
    finally:
        _release_lock(fd, lock_path)


def _parse_kst_match_time(value):
    if not value or value in {"시간 미정", "마감/진행중"}:
        return None
    match = re.search(
        r'(?:(\d{2,4})\.)?(\d{2})\.(\d{2}).*?(\d{2}):(\d{2})',
        str(value),
    )
    if not match:
        return None
    try:
        year_text, month, day, hour, minute = match.groups()
        month, day, hour, minute = map(int, (month, day, hour, minute))
        if year_text:
            year = int(year_text)
            if year < 100:
                year += 2000
            return datetime(year, month, day, hour, minute, tzinfo=KST)
        now = datetime.now(KST)
        candidates = [
            datetime(year, month, day, hour, minute, tzinfo=KST)
            for year in (now.year - 1, now.year, now.year + 1)
        ]
        return min(candidates, key=lambda item: abs((item - now).total_seconds()))
    except (TypeError, ValueError):
        return None

def _validate_sqlite_file(path):
    """Perform a bounded preflight check suitable for recurring workers.

    This deliberately does not scan every database page.  Full integrity
    checks are maintenance operations and must never sit in the common startup
    path of LIVE, scoring, team repair, or analysis workers.
    """
    path = _local_path(path)
    try:
        if not path.exists() or path.stat().st_size < 100:
            return False
        with open(path, "rb") as file:
            if file.read(16) != b"SQLite format 3\x00":
                return False
        uri = path.resolve().as_uri() + "?mode=ro"
        conn = sqlite3.connect(uri, uri=True, timeout=5)
        try:
            conn.execute("PRAGMA query_only = ON")
            schema_version = conn.execute("PRAGMA schema_version").fetchone()
            tables = {
                str(row[0])
                for row in conn.execute(
                    "SELECT name FROM sqlite_master "
                    "WHERE type='table' AND name IN ('predictions','db_meta')"
                ).fetchall()
            }
            return bool(
                schema_version
                and int(schema_version[0] or 0) >= 0
                and "predictions" in tables
            )
        finally:
            conn.close()
    except Exception as error:
        print(f"⚠️ SQLite 검증 실패({path.name}): {error}")
        return False


def _validate_sqlite_integrity_offline(path):
    """Full page scan for explicit offline maintenance only.

    No scheduler or worker calls this function.  The service must be stopped
    and the operator must run it deliberately when a full integrity audit is
    required.
    """
    path = _local_path(path)
    if not _validate_sqlite_file(path):
        return False
    try:
        uri = path.resolve().as_uri() + "?mode=ro"
        conn = sqlite3.connect(uri, uri=True, timeout=30)
        try:
            check = conn.execute("PRAGMA quick_check").fetchone()
            return bool(check and str(check[0]).casefold() == "ok")
        finally:
            conn.close()
    except Exception as error:
        print(f"⚠️ SQLite 전체 무결성검사 실패({path.name}): {error}")
        return False


def download_latest_db_from_github():
    print(f"\n[🔄 {time.strftime('%Y-%m-%d %H:%M:%S')}] 기존 DB를 확인합니다 (정상 로컬 기록 우선)...")
    url = f"https://raw.githubusercontent.com/{GITHUB_REPO}/main/ai_predictions.db?t={int(time.time())}"
    final_path = _local_path("ai_predictions.db")
    # EC2 is authoritative; failed uploads leave GitHub behind.
    if _validate_sqlite_file(final_path):
        print("✅ 로컬 정상 DB 보존 (원격본으로 과거 기록을 덮어쓰지 않음)")
        return True
    temp_path = final_path.with_name(f".{final_path.name}.{os.getpid()}.download")
    backup_path = final_path.with_name(f"{final_path.name}.last_good")
    try:
        res = requests.get(url, timeout=30)
        if res.status_code != 200:
            print(f"⚠️ GitHub DB 다운로드 실패: HTTP {res.status_code} (로컬 정상본 보존)")
            return False
        with open(temp_path, "wb") as file:
            file.write(res.content)
            file.flush()
            os.fsync(file.fileno())
        if not _validate_sqlite_file(temp_path):
            print("❌ 원격 DB가 유효한 SQLite가 아니어서 교체하지 않습니다.")
            return False
        if _validate_sqlite_file(final_path):
            _atomic_write_bytes(backup_path, final_path.read_bytes())
        os.replace(temp_path, final_path)
        print("✅ 검증된 기존 DB를 원자적으로 동기화했습니다.")
        return True
    except Exception as error:
        print(f"❌ DB 다운로드 에러: {error} (로컬 정상본 보존)")
        return False
    finally:
        try:
            temp_path.unlink(missing_ok=True)
        except Exception:
            pass


def _github_upload_error_detail(response):
    try:
        return response.json()
    except Exception:
        return str(getattr(response, "text", "") or "")[:300]


def _github_upload_is_retryable(response, detail):
    """Retry only conflicts and explicitly transient GitHub failures."""
    status = int(getattr(response, "status_code", 0) or 0)
    detail_text = json.dumps(detail, ensure_ascii=False).lower()
    if status == 422 and (
        "file is too large" in detail_text
        or "too large to be processed" in detail_text
    ):
        return False
    if status in {409, 422, 429} or 500 <= status < 600:
        return True
    return status == 403 and (
        "timed out validating rule" in detail_text
        or ("please try again" in detail_text and "validating rule" in detail_text)
    )


def upload_to_github(file_path, remote_path=None):
    local_path = _local_path(file_path)
    remote_path = str(remote_path or Path(file_path).name).replace("\\", "/")
    if not GITHUB_TOKEN:
        print(f"⚠️ GitHub 토큰이 없어 업로드를 건너뜁니다: {remote_path}")
        return False
    if not local_path.exists():
        print(f"⚠️ 업로드할 파일이 없습니다: {local_path}")
        return False

    fd, lock_path = _try_acquire_lock("github-upload", stale_after=180, wait_seconds=30)
    if fd is None:
        print(f"⚠️ 다른 업로드가 진행 중이어서 건너뜁니다: {remote_path}")
        return False
    try:
        url = f"https://api.github.com/repos/{GITHUB_REPO}/contents/{remote_path}"
        git_headers = {
            "Authorization": f"token {GITHUB_TOKEN}",
            "Accept": "application/vnd.github.v3+json",
        }
        with open(local_path, "rb") as file:
            content = file.read()
        b64_content = base64.b64encode(content).decode("utf-8")

        max_attempts = 3
        for attempt in range(max_attempts):
            try:
                sha = None
                r_get = requests.get(url, headers=git_headers, timeout=15)
                if r_get.status_code == 200:
                    sha = r_get.json().get("sha")
                elif r_get.status_code not in (404,):
                    print(f"⚠️ GitHub 현재 버전 조회 실패({remote_path}): HTTP {r_get.status_code}")
                data = {"message": f"Auto update {remote_path}", "content": b64_content}
                if sha:
                    data["sha"] = sha
                r_put = requests.put(url, headers=git_headers, json=data, timeout=45)
            except Exception as error:
                if attempt + 1 >= max_attempts:
                    print(f"❌ [관제 봇 떡밥] GitHub 업로드 에러: {error}")
                    return False
                print(
                    f"⚠️ GitHub 일시 연결 오류({remote_path}) · "
                    f"재시도 {attempt + 2}/{max_attempts}: {error}"
                )
                time.sleep(2 ** attempt)
                continue
            if r_put.status_code in (200, 201):
                print(f"✅ GitHub 동기화 완료: {remote_path}")
                return True
            detail = _github_upload_error_detail(r_put)
            if not _github_upload_is_retryable(r_put, detail) or attempt + 1 >= max_attempts:
                print(f"❌ GitHub 동기화 실패 ({remote_path}): {detail}")
                return False
            print(
                f"⚠️ GitHub 일시 오류({remote_path}, HTTP {r_put.status_code}) · "
                f"재시도 {attempt + 2}/{max_attempts}"
            )
            time.sleep(2 ** attempt)
        return False
    except Exception as error:
        print(f"❌ [관제 봇 떡밥] GitHub 업로드 에러: {error}")
        return False
    finally:
        _release_lock(fd, lock_path)


def upload_sqlite_to_github(db_path="ai_predictions.db"):
    """Upload a consistent SQLite snapshot rather than a file mid-transaction."""
    source_path = _local_path(db_path)
    if not _validate_sqlite_file(source_path):
        print("❌ 로컬 DB 검증 실패로 업로드하지 않습니다.")
        return False
    defer_path = APP_DIR / ".db-backup-deferred.json"
    deferred = _read_json(defer_path, {})
    try:
        retry_at = datetime.fromisoformat(
            str((deferred or {}).get("next_retry_at") or "").replace("Z", "+00:00")
        )
        if retry_at.tzinfo is None:
            retry_at = retry_at.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) < retry_at:
            print(
                "⚠️ GitHub 용량 제한으로 DB 백업 보류 중입니다. "
                f"다음 확인: {retry_at.astimezone(KST).isoformat(timespec='minutes')} · "
                "화면 결과 게시는 계속합니다."
            )
            return False
    except (TypeError, ValueError):
        pass
    publish_fd, publish_lock = _try_acquire_lock(
        "db-publish", stale_after=300, wait_seconds=90
    )
    if publish_fd is None:
        print("⚠️ 다른 DB 게시 작업이 진행 중이어서 이번 업로드를 건너뜁니다.")
        return False
    temp_path = None
    try:
        fd, temp_name = tempfile.mkstemp(
            prefix="ai_predictions.", suffix=".snapshot.db", dir=APP_DIR
        )
        os.close(fd)
        temp_path = Path(temp_name)
        source = None
        target = None
        try:
            source = sqlite3.connect(str(source_path), timeout=30)
            target = sqlite3.connect(str(temp_path), timeout=30)
            source.backup(target)
            # API responses are disposable cache, not prediction history. Keep
            # them in the server DB, but do not republish tens of MB each cycle.
            if target.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='api_cache'").fetchone():
                target.execute("DELETE FROM api_cache")
            target.commit()
            target.execute("VACUUM")
        finally:
            if target is not None:
                target.close()
            if source is not None:
                source.close()
        if not _validate_sqlite_file(temp_path):
            print("❌ DB 스냅샷 검증 실패로 업로드하지 않습니다.")
            return False
        snapshot_size = temp_path.stat().st_size
        if snapshot_size > GITHUB_DB_SNAPSHOT_MAX_BYTES:
            now = datetime.now(timezone.utc)
            next_retry = now + timedelta(hours=DB_BACKUP_DEFER_HOURS)
            _atomic_write_json(
                defer_path,
                {
                    "reason": "github_contents_size_limit",
                    "deferred_at": now.isoformat(timespec="seconds"),
                    "next_retry_at": next_retry.isoformat(timespec="seconds"),
                    "snapshot_size_bytes": snapshot_size,
                    "safe_limit_bytes": GITHUB_DB_SNAPSHOT_MAX_BYTES,
                    "source_name": source_path.name,
                },
                indent=2,
            )
            print(
                "⚠️ DB 스냅샷이 GitHub 안전 용량을 넘어서 백업만 보류합니다: "
                f"{snapshot_size / (1024 * 1024):.1f}MB · "
                "로컬 DB와 화면 결과 게시는 그대로 유지합니다."
            )
            return False
        uploaded = upload_to_github(temp_path, remote_path=Path(db_path).name)
        if uploaded:
            try:
                defer_path.unlink(missing_ok=True)
            except Exception:
                pass
        return uploaded
    except Exception as error:
        print(f"❌ DB 스냅샷 업로드 실패: {error}")
        return False
    finally:
        if temp_path is not None:
            try:
                temp_path.unlink(missing_ok=True)
            except Exception:
                pass
        _release_lock(publish_fd, publish_lock)


def _request_db_backup(source):
    """Record a coalesced backup request without blocking product workers."""
    fd, lock_path = _try_acquire_lock(
        "db-backup-request", stale_after=60, wait_seconds=2
    )
    if fd is None:
        return False
    try:
        payload = _read_json(DB_BACKUP_REQUEST_FILE, {})
        if not isinstance(payload, dict):
            payload = {}
        sources = {
            str(value).strip()
            for value in (payload.get("sources") or [])
            if str(value).strip()
        }
        sources.add(str(source or "unknown"))
        payload.update({
            "requested_at": payload.get("requested_at") or _utc_iso(),
            "updated_at": _utc_iso(),
            "sources": sorted(sources),
        })
        _atomic_write_json(DB_BACKUP_REQUEST_FILE, payload, indent=2)
        return True
    finally:
        _release_lock(fd, lock_path)


def run_db_backup_job():
    """Create/upload a DB snapshot only in its own low-frequency worker."""
    request = _read_json(DB_BACKUP_REQUEST_FILE, {})
    if not isinstance(request, dict) or not request:
        _update_collector_status(
            "backup", "running", last_stage="complete_no_request"
        )
        return True
    backup_ok = upload_sqlite_to_github("ai_predictions.db")
    if backup_ok:
        try:
            DB_BACKUP_REQUEST_FILE.unlink(missing_ok=True)
        except Exception:
            pass
        _update_collector_status(
            "backup", "running", last_stage="complete", db_backup_ok=True,
            requested_sources=list(request.get("sources") or []),
        )
    else:
        # A GitHub size/defer warning is not a product-worker failure. Keep the
        # request so the next scheduled backup can retry without blocking LIVE.
        _update_collector_status(
            "backup", "running", last_stage="backup_deferred",
            db_backup_ok=False,
            requested_sources=list(request.get("sources") or []),
        )
    return True


def _normalize_toto14_picks(picks):
    normalized = []
    for pick in picks or []:
        pick = str(pick).strip()
        if pick in {"승", "무", "패"} and pick not in normalized:
            normalized.append(pick)
    return normalized[:2]


def _toto14_picks_from_display(display, home_team, away_team):
    display = str(display or "")
    picks = []
    if f"{home_team} 승" in display:
        picks.append("승")
    if "무승부" in display:
        picks.append("무")
    if f"{away_team} 승" in display:
        picks.append("패")
    return _normalize_toto14_picks(picks)


def _toto14_item_has_usable_pick(item, home_team="", away_team=""):
    """True only for a real pre-kickoff mark, never an empty wait card."""
    if not isinstance(item, dict):
        return False
    picks = _normalize_toto14_picks(item.get("picks"))
    if not picks and home_team and away_team:
        picks = _toto14_picks_from_display(
            item.get("best_pick_display"), home_team, away_team
        )
    return bool(picks)


def _render_toto14_picks_html(picks):
    picks = set(_normalize_toto14_picks(picks))
    styles = {
        "승": "background: #00F2FE; color: #0B0F19; font-weight: 900; border: 1px solid #00F2FE;" if "승" in picks else "background: transparent; color: #64748B; border: 1px solid #1E293B;",
        "무": "background: #10B981; color: #0B0F19; font-weight: 900; border: 1px solid #10B981;" if "무" in picks else "background: transparent; color: #64748B; border: 1px solid #1E293B;",
        "패": "background: #EF4444; color: #0B0F19; font-weight: 900; border: 1px solid #EF4444;" if "패" in picks else "background: transparent; color: #64748B; border: 1px solid #1E293B;",
    }
    return "".join(
        f"<div style='width:38px;height:38px;display:flex;align-items:center;justify-content:center;box-sizing:border-box;text-align:center;border-radius:7px;font-size:13px; {styles[pick]}'>{pick}</div>"
        for pick in ("승", "무", "패")
    )


def _render_team_availability_status(injury_data, diff_hours, lineup_confirmed, lineup_msg=""):
    """Show whether squad data is clean, unavailable, or still awaiting lineups."""
    badges = []
    injury_data = injury_data if isinstance(injury_data, dict) else {}
    if injury_data.get("available"):
        if int(injury_data.get("count", 0) or 0) == 0:
            badges.append(
                "<div class='injury-badge' style='color:#10B981; border-color:#10B981;'>"
                "🏥 부상자료 확인 · 등록 결장 없음</div>"
            )
        elif not injury_data.get("ace_missing"):
            badges.append(
                "<div class='injury-badge' style='color:#94A3B8; border-color:#475569;'>"
                "🏥 부상자료 확인 · 핵심 결장 없음</div>"
            )
    else:
        badges.append(
            "<div class='injury-badge' style='color:#F59E0B; border-color:#F59E0B;'>"
            "⚠️ 부상자료 미수신</div>"
        )

    if not lineup_msg:
        if lineup_confirmed:
            badges.append(
                "<div class='injury-badge' style='color:#10B981; border-color:#10B981;'>"
                "👥 선발 확인 · 핵심 제외 없음</div>"
            )
        elif float(diff_hours or 0) <= 1.5:
            badges.append(
                "<div class='injury-badge' style='color:#F59E0B; border-color:#F59E0B;'>"
                "⏳ 공식 선발자료 미수신</div>"
            )
        else:
            badges.append(
                "<div class='injury-badge' style='color:#64748B; border-color:#334155;'>"
                "👥 선발 확인 예정</div>"
            )
    return "".join(badges)


def _choose_toto14_picks(probs_dict, current_combinations, max_combinations=None):
    """Choose unique marks without exceeding the configured ticket budget."""
    max_combinations = max(1, int(max_combinations or TOTO14_MAX_COMBINATIONS))
    sorted_probs = sorted(
        ((pick, float(probs_dict.get(pick, 0) or 0)) for pick in ("승", "무", "패")),
        key=lambda item: item[1],
        reverse=True,
    )
    first_pick, first_pct = sorted_probs[0]
    second_pick, second_pct = sorted_probs[1]
    wants_double = first_pct - second_pct <= 7.0
    can_afford_double = int(current_combinations) * 2 <= max_combinations
    picks = [first_pick, second_pick] if wants_double and can_afford_double else [first_pick]
    return _normalize_toto14_picks(picks), first_pct, wants_double and not can_afford_double


def _toto14_from_canonical_proto(match, proto_items, probability_policy=None):
    """Reuse current same-fixture WDL; never rewrite a previously frozen ticket."""
    when = _parse_kst_match_time(match.get("match_time"))
    if when is None or when <= datetime.now(KST):
        return None
    matches = []
    for item in proto_items:
        if not _published_team_identity_ready(item):
            continue
        source = item.get("match") or {}
        source_when = _parse_kst_match_time(item.get("final_match_time") or source.get("match_time"))
        vector = item.get("wdl_forecast") or {}
        try:
            generated = datetime.fromisoformat(str(vector.get("generated_at") or "").replace("Z", "+00:00"))
            if generated.tzinfo is None or not generated < when or generated > datetime.now(KST):
                continue
        except ValueError:
            continue
        if (int(item.get("api_fixture_id") or 0) <= 0 or not source_when
                or int(vector.get("fixture_id") or 0) != int(item.get("api_fixture_id") or 0)
                or abs((source_when-when).total_seconds()) > 60
                or str(source.get("home")) != str(match.get("home"))
                or str(source.get("away")) != str(match.get("away"))
                or vector.get("forecast_model_version") != FORECAST_MODEL_VERSION):
            continue
        probs = vector.get("probabilities") or []
        if len(probs) == 3 and all(math.isfinite(float(p)) and 0 <= float(p) <= 1 for p in probs) and abs(sum(probs)-1) < 1e-5:
            matches.append((item, probs))
    if not matches or len({int(item["api_fixture_id"]) for item, _ in matches}) != 1:
        return None
    # Ambiguous snapshots for one fixture cannot silently choose different WDL.
    if any(tuple(probs) != tuple(matches[0][1]) for _, probs in matches):
        return None
    item, raw_probs = matches[0]
    probs = apply_toto14_probability_policy(
        raw_probs, probability_policy,
        [match.get("vote_h"), match.get("vote_d"), match.get("vote_a")],
    )
    result = {k: item.get(k) for k in ("home_team_id", "away_team_id", "home_logo", "away_logo", "analysis_version", "analysis_confidence",
              "analysis_stage", "home_form", "away_form", "h_rank_html", "a_rank_html", "h_inj_html", "a_inj_html")}
    pct_h, pct_d = round(probs[0]*100, 1), round(probs[1]*100, 1)
    result.update(match=dict(match), api_fixture_id=item["api_fixture_id"], _pending_toto_save=True,
                  p_h=pct_h, p_d=pct_d, p_a=round(100-pct_h-pct_d, 1),
                  goal_model_audit=item.get("goal_model_audit"),
                  wdl_forecast={
                      **dict(item["wdl_forecast"]),
                      "uncalibrated_probabilities": list(raw_probs),
                      "probabilities": list(probs),
                      "toto14_probability_policy": dict(probability_policy or {}),
                  },
                  probability_source=(
                      "canonical_proto_same_fixture+toto14_validated_calibration"
                      if (probability_policy or {}).get("active")
                      else "canonical_proto_same_fixture"
                  ))
    official_side = max(
        (("home", probs[0]), ("draw", probs[1]), ("away", probs[2])),
        key=lambda row: float(row[1]),
    )[0]
    official_raw = (
        match["home"] + " 승" if official_side == "home" else
        match["away"] + " 승" if official_side == "away" else "무승부"
    )
    result["official_comparison_pick"] = {
        "market_key": "1x2", "selection_side": official_side,
        "raw_pick": official_raw,
        "prob": float(probs[{"home": 0, "draw": 1, "away": 2}[official_side]]),
        "official_policy_version": OFFICIAL_PICK_POLICY_VERSION,
        "selection_axis": "toto14_single_direction_accuracy",
    }
    frozen_robot = _load_frozen_autonomous_robot_sample(
        "TOTO14_" + str(match.get("id") or ""), item.get("api_fixture_id") or 0,
        "TOTO14",
    )
    frozen_wdl = {
        str(candidate.get("selection_side")): float(
            candidate.get("robot_probability")
            if candidate.get("robot_probability") is not None
            else candidate.get("prob") or 0
        )
        for candidate in ((frozen_robot or {}).get("candidates") or [])
        if isinstance(candidate, dict)
        and str(candidate.get("market_key") or "") == "1x2"
        and str(candidate.get("selection_side") or "") in {"home", "draw", "away"}
    }
    robot_wdl = (
        frozen_wdl if set(frozen_wdl) == {"home", "draw", "away"}
        else dict(item.get("robot_wdl_probabilities") or {})
    )
    if all(side in robot_wdl for side in ("home", "draw", "away")):
        robot_side = max(
            ("home", "draw", "away"),
            key=lambda side: float(robot_wdl.get(side) or 0),
        )
        robot_mark = {"home": "승", "draw": "무", "away": "패"}[robot_side]
        result.update(
            robot_wdl_probabilities=robot_wdl,
            robot_mark=robot_mark,
            robot_pick_display=(
                match["home"] + " 승" if robot_mark == "승" else
                match["away"] + " 승" if robot_mark == "패" else "무승부"
            ),
            robot_pick_probability=round(float(robot_wdl[robot_side]) * 100, 1),
            robot_pick_version=ROBOT_PICK_VERSION,
            robot_first_pick_frozen=bool(frozen_robot),
            robot_frozen_at=str((frozen_robot or {}).get("captured_at") or ""),
        )
        robot_raw = (
            match["home"] + " 승" if robot_side == "home" else
            match["away"] + " 승" if robot_side == "away" else "무승부"
        )
        result["robot_pick"] = {
            "market_key": "1x2", "selection_side": robot_side,
            "raw_pick": robot_raw, "prob": float(robot_wdl[robot_side]),
            "robot_probability": float(robot_wdl[robot_side]),
            "robot_pick_version": ROBOT_PICK_VERSION,
            "robot_model_version": ROBOT_MODEL_VERSION,
        }
    picks, _, _ = _choose_toto14_picks({"승":pct_h, "무":pct_d, "패":result["p_a"]}, 1)
    result.update(picks=picks, picks_html=_render_toto14_picks_html(picks),
                  best_pick_display=", ".join("무승부" if p == "무" else f"{match['home'] if p == '승' else match['away']} 승" for p in picks))
    return result


def _ensure_toto14_freeze_table(conn):
    conn.execute("""
        CREATE TABLE IF NOT EXISTS toto14_prediction_freezes (
            match_id TEXT PRIMARY KEY,
            home_team TEXT NOT NULL,
            away_team TEXT NOT NULL,
            match_time TEXT,
            payload_json TEXT NOT NULL,
            frozen_at TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS toto14_prediction_freeze_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            match_id TEXT NOT NULL,
            home_team TEXT NOT NULL,
            away_team TEXT NOT NULL,
            match_time TEXT,
            analysis_version TEXT DEFAULT '',
            payload_json TEXT NOT NULL,
            frozen_at TEXT NOT NULL,
            fingerprint TEXT NOT NULL,
            UNIQUE(match_id, fingerprint)
        )
    """)
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_toto14_freeze_history_match "
        "ON toto14_prediction_freeze_snapshots(match_id, id)"
    )


def _load_toto14_freezes():
    conn = None
    try:
        conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=30)
        conn.execute("PRAGMA busy_timeout = 30000")
        _ensure_toto14_freeze_table(conn)
        conn.commit()
        rows = conn.execute(
            "SELECT match_id, home_team, away_team, payload_json FROM toto14_prediction_freezes"
        ).fetchall()
        result = {}
        for match_id, home_team, away_team, payload_json in rows:
            try:
                payload = json.loads(payload_json)
            except (TypeError, ValueError, json.JSONDecodeError):
                continue
            if isinstance(payload, dict):
                result[str(match_id)] = {
                    "home_team": str(home_team),
                    "away_team": str(away_team),
                    "payload": payload,
                }
        return result
    except Exception as error:
        print(f"⚠️ 승무패 14 동결본 조회 실패: {error}")
        return {}
    finally:
        if conn is not None:
            conn.close()


def _freeze_toto14_prediction(match_id, home_team, away_team, match_time, payload):
    """Persist the current pre-kickoff ticket and keep every older revision.

    Every former and replacement payload is copied into an append-only history
    table. Scheduled matches follow the newest official/robot revision; once
    kickoff has passed, the last pre-kickoff ticket is immutable.
    """
    conn = None
    try:
        frozen_payload = dict(payload)
        frozen_payload["picks"] = _normalize_toto14_picks(
            frozen_payload.get("picks")
            or _toto14_picks_from_display(
                frozen_payload.get("best_pick_display"), home_team, away_team
            )
        )
        frozen_payload["prediction_frozen"] = True
        frozen_payload.setdefault("frozen_at", _utc_iso())
        conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=30)
        conn.execute("PRAGMA busy_timeout = 30000")
        _ensure_toto14_freeze_table(conn)
        existing = conn.execute(
            """
            SELECT home_team, away_team, match_time, payload_json, frozen_at
            FROM toto14_prediction_freezes WHERE match_id = ?
            """,
            (str(match_id),),
        ).fetchone()
        if existing and (
            str(existing[0]) != str(home_team)
            or str(existing[1]) != str(away_team)
        ):
            return None

        def preserve_history(payload_value, stored_match_time, stored_frozen_at):
            if isinstance(payload_value, str):
                payload_text = payload_value
                try:
                    payload_object = json.loads(payload_value)
                except (TypeError, ValueError, json.JSONDecodeError):
                    payload_object = {"unreadable_legacy_payload": True}
            else:
                payload_object = dict(payload_value or {})
                payload_text = json.dumps(
                    payload_object, ensure_ascii=False, sort_keys=True
                )
            canonical = json.dumps(payload_object, ensure_ascii=False, sort_keys=True)
            fingerprint = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
            conn.execute(
                """
                INSERT OR IGNORE INTO toto14_prediction_freeze_snapshots (
                    match_id, home_team, away_team, match_time,
                    analysis_version, payload_json, frozen_at, fingerprint
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    str(match_id), str(home_team), str(away_team),
                    str(stored_match_time or ""),
                    str(payload_object.get("analysis_version") or ""),
                    payload_text, str(stored_frozen_at or _utc_iso()), fingerprint,
                ),
            )

        incoming_version = str(frozen_payload.get("analysis_version") or "")
        existing_payload = {}
        if existing:
            try:
                existing_payload = json.loads(existing[3])
            except (TypeError, ValueError, json.JSONDecodeError):
                existing_payload = {}
        existing_version = str(existing_payload.get("analysis_version") or "")
        kickoff = _parse_kst_match_time((existing[2] if existing else None) or match_time)
        def current_pick_signature(value):
            value = value if isinstance(value, dict) else {}
            official = value.get("official_comparison_pick") or {}
            robot = value.get("robot_pick") or {}
            return json.dumps({
                "analysis_version": str(value.get("analysis_version") or ""),
                "picks": _normalize_toto14_picks(value.get("picks") or []),
                "best_pick_display": str(value.get("best_pick_display") or ""),
                "probabilities": [
                    value.get("p_h"), value.get("p_d"), value.get("p_a")
                ],
                "official": {
                    "raw_pick": official.get("raw_pick"),
                    "probability": official.get("prob", official.get("probability")),
                },
                "robot": {
                    "raw_pick": robot.get("raw_pick"),
                    "probability": robot.get("prob", robot.get("probability")),
                    "pick_version": robot.get("robot_pick_version"),
                    "model_version": robot.get("robot_model_version"),
                    "training_samples": robot.get("robot_training_samples"),
                    "learning_revision": robot.get("robot_learning_revision"),
                },
            }, ensure_ascii=False, sort_keys=True, default=str)

        # The latest user policy freezes only a match that already started.
        # Before kickoff a new analysis version or a newly learned robot answer
        # replaces the current ticket, while preserve_history keeps the former
        # public value auditable.
        can_migrate = bool(
            existing
            and kickoff
            and datetime.now(KST) < kickoff
            and incoming_version == ANALYSIS_VERSION
            and _toto14_item_has_usable_pick(
                frozen_payload, home_team, away_team
            )
            and current_pick_signature(existing_payload)
                != current_pick_signature(frozen_payload)
        )
        can_repair_unavailable = bool(
            existing
            and kickoff
            and datetime.now(KST) < kickoff
            and incoming_version == ANALYSIS_VERSION
            and not _toto14_item_has_usable_pick(
                existing_payload, home_team, away_team
            )
            and _toto14_item_has_usable_pick(
                frozen_payload, home_team, away_team
            )
        )
        if existing:
            preserve_history(existing[3], existing[2], existing[4])
        if not existing or can_migrate or can_repair_unavailable:
            preserve_history(
                frozen_payload, match_time, frozen_payload.get("frozen_at")
            )
        conn.execute(
            """
            INSERT OR IGNORE INTO toto14_prediction_freezes
                (match_id, home_team, away_team, match_time, payload_json, frozen_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                str(match_id), str(home_team), str(away_team), str(match_time or ""),
                json.dumps(frozen_payload, ensure_ascii=False),
                str(frozen_payload["frozen_at"]),
            ),
        )
        if can_migrate or can_repair_unavailable:
            conn.execute(
                """
                UPDATE toto14_prediction_freezes
                SET match_time = ?, payload_json = ?, frozen_at = ?
                WHERE match_id = ? AND home_team = ? AND away_team = ?
                """,
                (
                    str(match_time or ""),
                    json.dumps(frozen_payload, ensure_ascii=False),
                    str(frozen_payload["frozen_at"]), str(match_id),
                    str(home_team), str(away_team),
                ),
            )
            if can_repair_unavailable:
                print(
                    f"🩹 시작 전 승무패14 빈 동결본 복구: "
                    f"{home_team} vs {away_team} · 현재 픽 저장"
                )
            else:
                print(
                    f"🔄 시작 전 승무패14 공개경계 교체: {home_team} vs {away_team} · "
                    f"{existing_version or '버전 미기록'} → {ANALYSIS_VERSION}"
                )
        conn.commit()
        row = conn.execute(
            "SELECT home_team, away_team, payload_json FROM toto14_prediction_freezes WHERE match_id = ?",
            (str(match_id),),
        ).fetchone()
        if not row or str(row[0]) != str(home_team) or str(row[1]) != str(away_team):
            return None
        stored = json.loads(row[2])
        return stored if isinstance(stored, dict) else None
    except Exception as error:
        print(f"⚠️ 승무패 14 예측 동결 실패({match_id}): {error}")
        return None
    finally:
        if conn is not None:
            conn.close()


def _locked_toto14_fallback(match):
    """Use the last database prediction after kickoff; never calculate hindsight."""
    match_id = f"TOTO14_{match.get('id', '')}"
    conn = None
    try:
        conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=15)
        identity = conn.execute(
            """
            SELECT home_team, away_team
            FROM predictions WHERE match_id = ?
            """,
            (match_id,),
        ).fetchone()
        if (
            not identity
            or str(identity[0]) != str(match.get("home"))
            or str(identity[1]) != str(match.get("away"))
        ):
            return None
        kickoff = _parse_kst_match_time(match.get("match_time"))
        if kickoff is None:
            return None
        cutoff = kickoff.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        row = conn.execute(
            """
            SELECT prob_pick, prob_pick_prob, stage, analysis_version
            FROM prediction_snapshots
            WHERE match_id = ? AND created_at <= ?
            ORDER BY created_at DESC, id DESC LIMIT 1
            """,
            (match_id, cutoff),
        ).fetchone()
        if not row:
            return None
        picks = _toto14_picks_from_display(row[0], identity[0], identity[1])
        return {
            "match": dict(match),
            "home_logo": None,
            "away_logo": None,
            "best_pick_display": str(row[0] or "동결 예측 없음"),
            "p_h": 0.0,
            "p_d": 0.0,
            "p_a": 0.0,
            "probabilities_unavailable": True,
            "picks": picks,
            "picks_html": _render_toto14_picks_html(picks),
            # 이미 동결된 예측은 당시 버전을 그대로 표시해야 새 버전의
            # 성적으로 잘못 섞이지 않는다.
            "analysis_version": str(row[3] or ANALYSIS_VERSION),
            "analysis_confidence": 0.0,
            "analysis_stage": "locked",
            "frozen_from_stage": str(row[2] or "regular"),
            "prediction_frozen": True,
            "home_form": "",
            "away_form": "",
            "h_rank_html": "",
            "a_rank_html": "",
        }
    except Exception as error:
        print(f"⚠️ 승무패 14 잠금 예측 복구 실패({match_id}): {error}")
        return None
    finally:
        if conn is not None:
            conn.close()


def _unavailable_toto14_item(match):
    return {
        "match": dict(match),
        "home_logo": None,
        "away_logo": None,
        "best_pick_display": "킥오프 전 동결본 없음",
        "p_h": 0.0,
        "p_d": 0.0,
        "p_a": 0.0,
        "probabilities_unavailable": True,
        "picks": [],
        "picks_html": _render_toto14_picks_html([]),
        "analysis_version": ANALYSIS_VERSION,
        "analysis_confidence": 0.0,
        "analysis_stage": "locked_unavailable",
        # 킥오프 전의 빈 대기 카드는 픽이 아니므로 다음 주기에
        # 팀·경기 신원을 다시 확인할 수 있어야 한다.
        "prediction_frozen": False,
        "home_form": "",
        "away_form": "",
        "h_rank_html": "",
        "a_rank_html": "",
    }


def save_dual_predictions_to_local_db(m_id, league, home_team, away_team, prob_pick, prob_val, ev_pick, ev_val, odd_h, odd_d, odd_a, match_time, is_toto14, fixture_id, analysis_stage="regular", confidence=0.0, analysis_version=None):
    target_analysis_version = str(analysis_version or ANALYSIS_VERSION)
    conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=30)
    conn.execute("PRAGMA busy_timeout = 30000")
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT stage, confidence, prob_pick, prob_pick_prob, ev_pick, ev_pick_prob,
                   analysis_version
            FROM prediction_snapshots
            WHERE match_id = ?
            ORDER BY id DESC LIMIT 1
        """, (str(m_id),))
        previous = cursor.fetchone()
        cursor.execute(
            """
            SELECT api_fixture_id, actual_result, match_time, home_team, away_team
            FROM predictions WHERE match_id = ?
            """,
            (m_id,),
        )
        row = cursor.fetchone()
        if not row:
            # A first prediction created after kickoff is hindsight, not a forecast.
            if analysis_stage == "locked" or (
                _parse_kst_match_time(match_time) is not None
                and datetime.now(KST) >= _parse_kst_match_time(match_time)
            ):
                print(f"⚠️ 킥오프 후 신규 예측 저장 차단: {home_team} vs {away_team}")
                return False
            cursor.execute("""
                INSERT INTO predictions 
                (match_id, league, home_team, away_team, prob_pick, prob_pick_prob,
                 ev_pick, ev_pick_prob, odd_h, odd_d, odd_a, match_time,
                 is_toto14, api_fixture_id, analysis_version)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                m_id, league, home_team, away_team, prob_pick, prob_val,
                ev_pick, ev_val, odd_h, odd_d, odd_a, match_time,
                is_toto14, fixture_id, target_analysis_version,
            ))
        else:
            existing_fix_id, actual_result, stored_match_time, stored_home, stored_away = row
            if str(stored_home) != str(home_team) or str(stored_away) != str(away_team):
                print(
                    f"❌ 예측 ID 충돌 차단({m_id}): "
                    f"{stored_home} vs {stored_away} != {home_team} vs {away_team}"
                )
                return False
            stored_kickoff = _parse_kst_match_time(stored_match_time)
            kickoff_passed = bool(stored_kickoff and datetime.now(KST) >= stored_kickoff)
            prediction_locked = (
                analysis_stage == "locked"
                or str(actual_result or "PENDING") != "PENDING"
                or kickoff_passed
            )
            if prediction_locked:
                # Fixture identity may be recovered once, but prediction/odds/team
                # fields become immutable only after kickoff or a known result.
                # A pre-kickoff TOTO stage no longer locks the testing answer.
                if (
                    str(actual_result or "PENDING") == "PENDING"
                    and not int(existing_fix_id or 0)
                    and int(fixture_id or 0)
                ):
                    cursor.execute(
                        "UPDATE predictions SET api_fixture_id = ? WHERE match_id = ?",
                        (int(fixture_id), m_id),
                    )
                conn.commit()
                return True

            final_fix_id = int(fixture_id or 0) or int(existing_fix_id or 0)
            # Scheduled cards always expose the newest pre-kickoff answer,
            # whether it came from a formula release or fresher evidence in
            # the same release. The prior answer remains in the append-only
            # prediction_snapshots table. Kickoff/finished rows returned above.
            cursor.execute("""
                UPDATE predictions
                SET prob_pick = ?, prob_pick_prob = ?, ev_pick = ?,
                    ev_pick_prob = ?, odd_h = ?, odd_d = ?, odd_a = ?,
                    api_fixture_id = ?, match_time = ?, league = ?,
                    analysis_version = ?
                WHERE match_id = ?
            """, (
                prob_pick, prob_val, ev_pick, ev_val, odd_h, odd_d, odd_a,
                final_fix_id, match_time, league, target_analysis_version, m_id,
            ))

        current = (
            str(analysis_stage), round(float(confidence or 0), 4), str(prob_pick),
            round(float(prob_val or 0), 2), str(ev_pick), round(float(ev_val or 0), 2),
            target_analysis_version,
        )
        previous_normalized = None
        if previous:
            previous_normalized = (
                str(previous[0]), round(float(previous[1] or 0), 4), str(previous[2]),
                round(float(previous[3] or 0), 2), str(previous[4]), round(float(previous[5] or 0), 2),
                str(previous[6] or ""),
            )
        if previous_normalized != current:
            cursor.execute("""
                INSERT INTO prediction_snapshots (
                    match_id, analysis_version, stage, confidence,
                    prob_pick, prob_pick_prob, ev_pick, ev_pick_prob,
                    odd_h, odd_d, odd_a, api_fixture_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                str(m_id), target_analysis_version, analysis_stage, float(confidence or 0),
                prob_pick, prob_val, ev_pick, ev_val, odd_h, odd_d, odd_a, int(fixture_id or 0)
            ))
        conn.commit()
        return True
    except Exception as e: print(f"⚠️ [DB 에러] 듀얼 예측 저장 실패: {e}")
    finally: conn.close()
    return False

# === 🧠 [V3/V4 통합 엔진] 주전 선발 & 전력 누수(WAR) 계산기 ===
POSITION_WEIGHTS = {
    "Goalkeeper": 1.5,
    "Defender": 1.3,
    "Midfielder": 1.1,
    "Attacker": 1.0
}
SQUAD_CACHE = {} 

def fetch_team_squad_cached(team_id):
    if not team_id:
        return []
    team_id = int(team_id)
    if team_id in SQUAD_CACHE:
        return SQUAD_CACHE[team_id]

    cache_key = f"team_squad_v2_{team_id}"
    cached_players = get_db_cache(cache_key, SQUAD_CACHE_TTL_HOURS)
    if isinstance(cached_players, list):
        SQUAD_CACHE[team_id] = cached_players
        return cached_players

    # 프로세스가 20분마다 새로 시작되어도 같은 선수단을 다시 부르지 않도록
    # SQLite 캐시를 사용한다. 일시 오류 때는 오래된 정상본을 사용한다.
    stale_players = get_db_cache(cache_key, 24 * 365 * 2)
    retry_guard = get_db_cache(
        f"{cache_key}_retry_guard", FIXTURE_IDENTITY_RETRY_HOURS
    )
    if retry_guard is not None:
        players = stale_players if isinstance(stale_players, list) else []
        SQUAD_CACHE[team_id] = players
        return players
    try:
        res = api_get("/players/squads", params={"team": team_id}, timeout=5)
        if res.status_code == 200:
            data = res.json()
            if not data.get("errors"):
                response_rows = data.get("response") or []
                players = (
                    response_rows[0].get("players", [])
                    if response_rows and isinstance(response_rows[0], dict)
                    else []
                )
                players = players if isinstance(players, list) else []
                SQUAD_CACHE[team_id] = players
                set_db_cache(cache_key, players)
                return players
    except Exception:
        pass
    set_db_cache(f"{cache_key}_retry_guard", {"failed": True})
    players = stale_players if isinstance(stale_players, list) else []
    SQUAD_CACHE[team_id] = players
    return players

def calculate_war_penalty(team_name, ace_names, total_inj_count, team_id):
    squad = fetch_team_squad_cached(team_id)
    war_penalty = 0.0
    details = []
    missing_aces_found = 0
    
    for ace in ace_names:
        pos = "Attacker" 
        for p in squad:
            if p.get("name") and (ace.lower() in p["name"].lower() or p["name"].lower() in ace.lower()):
                pos = p.get("position", "Attacker")
                break
        
        weight = POSITION_WEIGHTS.get(pos, 1.0)
        gap = 1.5 
        drop = gap * weight
        war_penalty += drop
        
        pos_kr = {"Goalkeeper": "GK", "Defender": "DF", "Midfielder": "MF", "Attacker": "FW"}.get(pos, "FW")
        details.append(f"{ace}({pos_kr})")
        missing_aces_found += 1
        
    regular_injuries = max(0, total_inj_count - missing_aces_found)
    effective_bench_injuries = min(regular_injuries, 3) 
    
    if effective_bench_injuries > 0:
        drop = effective_bench_injuries * 0.3
        war_penalty += drop
        if regular_injuries >= 4:
            details.append("서브 결장 다수")
        elif effective_bench_injuries >= 2:
            details.append(f"기타 서브 {effective_bench_injuries}명")
        elif effective_bench_injuries == 1:
            details.append("서브 1명")

    scaled_penalty = min(0.35, war_penalty * 0.08) 
    return scaled_penalty, details, war_penalty


def get_expected_core_players(team_id, league_id, season):
    """득점/도움 상위 선수와 보호 선수 중 현재 해당 팀 소속인 선수만 반환한다."""
    if not team_id:
        return []
    core_players = []
    key_players = fetch_league_key_players(league_id, season) if league_id and season else {}
    for name, stats in key_players.items():
        if stats.get("team_id") == team_id and name not in core_players:
            core_players.append(name)

    for player in fetch_team_squad_cached(team_id):
        actual_name = player.get("name", "")
        if actual_name and find_protected_star(actual_name) and actual_name not in core_players:
            core_players.append(actual_name)
    return core_players[:8]


_ROBOT_LINEUP_EXPERIENCE_CACHE = {}


def _load_robot_lineup_experience(team_id, serving_only=False):
    """Load every post-match official XI answer for this team.

    There is no minimum-match activation gate. One official answer changes the
    next estimate, while the returned counts keep that early evidence honest.
    """
    if not int(team_id or 0):
        return {"players": {}, "formations": {}, "samples": 0}
    team_id = int(team_id)
    cached_process = _ROBOT_LINEUP_EXPERIENCE_CACHE.get(team_id)
    if isinstance(cached_process, dict):
        return cached_process
    cache_key = f"robot_lineup_experience_v1_{team_id}"
    cached_persistent = get_db_cache(cache_key, 48)
    if isinstance(cached_persistent, dict):
        _ROBOT_LINEUP_EXPERIENCE_CACHE[team_id] = cached_persistent
        return cached_persistent
    if serving_only:
        return {"players": {}, "formations": {}, "samples": 0, "serving_cache_miss": True}
    conn = None
    try:
        conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=10)
        tables = {
            str(row[0]) for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        }
        if "robot_learning_samples" not in tables:
            return {"players": {}, "formations": {}, "samples": 0}
        columns = {
            str(row[1]) for row in conn.execute(
                "PRAGMA table_info(robot_learning_samples)"
            ).fetchall()
        }
        required = {
            "lineup_prediction_json", "official_lineup_json", "full_evidence_json"
        }
        if not required.issubset(columns):
            return {"players": {}, "formations": {}, "samples": 0}
        rows = conn.execute(
            """
            SELECT lineup_prediction_json,official_lineup_json,full_evidence_json
            FROM robot_learning_samples
            WHERE lineup_known_timestamp IS NOT NULL
              AND official_lineup_json NOT IN ('','{}')
            ORDER BY kickoff_timestamp,id
            """
        ).fetchall()
    except sqlite3.Error:
        return {"players": {}, "formations": {}, "samples": 0}
    finally:
        if conn is not None:
            conn.close()

    players = {}
    formations = Counter()
    samples = 0
    for prediction_json, official_json, evidence_json in rows:
        try:
            prediction = json.loads(prediction_json or "{}")
            official = json.loads(official_json or "{}")
            evidence = json.loads(evidence_json or "{}")
        except (TypeError, ValueError, json.JSONDecodeError):
            continue
        side = next((
            value for value in ("home", "away")
            if int(prediction.get(f"{value}_team_id") or 0) == int(team_id)
        ), None)
        if not side:
            continue
        team_detail = (official.get("details") or {}).get(str(int(team_id))) or {}
        actual = [
            str(row.get("name") or "").strip()
            for row in (team_detail.get("start_xi") or [])
            if str(row.get("name") or "").strip()
        ]
        if len(actual) < 11:
            continue
        candidate_rows = ((evidence.get("squads") or {}).get(side) or [])
        candidate_names = [
            str(row.get("name") or "").strip()
            for row in candidate_rows if isinstance(row, dict)
            and str(row.get("name") or "").strip()
        ]
        candidate_names.extend(
            prediction.get(f"{side}_predicted_starting_xi") or []
        )
        candidate_names.extend(actual)
        actual_keys = {_normalize_player_name(name) for name in actual}
        unique_candidates = {}
        for name in candidate_names:
            normalized = _normalize_player_name(name)
            if normalized:
                unique_candidates.setdefault(normalized, str(name))
        for normalized, name in unique_candidates.items():
            cell = players.setdefault(normalized, {
                "name": str(name), "eligible_games": 0, "starts": 0,
            })
            cell["eligible_games"] += 1
            if normalized in actual_keys:
                cell["starts"] += 1
        formation = str(team_detail.get("formation") or "").strip()
        if formation:
            formations[formation] += 1
        samples += 1
    for cell in players.values():
        games = int(cell.get("eligible_games") or 0)
        starts = int(cell.get("starts") or 0)
        cell["learned_start_probability"] = round(
            (starts + 0.5) / (games + 1.0), 8
        )
    result = {
        "players": players,
        "formations": dict(formations),
        "samples": samples,
    }
    _ROBOT_LINEUP_EXPERIENCE_CACHE[team_id] = result
    set_db_cache(cache_key, result)
    return result


def _formation_quotas(formation):
    try:
        parts = [int(part) for part in str(formation or "").split("-")]
    except ValueError:
        return None
    if not parts or sum(parts) != 10:
        return None
    defenders = parts[0]
    attackers = parts[-1] if len(parts) > 1 else 0
    midfielders = max(0, 10 - defenders - attackers)
    return {
        "Goalkeeper": 1, "Defender": defenders,
        "Midfielder": midfielders, "Attacker": attackers,
    }


def predict_starting_xi(
    team_id, league_id=None, season=None, unavailable_names=None,
    historical_lineups=True, cached_learning_only=False,
):
    """Predict an XI from recent official lineups and the current squad.

    The result is explicitly a pre-match estimate. Confirmed lineups are never
    invented: callers replace this list with ``fetch_lineups_api`` once eleven
    official starters are available. Historical lineup calls are cached for a
    day and their confirmed responses remain in the long-lived API cache.
    """
    if not team_id:
        return [], {
            "method": "recent-official-lineup-frequency-v1",
            "sample_lineups": 0,
            "confidence": 0.0,
            "reason": "팀 ID 없음",
        }

    squad = [
        player for player in fetch_team_squad_cached(team_id)
        if isinstance(player, dict) and str(player.get("name") or "").strip()
    ]
    unavailable = [
        _normalize_player_name(name)
        for name in (unavailable_names or []) if str(name or "").strip()
    ]

    def excluded(name):
        target = _normalize_player_name(name)
        return any(
            target == missing
            or (len(target) >= 6 and len(missing) >= 6
                and (target in missing or missing in target))
            for missing in unavailable if target and missing
        )

    recent = fetch_team_recent_fixtures_api(team_id, 24)[-4:]
    fixture_ids = [
        int((fixture.get("fixture") or {}).get("id") or 0)
        for fixture in recent if isinstance(fixture, dict)
    ]
    fixture_ids = [fixture_id for fixture_id in fixture_ids if fixture_id > 0]
    usage_key = "lineup_usage_v1_{}_{}".format(
        int(team_id), "-".join(map(str, fixture_ids)) or "none"
    )
    cached_usage = get_db_cache(usage_key, 24)
    usage = dict(cached_usage or {}) if isinstance(cached_usage, dict) else {}
    sample_lineups = int(usage.pop("_sample_lineups", 0) or 0)
    if not cached_usage and historical_lineups:
        usage = {}
        sample_lineups = 0
        # Newer lineups receive more weight. Only confirmed historical XI rows
        # are used, and the API helper caches them permanently once confirmed.
        for recency, fixture_id in enumerate(fixture_ids, start=1):
            lineups = fetch_lineups_api(fixture_id, 24 * 365 * 5)
            starters = list(lineups.get(str(team_id), []) or [])
            if not lineups.get("confirmed") or len(starters) < 11:
                continue
            sample_lineups += 1
            weight = float(recency)
            for name in starters:
                clean_name = str(name or "").strip()
                if clean_name:
                    usage[clean_name] = float(usage.get(clean_name, 0)) + weight
        set_db_cache(usage_key, {**usage, "_sample_lineups": sample_lineups})

    core = get_expected_core_players(team_id, league_id, season)
    robot_experience = _load_robot_lineup_experience(team_id, serving_only=cached_learning_only)
    learned_players = robot_experience.get("players") or {}
    core_normalized = {_normalize_player_name(name) for name in core}
    usage_by_normalized = {
        _normalize_player_name(name): float(score or 0)
        for name, score in usage.items() if _normalize_player_name(name)
    }
    players = []
    seen = set()
    for player in squad:
        name = str(player.get("name") or "").strip()
        normalized = _normalize_player_name(name)
        if not normalized or normalized in seen or excluded(name):
            continue
        seen.add(normalized)
        position = str(player.get("position") or "Unknown")
        appearances = usage_by_normalized.get(normalized, 0.0)
        learned = learned_players.get(normalized) or {}
        learned_games = int(learned.get("eligible_games") or 0)
        learned_probability = float(learned.get("learned_start_probability") or 0)
        core_bonus = 4.0 if normalized in core_normalized else 0.0
        try:
            shirt_number = int(player.get("number") or 99)
        except (TypeError, ValueError):
            shirt_number = 99
        players.append({
            "name": name,
            "position": position,
            "score": appearances + core_bonus + learned_probability * learned_games,
            "recent_weight": appearances,
            "learned_start_probability": learned_probability,
            "learned_games": learned_games,
            "shirt_number": shirt_number,
        })

    # If the current squad endpoint is temporarily empty, retain confirmed
    # recent starters as a bounded fallback instead of fabricating names.
    if not players:
        for name, appearances in usage.items():
            if str(name).startswith("_") or excluded(name):
                continue
            normalized = _normalize_player_name(name)
            if normalized and normalized not in seen:
                seen.add(normalized)
                players.append({
                    "name": str(name), "position": "Unknown",
                    "score": float(appearances or 0),
                    "recent_weight": float(appearances or 0),
                    "shirt_number": 99,
                })

    def rank_key(player):
        return (
            float(player.get("score") or 0),
            float(player.get("recent_weight") or 0),
            -int(player.get("shirt_number") or 99),
            str(player.get("name") or ""),
        )

    remaining = sorted(players, key=rank_key, reverse=True)
    selected = []
    # A neutral 4-3-3 positional shell is used only to stop a squad-list
    # fallback from selecting eleven attackers. It is not a formation claim.
    learned_formation = ""
    if robot_experience.get("formations"):
        learned_formation = max(
            robot_experience["formations"],
            key=lambda key: (robot_experience["formations"][key], key),
        )
    quotas = _formation_quotas(learned_formation) or {
        "Goalkeeper": 1, "Defender": 4,
        "Midfielder": 3, "Attacker": 3,
    }
    for position, quota in quotas.items():
        for player in [p for p in remaining if p["position"] == position][:quota]:
            selected.append(player)
            remaining.remove(player)
    for player in remaining:
        if len(selected) >= 11:
            break
        selected.append(player)

    names = [player["name"] for player in selected[:11]]
    method = (
        "recent-official-lineup-frequency-v1"
        if sample_lineups else "current-squad-core-positional-fallback-v1"
    )
    confidence = min(
        0.82,
        (0.42 + sample_lineups * 0.09 + (0.05 if len(names) == 11 else 0.0)),
    ) if names else 0.0
    return names, {
        "method": method,
        "sample_lineups": sample_lineups,
        "confidence": round(confidence, 3),
        "predicted_count": len(names),
        "excluded_unavailable_count": len(unavailable),
        "robot_lineup_answer_samples": int(robot_experience.get("samples") or 0),
        "learned_formation": learned_formation,
        "formation_note": (
            f"공식 선발 정답에서 학습한 포메이션 {learned_formation}"
            if learned_formation else
            "공식 선발 정답 전 포지션 균형용 4-3-3 임시 틀"
        ),
    }


def find_missing_core_players(core_players, starters):
    normalized_starters = [_normalize_player_name(name) for name in starters]
    missing = []
    for core in core_players:
        target = _normalize_player_name(core)
        found = any(
            target == starter or (len(target) >= 6 and (target in starter or starter in target))
            for starter in normalized_starters if starter
        )
        if not found:
            missing.append(core)
    return missing


def calculate_data_confidence(home_info, away_info, fixture_id, h_stand, a_stand, h_long, a_long,
                              h_recent, a_recent, h_stats, a_stats, h_inj_data, a_inj_data,
                              diff_hours, lineup_confirmed):
    """데이터가 부족한 경기는 확률을 낮춰 보이게 하고 TOP3 우선순위도 낮춘다."""
    score = 0.35
    if home_info.get("id") and away_info.get("id"):
        score += 0.10
    if fixture_id:
        score += 0.10
    if min(h_long.get("home_total", 0), a_long.get("away_total", 0)) >= 5:
        score += 0.12
    if h_stand.get("rank", 99) != 99 and a_stand.get("rank", 99) != 99:
        score += 0.08
    if min(h_recent.get("matches", 0), a_recent.get("matches", 0)) >= 4:
        score += 0.08
    if min(h_stats.get("sample_size", 0), a_stats.get("sample_size", 0)) >= 1:
        score += 0.04
    if h_inj_data.get("available") and a_inj_data.get("available"):
        score += 0.05
    if diff_hours > 1.5:
        score += 0.03
    elif lineup_confirmed:
        score += 0.08
    return round(max(0.35, min(0.95, score)), 3)


def prediction_stage(diff_hours, lineup_confirmed=False):
    if diff_hours <= 0:
        return "locked"
    if lineup_confirmed or diff_hours <= 0.5:
        return "T-30-final"
    if diff_hours <= 1.0:
        return "T-60"
    if diff_hours <= 1.5:
        return "T-90"
    return "regular"


MARKET_LABELS = {
    "1x2": "승무패",
    "handicap": "핸디캡",
    "totals": "언더오버",
}


def infer_pick_market(pick_or_text):
    if isinstance(pick_or_text, dict):
        explicit = str(pick_or_text.get("market_key") or "").strip().lower()
        if explicit in MARKET_LABELS:
            return explicit
        sort_id = int(pick_or_text.get("sort_id") or 0)
        if sort_id == 1:
            return "totals"
        if sort_id == 2:
            return "handicap"
        text = str(pick_or_text.get("raw_pick") or "")
    else:
        text = str(pick_or_text or "")
    lowered = text.lower().replace(" ", "")
    if "언더" in lowered or "오버" in lowered or "u/o" in lowered:
        return "totals"
    if "핸디" in lowered or "마핸" in lowered or "플핸" in lowered:
        return "handicap"
    return "1x2"


def _market_performance_cache_key(league_name=None):
    normalized = re.sub(r"[^0-9a-z가-힣]+", "_", str(league_name or "global").casefold()).strip("_")
    return f"market_performance_serving_v2_{normalized or 'global'}"


_SERVING_MARKET_PERFORMANCE_FALLBACK = None


def _lightweight_market_performance(league_name=None):
    """Fast serving fallback using only recent already-graded official rows.

    Heavy candidate replay/policy fitting is intentionally excluded from the
    customer pick path. The full learner may later replace this cache, while
    serving remains bounded and honest when no learned cache exists yet.
    """
    global _SERVING_MARKET_PERFORMANCE_FALLBACK
    if isinstance(_SERVING_MARKET_PERFORMANCE_FALLBACK, dict):
        return _SERVING_MARKET_PERFORMANCE_FALLBACK
    summary = {
        key: {"samples": 0, "hits": 0, "hit_rate": 0.5, "selection_share": 0.0,
              "scope": "recent-serving-fallback", "price_policy": {},
              "official_selection_policy": {}}
        for key in MARKET_LABELS
    }
    conn = None
    try:
        conn = sqlite3.connect(
            f"file:{_local_path('ai_predictions.db')}?mode=ro", uri=True, timeout=2
        )
        conn.execute("PRAGMA busy_timeout=2000")
        rows = conn.execute(
            """
            SELECT prob_pick,is_correct_prob
            FROM predictions
            WHERE actual_result='FINISHED' AND COALESCE(is_toto14,0)=0
              AND prob_pick IS NOT NULL AND prob_pick<>''
            ORDER BY rowid DESC LIMIT 300
            """
        ).fetchall()
    except sqlite3.Error:
        rows = []
    finally:
        if conn is not None:
            conn.close()
    counts = {key: 0 for key in MARKET_LABELS}
    for pick_text, hit in rows:
        market = infer_pick_market(pick_text)
        if market not in summary:
            continue
        counts[market] += 1
        summary[market]["samples"] += 1
        summary[market]["hits"] += 1 if int(hit or 0) == 1 else 0
    total = sum(counts.values())
    for market, values in summary.items():
        values["hit_rate"] = round((values["hits"] + 4.0) / (values["samples"] + 8.0), 4)
        values["selection_share"] = round(counts[market] / total, 4) if total else 0.0
    summary["_movement_policy"] = validate_movement_policy([])
    summary["_serving_fallback"] = True
    _SERVING_MARKET_PERFORMANCE_FALLBACK = summary
    return summary


def load_market_performance(league_name=None, serving_only=False):
    """Read honest market records, with a persistent fast cache for serving."""
    cache_key = _market_performance_cache_key(league_name)
    cached_summary = get_db_cache(cache_key, MASTER_MARKET_POLICY_CACHE_HOURS)
    if isinstance(cached_summary, dict):
        return cached_summary
    if serving_only:
        return _lightweight_market_performance(league_name)
    summary = {
        key: {"samples": 0, "hits": 0, "hit_rate": 0.5, "selection_share": 0.0}
        for key in MARKET_LABELS
    }
    candidate_rows = []
    movement_policy = validate_movement_policy([])
    try:
        conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=15)
        tables = {
            str(row[0]) for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table'"
            )
        }
        if "prediction_candidate_results" in tables:
            result_columns = {
                str(row[1]) for row in conn.execute(
                    "PRAGMA table_info(prediction_candidate_results)"
                )
            }
            if "market_rank" in result_columns:
                prediction_columns = {
                    str(row[1]) for row in conn.execute("PRAGMA table_info(predictions)")
                }
                if "league" in prediction_columns:
                    candidate_rows = conn.execute(
                        """
                        SELECT result.market_key, result.is_correct, prediction.league
                        FROM prediction_candidate_results AS result
                        LEFT JOIN predictions AS prediction
                          ON prediction.match_id = result.match_id
                        WHERE result.market_rank = 1
                          AND NOT (
                              prediction.match_id LIKE 'WORLD_%'
                              AND COALESCE(prediction.api_fixture_id, 0) > 0
                              AND EXISTS (
                                  SELECT 1 FROM predictions AS canonical
                                  WHERE canonical.api_fixture_id = prediction.api_fixture_id
                                    AND canonical.is_toto14 = 0
                                    AND canonical.match_id NOT LIKE 'WORLD_%'
                              )
                          )
                        ORDER BY result.id DESC LIMIT 1800
                        """
                    ).fetchall()
                else:
                    candidate_rows = [
                        (market, hit, "") for market, hit in conn.execute(
                            """
                            SELECT market_key, is_correct
                            FROM prediction_candidate_results
                            WHERE market_rank = 1
                            ORDER BY id DESC LIMIT 900
                            """
                        ).fetchall()
                    ]
        prediction_columns = {
            str(row[1]) for row in conn.execute("PRAGMA table_info(predictions)")
        }
        required_columns = {
            "prob_pick", "is_correct_prob", "ev_pick", "is_correct_ev",
            "actual_result", "match_time",
        }
        rows = (
            conn.execute(
                """
                SELECT prob_pick, is_correct_prob, ev_pick, is_correct_ev
                FROM predictions AS prediction
                WHERE actual_result = 'FINISHED'
                  AND NOT (
                      prediction.match_id LIKE 'WORLD_%'
                      AND COALESCE(prediction.api_fixture_id, 0) > 0
                      AND EXISTS (
                          SELECT 1 FROM predictions AS canonical
                          WHERE canonical.api_fixture_id = prediction.api_fixture_id
                            AND canonical.is_toto14 = 0
                            AND canonical.match_id NOT LIKE 'WORLD_%'
                      )
                  )
                ORDER BY match_time DESC LIMIT 300
                """
            ).fetchall()
            if required_columns.issubset(prediction_columns)
            else []
        )
        diagnostics = _candidate_learning_diagnostics(conn)
        price_policy = _verified_price_policy(conn)
        movement_policy = _verified_movement_policy(conn)
        official_selection_policy = _verified_official_selection_policy(conn)
        for market in summary:
            summary[market].update(diagnostics.get(market, {}))
            summary[market]["price_policy"] = price_policy
            summary[market]["official_selection_policy"] = official_selection_policy
        conn.close()
    except Exception:
        summary["_movement_policy"] = movement_policy
        return summary

    high_market_counts = {key: 0 for key in MARKET_LABELS}
    for prob_pick, prob_hit, ev_pick, ev_hit in rows:
        prob_market = infer_pick_market(prob_pick)
        high_market_counts[prob_market] += 1
        for pick_text, hit in ((prob_pick, prob_hit), (ev_pick, ev_hit)):
            if not pick_text:
                continue
            market = infer_pick_market(pick_text)
            summary[market]["samples"] += 1
            summary[market]["hits"] += 1 if int(hit or 0) == 1 else 0

    # The old record contains only picks the selector happened to expose, so it
    # is selection-biased.  New snapshots grade the top candidate inside every
    # available market.  As soon as those exist, they become the calibration
    # source and let 1X2, handicap and totals compete on their actual record.
    if candidate_rows:
        for market in MARKET_LABELS:
            summary[market]["samples"] = 0
            summary[market]["hits"] = 0
        for market, hit, _league in candidate_rows:
            market = str(market or "")
            if market not in summary:
                continue
            summary[market]["samples"] += 1
            summary[market]["hits"] += 1 if int(hit or 0) == 1 else 0

    total_high = sum(high_market_counts.values())
    target_league = " ".join(str(league_name or "").casefold().split())
    for market, values in summary.items():
        # 작은 표본이 한 시장을 과도하게 올리거나 내리지 않도록 베타 사전분포로 보정한다.
        global_rate = (values["hits"] + 4.0) / (values["samples"] + 8.0)
        league_rows = [
            int(hit or 0)
            for row_market, hit, row_league in candidate_rows
            if str(row_market or "") == market
            and target_league
            and " ".join(str(row_league or "").casefold().split()) == target_league
        ]
        league_samples = len(league_rows)
        league_hits = sum(1 for hit in league_rows if hit == 1)
        values["league_samples"] = league_samples
        values["league_hits"] = league_hits
        if league_samples >= 8:
            league_rate = (league_hits + 4.0) / (league_samples + 8.0)
            league_weight = min(0.50, league_samples / (league_samples + 24.0))
            values["hit_rate"] = round(
                global_rate * (1.0 - league_weight) + league_rate * league_weight,
                4,
            )
            values["scope"] = "global+league"
        else:
            values["hit_rate"] = round(global_rate, 4)
            values["scope"] = "global"
        values["selection_share"] = round(
            high_market_counts[market] / total_high, 4
        ) if total_high else 0.0
    summary["_movement_policy"] = movement_policy
    set_db_cache(cache_key, summary)
    return summary


def validate_time_ordered_calibration(groups):
    """Prequential replay: a result may train only after it was received.

    30 prior observations per bin and 30 independent later fixtures are a
    conservative deployment guard, not a claim of statistical significance.
    Full market vectors are normalized exactly as in the live calibrator.
    """
    bins, training, seen = {}, [], set()
    baseline_loss = corrected_loss = 0.0
    evaluated = 0
    for group in sorted(groups, key=lambda x: (x["kickoff"], str(x["key"]))):
        for previous in training:
            if previous["key"] in seen or previous["known_at"] >= group["kickoff"]:
                continue
            seen.add(previous["key"])
            for p, y in zip(previous["probabilities"], previous["outcomes"]):
                bucket = bins.setdefault(str(min(9, int(p*10))), {"samples": 0, "error_sum": 0.0})
                bucket["samples"] += 1
                bucket["error_sum"] += y-p
        corrected = []
        eligible = False
        for p in group["probabilities"]:
            bucket = bins.get(str(min(9, int(p*10))), {})
            n = bucket.get("samples", 0)
            eligible = eligible or n >= 30
            weight = n/(n+30.0)*.18 if n else 0
            corrected.append(max(0.0, min(1.0, p + weight*bucket.get("error_sum", 0)/n)) if n else p)
        corrected = normalize_probabilities(corrected)
        if eligible:
            baseline_loss += sum((p-y)**2 for p,y in zip(group["probabilities"], group["outcomes"]))
            corrected_loss += sum((p-y)**2 for p,y in zip(corrected, group["outcomes"]))
            evaluated += 1
        training.append(group)
    return {"calibration_validated": evaluated >= 30 and corrected_loss < baseline_loss,
            "validation_fixtures": evaluated,
            "baseline_brier": baseline_loss/evaluated if evaluated else None,
            "corrected_brier": corrected_loss/evaluated if evaluated else None,
            "method": "result-availability-aware-prequential-v1"}


def _official_selection_segment_keys(candidate):
    market = str(candidate.get("market_key") or "1x2")
    side = str(candidate.get("selection_side") or "unknown")
    probability = max(0.0, min(1.0, float(
        candidate.get("robust_probability")
        if candidate.get("robust_probability") is not None
        else candidate.get("prob") or 0
    )))
    odd = float(candidate.get("odd") or 0)
    price_band = (
        "no_price" if odd <= 1.0 else "below_1_50" if odd < 1.5
        else "1_50_to_2_00" if odd < 2.0
        else "2_00_to_3_00" if odd < 3.0 else "3_plus"
    )
    keys = [
        "global", f"market:{market}", f"market_side:{market}:{side}",
        f"market_price:{market}:{price_band}",
        f"market_probability:{market}:{min(9, max(0, int(probability * 10)))}",
    ]
    if candidate.get("is_true_underdog"):
        keys.append("opportunity:true_underdog")
    if odd >= 2.35:
        keys.append("opportunity:high_price")
    return keys


def _fit_official_selection_cells(groups):
    cells = {}
    for group in groups:
        for candidate in group.get("candidates") or []:
            probability = float(candidate.get("prob") or 0)
            outcome = candidate.get("outcome")
            if not 0 < probability < 1 or outcome not in (0, 1):
                continue
            for key in _official_selection_segment_keys(candidate):
                cell = cells.setdefault(
                    key, {"samples": 0, "error_sum": 0.0, "correct": 0}
                )
                cell["samples"] += 1
                cell["error_sum"] += int(outcome) - probability
                cell["correct"] += int(outcome)
    for cell in cells.values():
        samples = int(cell["samples"])
        cell["correction"] = round(max(
            -.12, min(.12, float(cell["error_sum"]) / (samples + 30.0))
        ), 8)
        cell["accuracy"] = round(float(cell["correct"]) / samples, 8)
        cell["error_sum"] = round(float(cell["error_sum"]), 8)
    return cells


def _official_selection_probability(candidate, cells, weight):
    base = max(0.0, min(1.0, float(candidate.get("prob") or 0)))
    eligible = [
        cells[key] for key in _official_selection_segment_keys(candidate)
        if key in cells and int(cells[key].get("samples") or 0) >= 20
    ]
    if not eligible:
        return base
    cohort_weights = [math.sqrt(int(cell["samples"])) for cell in eligible]
    correction = sum(
        cohort_weight * float(cell.get("correction") or 0)
        for cohort_weight, cell in zip(cohort_weights, eligible)
    ) / max(1e-9, sum(cohort_weights))
    return max(.001, min(.999, base + float(weight) * correction))


def validate_official_selection_policy(groups):
    """Promote a grading-note selector only on a later chronological block."""
    policy = {
        "active": False,
        "policy_version": "official-chronological-candidate-reliability-v2",
        "target_accuracy": .70,
        "train_fixtures": 0,
        "tuning_fixtures": 0,
        "validation_fixtures": 0,
        "baseline_accuracy": None,
        "validation_accuracy": None,
        "selected_weight": 0.0,
        "cells": {},
        "history_rewrite": False,
        "validation_scope": "frozen-prekickoff-features-chronological-holdout",
        "reason": "시간순 미래검증 표본 부족 · 현 공식 선택법 유지",
    }
    ordered = sorted(
        [group for group in groups if group.get("candidates")],
        key=lambda group: (float(group.get("kickoff") or 0), str(group.get("key") or "")),
    )
    if len(ordered) < 120:
        policy["available_fixtures"] = len(ordered)
        return policy
    validation_size = min(80, max(30, len(ordered) // 5))
    tuning_size = min(80, max(30, len(ordered) // 5))
    # Candidate grades may have been backfilled long after the match.  Their
    # frozen feature snapshot still predates kickoff, so an earlier-match
    # training block and a completely untouched later-match holdout is a valid
    # offline chronological study.  ``captured < kickoff < graded`` is checked
    # while loading; validation outcomes never enter the fitted cells.
    training = list(ordered[:-(validation_size + tuning_size)])
    tuning = ordered[-(validation_size + tuning_size):-validation_size]
    validation = ordered[-validation_size:]
    if len(training) < 60 or len(tuning) < 30 or len(validation) < 30:
        policy["available_fixtures"] = len(ordered)
        return policy
    training_cells = _fit_official_selection_cells(training)

    def replay(rows, cells, weight):
        correct = 0
        brier = 0.0
        changed = 0
        for group in rows:
            candidates = list(group.get("candidates") or [])
            current = next(
                (candidate for candidate in candidates if candidate.get("was_selected")),
                max(candidates, key=lambda candidate: (
                    float(candidate.get("official_score") or candidate.get("prob") or 0),
                    str(candidate.get("raw_pick") or ""),
                )),
            )
            if weight is None:
                chosen = current
                probability = float(chosen.get("prob") or 0)
            else:
                chosen = max(candidates, key=lambda candidate: (
                    _official_selection_probability(candidate, cells, weight),
                    float(candidate.get("official_score") or 0),
                    float(candidate.get("odd") or 0),
                    str(candidate.get("raw_pick") or ""),
                ))
                probability = _official_selection_probability(chosen, cells, weight)
                changed += int(chosen.get("raw_pick") != current.get("raw_pick"))
            outcome = int(chosen.get("outcome") or 0)
            correct += outcome
            brier += (probability - outcome) ** 2
        count = max(1, len(rows))
        return {
            "samples": len(rows), "correct": correct,
            "accuracy": correct / count, "brier": brier / count,
            "changed_selections": changed,
        }

    tuning_baseline = replay(tuning, training_cells, None)
    tuning_candidates = [
        (weight, replay(tuning, training_cells, weight))
        for weight in (.35, .65, 1.0)
    ]
    best_weight, tuning_best = min(
        tuning_candidates,
        key=lambda row: (
            -row[1]["accuracy"], row[1]["brier"], row[0]
        ),
    )
    # The weight is selected only on the middle chronological block.  The
    # final block below remains untouched until this one evaluation, so it is
    # a true future-style promotion test rather than a tuned-on-holdout score.
    validation_cells = _fit_official_selection_cells(training + list(tuning))
    baseline = replay(validation, validation_cells, None)
    best = replay(validation, validation_cells, best_weight)
    tuning_improved = bool(
        tuning_best["accuracy"] > tuning_baseline["accuracy"]
        or (
            tuning_best["accuracy"] == tuning_baseline["accuracy"]
            and tuning_best["brier"] < tuning_baseline["brier"]
        )
    )
    improved = bool(
        tuning_improved
        and
        tuning_best["changed_selections"] > 0
        and best["changed_selections"] > 0
        and (
            best["accuracy"] > baseline["accuracy"]
            or (
                best["accuracy"] == baseline["accuracy"]
                and best["brier"] < baseline["brier"]
            )
        )
    )
    policy.update({
        "active": improved,
        "train_fixtures": len(training),
        "tuning_fixtures": len(tuning),
        "validation_fixtures": len(validation),
        "tuning_baseline_accuracy": round(tuning_baseline["accuracy"], 8),
        "tuning_accuracy": round(tuning_best["accuracy"], 8),
        "baseline_accuracy": round(baseline["accuracy"], 8),
        "baseline_brier": round(baseline["brier"], 8),
        "validation_accuracy": round(best["accuracy"], 8),
        "validation_brier": round(best["brier"], 8),
        "validation_changed_selections": int(best["changed_selections"]),
        "selected_weight": best_weight if improved else 0.0,
        "cells": _fit_official_selection_cells(ordered) if improved else {},
        "goal_reached": bool(best["accuracy"] >= .70),
        "reason": (
            f"시간순 미래 {len(validation)}경기에서 기존 "
            f"{baseline['accuracy'] * 100:.1f}% → 학습 {best['accuracy'] * 100:.1f}%"
            if improved else
            f"시간순 미래 {len(validation)}경기에서 기존보다 개선되지 않아 현 공식 선택법 유지"
        ),
    })
    return policy


def _apply_toto14_probability_parameters(probabilities, parameters):
    """Apply a small learned 1X2 calibration without fabricating certainty."""
    try:
        raw = [max(1e-9, float(value)) for value in list(probabilities)[:3]]
    except (TypeError, ValueError):
        return []
    if len(raw) != 3 or not all(math.isfinite(value) for value in raw):
        return []
    total = sum(raw)
    if total <= 0:
        return []
    raw = [value / total for value in raw]
    parameters = parameters if isinstance(parameters, dict) else {}
    temperature = max(.55, min(1.8, float(parameters.get("temperature") or 1.0)))
    biases = [
        0.0,
        max(-.45, min(.45, float(parameters.get("draw_bias") or 0.0))),
        max(-.45, min(.45, float(parameters.get("away_bias") or 0.0))),
    ]
    logits = [math.log(value) / temperature + bias for value, bias in zip(raw, biases)]
    ceiling = max(logits)
    weights = [math.exp(value - ceiling) for value in logits]
    weight_total = sum(weights)
    return [value / weight_total for value in weights]


def apply_toto14_probability_policy(
    probabilities, policy, public_probabilities=None
):
    """Use only a policy that won chronological later-round validation."""
    raw = _apply_toto14_probability_parameters(probabilities, {})
    if not raw or not isinstance(policy, dict) or not policy.get("active"):
        return raw
    try:
        public_weight = max(
            0.0, min(.8, float(policy.get("public_vote_weight") or 0.0))
        )
    except (TypeError, ValueError):
        public_weight = 0.0
    if public_weight:
        public = _apply_toto14_probability_parameters(
            public_probabilities, {}
        )
        if len(public) == 3:
            raw = [
                (1.0 - public_weight) * model + public_weight * crowd
                for model, crowd in zip(raw, public)
            ]
    calibrated = _apply_toto14_probability_parameters(
        raw, policy.get("parameters") or {}
    )
    return calibrated or raw


def validate_toto14_probability_policy(records):
    """Promote W/D/L calibration only after a completely later pools round."""
    policy = {
        "active": False,
        "policy_version": "toto14-chronological-model-public-comparison-v2",
        "target_accuracy": .70,
        "train_fixtures": 0,
        "validation_fixtures": 0,
        "baseline_accuracy": None,
        "validation_accuracy": None,
        "baseline_brier": None,
        "validation_brier": None,
        "parameters": {},
        "history_rewrite": False,
        "validation_scope": "earlier-round-train-middle-round-tune-later-untouched-block",
        "reason": "승무패14 완료 회차 표본 부족 · 기존 확률 유지",
    }
    unique = {}
    for record in records or []:
        try:
            key = str(record.get("key") or "")
            round_key = str(record.get("round_key") or "")
            kickoff = float(record.get("kickoff") or 0)
            probabilities = _apply_toto14_probability_parameters(
                record.get("probabilities"), {}
            )
            outcome = int(record.get("outcome"))
            public_probabilities = _apply_toto14_probability_parameters(
                record.get("public_probabilities"), {}
            )
        except (TypeError, ValueError, AttributeError):
            continue
        if not key or not round_key or kickoff <= 0 or len(probabilities) != 3:
            continue
        if outcome not in (0, 1, 2):
            continue
        unique.setdefault(key, {
            "key": key, "round_key": round_key, "kickoff": kickoff,
            "probabilities": probabilities, "outcome": outcome,
            "public_probabilities": public_probabilities,
        })
    ordered = sorted(unique.values(), key=lambda row: (row["kickoff"], row["key"]))
    rounds = {}
    for row in ordered:
        rounds.setdefault(row["round_key"], []).append(row)
    round_order = sorted(
        rounds,
        key=lambda key: (min(row["kickoff"] for row in rounds[key]), key),
    )
    if len(round_order) < 2:
        policy["available_fixtures"] = len(ordered)
        policy["available_rounds"] = len(round_order)
        return policy
    validation_round = round_order[-1]
    validation = list(rounds[validation_round])
    training = [row for key in round_order[:-1] for row in rounds[key]]

    # The public share is one pre-kickoff signal, never an answer. It may be
    # blended only after an earlier train block, a later tuning block, and a
    # still later untouched block all confirm the prospective change.
    if len(round_order) >= 3:
        tuning_round = round_order[-2]
        public_training = [
            row for key in round_order[:-2] for row in rounds[key]
            if len(row.get("public_probabilities") or []) == 3
        ]
        tuning = [
            row for row in rounds[tuning_round]
            if len(row.get("public_probabilities") or []) == 3
        ]
        public_validation = [
            row for row in validation
            if len(row.get("public_probabilities") or []) == 3
        ]

        def public_score(rows, public_weight):
            correct = 0
            brier = 0.0
            log_loss = 0.0
            selections = []
            for row in rows:
                values = [
                    (1.0 - public_weight) * model + public_weight * public
                    for model, public in zip(
                        row["probabilities"], row["public_probabilities"]
                    )
                ]
                values = _apply_toto14_probability_parameters(values, {})
                choice = max(range(3), key=lambda index: values[index])
                outcome = int(row["outcome"])
                correct += int(choice == outcome)
                brier += sum(
                    (value - int(index == outcome)) ** 2
                    for index, value in enumerate(values)
                ) / 3.0
                log_loss -= math.log(max(1e-9, values[outcome]))
                selections.append(choice)
            count = max(1, len(rows))
            return {
                "accuracy": correct / count,
                "brier": brier / count,
                "log_loss": log_loss / count,
                "selections": selections,
            }

        if (
            len(public_training) >= 12 and len(tuning) >= 5
            and len(public_validation) >= 5
            and max(row["kickoff"] for row in public_training) + 6 * 3600
                < min(row["kickoff"] for row in tuning)
            and max(row["kickoff"] for row in tuning) + 6 * 3600
                < min(row["kickoff"] for row in public_validation)
        ):
            training_baseline = public_score(public_training, 0.0)
            public_candidates = [
                (weight, public_score(public_training, weight))
                for weight in (.2, .4, .6, .8)
            ]
            public_weight, training_best = min(
                public_candidates,
                key=lambda row: (
                    -row[1]["accuracy"], row[1]["brier"],
                    row[1]["log_loss"], row[0],
                ),
            )
            tuning_baseline = public_score(tuning, 0.0)
            tuning_best = public_score(tuning, public_weight)
            validation_baseline = public_score(public_validation, 0.0)
            validation_best = public_score(public_validation, public_weight)
            validation_changed = sum(
                int(old != new) for old, new in zip(
                    validation_baseline["selections"],
                    validation_best["selections"],
                )
            )
            training_improved = bool(
                training_best["accuracy"] > training_baseline["accuracy"]
                or (
                    training_best["accuracy"] == training_baseline["accuracy"]
                    and training_best["brier"] < training_baseline["brier"]
                    and training_best["log_loss"] < training_baseline["log_loss"]
                )
            )
            tuning_confirmed = bool(
                tuning_best["accuracy"] >= tuning_baseline["accuracy"]
                and tuning_best["brier"] < tuning_baseline["brier"]
                and tuning_best["log_loss"] < tuning_baseline["log_loss"]
            )
            future_improved = bool(
                validation_changed > 0
                and validation_best["accuracy"] > validation_baseline["accuracy"]
                and validation_best["brier"] < validation_baseline["brier"]
                and validation_best["log_loss"] < validation_baseline["log_loss"]
            )
            if training_improved and tuning_confirmed and future_improved:
                policy.update({
                    "active": True,
                    "train_fixtures": len(public_training),
                    "tuning_fixtures": len(tuning),
                    "validation_fixtures": len(public_validation),
                    "tuning_round": tuning_round,
                    "validation_round": validation_round,
                    "training_accuracy": round(training_best["accuracy"], 8),
                    "tuning_baseline_accuracy": round(tuning_baseline["accuracy"], 8),
                    "tuning_accuracy": round(tuning_best["accuracy"], 8),
                    "baseline_accuracy": round(validation_baseline["accuracy"], 8),
                    "validation_accuracy": round(validation_best["accuracy"], 8),
                    "baseline_brier": round(validation_baseline["brier"], 8),
                    "validation_brier": round(validation_best["brier"], 8),
                    "baseline_log_loss": round(validation_baseline["log_loss"], 8),
                    "validation_log_loss": round(validation_best["log_loss"], 8),
                    "validation_changed_selections": validation_changed,
                    "public_vote_weight": public_weight,
                    "parameters": {},
                    "goal_reached": bool(validation_best["accuracy"] >= .70),
                    "reason": (
                        f"시간순 마지막 {len(public_validation)}경기 단통이 기존 "
                        f"{validation_baseline['accuracy'] * 100:.1f}% → 비교학습 "
                        f"{validation_best['accuracy'] * 100:.1f}%로 개선"
                    ),
                })
                return policy
    if len(training) < 12 or len(validation) < 5:
        policy["available_fixtures"] = len(ordered)
        policy["available_rounds"] = len(round_order)
        return policy
    if max(row["kickoff"] for row in training) + 6 * 3600 >= min(
        row["kickoff"] for row in validation
    ):
        policy.update(
            available_fixtures=len(ordered), available_rounds=len(round_order),
            reason="이전 회차 결과 확정과 다음 회차 시작 간격 미확인 · 기존 확률 유지",
        )
        return policy

    def score(rows, parameters):
        correct = 0
        brier = 0.0
        log_loss = 0.0
        selections = []
        for row in rows:
            calibrated = _apply_toto14_probability_parameters(
                row["probabilities"], parameters
            )
            choice = max(range(3), key=lambda index: calibrated[index])
            outcome = int(row["outcome"])
            correct += int(choice == outcome)
            brier += sum(
                (probability - int(index == outcome)) ** 2
                for index, probability in enumerate(calibrated)
            ) / 3.0
            log_loss -= math.log(max(1e-9, calibrated[outcome]))
            selections.append(choice)
        count = max(1, len(rows))
        return {
            "accuracy": correct / count,
            "brier": brier / count,
            "log_loss": log_loss / count,
            "selections": selections,
        }

    identity = {"temperature": 1.0, "draw_bias": 0.0, "away_bias": 0.0}
    training_baseline = score(training, identity)
    candidates = []
    for temperature in (.7, .85, 1.0, 1.2, 1.45):
        for draw_bias in (-.35, -.18, 0.0, .18, .35):
            for away_bias in (-.35, -.18, 0.0, .18, .35):
                parameters = {
                    "temperature": temperature,
                    "draw_bias": draw_bias,
                    "away_bias": away_bias,
                }
                result = score(training, parameters)
                complexity = (
                    abs(temperature - 1.0) + abs(draw_bias) + abs(away_bias)
                )
                candidates.append((parameters, result, complexity))
    parameters, training_best, _ = min(
        candidates,
        key=lambda row: (
            -row[1]["accuracy"], row[1]["brier"], row[1]["log_loss"], row[2]
        ),
    )
    baseline = score(validation, identity)
    best = score(validation, parameters)
    changed = sum(
        int(old != new)
        for old, new in zip(baseline["selections"], best["selections"])
    )
    training_improved = bool(
        training_best["accuracy"] > training_baseline["accuracy"]
        and training_best["brier"] <= training_baseline["brier"]
        or (
            training_best["accuracy"] == training_baseline["accuracy"]
            and training_best["brier"] < training_baseline["brier"]
            and training_best["log_loss"] < training_baseline["log_loss"]
        )
    )
    improved = bool(
        training_improved
        and (
            best["accuracy"] > baseline["accuracy"]
            and best["brier"] <= baseline["brier"]
            or (
                best["accuracy"] == baseline["accuracy"]
                and best["brier"] < baseline["brier"]
                and best["log_loss"] < baseline["log_loss"]
            )
        )
    )
    policy.update({
        "active": improved,
        "train_fixtures": len(training),
        "validation_fixtures": len(validation),
        "validation_round": validation_round,
        "training_accuracy": round(training_best["accuracy"], 8),
        "baseline_accuracy": round(baseline["accuracy"], 8),
        "validation_accuracy": round(best["accuracy"], 8),
        "baseline_brier": round(baseline["brier"], 8),
        "validation_brier": round(best["brier"], 8),
        "baseline_log_loss": round(baseline["log_loss"], 8),
        "validation_log_loss": round(best["log_loss"], 8),
        "validation_changed_selections": changed,
        "parameters": parameters if improved else {},
        "goal_reached": bool(best["accuracy"] >= .70),
        "reason": (
            f"다음 완전 회차 {len(validation)}경기에서 기존 "
            f"{baseline['accuracy'] * 100:.1f}% → 학습 {best['accuracy'] * 100:.1f}%"
            if improved else
            f"다음 완전 회차 {len(validation)}경기에서 확률·적중이 함께 개선되지 않아 기존 확률 유지"
        ),
    })
    return policy


def _verified_toto14_probability_policy(conn):
    records = []
    try:
        rows = conn.execute(
            """
            SELECT p.match_id,p.match_time,p.actual_score,f.payload_json,f.frozen_at
            FROM predictions AS p
            JOIN toto14_prediction_freezes AS f ON f.match_id=p.match_id
            WHERE p.is_toto14=1 AND p.actual_result='FINISHED'
              AND p.actual_score LIKE '%:%'
            ORDER BY p.match_time,p.match_id
            """
        ).fetchall()
    except sqlite3.Error:
        return validate_toto14_probability_policy([])
    for match_id, match_time, actual_score, payload_json, frozen_at in rows:
        try:
            kickoff = _parse_kst_match_time(match_time).timestamp()
            captured = datetime.fromisoformat(
                str(frozen_at).replace("Z", "+00:00")
            )
            if captured.tzinfo is None:
                captured = captured.replace(tzinfo=timezone.utc)
            if captured.timestamp() >= kickoff:
                continue
            home_goals, away_goals = [
                int(value) for value in str(actual_score).split(":", 1)
            ]
            outcome = 0 if home_goals > away_goals else 2 if home_goals < away_goals else 1
            payload = json.loads(payload_json or "{}")
            probabilities = [
                float(payload.get("p_h")) / 100.0,
                float(payload.get("p_d")) / 100.0,
                float(payload.get("p_a")) / 100.0,
            ]
            match_payload = payload.get("match") or {}
            public_probabilities = [
                float(match_payload.get("vote_h")) / 100.0,
                float(match_payload.get("vote_d")) / 100.0,
                float(match_payload.get("vote_a")) / 100.0,
            ]
            records.append({
                "key": str(match_id),
                "round_key": str(match_id).rsplit("_", 1)[0],
                "kickoff": kickoff,
                "probabilities": probabilities,
                "public_probabilities": public_probabilities,
                "outcome": outcome,
            })
        except (TypeError, ValueError, AttributeError, json.JSONDecodeError):
            continue
    policy = validate_toto14_probability_policy(records)
    policy["cohort_fixtures"] = len(records)
    return policy


def load_toto14_probability_policy():
    """Read the local frozen scorecard once; never calls a sports API."""
    conn = None
    try:
        conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=10)
        return _verified_toto14_probability_policy(conn)
    except sqlite3.Error:
        return validate_toto14_probability_policy([])
    finally:
        if conn is not None:
            conn.close()


def _verified_official_selection_policy(conn):
    """Rebuild a read-only candidate policy from timestamp-proven snapshots."""
    groups = {}
    chosen_snapshots = {}
    payloads = {}
    try:
        rows = conn.execute(
            """
            SELECT p.api_fixture_id,p.match_id,p.match_time,s.id,s.created_at,
                   s.candidates_json,r.raw_pick,r.market_key,r.model_probability,
                   r.fair_probability,r.odd,r.is_correct,r.graded_at,r.selected_as
            FROM prediction_analysis_snapshots AS s
            JOIN predictions AS p ON p.match_id=s.match_id
            JOIN prediction_candidate_results AS r ON r.analysis_snapshot_id=s.id
            WHERE p.actual_result='FINISHED' AND COALESCE(p.is_toto14,0)=0
              AND COALESCE(p.api_fixture_id,0)>0
            ORDER BY s.id DESC,r.id DESC LIMIT 12000
            """
        ).fetchall()
    except sqlite3.Error:
        return validate_official_selection_policy([])

    def stamp(value):
        moment = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if moment.tzinfo is None:
            moment = moment.replace(tzinfo=timezone.utc)
        return moment.timestamp()

    for (
        fixture, match_id, match_time, snapshot_id, created_at, payload,
        raw_pick, market, probability, fair_probability, odd, outcome,
        graded_at, selected_as,
    ) in rows:
        try:
            kickoff = _parse_kst_match_time(match_time).timestamp()
            captured = stamp(created_at)
            known_at = stamp(graded_at)
            if not captured < kickoff < known_at or outcome not in (0, 1):
                continue
            fixture_key = str(int(fixture))
            chosen_snapshots.setdefault(fixture_key, int(snapshot_id))
            if chosen_snapshots[fixture_key] != int(snapshot_id):
                continue
            if snapshot_id not in payloads:
                payloads[snapshot_id] = {
                    str(item.get("raw_pick") or ""): item
                    for item in json.loads(payload or "[]")
                    if isinstance(item, dict)
                }
            saved = dict(payloads[snapshot_id].get(str(raw_pick or "")) or {})
            probability = float(
                saved.get("model_probability")
                if saved.get("model_probability") is not None else probability
            )
            if not 0 < probability < 1:
                continue
            try:
                memberships = json.loads(selected_as or "[]")
            except (TypeError, ValueError, json.JSONDecodeError):
                memberships = []
            candidate = {
                **saved,
                "raw_pick": str(raw_pick or ""),
                "market_key": str(market or saved.get("market_key") or "1x2"),
                "selection_side": str(saved.get("selection_side") or ""),
                "prob": probability,
                "robust_probability": float(
                    saved.get("robust_probability")
                    if saved.get("robust_probability") is not None else probability
                ),
                "fair_prob": saved.get("fair_probability", fair_probability),
                "odd": float(saved.get("odd") or odd or 0),
                "official_score": float(saved.get("official_score") or probability),
                "outcome": int(outcome),
                "was_selected": "high_probability" in memberships,
            }
            group = groups.setdefault(fixture_key, {
                "key": fixture_key, "kickoff": kickoff,
                "known_at": known_at, "candidates": [],
            })
            group["known_at"] = max(float(group["known_at"]), known_at)
            if not any(row.get("raw_pick") == candidate["raw_pick"] for row in group["candidates"]):
                group["candidates"].append(candidate)
        except (TypeError, ValueError, AttributeError, KeyError, json.JSONDecodeError):
            continue
    complete = [
        group for group in groups.values()
        if len(group["candidates"]) >= 5
        and len({row["market_key"] for row in group["candidates"]}) >= 2
    ]
    policy = validate_official_selection_policy(complete)
    policy["cohort_fixtures"] = len(complete)
    return policy


def _verified_price_policy(conn):
    """Replay complete frozen candidate sets once per fixture, read-only."""
    groups = {}
    try:
        rows = conn.execute("""SELECT p.api_fixture_id,p.match_time,s.id,s.created_at,s.candidates_json,
            r.raw_pick,r.is_correct,r.graded_at,s.confidence
            FROM prediction_analysis_snapshots s JOIN predictions p ON p.match_id=s.match_id
            JOIN prediction_candidate_results r ON r.analysis_snapshot_id=s.id
            WHERE p.actual_result='FINISHED' AND COALESCE(p.is_toto14,0)=0
              AND p.api_fixture_id>0 AND s.candidates_json LIKE ?
            ORDER BY s.id DESC,r.id DESC LIMIT 8000""",
            ('%"forecast_model_version": "'+FORECAST_MODEL_VERSION+'"%',)).fetchall()
    except sqlite3.Error:
        return validate_price_policy([])
    selected_snapshots, payloads = {}, {}
    now = datetime.now(timezone.utc).timestamp()
    def stamp(value):
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return (dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)).timestamp()
    for fixture, when, sid, created, raw, pick_name, outcome, received, confidence in rows:
        try:
            kickoff = _parse_kst_match_time(when).timestamp()
            known_at = stamp(received)
            if not stamp(created) < kickoff < known_at <= now:
                continue
            selected_snapshots.setdefault(fixture, sid)
            if selected_snapshots[fixture] != sid:
                continue
            if sid not in payloads:
                payloads[sid] = {p["raw_pick"]: p for p in json.loads(raw)}
            saved = payloads[sid].get(pick_name) or {}
            if saved.get("forecast_model_version") != FORECAST_MODEL_VERSION or outcome not in (0, 1):
                continue
            pick = dict(saved, prob=saved.get("model_probability"), fair_prob=saved.get("fair_probability"), outcome=outcome)
            if not valid_analysis_candidates([pick]) or not float(pick.get("odd") or 0) > 1:
                continue
            group = groups.setdefault(fixture, dict(fixture=fixture, kickoff=kickoff, known_at=known_at,
                                                   confidence=float(confidence or 0), picks={}))
            group["known_at"] = max(group["known_at"], known_at)
            group["picks"][pick_name] = pick
        except (ValueError, TypeError, KeyError, AttributeError):
            continue
    # Price policy must see all eight real binary priced candidates, not just
    # whichever winning market happened to be saved. Partial games don't train it.
    complete = [dict(g, picks=list(g["picks"].values())) for g in groups.values() if len(g["picks"]) == 8]
    policy = validate_price_policy(complete)
    policy["cohort_fixtures"] = len(complete)
    policy["forecast_model_version"] = FORECAST_MODEL_VERSION
    return policy


def _movement_cohort_keys(features):
    side = str(features.get("side") or "")
    timing = str(features.get("timing") or "regular")
    league = re.sub(
        r"[^0-9a-z가-힣]+", "", str(features.get("league") or "").casefold()
    )
    context = "|".join([
        f"side:{side}", f"timing:{timing}",
        f"cross:{int(bool(features.get('cross_market_agreement')))}",
        f"persistent:{int(bool(features.get('persistent')))}",
        f"underdog:{int(bool(features.get('underdog_move')))}",
    ])
    keys = []
    bookmaker_set = str(features.get("bookmaker_set") or "")
    if bookmaker_set:
        keys.append(f"book:{bookmaker_set}|side:{side}")
    if league:
        keys.append(f"league:{league}|side:{side}|timing:{timing}")
    keys.extend(["context:" + context, f"side:{side}"])
    return keys


def _fit_movement_corrections(rows):
    cohorts = {}
    for row in rows:
        for key in _movement_cohort_keys(row["features"]):
            bucket = cohorts.setdefault(key, {"samples": 0, "error_sum": 0.0})
            bucket["samples"] += 1
            bucket["error_sum"] += float(row["outcome"]) - float(row["probability"])
    corrections = {}
    for key, bucket in cohorts.items():
        minimum = (25 if key.startswith(("book:", "league:"))
                   else 20 if key.startswith("context:") else 40)
        if bucket["samples"] < minimum:
            continue
        correction = max(-.05, min(.05, bucket["error_sum"] / (bucket["samples"] + 30.0)))
        corrections[key] = {"samples": bucket["samples"], "correction": round(correction, 6)}
    return corrections


def validate_movement_policy(records):
    """Promote odds-movement learning only after a chronological holdout."""
    policy = {"active": False, "method": "chronological-league-bookmaker-movement-residual-v2",
              "validation_fixtures": 0, "corrections": {},
              "reason": "배당 변화 학습의 시간순 검증 표본 부족"}
    unique = {str(row["fixture"]): row for row in records}
    ordered = sorted(unique.values(), key=lambda row: (row["kickoff"], str(row["fixture"])))
    if len(ordered) < 110:
        return policy
    split = max(80, int(len(ordered) * .8))
    boundary = ordered[split]["kickoff"]
    train = [row for row in ordered if row["kickoff"] < boundary and row["known_at"] < boundary]
    validation = [row for row in ordered if row["kickoff"] >= boundary]
    if len(train) < 80 or len(validation) < 30:
        return policy
    corrections = _fit_movement_corrections(train)
    baseline = corrected = 0.0
    evaluated = 0
    for row in validation:
        cohort = next((corrections[key] for key in _movement_cohort_keys(row["features"])
                       if key in corrections), None)
        if not cohort:
            continue
        p = float(row["probability"])
        q = max(.001, min(.999, p + float(cohort["correction"])))
        y = int(row["outcome"])
        baseline += (p - y) ** 2
        corrected += (q - y) ** 2
        evaluated += 1
    passed = evaluated >= 30 and corrected < baseline
    policy.update(train_fixtures=len(train), validation_fixtures=evaluated,
                  train_before=boundary,
                  baseline_brier=baseline / evaluated if evaluated else None,
                  corrected_brier=corrected / evaluated if evaluated else None,
                  active=passed,
                  reason=("시간순 보류 표본에서 배당 변화 보정 오차 감소" if passed
                          else "시간순 개선 미확인 · 배당 변화는 설명 근거로만 사용"))
    if passed:
        policy["corrections"] = _fit_movement_corrections(ordered)
    return policy


def _verified_movement_policy(conn):
    records, chosen = [], {}
    try:
        rows = conn.execute("""
            SELECT p.api_fixture_id,p.match_time,p.league,s.id,s.created_at,s.candidates_json,
                   r.raw_pick,r.is_correct,r.graded_at
            FROM prediction_analysis_snapshots s
            JOIN predictions p ON p.match_id=s.match_id
            JOIN prediction_candidate_results r ON r.analysis_snapshot_id=s.id
            WHERE p.actual_result='FINISHED' AND COALESCE(p.is_toto14,0)=0
              AND p.api_fixture_id>0 AND r.market_key='1x2'
            ORDER BY s.id DESC,r.id DESC LIMIT 8000
        """).fetchall()
    except sqlite3.Error:
        return validate_movement_policy([])

    def stamp(value):
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return (dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)).timestamp()

    payloads = {}
    for fixture, match_time, league, snapshot_id, created, payload, raw_pick, outcome, graded_at in rows:
        try:
            kickoff = _parse_kst_match_time(match_time).timestamp()
            known_at = stamp(graded_at)
            if not stamp(created) < kickoff < known_at:
                continue
            chosen.setdefault(str(fixture), snapshot_id)
            if chosen[str(fixture)] != snapshot_id:
                continue
            if snapshot_id not in payloads:
                payloads[snapshot_id] = {str(item.get("raw_pick") or ""): item
                                         for item in json.loads(payload or "[]")}
            candidate = payloads[snapshot_id].get(str(raw_pick or "")) or {}
            features = candidate.get("movement_features") or {}
            probability = float(candidate.get("raw_model_probability") or candidate.get("model_probability") or 0)
            if (candidate.get("forecast_model_version") != FORECAST_MODEL_VERSION
                    or not features.get("qualified") or not features.get("direction_match")
                    or features.get("side") not in {"home", "draw", "away"}
                    or outcome not in (0, 1) or not 0 < probability < 1):
                continue
            features = dict(features)
            features["league"] = str(league or "")
            records.append({"fixture": str(fixture), "kickoff": kickoff, "known_at": known_at,
                            "probability": probability, "outcome": int(outcome),
                            "features": features})
        except (TypeError, ValueError, AttributeError, KeyError):
            continue
    policy = validate_movement_policy(records)
    policy["cohort_fixtures"] = len({row["fixture"] for row in records})
    policy["forecast_model_version"] = FORECAST_MODEL_VERSION
    return policy


def learned_movement_wdl_adjustment(movement, policy, league_name=""):
    """Return a W/D/L residual vector; inactive validation means all zero."""
    if not (isinstance(policy, dict) and policy.get("active")
            and policy.get("forecast_model_version") == FORECAST_MODEL_VERSION
            and movement.get("qualified") and movement.get("comparable_bookmakers")):
        return [0.0, 0.0, 0.0]
    corrections = policy.get("corrections") or {}
    vector = {"home": 0.0, "draw": 0.0, "away": 0.0}
    for signal in movement.get("signals") or []:
        if signal.get("market") != "1x2" or signal.get("side") not in vector:
            continue
        features = {"side": signal.get("side"), "timing": movement.get("timing"),
                    "league": league_name,
                    "cross_market_agreement": signal.get("side") in (movement.get("agreement_sides") or []),
                    "persistent": bool(signal.get("persistent_from_opening")),
                    "underdog_move": bool(movement.get("underdog_move")),
                    "bookmaker_set": ",".join(str(value) for value in movement.get("bookmaker_ids") or [])}
        cohort = next((corrections[key] for key in _movement_cohort_keys(features)
                       if key in corrections), None)
        if cohort:
            vector[str(signal["side"])] = max(-.05, min(.05, float(cohort.get("correction") or 0)))
    return [vector[side] for side in ("home", "draw", "away")]


def _verified_calibration_history(conn):
    """Use pre-learning probabilities with timestamp proof; never read APIs."""
    out = {market: {"calibration_bins": {}, "calibration_validated": False,
                    "validation_fixtures": 0} for market in MARKET_LABELS}
    try:
        rows = conn.execute("""
            SELECT r.market_key,r.raw_pick,r.is_correct,r.graded_at,p.api_fixture_id,
                   p.match_id,p.match_time,s.id,s.created_at,s.candidates_json,r.analysis_version
            FROM prediction_candidate_results r
            JOIN predictions p ON p.match_id=r.match_id
            JOIN prediction_analysis_snapshots s ON s.id=r.analysis_snapshot_id
            WHERE p.actual_result='FINISHED' AND COALESCE(p.is_toto14,0)=0
              AND (r.analysis_version IN (?,?) OR s.candidates_json LIKE ?)
            ORDER BY s.id DESC,r.id DESC LIMIT 8000
        """, (ANALYSIS_VERSION, WORLD_ANALYSIS_VERSION,
                '%"forecast_model_version": "'+FORECAST_MODEL_VERSION+'"%')).fetchall()
    except sqlite3.Error:
        return out
    parsed, snapshots, grouped, seen = {}, {}, {}, set()
    now = datetime.now(timezone.utc).timestamp()

    def utc_stamp(value):
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return (dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)).timestamp()

    for market, raw_pick, y, received, fixture, match_id, match_time, sid, created, payload, version in rows:
        if market not in out:
            continue
        try:
            kickoff = _parse_kst_match_time(match_time).timestamp()
            known_at = utc_stamp(received)
            if utc_stamp(created) >= kickoff or not kickoff < known_at <= now:
                continue
            if sid not in parsed:
                parsed[sid] = {str(c.get("raw_pick")): c for c in json.loads(payload or "[]")}
            candidate = parsed[sid].get(raw_pick) or {}
            signature = candidate.get("forecast_model_version")
            if signature and signature != FORECAST_MODEL_VERSION:
                continue
            if not signature and version not in {ANALYSIS_VERSION, WORLD_ANALYSIS_VERSION}:
                continue
            if int(fixture or 0) <= 0:
                continue  # Unknown fixture cannot count as an independent match.
            p = float(candidate["raw_model_probability"])
            if not 0 < p < 1 or y not in (0, 1) or not candidate.get("settlement_supported", True):
                continue
        except (ValueError, TypeError, AttributeError, KeyError):
            continue
        identity = (str(fixture or match_id), market)
        snapshots.setdefault(identity, sid)
        if snapshots[identity] != sid or (identity, raw_pick) in seen:
            continue
        seen.add((identity, raw_pick))
        group = grouped.setdefault(identity, {"key": identity, "kickoff": kickoff,
                                    "known_at": known_at, "probabilities": [], "outcomes": []})
        group["known_at"] = max(known_at, group["known_at"])
        group["probabilities"].append(p)
        group["outcomes"].append(y)
    for market in out:
        groups = [g for key,g in grouped.items() if key[1] == market
                  and len(g["probabilities"]) == (2 if market == "totals" else 3)
                  and abs(sum(g["probabilities"])-1) < 1e-4 and sum(g["outcomes"]) == 1]
        for group in groups:
            for p,y in zip(group["probabilities"], group["outcomes"]):
                bucket = out[market]["calibration_bins"].setdefault(str(min(9,int(p*10))), {"samples": 0, "error_sum": 0.0})
                bucket["samples"] += 1
                bucket["error_sum"] += y-p
        out[market].update(validate_time_ordered_calibration(groups))
    return out


def _candidate_learning_diagnostics(conn):
    """All frozen candidates, not only winners/selected picks. Read-only.

    Binary markets only: Asian/integer totals need refund-aware settlement,
    so legacy boolean results from those lines are not treated as ROI evidence.
    One snapshot per fixture; no hindsight pick replacement.
    """
    diagnostics = {market: {"candidate_samples": 0, "brier_score": None,
                           "unit_roi": None, "calibration_bins": {}, "odds_bands": {}}
                   for market in MARKET_LABELS}
    try:
        rows = conn.execute("""
            SELECT r.market_key,r.model_probability,r.odd,r.is_correct,r.raw_pick,
                   r.analysis_version,r.analysis_snapshot_id,p.api_fixture_id,r.match_id
            FROM prediction_candidate_results r JOIN predictions p ON p.match_id=r.match_id
            WHERE p.actual_result='FINISHED' AND COALESCE(p.is_toto14,0)=0
            ORDER BY r.analysis_snapshot_id DESC, r.id DESC LIMIT 8000
        """).fetchall()
    except sqlite3.Error:
        return diagnostics
    seen, chosen_snapshot, sums = set(), {}, {}
    for market, probability, odd, hit, raw_pick, version, snapshot, fixture, match_id in rows:
        if market not in diagnostics:
            continue
        if market == "totals":
            line = re.search(r'(\d+(?:\.\d+)?)', str(raw_pick))
            if not line or abs(float(line.group(1)) % 1 - 0.5) > 1e-6:
                continue
        if market == "handicap":
            line = re.search(r'([+-]\d+(?:\.\d+)?)', str(raw_pick))
            if line and abs(float(line.group(1)) * 2 - round(float(line.group(1)) * 2)) > 1e-6:
                continue
        key = (str(fixture) if fixture else str(match_id), str(version))
        chosen_snapshot.setdefault(key, snapshot)
        if chosen_snapshot[key] != snapshot or (key, market, raw_pick) in seen:
            continue
        seen.add((key, market, raw_pick))
        p, price, y = float(probability or 0), float(odd or 0), int(hit or 0)
        if not 0 < p < 1 or price <= 1 or y not in (0, 1):
            continue
        value = diagnostics[market]
        value["candidate_samples"] += 1
        totals = sums.setdefault(market, [0.0, 0.0])
        totals[0] += (p-y) ** 2
        totals[1] += y*price-1
        # The bands are diagnostics, never new recommendation thresholds.
        band = "below_2" if price < 2 else "2_to_3" if price < 3 else "3_plus"
        bucket = value["odds_bands"].setdefault(band, {"samples": 0, "hits": 0, "profit": 0.0})
        bucket["samples"] += 1
        bucket["hits"] += y
        bucket["profit"] = round(bucket["profit"] + y*price-1, 6)
        # Changed model versions do not silently inherit old calibration errors.
        if str(version) == ANALYSIS_VERSION:
            bin_key = str(min(9, int(p*10)))
            cohort = value["calibration_bins"].setdefault(bin_key, {"samples": 0, "error_sum": 0.0})
            cohort["samples"] += 1
            cohort["error_sum"] += y-p
    for market, value in diagnostics.items():
        n = value["candidate_samples"]
        if n:
            value["brier_score"] = round(sums[market][0]/n, 6)
            value["unit_roi"] = round(sums[market][1]/n, 6)
    verified = _verified_calibration_history(conn)
    for market in diagnostics:
        diagnostics[market].update(verified[market])
    return diagnostics


def attach_analysis_contracts(picks, exp_h, exp_a, total_line, goal_model_audit, matrix=None):
    """Persist the actual payout contract before selection and learning."""
    for pick in picks:
        pick["goal_model_audit"] = goal_model_audit
        pick["settlement_supported"] = True
        if infer_pick_market(pick) != "totals":
            continue
        pick["totals_base"] = total_line
        if abs(float(total_line) % 1 - .5) < 1e-8:
            continue
        settlement = total_settlement_probabilities(exp_h, exp_a, total_line, pick["selection_side"], matrix)
        pick["settlement"] = settlement
        pick["prob"] = settlement["profit_probability"]
        pick["non_binary_settlement"] = True
        # The existing official grading UI stores binary hit/miss. Until it
        # can carry refunds/half results end-to-end, don't publish such a bet
        # as a binary official recommendation. Keep the complete analysis.
        pick["settlement_supported"] = False
        pick["eligibility_reason"] = "환급·반적중 정산 연결 검증 대기(분석 후보 보존)"
    return picks


def calibrate_market_candidates(picks, market_performance, confidence):
    """Keep coherent probabilities and attach market-specific price evidence."""
    confidence = max(0.35, min(0.95, float(confidence or 0.35)))
    grouped = {key: [] for key in MARKET_LABELS}
    for pick in picks:
        market = infer_pick_market(pick)
        pick["market_key"] = market
        grouped[market].append(pick)

    for market, market_picks in grouped.items():
        if not market_picks:
            continue
        joint = (market_picks[0].get("goal_model_audit") or {}).get("joint_forecast") or {}
        coherent = joint.get("coherent_score_distribution", False)
        history = market_performance.get("1x2" if coherent else market, {})
        samples = int(history.get("samples") or 0)
        hit_rate = float(history.get("hit_rate") or 0.5)
        adjusted_values = []
        for pick in market_picks:
            raw_probability = max(0.0, min(1.0, float(pick.get("prob") or 0)))
            fair_probability = max(0.0, min(1.0, float(pick.get("market_prob") or 0)))
            side = pick.get("selection_side")
            index = ({"home": 0, "draw": 1, "away": 2} if market == "1x2"
                     else {"under": 3, "over": 4} if market == "totals"
                     else {"home": 5, "draw": 6, "away": 7}).get(side)
            original = joint.get("raw_market_probabilities", [])
            pick["raw_model_prob"] = round(original[index] if coherent and index is not None else raw_probability, 6)
            cohort = history.get("calibration_bins", {}).get(str(min(9, int(raw_probability*10))), {})
            cohort_n = int(cohort.get("samples") or 0)
            history_weight = min(0.18, cohort_n / (cohort_n + 30.0) * 0.18) if history.get("calibration_validated") else 0.0
            if raw_probability == 0 or pick.get("non_binary_settlement"):
                history_weight = 0.0
            correction = float(cohort.get("error_sum") or 0) / cohort_n if cohort_n else 0.0
            adjusted = max(0.0, min(1.0, raw_probability + history_weight * correction))
            if coherent:
                # Learning has already reweighted the shared score matrix.
                # Never independently move a marginal away from that matrix.
                adjusted = raw_probability
                history_weight = max(joint.get("wdl_learning_weights") or [0])
                cohort_n = min(joint.get("wdl_learning_samples") or [0])
            pick["learning_weight"] = round(history_weight, 4)
            pick["learning_cohort_samples"] = cohort_n
            adjusted_values.append(adjusted)

        normalized = adjusted_values if coherent or any(p.get("non_binary_settlement") for p in market_picks) else normalize_probabilities(adjusted_values)
        neutral = 1.0 / len(market_picks)
        for pick, probability in zip(market_picks, normalized):
            fair_probability = max(0.0, min(1.0, float(pick.get("market_prob") or 0)))
            edge = probability - fair_probability if fair_probability > 0 else 0.0
            conviction = (probability - neutral) / max(0.01, 1.0 - neutral)
            error_margin = min(
                0.18,
                0.04 + ((1.0 - confidence) * 0.14) + (0.03 if samples < 20 else 0.0),
            )
            pick["prob"] = round(probability, 6)
            pick["ev"] = round(probability * float(pick.get("odd") or 0), 6)
            if pick.get("settlement"):
                settle = pick["settlement"]
                pick["ev"] = round(settle["win_weight"] * float(pick.get("odd") or 0) + settle["refund_weight"], 6)
            pick["fair_prob"] = round(fair_probability, 6) if fair_probability > 0 else None
            pick["edge"] = round(edge, 6)
            pick["market_hit_rate"] = round(hit_rate, 4)
            pick["market_history_samples"] = samples
            pick["market_history_scope"] = str(history.get("scope") or "global")
            pick["learning_diagnostics"] = {key: history.get(key) for key in
                                            ("candidate_samples", "brier_score", "unit_roi", "odds_bands",
                                             "calibration_validated", "validation_fixtures", "baseline_brier", "corrected_brier")}
            pick["data_confidence"] = round(confidence, 4)
            pick["price_policy"] = history.get("price_policy") or {}
            pick["official_selection_policy"] = (
                history.get("official_selection_policy") or {}
            )
            pick["error_margin"] = round(error_margin, 4)
            pick["probability_interval"] = {
                "low": round(max(0.0, probability - error_margin), 6),
                "high": round(min(1.0, probability + error_margin), 6),
            }
            pick["interval_method"] = "heuristic_sensitivity_not_statistical_confidence"
            # 특정 시장이 자주 선택됐다는 이유만으로 감점하지 않는다.
            # 새 동결 기록에서 각 시장 1위 후보의 실제 성적을 채점한 뒤 그
            # 검증된 성적으로 보정한다.
            pick["balanced_score"] = round(
                (probability * 0.55)
                + (conviction * 0.35)
                + (max(edge, 0.0) * 0.10),
                6,
            )
    return picks


def build_analysis_evidence(context):
    """실제 값이 있는 항목만 근거에 포함하고 누락 항목은 신뢰도에서 제외한다."""
    evidence = []
    available_weight = 0.0

    def add(name, weight, available, value):
        nonlocal available_weight
        if not available:
            return
        available_weight += weight
        evidence.append({"name": name, "weight": weight, "value": str(value)})

    h_recent = context["h_recent"]
    a_recent = context["a_recent"]
    h_stats = context["h_stats"]
    a_stats = context["a_stats"]
    h_long = context["h_long"]
    a_long = context["a_long"]
    h_inj = context["h_inj"]
    a_inj = context["a_inj"]
    add(
        "최근 성적", 0.13,
        min(h_recent.get("matches", 0), a_recent.get("matches", 0)) >= 3,
        f"최근 {h_recent.get('matches', 0)}/{a_recent.get('matches', 0)}경기, "
        f"PPG {h_recent.get('ppg', 0):.2f}/{a_recent.get('ppg', 0):.2f}",
    )
    add(
        "xG", 0.12,
        h_stats.get("xg") is not None and a_stats.get("xg") is not None,
        f"{h_stats.get('xg')}/{a_stats.get('xg')}",
    )
    add(
        "슈팅 품질", 0.10,
        min(h_stats.get("field_samples", {}).get("shots_on_goal", 0),
            a_stats.get("field_samples", {}).get("shots_on_goal", 0)) >= 1,
        f"유효슈팅 {h_stats.get('shots_on_goal', 0):.1f}/{a_stats.get('shots_on_goal', 0):.1f}",
    )
    add(
        "홈·원정", 0.10,
        h_long.get("home_total", 0) >= 3 and a_long.get("away_total", 0) >= 3,
        f"홈 {h_long.get('home_wins', 0)}승/{h_long.get('home_total', 0)}경기, "
        f"원정 {a_long.get('away_wins', 0)}승/{a_long.get('away_total', 0)}경기",
    )
    add(
        "상대 전적", 0.08, context["h2h_total"] > 0,
        f"{context['h_wins']}승-{context['draws']}무-{context['a_wins']}승",
    )
    add(
        "리그 순위", 0.06,
        0 < int(context.get("home_rank") or 99) < 99
        and 0 < int(context.get("away_rank") or 99) < 99,
        f"{context.get('home_rank')}위/{context.get('away_rank')}위",
    )
    add(
        "선수 결장", 0.11,
        bool(h_inj.get("available") and a_inj.get("available")),
        f"결장 {h_inj.get('count', 0)}명/{a_inj.get('count', 0)}명",
    )
    add(
        "휴식일", 0.06,
        max(context["h_rest_days"], context["a_rest_days"]) < 90,
        f"{context['h_rest_days']}일/{context['a_rest_days']}일",
    )
    add("날씨", 0.05, bool(context.get("weather")), context.get("weather"))
    add("심판", 0.05, bool(context.get("referee")), context.get("referee"))
    add("동기·감독", 0.05, bool(context.get("motivation_text")), context.get("motivation_text"))
    tactical_text = context.get("tactical_text")
    add("전술 상성", 0.05, bool(tactical_text), tactical_text)
    movement_text = context.get("movement_text")
    add("배당 변동", 0.05, bool(movement_text), movement_text)
    add(
        "팀 신원·경기 연결", 0.10,
        bool(context.get("home_id") and context.get("away_id") and context.get("fixture_id")),
        f"팀ID {context.get('home_id')}/{context.get('away_id')}, 경기ID {context.get('fixture_id')}",
    )
    return evidence, round(max(0.0, min(1.0, available_weight)), 4)


def attach_underdog_signals(picks, home_team, away_team, metrics):
    """Attach auditable support to every direction; tag underdogs separately.

    The legacy name is kept for compatibility.  Earlier code stopped before
    attaching evidence to favourites, which made a regular favourite
    structurally unable to earn the same honey/VIP grade.  Underdog status is
    still recorded, but evidence grading itself is direction-neutral.
    """
    movement = metrics.get("movement") or {}
    for pick in picks:
        market = infer_pick_market(pick)
        side = str(pick.get("selection_side") or "")
        matched = [signal for signal in movement.get("signals") or []
                   if str(signal.get("market") or "") == market
                   and str(signal.get("side") or "") == side]
        if market == "handicap" and side in {"home", "away"}:
            matched += [signal for signal in movement.get("signals") or []
                        if signal.get("market") == "1x2" and signal.get("side") == side]
        pick["movement_features"] = {
            "direction_match": bool(matched),
            "market": market,
            "side": side,
            "timing": str(movement.get("timing") or "regular"),
            "persistent": any(bool(signal.get("persistent_from_opening")) for signal in matched),
            "cross_market_agreement": side in (movement.get("agreement_sides") or []),
            "underdog_move": bool(movement.get("underdog_move") and market == "1x2"),
            "bookmaker_count": int(movement.get("bookmaker_count") or 0),
            "bookmaker_set": ",".join(str(value) for value in movement.get("bookmaker_ids") or []),
            "qualified": bool(movement.get("qualified")),
        }
    for pick in picks:
        pick["support_signals"] = []
        pick["support_signal_groups"] = []
        pick["independent_support_count"] = 0
        market = infer_pick_market(pick)
        side = str(pick.get("selection_side") or "")
        context_audit = metrics.get("context_audit") or {}
        alignments = context_audit.get("side_alignment") or {}
        if side in {"home", "draw", "away"}:
            raw_alignment = float(alignments.get(side) or 0)
        elif side in {"under", "over"}:
            base_goals = context_audit.get("base_expected_goals") or {}
            adjusted_goals = context_audit.get("adjusted_expected_goals") or {}
            total_delta = (
                float(adjusted_goals.get("home") or 0)
                + float(adjusted_goals.get("away") or 0)
                - float(base_goals.get("home") or 0)
                - float(base_goals.get("away") or 0)
            )
            raw_alignment = total_delta / .40
            if side == "under":
                raw_alignment *= -1
        else:
            raw_alignment = 0.0
        pick["context_alignment"] = round(max(-1.0, min(1.0, raw_alignment)), 6)
        pick["context_model_version"] = str(context_audit.get("version") or "")
        pick["is_true_underdog"] = bool(
            market in {"1x2", "handicap"}
            and side in {"home", "away"}
            and side == metrics.get("underdog_side")
        )
        signals = []
        signal_groups = []

        def add_signal(group, label):
            # 결장과 선발 이탈처럼 같은 원인을 두 개의
            # 독립 근거로 중복 계산하지 않는다.
            if group in signal_groups:
                return
            signal_groups.append(group)
            signals.append(label)

        direction_matched = bool(
            (pick.get("movement_features") or {}).get("direction_match")
        )
        persistent_direction = any(
            str(signal.get("side") or "") == side
            and (
                str(signal.get("market") or "") == market
                or (market == "handicap" and signal.get("market") == "1x2")
            )
            and bool(signal.get("persistent_from_opening"))
            and int(signal.get("bookmaker_sample_count") or 0) >= 3
            for signal in movement.get("signals") or []
        )
        confirmed = bool(
            movement.get("comparable_bookmakers")
            and side in (movement.get("agreement_sides") or [])
            and direction_matched
            and persistent_direction
        )
        pick["market_movement_confirmed"] = confirmed
        if confirmed:
            add_signal("market", "다중 업체 배당 지속 하락·교차시장 동방향")

        if market == "totals":
            weather_component = next(
                (item for item in context_audit.get("components") or []
                 if item.get("name") == "weather_total"), None,
            )
            if weather_component:
                add_signal("weather", "날씨·득점 환경 반영")
        # Team-specific evidence cannot be honestly mapped to draw/totals.
        if side not in {"home", "away"}:
            pick["support_signals"] = signals
            pick["support_signal_groups"] = signal_groups
            pick["independent_support_count"] = len(signal_groups)
            continue

        opponent = "away" if side == "home" else "home"
        if side == "home" and metrics.get("home_venue_model"):
            add_signal("venue", "홈·원정 분리 성적과 홈 어드밴티지")
        if int(metrics.get(f"{side}_rank") or 99) < int(metrics.get(f"{opponent}_rank") or 99):
            add_signal("rank", "리그 순위 우위")
        if float(metrics.get(f"{opponent}_absence") or 0) - float(
            metrics.get(f"{side}_absence") or 0
        ) >= 0.05:
            add_signal("squad", "상대 핵심 결장·선발 누수")
        if float(metrics.get(f"{side}_tactical") or 0) > 0:
            add_signal("matchup", "상대 전적·전술 상성 우위")
        if float(metrics.get(f"{side}_title") or 0) > float(
            metrics.get(f"{opponent}_title") or 0
        ):
            add_signal("motivation", "우승·상위권 경쟁 동기")
        if float(metrics.get(f"{side}_manager") or 0) > float(
            metrics.get(f"{opponent}_manager") or 0
        ):
            add_signal("manager", "감독 변경 동기 신호")
        side_survival = metrics.get(f"{side}_survival") or {}
        opponent_survival = metrics.get(f"{opponent}_survival") or {}
        if side_survival.get("active") and not opponent_survival.get("active"):
            add_signal("motivation", "강등권 생존 동기")
        if float(metrics.get(f"{side}_recent") or 0) - float(
            metrics.get(f"{opponent}_recent") or 0
        ) >= 0.035:
            add_signal("form", "최근 경기력 지표 우위")
        if float(metrics.get(f"{side}_rest") or 0) - float(
            metrics.get(f"{opponent}_rest") or 0
        ) >= 2:
            add_signal("schedule", "휴식일 우위")
        if float(metrics.get(f"{opponent}_lineup") or 0) - float(
            metrics.get(f"{side}_lineup") or 0
        ) >= 0.08:
            add_signal("squad", "상대 선발 핵심 이탈")
        pick["support_signals"] = signals
        pick["support_signal_groups"] = signal_groups
        pick["independent_support_count"] = len(signal_groups)
    return picks


def _has_korean_final_consonant(text):
    """Return whether the last Hangul syllable has a 받침."""
    for char in reversed(str(text or "").strip()):
        code = ord(char)
        if 0xAC00 <= code <= 0xD7A3:
            return (code - 0xAC00) % 28 != 0
        if char.isalnum():
            return False
    return False


def _subject_form(name):
    name = str(name or "팀").strip()
    return f"{name}{'이' if _has_korean_final_consonant(name) else '가'}"


def _human_pick_label(raw_pick, home_team=""):
    """Explain Betman handicap notation without changing the stored grading key."""
    raw = str(raw_pick or "").strip()
    matched = re.match(
        r"^\[\s*([+-]?\d+(?:\.\d+)?)\s*\]\s*(.*?)\s*핸디(승|무|패)$",
        raw,
    )
    if not matched:
        return raw
    handicap, team_name, result = matched.groups()
    team_name = team_name.strip() or str(home_team or "홈팀").strip()
    try:
        handicap = f"{float(handicap):+.1f}"
    except (TypeError, ValueError):
        pass
    return f"{team_name} {handicap} 적용 후 {result}"


def _report_pick_line(pick, home_team=""):
    if not pick:
        return "계산 가능한 선택지 없음"
    probability = float(pick.get("prob") or 0)
    fair_probability = pick.get("fair_prob")
    comparison = "시장 공정확률 자료 없음"
    if fair_probability is not None:
        comparison = (
            f"시장 공정확률 {float(fair_probability) * 100:.1f}%, "
            f"차이 {float(pick.get('edge') or 0) * 100:+.1f}%p"
        )
    display_pick = _human_pick_label(pick.get("raw_pick", ""), home_team)
    if pick.get("non_binary_settlement"):
        refund = float((pick.get("settlement") or {}).get("refund_weight") or 0)
        return (f"{display_pick} · 이익 발생 확률 {probability*100:.1f}% · "
                f"예상 환급 지분 {refund*100:.1f}% · 공식 정산 검증 대기")
    odd = float(pick.get("odd") or 0)
    price = (f" · 실제 배당 {odd:.2f}배 · 손익분기 {100/odd:.1f}%"
             if odd > 1 else " · 실제 배당 미수신")
    return f"{display_pick} · 모델 {probability * 100:.1f}% · {comparison}{price}"


def build_detailed_report(
    selected_pick, evidence, confidence, candidates=None, categories=None, context=None
):
    """픽 확정 뒤 실제 사용값만 풀어 쓰는 고객용 상세 분석문을 만든다."""
    if not selected_pick:
        return "실제 배당과 모델 확률을 함께 비교할 수 있는 선택지가 없어 기존 분석을 유지했습니다."
    candidates = list(candidates or [])
    categories = categories or {}
    context = context or {}
    probability = float(selected_pick.get("prob") or 0)
    fair_probability = selected_pick.get("fair_prob")
    edge = selected_pick.get("edge")
    interval = selected_pick.get("probability_interval") or {}
    evidence_by_name = {
        str(item.get("name")): str(item.get("value"))
        for item in evidence if item.get("name") and item.get("value")
    }
    expected_names = (
        "최근 성적", "xG", "슈팅 품질", "홈·원정", "상대 전적", "선수 결장",
        "리그 순위", "휴식일", "날씨", "심판", "동기·감독", "전술 상성",
        "배당 변동", "팀 신원·경기 연결",
    )
    missing_names = [name for name in expected_names if name not in evidence_by_name]
    evidence_text = ", ".join(
        f"{name}: {value}" for name, value in evidence_by_name.items()
    ) or "확인 가능한 기본 경기 정보만 사용"
    fair_text = (
        f"베팅업체 마진 제거 공정확률은 {float(fair_probability) * 100:.1f}%이고 "
        f"모델과의 차이는 {float(edge or 0) * 100:+.1f}%p입니다."
        if fair_probability is not None else "비교 가능한 시장 공정확률 자료는 없습니다."
    )
    market_best = {}
    for market in MARKET_LABELS:
        market_candidates = [item for item in candidates if infer_pick_market(item) == market]
        market_best[market] = max(
            market_candidates,
            key=lambda item: float(item.get("prob") or 0),
            default=None,
        )

    home = str(context.get("home") or "홈팀")
    away = str(context.get("away") or "원정팀")
    exp_h = float(context.get("exp_h") or 0)
    exp_a = float(context.get("exp_a") or 0)
    if exp_h - exp_a >= 0.30:
        flow = f"득점 모형에서는 {_subject_form(home)} 앞섭니다. 점유율·전술 우위를 뜻하는 것은 아닙니다."
    elif exp_a - exp_h >= 0.30:
        flow = f"득점 모형에서는 {_subject_form(away)} 앞섭니다. 역습 전술을 확인했다는 뜻은 아닙니다."
    else:
        flow = "기대 득점 차이가 작아 한쪽의 일방적인 주도보다 접전 가능성을 높게 봅니다."
    weather = str(context.get("weather") or "")
    weather_note = ""
    if weather in {"Rain", "Snow"}:
        weather_ko = "비" if weather == "Rain" else "눈"
        weather_note = (
            f" 현지 {weather_ko} 정보는 참고 사항이며, 강도·경기 시각 검증 없이 득점을 일괄 감점하지 않습니다."
        )

    honey = categories.get("honey")
    vip = categories.get("vip_underdog")
    withheld = selected_pick.get("recommendation_status") == "WITHHELD"
    final_parts = (
        ["추천 보류: " + selected_pick.get("selection_reason", "가치 기준 미충족") + "."]
        if withheld else [f"최종 추천픽은 {_report_pick_line(selected_pick, home)}입니다.",
                          str(selected_pick.get("selection_reason") or "")]
    )
    if vip:
        signals = ", ".join(vip.get("support_signals") or []) or "복수 지표 동시 지지"
        final_parts.append(
            f"이 최종픽은 보수적 가치와 독립 근거 기준을 모두 통과해 VIP 검증 등급이며, "
            f"독립 근거는 {signals}입니다. 별도의 반대 픽을 함께 제시하지 않습니다."
        )
    elif honey:
        final_parts.append("이 최종픽은 실제 배당과 보수적 우위까지 확인되어 배당가치 우수 등급입니다.")
    elif not withheld:
        final_parts.append("승무패·핸디캡·언더오버와 경기 전 전체 지표를 동시 비교했으며, 별도 가치·VIP 등급은 부여하지 않았습니다.")
    missing_text = (
        f"확보하지 못한 항목({', '.join(missing_names)})은 임의로 추측하지 않고 신뢰도에서 감점했습니다."
        if missing_names else "요구된 핵심 데이터 항목이 모두 연결되어 있습니다."
    )
    goal_audit = selected_pick.get("goal_model_audit") or {}
    joint = goal_audit.get("joint_forecast") or {}
    opponent_model = goal_audit.get("opponent_model") or {}
    wdl_sides = {p.get("selection_side"): p for p in candidates if infer_pick_market(p) == "1x2"}
    wdl_text = " · ".join(f"{label} {float(wdl_sides[side].get('prob') or 0)*100:.1f}%"
                          for side, label in (("home", home+" 승"), ("draw", "무승부"), ("away", away+" 승")) if side in wdl_sides)
    underdogs = [p for p in wdl_sides.values() if p.get("is_true_underdog")]
    underdog_text = ("실제 승무패 역배 방향: " + _report_pick_line(underdogs[0], home) +
                    ". 정배팀이 못 이길 확률(무승부 포함)과 역배팀이 이길 확률은 다릅니다. 역배 여부와 꿀/VIP 등급은 별개입니다."
                    if underdogs else "승무패 역배 판단은 양 팀의 실제 배당 확인이 필요합니다. +1승/-1패 자체를 역배 승리로 분류하지 않습니다.")
    learning_text = (f"상대강도 모형 {'사용' if opponent_model.get('active') else '미사용'}: "
                     f"{opponent_model.get('reason') or '학습 자료 미확인'}. "
                     f"검증 경기 {int(opponent_model.get('validation_fixtures') or 0)}개. "
                     f"딕슨-콜스 저득점 상관계수는 {'학습값' if opponent_model.get('rho_active') else '검증된 안전값'} "
                     f"{float(joint.get('rho') or -.15):+.2f}. "
                     f"확률 보정 학습 {'적용' if joint.get('calibration_active') else '미적용(검증 근거 부족 또는 개선 미확인)'}. "
                     f"해외배당 변화 학습 {'적용' if joint.get('movement_learning_active') else '미적용(시간순 개선 미확인 또는 표본 부족)'}. "
                     "과거 8개 후보·픽·확률은 그대로 보존하며 이후 경기만 보정합니다. 실전 성능 향상은 별도 검증이 필요합니다.")
    formula_text = (
        "시간가중 상대 공격·수비·홈원정 모형과 중복 제거 결장·일정 보정을 사용합니다. "
        "최근득점·xG를 여기에 다시 곱하지 않습니다. "
        if opponent_model.get("active") else
        "득점 계산은 홈·원정 득실, 표본 수, 최근 득점, 확인된 xG·상대 xGA, 중복을 제거한 결장·일정 보정을 사용합니다. "
    )
    context_audit = goal_audit.get("context_integration") or {}
    context_components = [
        str(item.get("name")) for item in context_audit.get("components") or []
        if item.get("name")
    ]
    context_text = (
        "실제 확률 반영 항목: " + ", ".join(context_components) + ". "
        if context_components else "별도 방향성 지표는 없어 기초 득점모형을 유지했습니다. "
    )
    return "\n\n".join([
        (
            f"[종합 경기 흐름] 예상 정규시간 득점은 {home} {exp_h:.2f}골, "
            f"{away} {exp_a:.2f}골입니다. {flow}{weather_note}"
        ),
        f"[일반 승무패 분석] {_report_pick_line(market_best.get('1x2'), home)}.",
        f"[승무패 전체 방향] {wdl_text or '세 방향 자료 미확인'}. 승무패·핸디·언더오버는 같은 최종 스코어 확률표에서 계산합니다.",
        f"[핸디캡 분석] {_report_pick_line(market_best.get('handicap'), home)}.",
        f"[언더오버 분석] {_report_pick_line(market_best.get('totals'), home)}.",
        f"[역배 판단] {underdog_text}",
        f"[확인 자료와 계산 기준] {evidence_text}. {missing_text} "
        + formula_text + context_text
        + "순위·맞대결·동기·감독·검증된 배당 흐름은 방향 확률에, "
        "날씨·결장·선발·휴식은 득점 분포와 신뢰도에 적용합니다. "
        "심판처럼 검증된 승무패 방향이 없는 항목은 임의 가산하지 않고 중립으로 기록합니다. "
        "시장 배당은 득점으로 바꾸지 않고 확률 비교·보정에 사용합니다.",
        f"[학습 상태] {learning_text}",
        (
            ("[최종 선택과 신뢰도] " + " ".join(final_parts) +
             " 내부 후보만 기록·학습하며 공식 추천 적중률에는 포함하지 않습니다."
             if withheld else
            f"[최종 선택과 신뢰도] {' '.join(final_parts)} 선택된 최종픽의 보정 확률은 "
            f"{probability * 100:.1f}%이며, {fair_text} 가정에 따른 민감도 범위(통계적 신뢰구간 아님)는 "
            f"{float(interval.get('low', 0)) * 100:.1f}%~{float(interval.get('high', 1)) * 100:.1f}%, "
            f"데이터 신뢰도는 {confidence * 100:.1f}%입니다. 이 수치는 적중을 보장하지 않습니다.")
        ),
    ])


def _audit_number(value, default=None):
    try:
        number = float(value)
        if number != number or number in (float("inf"), float("-inf")):
            return default
        return round(number, 6)
    except (TypeError, ValueError):
        return default


ALPHAGO_PICK_DISPLAY_VERSION = "v2-ai-display-v1"


def _alphago_pick_payload(source_pick):
    """Expose an already-calculated V2 result without changing any pick.

    The V2 result is produced by ``football_model.py`` as ``v2_ai_pick``.
    This adapter only gives that existing H/D/A code a display-safe shape.
    It never calls the V2 model, does not select a replacement pick, and does
    not make a retrospective result for a match that has already started.
    """
    if not isinstance(source_pick, dict):
        return {
            "engine": "v2-ai", "engine_version": ALPHAGO_PICK_DISPLAY_VERSION,
            "status": "source_pending", "reason": "V2 원본 답안 대기",
        }
    code = str(source_pick.get("v2_ai_pick") or "").strip().upper()
    side = {"H": "home", "D": "draw", "A": "away"}.get(code)
    if not side:
        reason_map = {
            "V2_OFF": "V2 모델 파일 연결 대기",
            "NO_ODDS": "V2용 1X2 배당 미수신",
            "ERROR": "V2 모델 계산 오류",
        }
        return {
            "engine": "v2-ai", "engine_version": ALPHAGO_PICK_DISPLAY_VERSION,
            "status": "unavailable", "source_code": code,
            "reason": reason_map.get(code, "V2 원본 답안 대기"),
        }
    return {
        "engine": "v2-ai",
        "engine_version": ALPHAGO_PICK_DISPLAY_VERSION,
        "code": code,
        "status": "ready",
        "market_key": "1x2",
        "selection_side": side,
        "pre_match_only": True,
    }


def build_pick_selection_audit(
    candidates, categories, confidence, robot_pick=None, lineup_prediction=None,
):
    """Create one deterministic, machine-readable record of the full decision.

    Customer HTML is intentionally excluded.  The learning robot needs the
    values that existed before kickoff, the complete candidate set, and the
    exact reason a candidate won; it must not try to reconstruct them later.
    """
    candidates = list(candidates or [])
    categories = categories or {}
    category_membership = {}
    compact_categories = {}
    for category_key in ("high_probability", "honey", "vip_underdog"):
        selected = categories.get(category_key)
        if not selected:
            compact_categories[category_key] = None
            continue
        raw_pick = str(selected.get("raw_pick") or "")
        identity = (infer_pick_market(selected), raw_pick)
        category_membership.setdefault(identity, []).append(category_key)
        compact_categories[category_key] = {
            "raw_pick": raw_pick,
            "market_key": infer_pick_market(selected),
            "probability": _audit_number(selected.get("prob"), 0.0),
            "odd": _audit_number(selected.get("odd"), 0.0),
            "fair_probability": _audit_number(selected.get("fair_prob")),
            "robust_edge": _audit_number(selected.get("robust_edge"), 0.0),
            "context_alignment": _audit_number(selected.get("context_alignment"), 0.0),
            "official_score": _audit_number(selected.get("official_score"), 0.0),
            "official_goal_score": _audit_number(
                selected.get("official_goal_score"), selected.get("prob") or 0.0
            ),
            "official_learned_probability": _audit_number(
                selected.get("official_learned_probability"),
                selected.get("prob") or 0.0,
            ),
            "official_learning_active": bool(
                selected.get("official_learning_active")
            ),
            "official_learning_samples": int(
                selected.get("official_learning_samples") or 0
            ),
            "official_learning_correction": _audit_number(
                selected.get("official_learning_correction"), 0.0
            ),
            "official_policy_version": str(selected.get("official_policy_version") or PICK_POLICY_VERSION),
            "official_learning_axis": str(
                selected.get("official_learning_axis") or ""
            ),
            "value_pick_tier": str(selected.get("value_pick_tier") or ""),
            "final_pick_grade": str(selected.get("final_pick_grade") or "standard"),
            "learning_robot": dict(selected.get("learning_robot") or {}),
            "recommendation_status": selected.get("recommendation_status", "SELECTED"),
            "selection_reason": selected.get("selection_reason", ""),
            "probability_fallback": bool(selected.get("probability_fallback")),
            "selection_warning": str(selected.get("selection_warning") or ""),
            "independent_support_count": int(
                selected.get("independent_support_count", 0) or 0
            ),
        }

    compact_robot = None
    if isinstance(robot_pick, dict) and str(robot_pick.get("raw_pick") or "").strip():
        robot_raw_pick = str(robot_pick.get("raw_pick") or "")
        robot_market = infer_pick_market(robot_pick)
        category_membership.setdefault(
            (robot_market, robot_raw_pick), []
        ).append("robot_independent")
        compact_robot = {
            "raw_pick": robot_raw_pick,
            "market_key": robot_market,
            "probability": _audit_number(robot_pick.get("prob"), 0.0),
            "odd": _audit_number(robot_pick.get("odd"), 0.0),
            "fair_probability": _audit_number(robot_pick.get("fair_prob")),
            "robust_probability": _audit_number(
                robot_pick.get("robust_probability"), 0.0
            ),
            "robust_edge": _audit_number(robot_pick.get("robust_edge"), 0.0),
            "robust_ev": _audit_number(robot_pick.get("robust_ev"), 0.0),
            "robot_score": _audit_number(robot_pick.get("robot_score"), 0.0),
            "robot_kelly": _audit_number(robot_pick.get("robot_kelly")),
            "robot_learning_bonus": _audit_number(
                robot_pick.get("robot_learning_bonus"), 0.0
            ),
            "robot_context_bonus": _audit_number(
                robot_pick.get("robot_context_bonus"), 0.0
            ),
            "context_alignment": _audit_number(
                robot_pick.get("context_alignment"), 0.0
            ),
            "robot_learning_validated": bool(
                robot_pick.get("robot_learning_validated")
            ),
            "robot_probability": _audit_number(robot_pick.get("robot_probability")),
            "robot_expected_goals": dict(robot_pick.get("robot_expected_goals") or {}),
            "robot_model_version": str(robot_pick.get("robot_model_version") or ""),
            "robot_feature_schema_version": str(robot_pick.get("robot_feature_schema_version") or ""),
            "robot_model_active": bool(robot_pick.get("robot_model_active")),
            "robot_training_samples": int(robot_pick.get("robot_training_samples") or 0),
            "robot_validation_fixtures": int(robot_pick.get("robot_validation_fixtures") or 0),
            "robot_learning_revision": str(
                robot_pick.get("robot_learning_revision") or ""
            ),
            "robot_learning_reason": str(robot_pick.get("robot_learning_reason") or ""),
            "robot_pick_version": ROBOT_PICK_VERSION,
            "robot_policy_version": str(
                robot_pick.get("robot_policy_version")
                or AUTONOMOUS_ROBOT_POLICY_VERSION
            ),
            "robot_selection_axis": str(
                robot_pick.get("robot_selection_axis") or "all_markets"
            ),
            "v2_ai_pick": str(robot_pick.get("v2_ai_pick") or "").strip().upper(),
            "selection_reason": str(robot_pick.get("selection_reason") or ""),
            "recommendation_status": "SELECTED",
            "robot_fallback": bool(robot_pick.get("robot_fallback")),
            "is_true_underdog": bool(robot_pick.get("is_true_underdog")),
        }
    compact_categories["robot_independent"] = compact_robot

    selected_identity = None
    selected_for_rank = categories.get("high_probability")
    if selected_for_rank:
        selected_identity = (
            infer_pick_market(selected_for_rank),
            str(selected_for_rank.get("raw_pick") or ""),
        )
    ranked = sorted(
        candidates,
        key=lambda item: (
            (infer_pick_market(item), str(item.get("raw_pick") or "")) == selected_identity,
            infer_pick_market(item) == "1x2",
            float(item.get("robust_probability", item.get("prob", 0)) or 0),
            float(item.get("prob", 0) or 0),
            float(item.get("robust_edge", 0) or 0),
        ),
        reverse=True,
    )
    rank_by_identity = {
        (infer_pick_market(item), str(item.get("raw_pick") or "")): index
        for index, item in enumerate(ranked, start=1)
    }
    market_rank_by_identity = {}
    for market in MARKET_LABELS:
        market_ranked = sorted(
            [item for item in candidates if infer_pick_market(item) == market],
            key=lambda item: (
                float(item.get("prob", 0) or 0),
                float(item.get("balanced_score", 0) or 0),
                str(item.get("raw_pick") or ""),
            ),
            reverse=True,
        )
        for index, item in enumerate(market_ranked, start=1):
            market_rank_by_identity[
                (market, str(item.get("raw_pick") or ""))
            ] = index
    candidate_rows = []
    for item in candidates:
        raw_pick = str(item.get("raw_pick") or "")
        market_key = infer_pick_market(item)
        selected_as = list(category_membership.get((market_key, raw_pick), []))
        rank = rank_by_identity.get((market_key, raw_pick))
        candidate_rows.append({
            "market_key": market_key,
            "label": str(item.get("label") or ""),
            "raw_pick": raw_pick,
            "selection_side": str(item.get("selection_side") or ""),
            "handicap_base": _audit_number(item.get("handicap_base")),
            "totals_base": _audit_number(item.get("totals_base")),
            "settlement": item.get("settlement"),
            "settlement_supported": item.get("settlement_supported", True),
            "eligibility_reason": item.get("eligibility_reason", ""),
            "goal_model_audit": item.get("goal_model_audit"),
            "forecast_model_version": (item.get("goal_model_audit") or {}).get("joint_forecast", {}).get("forecast_model_version"),
            "calibration_version": (item.get("goal_model_audit") or {}).get("joint_forecast", {}).get("calibration_version"),
            "pick_policy_version": PICK_POLICY_VERSION,
            "sort_id": int(item.get("sort_id", 0) or 0),
            "model_probability": _audit_number(item.get("prob"), 0.0),
            "raw_model_probability": _audit_number(item.get("raw_model_prob")),
            "fair_probability": _audit_number(item.get("fair_prob")),
            "odd": _audit_number(item.get("odd"), 0.0),
            "edge": _audit_number(item.get("edge"), 0.0),
            "robust_probability": _audit_number(
                item.get("robust_probability"), 0.0
            ),
            "robust_edge": _audit_number(item.get("robust_edge"), 0.0),
            "robust_ev": _audit_number(item.get("robust_ev"), 0.0),
            "balanced_score": _audit_number(item.get("balanced_score"), 0.0),
            "safe_score": _audit_number(item.get("safe_score"), 0.0),
            "recommendation_score": _audit_number(
                item.get("recommendation_score"), 0.0
            ),
            "context_alignment": _audit_number(item.get("context_alignment"), 0.0),
            "official_score": _audit_number(item.get("official_score"), 0.0),
            "official_goal_score": _audit_number(
                item.get("official_goal_score"), item.get("prob") or 0.0
            ),
            "official_learned_probability": _audit_number(
                item.get("official_learned_probability"), item.get("prob") or 0.0
            ),
            "official_learning_active": bool(item.get("official_learning_active")),
            "official_learning_samples": int(
                item.get("official_learning_samples") or 0
            ),
            "official_learning_correction": _audit_number(
                item.get("official_learning_correction"), 0.0
            ),
            "official_learning_validation_accuracy": _audit_number(
                item.get("official_learning_validation_accuracy")
            ),
            "official_learning_baseline_accuracy": _audit_number(
                item.get("official_learning_baseline_accuracy")
            ),
            "official_learning_axis": str(
                item.get("official_learning_axis") or ""
            ),
            "robot_score": _audit_number(item.get("robot_score"), 0.0),
            "robot_probability": _audit_number(item.get("robot_probability")),
            "robot_expected_goals": dict(item.get("robot_expected_goals") or {}),
            "robot_model_version": str(item.get("robot_model_version") or ""),
            "robot_model_active": bool(item.get("robot_model_active")),
            "robot_goal_validation_accuracy": _audit_number(
                item.get("robot_goal_validation_accuracy")
            ),
            "robot_goal_target_reached": bool(
                item.get("robot_goal_target_reached")
            ),
            "robot_training_samples": int(item.get("robot_training_samples") or 0),
            "robot_validation_fixtures": int(item.get("robot_validation_fixtures") or 0),
            "robot_learning_revision": str(
                item.get("robot_learning_revision") or ""
            ),
            "market_hit_rate": _audit_number(item.get("market_hit_rate"), 0.5),
            "market_history_samples": int(
                item.get("market_history_samples", 0) or 0
            ),
            "market_history_scope": str(item.get("market_history_scope") or "global"),
            "learning_weight": _audit_number(item.get("learning_weight"), 0.0),
            "data_confidence": _audit_number(
                item.get("data_confidence"), confidence
            ),
            "error_margin": _audit_number(item.get("error_margin"), 0.0),
            "probability_interval": {
                "low": _audit_number(
                    (item.get("probability_interval") or {}).get("low"), 0.0
                ),
                "high": _audit_number(
                    (item.get("probability_interval") or {}).get("high"), 1.0
                ),
            },
            "is_true_underdog": bool(item.get("is_true_underdog")),
            "is_qualified_underdog": bool(item.get("is_qualified_underdog")),
            "support_signals": list(item.get("support_signals") or []),
            "movement_features": dict(item.get("movement_features") or {}),
            "independent_support_count": int(
                item.get("independent_support_count", 0) or 0
            ),
            "selection_rank": rank,
            "market_rank": market_rank_by_identity.get((market_key, raw_pick)),
            "selected_as": selected_as,
            "selection_reason": (
                "경기 전 전체 지표·전체 시장 통합 최종 추천픽"
                if "high_probability" in selected_as
                else (
                    "최종 추천픽의 배당가치 등급"
                    if "honey" in selected_as
                    else f"통합 비교 순위 {rank}위"
                )
            ),
        })

    market_counts = {
        market: sum(1 for item in candidate_rows if item["market_key"] == market)
        for market in MARKET_LABELS
    }
    selected_high = compact_categories.get("high_probability") or {}
    decision = {
        "schema_version": PICK_AUDIT_SCHEMA_VERSION,
        "analysis_version": ANALYSIS_VERSION,
        "selector": "all-evidence-best-one-v1",
        "score_order": [
            "settlement_eligibility", "cross_market_conviction",
            "full_context_alignment", "robust_probability", "robust_edge",
            "robust_ev", "independent_support", "mandatory_probability_fallback",
        ],
        "candidate_count": len(candidate_rows),
        "market_candidate_counts": market_counts,
        "missing_markets": [
            market for market, count in market_counts.items() if count == 0
        ],
        "data_confidence": _audit_number(confidence, 0.0),
        "selected_pick": selected_high.get("raw_pick", ""),
        "selected_market": selected_high.get("market_key", ""),
        "selection_reason": (
            selected_high.get("selection_reason") or "경기 전 저장된 선택 기준 유지"
        ),
        "final_pick_grade": str(selected_high.get("final_pick_grade") or "standard"),
        "provide_pick_when_analyzable": True,
        "probability_fallback": bool(selected_high.get("probability_fallback")),
        "selection_warning": str(selected_high.get("selection_warning") or ""),
        "value_badge": compact_categories.get("honey") is not None,
        "vip_promoted": compact_categories.get("vip_underdog") is not None,
        "learning_robot": dict(selected_high.get("learning_robot") or {
            "mode": "controlled_adviser", "influence_cap": 0.18,
            "history_rewrite": False, "self_modifying": False,
        }),
        "robot_pick_version": ROBOT_PICK_VERSION,
        "robot_pick": compact_robot,
        "alphago_pick": _alphago_pick_payload(robot_pick),
        "robot_selector": AUTONOMOUS_ROBOT_POLICY_VERSION,
        "robot_uses_prekickoff_inputs_only": True,
        "robot_history_rewrite": False,
        "robot_self_modifying_code": False,
        "lineup_prediction": dict(lineup_prediction or {}),
    }
    return candidate_rows, compact_categories, decision


def _ensure_prediction_analysis_tables(conn):
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS prediction_analysis (
            match_id TEXT PRIMARY KEY,
            analysis_version TEXT DEFAULT '',
            stage TEXT DEFAULT '',
            odds_source TEXT DEFAULT '',
            selected_market TEXT,
            selected_pick TEXT,
            model_probability REAL,
            fair_probability REAL,
            edge REAL,
            confidence REAL,
            error_margin REAL,
            probability_low REAL,
            probability_high REAL,
            evidence_json TEXT DEFAULT '[]',
            markets_json TEXT DEFAULT '[]',
            categories_json TEXT DEFAULT '{}',
            decision_json TEXT DEFAULT '{}',
            report_text TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    columns = {
        str(row[1]) for row in conn.execute("PRAGMA table_info(prediction_analysis)")
    }
    migrations = {
        "analysis_version": "TEXT DEFAULT ''",
        "stage": "TEXT DEFAULT ''",
        "odds_source": "TEXT DEFAULT ''",
        "categories_json": "TEXT DEFAULT '{}'",
        "decision_json": "TEXT DEFAULT '{}'",
    }
    for column, declaration in migrations.items():
        if column not in columns:
            conn.execute(
                f"ALTER TABLE prediction_analysis ADD COLUMN {column} {declaration}"
            )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS prediction_analysis_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            match_id TEXT NOT NULL,
            analysis_version TEXT NOT NULL,
            stage TEXT NOT NULL,
            odds_source TEXT DEFAULT '',
            confidence REAL DEFAULT 0,
            selected_market TEXT,
            selected_pick TEXT,
            candidate_count INTEGER DEFAULT 0,
            evidence_json TEXT DEFAULT '[]',
            candidates_json TEXT DEFAULT '[]',
            categories_json TEXT DEFAULT '{}',
            decision_json TEXT DEFAULT '{}',
            report_text TEXT DEFAULT '',
            fingerprint TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(match_id, analysis_version, stage, fingerprint)
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_analysis_snapshots_match "
        "ON prediction_analysis_snapshots(match_id, id)"
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS prediction_candidate_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            match_id TEXT NOT NULL,
            analysis_snapshot_id INTEGER NOT NULL,
            analysis_version TEXT NOT NULL,
            stage TEXT NOT NULL,
            market_key TEXT NOT NULL,
            raw_pick TEXT NOT NULL,
            model_probability REAL DEFAULT 0,
            fair_probability REAL,
            odd REAL DEFAULT 0,
            selection_rank INTEGER,
            market_rank INTEGER,
            selected_as TEXT DEFAULT '',
            is_correct INTEGER NOT NULL,
            actual_score TEXT NOT NULL,
            graded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(analysis_snapshot_id, market_key, raw_pick)
        )
        """
    )
    candidate_result_columns = {
        str(row[1]) for row in conn.execute(
            "PRAGMA table_info(prediction_candidate_results)"
        )
    }
    if "market_rank" not in candidate_result_columns:
        conn.execute(
            "ALTER TABLE prediction_candidate_results ADD COLUMN market_rank INTEGER"
        )


def _ensure_three_engine_tables(conn):
    """Create append-only history for active official and robot revisions."""
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS three_engine_pick_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            comparison_key TEXT NOT NULL,
            source TEXT NOT NULL,
            match_id TEXT NOT NULL,
            api_fixture_id INTEGER DEFAULT 0,
            league TEXT DEFAULT '',
            home_team TEXT NOT NULL,
            away_team TEXT NOT NULL,
            kickoff_at TEXT NOT NULL,
            kickoff_timestamp REAL NOT NULL,
            engine_key TEXT NOT NULL,
            engine_version TEXT NOT NULL,
            market_key TEXT DEFAULT '',
            selection_side TEXT DEFAULT '',
            raw_pick TEXT NOT NULL,
            probability REAL DEFAULT 0,
            odd REAL DEFAULT 0,
            pick_json TEXT NOT NULL,
            captured_at TEXT NOT NULL,
            captured_timestamp REAL NOT NULL,
            actual_home_goals INTEGER,
            actual_away_goals INTEGER,
            is_correct INTEGER,
            graded_at TEXT,
            UNIQUE(comparison_key, engine_key, engine_version)
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_three_engine_grade "
        "ON three_engine_pick_snapshots(is_correct,kickoff_timestamp)"
    )
    # R7.12.0 added a first-answer-only index. Scheduled matches now follow a
    # new analysis/robot-learning version, so the table-level versioned UNIQUE
    # constraint is the correct guard. Dropping the old index preserves rows.
    conn.execute("DROP INDEX IF EXISTS idx_three_engine_first_answer")


def _three_engine_compact_pick(pick):
    if not isinstance(pick, dict):
        return {}
    return {
        key: pick.get(key) for key in (
            "market_key", "selection_side", "raw_pick", "prob", "probability",
            "odd", "fair_prob", "handicap_base", "totals_base",
            "v2_ai_pick",
            "selection_reason", "selection_axis", "official_policy_version",
            "official_goal_score", "official_learned_probability",
            "official_learning_active", "official_learning_samples",
            "official_learning_correction",
            "official_learning_axis",
            "legacy_v4_policy_version", "legacy_v4_expected_goals",
            "robot_pick_version", "robot_model_version", "robot_expected_goals",
            "robot_training_samples", "robot_learning_revision",
            "robot_learning_reason",
        )
    }


def save_three_engine_picks(
    source, match_id, fixture_id, league, home_team, away_team, kickoff,
    official_pick, legacy_v4_pick, robot_pick,
):
    """Append active official/robot revisions before kickoff."""
    if not isinstance(kickoff, datetime):
        kickoff = _parse_kst_match_time(kickoff)
    if kickoff is None:
        return False
    if kickoff.tzinfo is None:
        kickoff = kickoff.replace(tzinfo=KST)
    kickoff_utc = kickoff.astimezone(timezone.utc)
    now = datetime.now(timezone.utc)
    if now >= kickoff_utc:
        return False
    robot_version = ":".join((
        ROBOT_PICK_VERSION,
        str((robot_pick or {}).get("robot_model_version") or ROBOT_MODEL_VERSION),
        str(int((robot_pick or {}).get("robot_training_samples") or 0)),
        str((robot_pick or {}).get("robot_learning_revision") or "no-revision"),
    ))
    engines = [
        ("official", ANALYSIS_VERSION, official_pick),
        ("robot", robot_version, robot_pick),
    ]
    v2_pick = _alphago_pick_payload(robot_pick)
    v2_code = str(v2_pick.get("code") or "")
    v2_raw = {
        "H": f"{home_team} 승", "D": "무승부", "A": f"{away_team} 승",
    }.get(v2_code, "")
    if v2_raw:
        v2_pick.update({"raw_pick": v2_raw, "prob": 0.0})
        engines.append(("v2", ALPHAGO_PICK_DISPLAY_VERSION, v2_pick))
    if any(not str((pick or {}).get("raw_pick") or "").strip() for _, _, pick in engines[:2]):
        return False
    comparison_key = f"{str(source or 'UNKNOWN').upper()}:{str(match_id)}"
    conn = None
    try:
        conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=30)
        conn.execute("PRAGMA busy_timeout = 30000")
        _ensure_three_engine_tables(conn)
        for engine_key, engine_version, pick in engines:
            compact = _three_engine_compact_pick(pick)
            probability = float(
                pick.get("probability")
                if pick.get("probability") is not None
                else pick.get("prob") or 0
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO three_engine_pick_snapshots (
                    comparison_key,source,match_id,api_fixture_id,league,
                    home_team,away_team,kickoff_at,kickoff_timestamp,
                    engine_key,engine_version,market_key,selection_side,
                    raw_pick,probability,odd,pick_json,captured_at,captured_timestamp
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    comparison_key, str(source or "UNKNOWN").upper(), str(match_id),
                    int(fixture_id or 0), str(league or ""), str(home_team),
                    str(away_team), kickoff_utc.isoformat(), kickoff_utc.timestamp(),
                    engine_key, engine_version, str(pick.get("market_key") or ""),
                    str(pick.get("selection_side") or ""),
                    str(pick.get("raw_pick") or ""), probability,
                    float(pick.get("odd") or 0),
                    json.dumps(compact, ensure_ascii=False, sort_keys=True),
                    now.isoformat(), now.timestamp(),
                ),
            )
        conn.commit()
        count = conn.execute(
            "SELECT COUNT(DISTINCT engine_key) FROM three_engine_pick_snapshots "
            "WHERE comparison_key=? AND engine_key IN ('official','robot')",
            (comparison_key,),
        ).fetchone()[0]
        return int(count or 0) >= 2
    except Exception as error:
        print(f"⚠️ 두 분석가 경기 전 픽 저장 실패({match_id}): {error}")
        return False
    finally:
        if conn is not None:
            conn.close()


def _grade_three_engine_picks(conn):
    """Grade frozen engine answers from one bounded finished-score scan.

    The former implementation queried ``predictions`` once for every ungraded
    engine row.  On the multi-GB production DB that N+1 pattern kept the score
    worker alive after the result cycle had already finished, blocking the
    single main-DB slot and starving ``master``.  Read the finished score index
    once, then grade all pending engine rows in memory.  No prediction, pick,
    probability or historical row is rewritten; only previously-null grade
    fields are filled exactly as before.
    """
    _ensure_three_engine_tables(conn)
    rows = conn.execute(
        """
        SELECT id,match_id,api_fixture_id,home_team,away_team,raw_pick
        FROM three_engine_pick_snapshots WHERE is_correct IS NULL
        ORDER BY id
        """
    ).fetchall()
    if not rows:
        return 0

    # One pass over finished prediction results replaces one SELECT per engine
    # row.  setdefault preserves the earliest rowid, matching the previous
    # ORDER BY ... rowid LIMIT 1 fallback semantics.
    finished_rows = conn.execute(
        """
        SELECT match_id,api_fixture_id,home_team,away_team,actual_score
        FROM predictions
        WHERE actual_result='FINISHED' AND actual_score IS NOT NULL
        ORDER BY rowid
        """
    ).fetchall()
    by_match = {}
    by_fixture = {}
    score_pattern = re.compile(r"^\s*(\d+)\s*:\s*(\d+)\s*$")
    for result_match_id, result_fixture_id, result_home, result_away, actual_score in finished_rows:
        score = score_pattern.match(str(actual_score or ""))
        if not score:
            continue
        value = (int(score.group(1)), int(score.group(2)))
        home_key = str(result_home)
        away_key = str(result_away)
        by_match.setdefault((str(result_match_id), home_key, away_key), value)
        try:
            fixture_key = int(result_fixture_id or 0)
        except (TypeError, ValueError):
            fixture_key = 0
        if fixture_key > 0:
            by_fixture.setdefault((fixture_key, home_key, away_key), value)

    now = _utc_iso()
    updates = []
    for row_id, match_id, fixture_id, home_team, away_team, raw_pick in rows:
        home_key = str(home_team)
        away_key = str(away_team)
        result = by_match.get((str(match_id), home_key, away_key))
        if result is None:
            try:
                fixture_key = int(fixture_id or 0)
            except (TypeError, ValueError):
                fixture_key = 0
            if fixture_key > 0:
                result = by_fixture.get((fixture_key, home_key, away_key))
        if result is None:
            continue
        goals_h, goals_a = result
        hit = int(evaluate_single_pick(
            raw_pick, home_team, away_team, goals_h, goals_a,
        ))
        updates.append((goals_h, goals_a, hit, now, int(row_id)))

    if not updates:
        return 0
    before = conn.total_changes
    conn.executemany(
        """
        UPDATE three_engine_pick_snapshots
        SET actual_home_goals=?,actual_away_goals=?,is_correct=?,graded_at=?
        WHERE id=? AND is_correct IS NULL
        """,
        updates,
    )
    graded = max(0, int(conn.total_changes - before))
    conn.commit()
    return graded


def _grading_pending_state(kickoff_at, now=None):
    """Classify an ungraded row without hiding future or grace-period games."""
    now = now or datetime.now(KST)
    try:
        kickoff = datetime.fromisoformat(
            str(kickoff_at or "").replace("Z", "+00:00")
        )
        if kickoff.tzinfo is None:
            kickoff = kickoff.replace(tzinfo=KST)
        kickoff = kickoff.astimezone(KST)
    except (TypeError, ValueError):
        return {
            "pending_status": "unknown",
            "pending_status_label": "시각 확인 필요",
            "grading_due_at": "",
        }
    grading_due = kickoff + timedelta(minutes=105)
    if now < kickoff:
        state, label = "scheduled", "시작 전"
    elif now < grading_due:
        state, label = "grace", "105분 유예 중"
    else:
        state, label = "delayed", "채점 지연"
    return {
        "pending_status": state,
        "pending_status_label": label,
        "grading_due_at": grading_due.isoformat(timespec="minutes"),
    }


def _three_engine_grading_payload(conn):
    """Return every preserved pre-kickoff analyst grade by product track.

    A version change must never erase a real, already-frozen answer from the
    scorecard.  Different engine versions remain auditable in ``pick_json``;
    the public total below only combines their genuine frozen outcomes and
    never invents an answer for a missing analyst.
    """
    _ensure_three_engine_tables(conn)
    _grade_three_engine_picks(conn)
    cursor = conn.execute(
        "SELECT * FROM three_engine_pick_snapshots "
        "WHERE engine_key IN ('official','robot','v2') "
        "ORDER BY kickoff_timestamp DESC,id DESC",
    )
    columns = [str(description[0]) for description in cursor.description]
    rows = [
        dict(row) if isinstance(row, sqlite3.Row) else dict(zip(columns, row))
        for row in cursor.fetchall()
    ]
    # All frozen robot versions belong to the same cumulative audit total.
    # Keep this variable for the existing payload shape; there is no separate
    # hidden predecessor total any more.
    previous_robot_rows = []
    grouped = {}
    for row in rows:
        group = grouped.setdefault(row["comparison_key"], {
            "comparison_key": row["comparison_key"], "source": row["source"],
            "match_id": row["match_id"], "api_fixture_id": row["api_fixture_id"],
            "league": row["league"], "home_team": row["home_team"],
            "away_team": row["away_team"], "kickoff_at": row["kickoff_at"],
            "engines": {},
        })
        # Rows are newest-first within a kickoff.  One engine contributes its
        # final pre-kickoff frozen answer only once for that product/match.
        if row["engine_key"] in group["engines"]:
            continue
        group["engines"][row["engine_key"]] = {
            "engine_version": row["engine_version"], "market_key": row["market_key"],
            "selection_side": row["selection_side"], "raw_pick": row["raw_pick"],
            "probability": float(row["probability"] or 0),
            "odd": float(row["odd"] or 0), "is_correct": row["is_correct"],
            "graded_at": str(row.get("graded_at") or ""),
            "actual_score": (
                f"{row['actual_home_goals']}:{row['actual_away_goals']}"
                if row["actual_home_goals"] is not None else ""
            ),
        }
    matches = list(grouped.values())

    def kst_date(value):
        try:
            parsed = datetime.fromisoformat(str(value or "").replace("Z", "+00:00"))
        except (TypeError, ValueError):
            return None
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(KST).date()

    def previous_robot_summary(track_key):
        candidates = []
        for row in previous_robot_rows:
            is_toto14 = str(row.get("source") or "").upper() == "TOTO14"
            if (track_key == "toto14") != is_toto14:
                continue
            if row.get("is_correct") not in (0, 1):
                continue
            candidates.append(row)
        if not candidates:
            return {}
        version_family = str(candidates[0].get("engine_version") or "").split(":", 1)[0]
        latest_by_match = {}
        for row in candidates:
            row_family = str(row.get("engine_version") or "").split(":", 1)[0]
            if row_family != version_family:
                continue
            latest_by_match.setdefault(str(row.get("comparison_key") or ""), row)
        values = [int(row["is_correct"]) for row in latest_by_match.values()]
        if not values:
            return {}
        return {
            "engine_version": version_family,
            "graded": len(values),
            "correct": sum(values),
            "accuracy": sum(values) / len(values),
            "history_rewrite": False,
        }

    def track_payload(track_matches, track_key):
        finished = [
            row for row in track_matches
            if any(
                engine.get("is_correct") in (0, 1)
                for engine in row["engines"].values()
            )
        ]
        now = datetime.now(KST)
        pending = [
            row for row in track_matches
            if not any(
                engine.get("is_correct") in (0, 1)
                for engine in row["engines"].values()
            )
        ]
        for row in pending:
            row.update(_grading_pending_state(row.get("kickoff_at"), now))
        pending_summary = {
            key: sum(1 for row in pending if row.get("pending_status") == key)
            for key in ("scheduled", "grace", "delayed", "unknown")
        }
        pending_summary["total"] = len(pending)
        today = now.date()
        summary = {}
        for engine_key in ("official", "robot", "v2"):
            graded_rows = [
                row for row in track_matches
                if (row.get("engines", {}).get(engine_key) or {}).get("is_correct")
                    in (0, 1)
            ]
            values = [
                int(row["engines"][engine_key]["is_correct"])
                for row in graded_rows
            ]
            today_values = [
                int(row["engines"][engine_key]["is_correct"])
                for row in graded_rows
                if kst_date(row.get("kickoff_at")) == today
            ]
            today_accuracy = (
                sum(today_values) / len(today_values) if today_values else None
            )
            summary[engine_key] = {
                "graded": len(values), "correct": sum(values),
                "accuracy": (sum(values) / len(values) if values else None),
                "today_graded": len(today_values),
                "today_correct": sum(today_values),
                "today_accuracy": today_accuracy,
                "reached_70_percent_today": bool(
                    today_values and today_accuracy >= 0.70
                ),
                "target_accuracy": 0.70,
                "target_reached": bool(
                    values and (sum(values) / len(values)) >= 0.70
                ),
                "target_gap": (
                    round(0.70 - (sum(values) / len(values)), 8)
                    if values else None
                ),
            }
        return {
            "summary": summary,
            "finished": finished,
            "pending": pending,
            "pending_summary": pending_summary,
            "previous_robot_summary": previous_robot_summary(track_key),
            "formula_review": {
                "threshold": 0.70,
                "basis": "all-preserved-prekickoff-frozen-picks-cumulative",
                "official_formula_hold_until_next_check": bool(
                    summary["official"]["target_reached"]
                ),
                "robot_training_continues": True,
                "robot_accuracy_goal": ROBOT_TARGET_ACCURACY,
                "no_accuracy_guarantee": True,
                "history_rewrite": False,
            },
        }

    proto_world_matches = [
        row for row in matches
        if str(row.get("source") or "").upper() not in {"TOTO14", "TOP3"}
    ]
    toto14_matches = [
        row for row in matches if str(row.get("source") or "").upper() == "TOTO14"
    ]
    top3_matches = [
        row for row in matches if str(row.get("source") or "").upper() == "TOP3"
    ]
    tracks = {
        "proto_world": track_payload(proto_world_matches, "proto_world"),
        "toto14": track_payload(toto14_matches, "toto14"),
        "top3": track_payload(top3_matches, "top3"),
    }
    return {
        "schema_version": "three-analyzer-grading.v5",
        "engine_versions": {
            "official": ANALYSIS_VERSION,
            "robot": ROBOT_PICK_VERSION,
            "v2": ALPHAGO_PICK_DISPLAY_VERSION,
        },
        "tracks": tracks,
        "legacy_rows_hidden": 0,
        "history_scope": "all-preserved-prekickoff-records",
        # Compatibility totals are PROTO LIVE. New UI reads individual tracks.
        "summary": tracks["proto_world"]["summary"],
        "finished": tracks["proto_world"]["finished"],
        "pending": tracks["proto_world"]["pending"],
    }


def save_prediction_analysis(
    match_id, pick, confidence, evidence, candidates, report,
    categories=None, analysis_stage="regular", odds_source="",
    analysis_version=None, robot_pick=None, lineup_prediction=None,
):
    """Freeze every market candidate and the exact pre-kickoff decision path."""
    if not pick or str(analysis_stage or "").startswith("locked"):
        return False
    conn = None
    try:
        conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=30)
        conn.execute("PRAGMA busy_timeout = 30000")
        _ensure_prediction_analysis_tables(conn)
        prediction_row = conn.execute(
            "SELECT actual_result, match_time FROM predictions WHERE match_id = ?",
            (str(match_id),),
        ).fetchone()
        if prediction_row:
            stored_kickoff = _parse_kst_match_time(prediction_row[1])
            if (
                str(prediction_row[0] or "PENDING") != "PENDING"
                or (stored_kickoff and datetime.now(KST) >= stored_kickoff)
            ):
                return False

        target_analysis_version = str(analysis_version or ANALYSIS_VERSION)
        interval = pick.get("probability_interval") or {}
        candidate_rows, compact_categories, decision = build_pick_selection_audit(
            candidates, categories or {"high_probability": pick}, confidence,
            robot_pick=robot_pick,
            lineup_prediction=lineup_prediction,
        )
        evidence_json = json.dumps(evidence or [], ensure_ascii=False, sort_keys=True)
        candidates_json = json.dumps(
            candidate_rows, ensure_ascii=False, sort_keys=True
        )
        categories_json = json.dumps(
            compact_categories, ensure_ascii=False, sort_keys=True
        )
        decision_json = json.dumps(decision, ensure_ascii=False, sort_keys=True)
        fingerprint_payload = "|".join((
            target_analysis_version, str(analysis_stage), str(odds_source or ""),
            evidence_json, candidates_json, categories_json, decision_json,
        ))
        fingerprint = hashlib.sha256(
            fingerprint_payload.encode("utf-8")
        ).hexdigest()

        conn.execute(
            """
            INSERT OR REPLACE INTO prediction_analysis (
                match_id, analysis_version, stage, odds_source,
                selected_market, selected_pick, model_probability,
                fair_probability, edge, confidence, error_margin,
                probability_low, probability_high, evidence_json, markets_json,
                categories_json, decision_json, report_text, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            """,
            (
                str(match_id), target_analysis_version, str(analysis_stage),
                str(odds_source or ""), infer_pick_market(pick),
                pick.get("raw_pick"), pick.get("prob"), pick.get("fair_prob"),
                pick.get("edge"), confidence, pick.get("error_margin"),
                interval.get("low"), interval.get("high"), evidence_json,
                candidates_json, categories_json, decision_json, report,
            ),
        )
        conn.execute(
            """
            INSERT OR IGNORE INTO prediction_analysis_snapshots (
                match_id, analysis_version, stage, odds_source, confidence,
                selected_market, selected_pick, candidate_count, evidence_json,
                candidates_json, categories_json, decision_json, report_text,
                fingerprint
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                str(match_id), target_analysis_version, str(analysis_stage),
                str(odds_source or ""), float(confidence or 0),
                infer_pick_market(pick), str(pick.get("raw_pick") or ""),
                len(candidate_rows), evidence_json, candidates_json,
                categories_json, decision_json, str(report or ""), fingerprint,
            ),
        )
        conn.commit()
        return True
    except Exception as error:
        print(f"⚠️ 통합 분석값 DB 저장 실패({match_id}): {error}")
        return False
    finally:
        if conn is not None:
            conn.close()


def _snapshot_existed_before_kickoff(created_at, kickoff):
    """Accept only timestamped evidence that existed before the stored kickoff."""
    if kickoff is None or not created_at:
        return False
    try:
        saved_at = datetime.fromisoformat(str(created_at).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return False
    if saved_at.tzinfo is None:
        saved_at = saved_at.replace(tzinfo=timezone.utc)
    return saved_at.astimezone(timezone.utc) <= kickoff.astimezone(timezone.utc)


def _json_object(value):
    try:
        parsed = json.loads(value or "{}")
    except (TypeError, ValueError, json.JSONDecodeError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _json_rows(value):
    try:
        parsed = json.loads(value or "[]")
    except (TypeError, ValueError, json.JSONDecodeError):
        return []
    return [dict(row) for row in parsed if isinstance(row, dict)] if isinstance(parsed, list) else []


def _first_three_engine_pick(conn, match_id, home_team, away_team, engine_key, kickoff):
    """Read the newest compatible engine answer captured before kickoff."""
    try:
        rows = conn.execute(
            """
            SELECT id,engine_version,market_key,selection_side,raw_pick,
                   probability,odd,pick_json,captured_at
            FROM three_engine_pick_snapshots
            WHERE match_id=? AND home_team=? AND away_team=? AND engine_key=?
            ORDER BY id DESC
            """,
            (str(match_id), str(home_team), str(away_team), str(engine_key)),
        ).fetchall()
    except sqlite3.Error:
        return None
    for row in rows:
        if not _snapshot_existed_before_kickoff(row[8], kickoff):
            continue
        engine_version = str(row[1] or "")
        if engine_key == "official" and engine_version != ANALYSIS_VERSION:
            continue
        if engine_key == "robot" and not engine_version.startswith(ROBOT_PICK_VERSION):
            continue
        raw_pick = str(row[4] or "").strip()
        if not raw_pick:
            continue
        pick = _json_object(row[7])
        pick.update({
            "market_key": str(row[2] or pick.get("market_key") or ""),
            "selection_side": str(row[3] or pick.get("selection_side") or ""),
            "raw_pick": raw_pick,
            "prob": float(row[5] or pick.get("prob") or 0),
            "probability": float(row[5] or pick.get("probability") or 0),
            "odd": float(row[6] or pick.get("odd") or 0),
            "public_pick_frozen": True,
            "three_engine_snapshot_id": int(row[0]),
        })
        if engine_key == "legacy_v4":
            pick["legacy_v4_policy_version"] = str(
                pick.get("legacy_v4_policy_version") or row[1] or ""
            )
        elif engine_key == "robot":
            pick["robot_pick_version"] = str(
                pick.get("robot_pick_version") or engine_version or ""
            )
        return pick
    return None


def _is_current_public_analysis_version(value):
    """Identify a complete R7.10 public analysis, excluding market previews."""
    return str(value or "") in {ANALYSIS_VERSION, WORLD_ANALYSIS_VERSION}


def _first_public_pick_bundle(conn, match_id, home_team, away_team, match_time=""):
    """Recover the active answer from append-only pre-kickoff revisions.

    During the test period a scheduled game follows the newest analysis
    version. After kickoff the same rule naturally selects the last revision
    that existed before kickoff. Older rows remain untouched for audit, and
    every writer still rejects hindsight calculations.
    """
    try:
        identity = conn.execute(
            "SELECT home_team, away_team, match_time FROM predictions WHERE match_id = ?",
            (str(match_id),),
        ).fetchone()
        if (
            not identity
            or str(identity[0]) != str(home_team)
            or str(identity[1]) != str(away_team)
        ):
            return None
        kickoff = _parse_kst_match_time(identity[2] or match_time)
        if kickoff is None:
            return None
        prediction_rows = conn.execute(
            """
            SELECT id, analysis_version, stage, confidence, prob_pick,
                   prob_pick_prob, ev_pick, ev_pick_prob, odd_h, odd_d, odd_a,
                   api_fixture_id, created_at
            FROM prediction_snapshots
            WHERE match_id = ? ORDER BY id ASC
            """,
            (str(match_id),),
        ).fetchall()
    except sqlite3.Error:
        return None

    eligible_public_rows = [
        row for row in prediction_rows
        if str(row[4] or "").strip()
        and _snapshot_existed_before_kickoff(row[12], kickoff)
    ]
    current_rows = [
        row for row in eligible_public_rows
        if str(row[1] or "") == ANALYSIS_VERSION
    ]
    public_row = (
        max(current_rows or eligible_public_rows, key=lambda row: int(row[0]))
        if eligible_public_rows else None
    )
    if public_row is None:
        return None

    official_pick = str(public_row[4] or "").strip()
    try:
        official_probability = max(0.0, min(1.0, float(public_row[5] or 0) / 100.0))
    except (TypeError, ValueError):
        official_probability = 0.0
    ev_pick = str(public_row[6] or "").strip()
    try:
        ev_probability = max(0.0, min(1.0, float(public_row[7] or 0) / 100.0))
    except (TypeError, ValueError):
        ev_probability = 0.0

    analysis_rows = []
    try:
        analysis_rows = conn.execute(
            """
            SELECT id, analysis_version, stage, odds_source, confidence,
                   selected_market, selected_pick, candidates_json,
                   categories_json, decision_json, report_text, created_at
            FROM prediction_analysis_snapshots
            WHERE match_id = ? ORDER BY id DESC
            """,
            (str(match_id),),
        ).fetchall()
    except sqlite3.Error:
        analysis_rows = []

    official_analysis = next(
        (
            row for row in analysis_rows
            if str(row[6] or "").strip() == official_pick
            and str(row[1] or "") == str(public_row[1] or "")
            and _snapshot_existed_before_kickoff(row[11], kickoff)
        ),
        None,
    )
    if official_analysis is None:
        official_analysis = next(
            (
                row for row in analysis_rows
                if str(row[6] or "").strip() == official_pick
                and _snapshot_existed_before_kickoff(row[11], kickoff)
            ),
            None,
        )
    categories = _json_object(official_analysis[8]) if official_analysis else {}
    candidates = _json_rows(official_analysis[7]) if official_analysis else []
    decision = _json_object(official_analysis[9]) if official_analysis else {}
    selected = dict(categories.get("high_probability") or {})
    if str(selected.get("raw_pick") or "") != official_pick:
        selected = next(
            (dict(row) for row in candidates if str(row.get("raw_pick") or "") == official_pick),
            {},
        )
    selected.update({
        "raw_pick": official_pick,
        "prob": official_probability,
        "probability": official_probability,
        "official_final_pick": True,
        "recommendation_status": "SELECTED",
        "public_pick_frozen": True,
    })
    if not selected.get("market_key"):
        selected["market_key"] = (
            str(official_analysis[5] or "") if official_analysis
            else infer_pick_market(selected)
        )
    if float(_audit_number(selected.get("odd"), 0.0) or 0) <= 1:
        normalized = official_pick.casefold()
        if "무승부" in normalized or normalized.strip() in {"무", "draw"}:
            selected["odd"] = float(public_row[9] or 0)
        elif str(home_team).casefold() in normalized and "승" in official_pick:
            selected["odd"] = float(public_row[8] or 0)
        elif str(away_team).casefold() in normalized and "승" in official_pick:
            selected["odd"] = float(public_row[10] or 0)

    frozen_categories = {
        "high_probability": selected,
        "honey": None,
        "vip_underdog": None,
    }
    for key in ("honey", "vip_underdog"):
        value = categories.get(key)
        if isinstance(value, dict) and str(value.get("raw_pick") or "") == official_pick:
            frozen_categories[key] = dict(value, public_pick_frozen=True)

    robot_pick = None
    robot_analysis_id = None
    for row in analysis_rows:
        if not _snapshot_existed_before_kickoff(row[11], kickoff):
            continue
        robot_categories = _json_object(row[8])
        robot_decision = _json_object(row[9])
        candidate_robot = robot_decision.get("robot_pick") or robot_categories.get("robot_independent")
        if not isinstance(candidate_robot, dict):
            continue
        robot_version = str(
            robot_decision.get("robot_pick_version")
            or candidate_robot.get("robot_pick_version")
            or ""
        )
        if robot_version != ROBOT_PICK_VERSION or not str(candidate_robot.get("raw_pick") or "").strip():
            continue
        robot_pick = dict(candidate_robot)
        robot_pick["prob"] = robot_pick.get("prob", robot_pick.get("probability", 0))
        robot_pick["probability"] = robot_pick.get("probability", robot_pick.get("prob", 0))
        robot_pick["public_pick_frozen"] = True
        robot_analysis_id = int(row[0])
        frozen_categories["robot_independent"] = robot_pick
        break

    # The three-engine table is the append-only source of truth for independent
    # answers. Older analysis snapshots did not always embed the robot payload.
    if robot_pick is None:
        robot_pick = _first_three_engine_pick(
            conn, match_id, home_team, away_team, "robot", kickoff
        )
        if robot_pick:
            frozen_categories["robot_independent"] = robot_pick
    alphago_pick = dict(decision.get("alphago_pick") or {})
    if not alphago_pick:
        alphago_pick = _alphago_pick_payload(robot_pick)

    if not candidates:
        candidates = [dict(selected)]
    elif not any(str(row.get("raw_pick") or "") == official_pick for row in candidates):
        candidates.insert(0, dict(selected))
    report = str(official_analysis[10] or "") if official_analysis else ""
    return {
        "match_id": str(match_id),
        "snapshot_id": int(public_row[0]),
        "analysis_snapshot_id": int(official_analysis[0]) if official_analysis else None,
        "robot_analysis_snapshot_id": robot_analysis_id,
        "analysis_version": str(
            (official_analysis[1] if official_analysis else None)
            or public_row[1]
            or ""
        ),
        "analysis_stage": str(
            (official_analysis[2] if official_analysis else None)
            or public_row[2]
            or "regular"
        ),
        "odds_source": str(official_analysis[3] or "") if official_analysis else "",
        "confidence": float(
            (official_analysis[4] if official_analysis else None)
            or public_row[3]
            or 0
        ),
        "selected": selected,
        "ev_pick": ev_pick,
        "ev_probability": ev_probability,
        "categories": frozen_categories,
        "legacy_v4_pick": {},
        "robot_pick": robot_pick,
        "alphago_pick": alphago_pick,
        "candidates": candidates,
        "decision": decision,
        "report": report,
        "frozen_at": str(public_row[12] or ""),
    }


def _load_first_public_pick_bundle(match_id, home_team, away_team, match_time=""):
    conn = None
    try:
        conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=10)
        conn.execute("PRAGMA busy_timeout = 10000")
        _ensure_prediction_analysis_tables(conn)
        return _first_public_pick_bundle(
            conn, match_id, home_team, away_team, match_time
        )
    except sqlite3.Error:
        return None
    finally:
        if conn is not None:
            conn.close()


def _public_proto_item_from_first_snapshot(match, current=None, locked=False):
    """Overlay the active pre-kickoff official/robot revision onto a card."""
    current = dict(current or {})
    latest_analysis_stage = str(
        current.get("latest_analysis_stage")
        or current.get("analysis_stage")
        or ""
    )
    bundle = _load_first_public_pick_bundle(
        str(match.get("id") or ""),
        str(match.get("home") or ""),
        str(match.get("away") or ""),
        str(match.get("match_time") or current.get("final_match_time") or ""),
    )
    if not bundle:
        return current
    current_categories = (
        current.get("pick_categories")
        if isinstance(current.get("pick_categories"), dict) else {}
    )
    current_robot = current.get("robot_pick") or current_categories.get(
        "robot_independent"
    ) or {}
    if not (
        isinstance(current_robot, dict)
        and str(current_robot.get("raw_pick") or "").strip()
        and str(current_robot.get("robot_pick_version") or "") == ROBOT_PICK_VERSION
    ):
        current_robot = {}
    public_robot = bundle.get("robot_pick") or current_robot
    current_alphago = current.get("alphago_pick")
    if not isinstance(current_alphago, dict):
        current_alphago = {}
    public_alphago = bundle.get("alphago_pick") or current_alphago
    if not isinstance(public_alphago, dict):
        public_alphago = {}
    public_categories = dict(bundle["categories"])
    if public_robot:
        public_categories["robot_independent"] = dict(public_robot)
    # A stored pre-kickoff answer is evidence, not a lock.  The old display
    # code marked it frozen even while the match was still scheduled, which
    # made a later recovery/revision look like a permanently blocked card.
    # Only the caller that has confirmed kickoff may mark the public card
    # frozen; the append-only DB evidence itself remains unchanged.
    for category in public_categories.values():
        if isinstance(category, dict):
            category["public_pick_frozen"] = bool(locked)
    if isinstance(public_robot, dict):
        public_robot = dict(public_robot)
        public_robot["public_pick_frozen"] = bool(locked)
    current_pick = str(
        ((current.get("pick_categories") or {}).get("high_probability") or {}).get("raw_pick")
        or ""
    )
    report = bundle.get("report") or (
        "시작 전 최신 분석 버전의 최종픽입니다. "
        "경기가 시작되면 마지막 경기 전 픽을 잠그고 변경하지 않습니다."
    )
    current.update({
        "match": dict(match),
        "final_match_time": current.get("final_match_time") or match.get("match_time"),
        "pick_categories": public_categories,
        "legacy_v4_pick": {},
        "robot_pick": dict(public_robot or {}),
        "alphago_pick": dict(public_alphago),
        "ev_sorted_picks": bundle["candidates"],
        "display_candidates": bundle["candidates"],
        "display_candidates_saved_at": bundle["frozen_at"],
        "detailed_report": report,
        "story": "<br><br>".join(
            paragraph.replace("\n", "<br>") for paragraph in report.split("\n\n")
        ),
        "analysis_version": bundle["analysis_version"],
        "analysis_stage": "locked" if locked else bundle["analysis_stage"],
        # The scheduled answer may move until kickoff. This operational field
        # records which evidence stage completed last.
        "latest_analysis_stage": latest_analysis_stage or bundle["analysis_stage"],
        "analysis_confidence": bundle["confidence"],
        "odds_source": bundle["odds_source"] or current.get("odds_source") or "",
        "model_probability": bundle["selected"].get("prob"),
        "fair_market_probability": bundle["selected"].get("fair_prob"),
        "probability_error_margin": bundle["selected"].get("error_margin"),
        "probability_interval": bundle["selected"].get("probability_interval"),
        "prediction_frozen": bool(locked),
        "public_pick_frozen": bool(locked),
        "public_pick_frozen_at": bundle["frozen_at"] if locked else "",
        "public_pick_snapshot_id": bundle["snapshot_id"],
        "public_pick_change_suppressed": bool(
            current_pick and current_pick != bundle["selected"]["raw_pick"]
        ),
    })
    return current


def _public_world_analysis_from_first_snapshot(match, current_analysis):
    """Expose newest scheduled picks and lock the last pre-kickoff revision."""
    current_analysis = dict(current_analysis or {})
    bundle = _load_first_public_pick_bundle(
        str(match.get("id") or ""),
        str(match.get("home") or ""),
        str(match.get("away") or ""),
        str(match.get("match_time") or ""),
    )
    if not bundle:
        return current_analysis
    selected = dict(bundle["selected"])
    selected["display"] = _human_pick_label(
        selected.get("raw_pick"), str(match.get("home") or "")
    )
    selected["probability"] = float(selected.get("prob") or 0)
    decision = dict(bundle.get("decision") or {})
    if bundle.get("robot_pick"):
        decision["robot_pick"] = dict(bundle["robot_pick"])
        decision["robot_pick_version"] = ROBOT_PICK_VERSION
    current_alphago = current_analysis.get("alphago_pick")
    if not isinstance(current_alphago, dict):
        current_alphago = {}
    public_alphago = bundle.get("alphago_pick") or current_alphago
    if not isinstance(public_alphago, dict):
        public_alphago = {}
    if public_alphago:
        decision["alphago_pick"] = dict(public_alphago)
    current_stage = str(current_analysis.get("analysis_stage") or "")
    current_report = str(current_analysis.get("report") or "").strip()
    frozen_report = str(bundle.get("report") or "").strip()
    # A market preview can be the first visible pick. Once the full-context pass
    # finishes, the scheduled card moves to that richer report and current two
    # answers. After kickoff the selector returns the last pre-match rows.
    report = (
        current_report
        if current_stage and current_stage != "market-preview" and current_report
        else (frozen_report or current_report)
    )
    if (
        current_stage and current_stage != "market-preview"
        and frozen_report and current_report and frozen_report != current_report
    ):
        report += (
            "\n\n[픽 이력 보호] 현재 값은 저장된 경기 전 공식픽·로봇픽입니다. "
            "시작 전에는 새 공식 분석이나 로봇 학습 결과로 갱신될 수 있고, "
            "시작 뒤에는 마지막 경기 전 값을 잠가 변경하지 않습니다."
        )
    current_analysis.update({
        "selected": selected,
        "categories": bundle["categories"],
        "legacy_v4_pick": {},
        "robot_pick": dict(bundle.get("robot_pick") or {}),
        "alphago_pick": dict(public_alphago),
        "candidates": bundle["candidates"],
        "decision": decision,
        "report": report,
        "public_pick_frozen": True,
        "public_pick_frozen_at": bundle["frozen_at"],
        "public_pick_analysis_version": bundle["analysis_version"],
        "public_pick_analysis_stage": bundle["analysis_stage"],
        "public_pick_snapshot_id": bundle["snapshot_id"],
    })
    return current_analysis


def _scoring_row_from_first_public_snapshot(conn, row):
    """Replace tuple pick fields only in memory; the stored history stays intact."""
    values = list(row)
    if len(values) < 7:
        return tuple(values)
    bundle = _first_public_pick_bundle(
        conn, values[0], values[1], values[2], values[5]
    )
    if bundle:
        values[3] = bundle["selected"]["raw_pick"]
        values[4] = bundle.get("ev_pick") or ""
    return tuple(values)


def annotate_pick_metrics(picks, confidence):
    for pick in picks:
        probability = float(pick.get("prob", 0) or 0)
        market_probability = float(
            pick.get("market_prob", pick.get("fair_prob", 0)) or 0
        )
        odd = float(pick.get("odd", 0) or 0)
        edge = probability - market_probability if market_probability > 0 else 0.0
        pick["edge"] = round(edge, 4)
        pick["safe_score"] = round(probability * confidence, 4)
        pick["value_score"] = round(max(0.0, edge) * confidence, 4)
        error_margin = max(0.0, float(pick.get("error_margin", 0) or 0))
        # 역배는 한 번의 추정치가 튀기 쉬워 오차범위의 30%를
        # 먼저 뺀 보수적 확률과 가치로 다시 검증한다.
        robust_probability = max(0.0, probability - (error_margin * 0.30))
        robust_edge = (
            robust_probability - market_probability
            if market_probability > 0 else 0.0
        )
        pick["robust_probability"] = round(robust_probability, 6)
        pick["robust_edge"] = round(robust_edge, 6)
        pick["robust_ev"] = round(robust_probability * odd, 6)
        if pick.get("settlement"):
            settlement = pick["settlement"]
            conservative_win_stake = max(0.0, settlement["win_weight"] - error_margin*.30)
            pick["robust_ev"] = round(conservative_win_stake*odd + settlement["refund_weight"], 6)
        pick["underdog_gate_version"] = UNDERDOG_GATE_VERSION
        pick["is_qualified_underdog"] = bool(
            pick.get("is_true_underdog")
            and 2.20 <= odd <= 5.00
            and probability >= 0.22
            and robust_edge >= 0.015
            and float(pick.get("robust_ev", 0) or 0) >= 1.02
            and confidence >= 0.55
            and int(pick.get("independent_support_count", 0) or 0) >= 1
        )
        pick["recommendation_score"] = round(
            (probability * 0.72) + (confidence * 0.20) + (min(max(edge, 0.0), 0.15) * 0.55), 4
        )
    return picks


PICK_CATEGORY_LABELS = {
    "high_probability": "최종 추천픽",
    "honey": "배당가치 우수",
    "vip_underdog": "VIP 검증 등급",
}


def _tag_pick_category(pick, category_key):
    """원본 후보를 건드리지 않고 화면용 카테고리 정보를 붙입니다."""
    if not pick:
        return None
    selected = dict(pick)
    selected["category_key"] = category_key
    selected["category_label"] = PICK_CATEGORY_LABELS[category_key]
    return selected


def _pick_possible_wdl_results(pick):
    """Return the regulation-time 1X2 results compatible with a candidate."""
    market = infer_pick_market(pick)
    side = str((pick or {}).get("selection_side") or "").strip().lower()
    all_sides = {"home", "draw", "away"}
    if market == "totals":
        return all_sides
    if market == "1x2":
        return {side} if side in all_sides else all_sides
    if market != "handicap" or side not in all_sides:
        return all_sides

    handicap = (pick or {}).get("handicap_base")
    if handicap is None:
        matched = re.search(
            r"\[\s*([+-]?\d+(?:\.\d+)?)\s*\]",
            str((pick or {}).get("raw_pick") or ""),
        )
        handicap = matched.group(1) if matched else None
    try:
        handicap = float(handicap)
    except (TypeError, ValueError):
        return all_sides

    possible = set()
    for goal_difference in range(-20, 21):
        adjusted = goal_difference + handicap
        handicap_side = (
            "home" if adjusted > 1e-9
            else ("away" if adjusted < -1e-9 else "draw")
        )
        if handicap_side != side:
            continue
        possible.add(
            "home" if goal_difference > 0
            else ("away" if goal_difference < 0 else "draw")
        )
    return possible


def picks_can_coexist(primary, alternative):
    """True only when two different-market picks can win on one final score."""
    if not primary or not alternative:
        return False
    primary_market = infer_pick_market(primary)
    alternative_market = infer_pick_market(alternative)
    if primary_market == alternative_market:
        return False
    if "totals" in {primary_market, alternative_market}:
        return True
    return bool(
        _pick_possible_wdl_results(primary)
        & _pick_possible_wdl_results(alternative)
    )


def select_pick_categories(picks, confidence):
    """Select exactly one official pick from all supported pre-match markets."""
    categories = {
        "high_probability": None,
        "honey": None,
        "vip_underdog": None,
    }
    if not picks:
        return categories, []

    confidence = float(confidence or 0)
    available = valid_analysis_candidates(picks)
    if not available:
        return categories, []

    policy = available[0].get("price_policy") or {}
    high_source, choice_reason = all_evidence_choice(
        available, confidence, return_reason=True
    )
    high_source = dict(high_source)
    value_qualified = price_eligible(high_source, confidence)
    high_source["value_pick_tier"] = "qualified" if value_qualified else "not_qualified"
    high_source["odds_verified"] = bool(
        high_source.get("fair_prob") is not None
        and float(high_source.get("odd", 0) or 0) > 1.0
    )
    high_source["official_final_pick"] = True
    high_source["recommendation_status"] = "SELECTED"
    reason_text = "경기 전 전체 지표와 승무패·핸디캡·언더오버를 함께 계산하고 시간순 미래검증을 통과한 후보 채점 학습으로 가장 강한 한 방향을 선택"
    high_source["selection_axis"] = "evidence_ensemble_accuracy_first"
    high_source["official_learning_axis"] = (
        "chronological_candidate_learning_accuracy_first"
    )
    high_source["cross_market_decision"] = choice_reason
    high_source["selection_reason"] = (
        f"{reason_text}했습니다. 선택 배당 "
        + (f"{float(high_source.get('odd') or 0):.2f}배." if float(high_source.get('odd') or 0) > 1 else "미수신.")
    )
    if not value_qualified:
        # Warn on the chosen candidate; do not reselect from another pool.
        high_source.update(choose_analysis_fallback([high_source]))
        if confidence < .50:
            high_source["selection_warning"] += " · 데이터 신뢰도 낮음"
        high_source["selection_reason"] = (
            "경기 전 전체 지표와 세 시장을 모두 비교해 가장 강한 한 픽을 선택했습니다. "
            "다만 " + high_source["selection_warning"] + "."
        )
    else:
        high_source["probability_fallback"] = False
        high_source["selection_warning"] = ""
    high_source["selection_policy"] = {"minimum_odds": None,
                                       "policy_version": PICK_POLICY_VERSION,
                                       "decision_axis": "chronological_candidate_learning_accuracy_first",
                                       "cross_market_decision": choice_reason,
                                       "minimum_edge_advantage": None,
                                       "price_tradeoff_validated": False,
                                       "price_validation": policy,
                                       "valid_decimal_odds_above": 1.0,
                                       "conservative_gross_return_floor": 1.01,
                                       "compare_all_markets": True,
                                       "compare_other_markets_after_wdl": False,
                                       "provide_pick_when_analyzable": True,
                                       "value_failure_action": "probability_pick_with_warning",
                                       "force_underdog": False}
    high_source["learning_robot"] = {
        "mode": "controlled_adviser",
        "market": infer_pick_market(high_source),
        "samples": int(high_source.get("learning_cohort_samples", 0) or 0),
        "hit_rate": round(float(high_source.get("market_hit_rate", 0.5) or 0.5), 4),
        "scope": str(high_source.get("market_history_scope") or "global"),
        "influence_weight": round(float(high_source.get("learning_weight", 0) or 0), 4),
        "influence_cap": 0.18,
        "history_rewrite": False,
        "self_modifying": False,
        "objective": "all_pre_match_evidence_best_single_pick_without_empty_pick",
        "value_failure_action": "probability_pick_with_warning",
        "calibration_model_version": FORECAST_MODEL_VERSION,
        "calibration_version": CALIBRATION_VERSION,
        "calibration_cohort_samples": int(high_source.get("learning_cohort_samples") or 0),
        "calibration_active": float(high_source.get("learning_weight") or 0) > 0,
        "diagnostics": high_source.get("learning_diagnostics") or {},
    }

    # 꿀픽과 VIP는 다른 예측이 아니다. 최종 추천픽 하나가 각 기준을
    # 통과했을 때만 동일한 raw_pick에 등급 배지를 붙인다.
    # Reuse the existing stronger value thresholds, not a new odds-only grade.
    strong_value = bool(value_qualified
                        and float(high_source.get("robust_edge", 0) or 0) >= 0.03
                        and float(high_source.get("robust_ev", 0) or 0) >= 1.08
                        and confidence >= 0.68)
    honey_source = high_source if strong_value else None
    vip_source = None
    if value_qualified:
        vip_passed = bool(
            strong_value
            and high_source.get("market_movement_confirmed")
            and float(high_source.get("robust_edge", 0) or 0) >= 0.03
            and float(high_source.get("robust_ev", 0) or 0) >= 1.08
            and confidence >= 0.68
            and int(high_source.get("independent_support_count", 0) or 0) >= 3
            and 1.0 < float(high_source.get("odd", 0) or 0) <= 4.50
        )
        if vip_passed:
            vip_source = high_source

    high_source["final_pick_grade"] = (
        "vip" if vip_source else "value" if honey_source else "standard"
    )

    categories["high_probability"] = _tag_pick_category(high_source, "high_probability")
    categories["honey"] = _tag_pick_category(honey_source, "honey")
    categories["vip_underdog"] = _tag_pick_category(vip_source, "vip_underdog")
    return categories, [categories["high_probability"]]


_AUTONOMOUS_ROBOT_CACHE = {}
_ROBOT_LEARNING_MARKER_CACHE = {}


def _robot_learning_track(source):
    """Keep pools tickets out of the open PROTO/WORLD learning brain."""
    return "toto14" if str(source or "").strip().upper() == "TOTO14" else "proto_world"


def _robot_track_sql(source, alias=""):
    prefix = f"{alias}." if alias else ""
    if _robot_learning_track(source) == "toto14":
        return f"UPPER({prefix}source)='TOTO14'", ()
    return f"UPPER({prefix}source) IN ('PROTO','WORLD')", ()


def _robot_learning_revision_marker(source="PROTO"):
    """Return a cheap local marker that changes after a new robot result."""
    track = _robot_learning_track(source)
    cache = _ROBOT_LEARNING_MARKER_CACHE.get(track) or {}
    checked_at = float(cache.get("checked_at") or 0)
    cached = cache.get("value")
    if cached and time.monotonic() - checked_at < 15:
        return str(cached)
    conn = None
    try:
        path = _local_path("ai_predictions.db")
        if not Path(path).exists():
            marker = f"{track}:{ROBOT_PICK_VERSION}:{ROBOT_MODEL_VERSION}:0:0.000"
        else:
            conn = sqlite3.connect(str(path), timeout=5)
            conn.execute("PRAGMA busy_timeout = 5000")
            table = conn.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' "
                "AND name='robot_learning_samples'"
            ).fetchone()
            if not table:
                count, latest = 0, 0.0
            else:
                track_where, track_params = _robot_track_sql(source)
                count, latest = conn.execute(
                    "SELECT COUNT(*),COALESCE(MAX(result_known_timestamp),0) "
                    "FROM robot_learning_samples WHERE actual_home_goals IS NOT NULL "
                    f"AND actual_away_goals IS NOT NULL AND {track_where}",
                    track_params,
                ).fetchone()
            marker = (
                f"{track}:{ROBOT_PICK_VERSION}:{ROBOT_MODEL_VERSION}:"
                f"{int(count or 0)}:{float(latest or 0):.3f}"
            )
        _ROBOT_LEARNING_MARKER_CACHE[track] = {
            "checked_at": time.monotonic(), "value": marker,
        }
        return marker
    except sqlite3.Error:
        return str(cached or "")
    finally:
        if conn is not None:
            conn.close()


def _ensure_autonomous_robot_tables(conn):
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS robot_learning_samples (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fixture_key TEXT NOT NULL,
            source TEXT NOT NULL,
            match_id TEXT NOT NULL,
            api_fixture_id INTEGER DEFAULT 0,
            league TEXT DEFAULT '',
            home_team TEXT NOT NULL,
            away_team TEXT NOT NULL,
            kickoff_at TEXT NOT NULL,
            kickoff_timestamp REAL NOT NULL,
            captured_at TEXT NOT NULL,
            captured_timestamp REAL NOT NULL,
            robot_pick_version TEXT NOT NULL,
            feature_schema_version TEXT NOT NULL,
            memory_schema_version TEXT DEFAULT '',
            features_json TEXT NOT NULL,
            full_evidence_json TEXT DEFAULT '{}',
            lineup_prediction_json TEXT DEFAULT '{}',
            candidates_json TEXT NOT NULL,
            robot_pick_json TEXT NOT NULL,
            actual_home_goals INTEGER,
            actual_away_goals INTEGER,
            result_known_at TEXT,
            result_known_timestamp REAL,
            robot_pick_correct INTEGER,
            candidate_results_json TEXT DEFAULT '[]',
            official_lineup_json TEXT DEFAULT '{}',
            lineup_comparison_json TEXT DEFAULT '{}',
            lineup_known_at TEXT,
            lineup_known_timestamp REAL,
            lineup_retry_at REAL DEFAULT 0,
            lineup_retry_attempts INTEGER DEFAULT 0,
            UNIQUE(fixture_key, robot_pick_version)
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_robot_samples_result "
        "ON robot_learning_samples(robot_pick_version, result_known_timestamp, kickoff_timestamp)"
    )
    robot_columns = {
        str(row[1]) for row in conn.execute("PRAGMA table_info(robot_learning_samples)")
    }
    if "robot_pick_correct" not in robot_columns:
        conn.execute("ALTER TABLE robot_learning_samples ADD COLUMN robot_pick_correct INTEGER")
    if "candidate_results_json" not in robot_columns:
        conn.execute(
            "ALTER TABLE robot_learning_samples ADD COLUMN candidate_results_json TEXT DEFAULT '[]'"
        )
    robot_column_defaults = {
        "memory_schema_version": "TEXT DEFAULT ''",
        "full_evidence_json": "TEXT DEFAULT '{}'",
        "lineup_prediction_json": "TEXT DEFAULT '{}'",
        "official_lineup_json": "TEXT DEFAULT '{}'",
        "lineup_comparison_json": "TEXT DEFAULT '{}'",
        "lineup_known_at": "TEXT",
        "lineup_known_timestamp": "REAL",
        "lineup_retry_at": "REAL DEFAULT 0",
        "lineup_retry_attempts": "INTEGER DEFAULT 0",
    }
    for column, declaration in robot_column_defaults.items():
        if column not in robot_columns:
            conn.execute(
                f"ALTER TABLE robot_learning_samples ADD COLUMN {column} {declaration}"
            )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS robot_pre_match_observations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fixture_key TEXT NOT NULL,
            robot_pick_version TEXT NOT NULL,
            feature_schema_version TEXT NOT NULL,
            memory_schema_version TEXT NOT NULL,
            captured_at TEXT NOT NULL,
            captured_timestamp REAL NOT NULL,
            kickoff_timestamp REAL NOT NULL,
            analysis_stage TEXT DEFAULT '',
            features_json TEXT NOT NULL,
            full_evidence_json TEXT NOT NULL,
            evidence_fingerprint TEXT NOT NULL,
            UNIQUE(fixture_key,robot_pick_version,evidence_fingerprint)
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_robot_observations_fixture "
        "ON robot_pre_match_observations(fixture_key,captured_timestamp)"
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS robot_pick_revision_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fixture_key TEXT NOT NULL,
            source TEXT NOT NULL,
            match_id TEXT NOT NULL,
            api_fixture_id INTEGER DEFAULT 0,
            home_team TEXT NOT NULL,
            away_team TEXT NOT NULL,
            kickoff_timestamp REAL NOT NULL,
            robot_pick_version TEXT NOT NULL,
            robot_model_version TEXT DEFAULT '',
            captured_at TEXT NOT NULL,
            captured_timestamp REAL NOT NULL,
            features_json TEXT NOT NULL,
            candidates_json TEXT NOT NULL,
            robot_pick_json TEXT NOT NULL,
            revision_fingerprint TEXT NOT NULL,
            UNIQUE(fixture_key,robot_pick_version,revision_fingerprint)
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_robot_pick_revisions_fixture "
        "ON robot_pick_revision_snapshots(fixture_key,captured_timestamp)"
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS robot_model_promotions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            robot_pick_version TEXT NOT NULL,
            model_version TEXT NOT NULL,
            sample_signature TEXT NOT NULL,
            artifact_json TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            UNIQUE(robot_pick_version, sample_signature)
        )
        """
    )


def _load_historical_grading_experience(conn):
    """Use every honest grading row as probability-calibration experience.

    Detailed robot features exist only for newer matches.  Older grading-note
    rows still contain the probability shown before kickoff and the settled
    result, so they can teach probability calibration without inventing any
    missing team, lineup or event feature.
    """
    _ensure_prediction_analysis_tables(conn)
    cells = {}

    def add(market, probability, hit, count=1):
        try:
            probability = float(probability)
            hit = float(hit)
            count = int(count)
        except (TypeError, ValueError):
            return
        if not 0 <= probability <= 1 or hit < 0 or count <= 0:
            return
        bucket = min(9, max(0, int(probability * 10)))
        key = (str(market or "1x2"), bucket)
        cell = cells.setdefault(key, {"samples": 0, "correct": 0.0})
        cell["samples"] += count
        cell["correct"] += hit

    for market, probability, samples, correct in conn.execute(
        """
        SELECT market_key,model_probability,COUNT(*),SUM(is_correct)
        FROM prediction_candidate_results
        WHERE model_probability BETWEEN 0 AND 1 AND is_correct IN (0,1)
        GROUP BY market_key,ROUND(model_probability,4)
        """
    ).fetchall():
        add(market, probability, correct, samples)

    # Compatibility rows from before candidate-level grading existed.
    tables = {
        str(row[0]) for row in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    }
    if "predictions" in tables:
        prediction_columns = {
            str(row[1]) for row in conn.execute("PRAGMA table_info(predictions)")
        }
        required = {
            "match_id", "prob_pick", "prob_pick_prob", "is_correct_prob",
            "actual_result",
        }
        if required.issubset(prediction_columns):
            for raw_pick, probability, hit in conn.execute(
                """
                SELECT p.prob_pick,p.prob_pick_prob,p.is_correct_prob
                FROM predictions p
                WHERE p.actual_result='FINISHED'
                  AND p.is_correct_prob IN (0,1)
                  AND p.prob_pick_prob BETWEEN 0 AND 100
                  AND NOT EXISTS (
                      SELECT 1 FROM prediction_candidate_results r
                      WHERE r.match_id=p.match_id
                  )
                """
            ).fetchall():
                add(
                    infer_pick_market({"raw_pick": raw_pick}),
                    float(probability or 0) / 100.0,
                    hit,
                )

    markets = {}
    total = 0
    for (market, bucket), cell in sorted(cells.items()):
        samples = int(cell["samples"])
        correct = float(cell["correct"])
        total += samples
        markets.setdefault(market, {})[str(bucket)] = {
            "samples": samples,
            "correct": round(correct, 6),
            "observed_rate": round(correct / samples, 8),
        }
    return {
        "schema_version": "grading-experience.v1",
        "samples": total,
        "markets": markets,
        "minimum_sample_gate": False,
        "history_rewrite": False,
    }


def _load_robot_self_grading_experience(conn, source="PROTO"):
    """Build calibration cells only from the robot's own frozen answers.

    Every candidate was saved before kickoff and later receives both a right
    or wrong label. This deliberately excludes official/Codex grading rows so
    the autonomous robot learns from its own decisions and probability errors.
    """
    _ensure_autonomous_robot_tables(conn)
    cells = {}
    price_segments = {}
    selection_price_segments = {}
    selection_samples = 0
    selection_correct = 0
    track_where, track_params = _robot_track_sql(source)
    rows = conn.execute(
        f"""
        SELECT candidate_results_json,robot_pick_correct,robot_pick_json,
               candidates_json,robot_pick_version
        FROM robot_learning_samples
        WHERE result_known_timestamp IS NOT NULL
          AND actual_home_goals IS NOT NULL AND actual_away_goals IS NOT NULL
          AND candidate_results_json NOT IN ('','[]','null')
          AND robot_pick_version LIKE 'robot-self-learning-online-%'
          AND {track_where}
        ORDER BY kickoff_timestamp,id
        """,
        tuple(track_params),
    ).fetchall()
    selection_markets = {}
    source_versions = set()

    def price_segment_keys(pick):
        try:
            odd = float((pick or {}).get("odd") or 0)
        except (TypeError, ValueError):
            odd = 0.0
        keys = []
        if odd >= 3.5:
            keys.extend(["very_high_price", "high_price"])
        elif odd >= 2.35:
            keys.append("high_price")
        elif odd > 1.0:
            keys.append("regular_price")
        if bool((pick or {}).get("is_true_underdog")):
            keys.append("true_underdog")
        try:
            expected_return = float(
                (pick or {}).get("robot_ev")
                or (float((pick or {}).get("robot_probability") or 0) * odd)
                or 0
            )
        except (TypeError, ValueError):
            expected_return = 0.0
        if expected_return >= 1.02:
            keys.append("positive_value")
        return keys, odd

    def add_price_grade(target, pick, hit):
        keys, odd = price_segment_keys(pick)
        for key in keys:
            cell = target.setdefault(
                key, {"samples": 0, "correct": 0, "gross_return": 0.0}
            )
            cell["samples"] += 1
            cell["correct"] += int(hit)
            if odd > 1.0:
                cell["gross_return"] += int(hit) * odd

    for candidate_json, robot_pick_correct, robot_pick_json, original_json, source_version in rows:
        source_versions.add(str(source_version or ""))
        try:
            original_candidates = json.loads(original_json or "[]")
        except (TypeError, ValueError, json.JSONDecodeError):
            original_candidates = []
        original_by_identity = {
            (
                str(candidate.get("market_key") or "1x2"),
                str(candidate.get("raw_pick") or ""),
            ): candidate
            for candidate in original_candidates
            if isinstance(candidate, dict)
        }
        if robot_pick_correct in (0, 1):
            selection_samples += 1
            selection_correct += int(robot_pick_correct)
            try:
                frozen_pick = json.loads(robot_pick_json or "{}")
            except (TypeError, ValueError, json.JSONDecodeError):
                frozen_pick = {}
            market = str((frozen_pick or {}).get("market_key") or "1x2")
            market_cell = selection_markets.setdefault(
                market, {"samples": 0, "correct": 0}
            )
            market_cell["samples"] += 1
            market_cell["correct"] += int(robot_pick_correct)
            add_price_grade(
                selection_price_segments, frozen_pick, robot_pick_correct
            )
        try:
            candidates = json.loads(candidate_json or "[]")
        except (TypeError, ValueError, json.JSONDecodeError):
            continue
        for candidate in candidates if isinstance(candidates, list) else []:
            if not isinstance(candidate, dict) or candidate.get("is_correct") not in (0, 1):
                continue
            original = original_by_identity.get((
                str(candidate.get("market_key") or "1x2"),
                str(candidate.get("raw_pick") or ""),
            )) or {}
            if original:
                candidate = {**original, **candidate}
            try:
                probability = float(candidate.get("robot_probability"))
            except (TypeError, ValueError):
                continue
            if not math.isfinite(probability) or not 0 <= probability <= 1:
                continue
            market = str(candidate.get("market_key") or "1x2")
            side = str(candidate.get("selection_side") or "unknown")
            key = f"{market}:{side}"
            bucket = str(min(9, max(0, int(probability * 10))))
            cell = cells.setdefault(key, {}).setdefault(
                bucket, {"samples": 0, "correct": 0}
            )
            cell["samples"] += 1
            cell["correct"] += int(candidate["is_correct"])
            add_price_grade(price_segments, candidate, candidate["is_correct"])

    total = 0
    for market_cells in cells.values():
        for cell in market_cells.values():
            total += int(cell["samples"])
            cell["observed_rate"] = round(
                float(cell["correct"]) / max(1, int(cell["samples"])), 8
            )
    for cell in selection_markets.values():
        cell["accuracy"] = round(
            float(cell["correct"]) / max(1, int(cell["samples"])), 8
        )
    for segment_cells in (price_segments, selection_price_segments):
        for cell in segment_cells.values():
            samples = max(1, int(cell["samples"]))
            cell["gross_return"] = round(float(cell["gross_return"]), 8)
            cell["accuracy"] = round(float(cell["correct"]) / samples, 8)
            cell["profit_units"] = round(float(cell["gross_return"]) - samples, 8)
            cell["roi"] = round(float(cell["gross_return"]) / samples - 1.0, 8)
    return {
        "schema_version": "robot-self-grading-experience.v4-price-skill",
        "samples": total,
        "markets": cells,
        "price_segments": price_segments,
        "selection_markets": selection_markets,
        "selection_price_segments": selection_price_segments,
        "source_robot_versions": sorted(version for version in source_versions if version),
        "compatibility_policy": "all-frozen-robot-candidate-grades-v1",
        "selection_samples": selection_samples,
        "selection_correct": selection_correct,
        "selection_accuracy": (
            round(selection_correct / selection_samples, 8)
            if selection_samples else None
        ),
        "minimum_sample_gate": False,
        "official_grading_used": False,
        "robot_pick_version": ROBOT_PICK_VERSION,
        "learning_track": _robot_learning_track(source),
        "history_rewrite": False,
    }


def _robot_fixture_key(match_id, fixture_id, home_team, away_team, kickoff, source="PROTO"):
    track = _robot_learning_track(source)
    if int(fixture_id or 0) > 0:
        return f"{track}:fixture:{int(fixture_id)}"
    normalized = lambda value: re.sub(r"[^0-9a-z가-힣]+", "", str(value or "").casefold())
    return f"{track}:scheduled:" + "|".join((
        normalized(home_team), normalized(away_team),
        kickoff.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M"),
        normalized(match_id),
    ))


def _select_autonomous_robot_artifact(
    conn, artifact, source, track, signature, grading_experience=None,
):
    """Restore the same promoted model a fresh one-shot worker would select."""
    challenger = dict(artifact or {})
    experience = grading_experience
    if not isinstance(experience, dict):
        experience = _load_robot_self_grading_experience(conn, source)
    challenger["learning_track"] = track
    challenger["learning_revision_marker"] = signature
    challenger["grading_experience"] = experience
    challenger["grading_experience_samples"] = int(experience.get("samples") or 0)
    eligibility_is_explicit = "deployment_eligible" in challenger
    challenger_eligible = bool(
        challenger.get("deployment_eligible")
        if eligibility_is_explicit else challenger.get("active")
    )
    selected_artifact = challenger if challenger_eligible else None
    if not challenger_eligible:
        champion_row = conn.execute(
            """
            SELECT artifact_json FROM robot_model_promotions
            WHERE robot_pick_version=? AND model_version=? AND active=1
              AND sample_signature LIKE ?
            ORDER BY id DESC LIMIT 1
            """,
            (ROBOT_PICK_VERSION, ROBOT_MODEL_VERSION, track + ":%"),
        ).fetchone()
        if champion_row:
            try:
                champion = json.loads(champion_row[0] or "{}")
            except (TypeError, ValueError, json.JSONDecodeError):
                champion = {}
            if champion.get("parameters"):
                champion = dict(champion)
                champion["learning_track"] = track
                champion["grading_experience"] = experience
                champion["grading_experience_samples"] = int(
                    experience.get("samples") or 0
                )
                champion["latest_challenger_samples"] = challenger.get("samples", 0)
                champion["latest_challenger_reason"] = challenger.get("reason", "")
                champion["learning_revision_marker"] = signature
                selected_artifact = champion
    if selected_artifact is None:
        # Candidate grading still calibrates every market from result one, but
        # a goal-formula challenger cannot alter future goals until it proves
        # itself on a later chronological block.  This safety baseline is a
        # deployed model, not a fabricated old prediction.
        selected_artifact = {
            **challenger,
            "active": True,
            "parameters": {
                "model_family": "context_baseline",
                "rho": -.15,
                "learning_strength": 0.0,
            },
            "selected_model_family": "context_baseline",
            "deployed_model_family": "context_baseline",
            "deployment_eligible": False,
            "latest_challenger_samples": challenger.get("samples", 0),
            "latest_challenger_reason": challenger.get("reason", ""),
            "reason": (
                "새 계산식의 시간순 미래검증 전 · 전체 경기 전 자료 기초모형과 "
                "자체 후보 채점 보정 사용"
            ),
        }
    selected_artifact["challenger_deployment_eligible"] = challenger_eligible
    selected_artifact["learning_revision_marker"] = signature
    return selected_artifact


def _load_autonomous_robot_artifact(source="PROTO", serving_only=False):
    track = _robot_learning_track(source)

    if serving_only:
        cached = _AUTONOMOUS_ROBOT_CACHE.get(track) or {}
        cached_artifact = cached.get("artifact") if isinstance(cached, dict) else None
        if isinstance(cached_artifact, dict) and cached_artifact:
            return cached_artifact
        latest_row = None
        serving_conn = None
        try:
            serving_conn = sqlite3.connect(
                f"file:{_local_path('ai_predictions.db')}?mode=ro",
                uri=True, timeout=2,
            )
            serving_conn.execute("PRAGMA busy_timeout = 2000")
            has_table = serving_conn.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='robot_model_promotions'"
            ).fetchone()
            if has_table:
                latest_row = serving_conn.execute(
                    """
                    SELECT sample_signature,artifact_json FROM robot_model_promotions
                    WHERE robot_pick_version=? AND model_version=?
                      AND sample_signature LIKE ?
                    ORDER BY id DESC LIMIT 1
                    """,
                    (ROBOT_PICK_VERSION, ROBOT_MODEL_VERSION, track + ":%"),
                ).fetchone()
        except sqlite3.Error:
            latest_row = None
        finally:
            if serving_conn is not None:
                serving_conn.close()
        if latest_row:
            try:
                latest_artifact = json.loads(latest_row[1] or "{}")
            except (TypeError, ValueError, json.JSONDecodeError):
                latest_artifact = {}
            if isinstance(latest_artifact, dict) and latest_artifact:
                latest_artifact = dict(latest_artifact)
                latest_artifact["serving_only"] = True
                latest_artifact["learning_revision_marker"] = str(latest_row[0] or "")
                _AUTONOMOUS_ROBOT_CACHE[track] = {
                    "signature": str(latest_row[0] or ""),
                    "artifact": latest_artifact,
                }
                return latest_artifact
        baseline = {
            "active": True,
            "parameters": {
                "model_family": "context_baseline",
                "rho": -.15,
                "learning_strength": 0.0,
            },
            "selected_model_family": "context_baseline",
            "deployed_model_family": "context_baseline",
            "deployment_eligible": False,
            "serving_only": True,
            "reason": "학습 산출물 준비 전 빠른 경기전 서비스용 기초모형",
            "learning_revision_marker": "serving-baseline",
        }
        _AUTONOMOUS_ROBOT_CACHE[track] = {
            "signature": "serving-baseline", "artifact": baseline,
        }
        return baseline

    conn = None
    try:
        conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=30)
        conn.execute("PRAGMA busy_timeout = 30000")
        _ensure_autonomous_robot_tables(conn)
        _ensure_prediction_analysis_tables(conn)

        track_where, track_params = _robot_track_sql(source)
        signature_row = conn.execute(
            f"""
            SELECT COUNT(*), COALESCE(MAX(result_known_timestamp), 0)
            FROM robot_learning_samples
            WHERE actual_home_goals IS NOT NULL AND actual_away_goals IS NOT NULL
              AND {track_where}
            """,
            track_params,
        ).fetchone()
        signature = (
            f"{track}:{ROBOT_PICK_VERSION}:{ROBOT_MODEL_VERSION}:"
            f"{int(signature_row[0] or 0)}:"
            f"{float(signature_row[1] or 0):.3f}"
        )
        if (
            (_AUTONOMOUS_ROBOT_CACHE.get(track) or {}).get("signature") == signature
            and isinstance((_AUTONOMOUS_ROBOT_CACHE.get(track) or {}).get("artifact"), dict)
        ):
            return _AUTONOMOUS_ROBOT_CACHE[track]["artifact"]
        # Master/WORLD run in short-lived child processes. Their process-local
        # cache starts empty each time, so reuse the immutable model promotion
        # for this exact result signature instead of repeating the full formula
        # search every cycle. A newly graded result changes the signature and
        # therefore still triggers a fresh training pass.
        persisted_row = conn.execute(
            """
            SELECT artifact_json FROM robot_model_promotions
            WHERE robot_pick_version=? AND model_version=?
              AND substr(sample_signature,1,?)=?
              AND substr(sample_signature,?+1,1)=':'
            ORDER BY id DESC LIMIT 1
            """,
            (
                ROBOT_PICK_VERSION, ROBOT_MODEL_VERSION,
                len(signature), signature, len(signature),
            ),
        ).fetchone()
        if persisted_row:
            try:
                persisted_artifact = json.loads(persisted_row[0] or "{}")
            except (TypeError, ValueError, json.JSONDecodeError):
                persisted_artifact = {}
            if isinstance(persisted_artifact, dict) and persisted_artifact:
                if serving_only:
                    selected_artifact = dict(persisted_artifact)
                    selected_artifact["serving_only"] = True
                    selected_artifact["learning_revision_marker"] = signature
                else:
                    selected_artifact = _select_autonomous_robot_artifact(
                        conn, persisted_artifact, source, track, signature
                    )
                _ROBOT_LEARNING_MARKER_CACHE[track] = {
                    "checked_at": time.monotonic(), "value": signature,
                }
                _AUTONOMOUS_ROBOT_CACHE[track] = {
                    "signature": signature, "artifact": selected_artifact,
                }
                return selected_artifact
        examples = []
        compatible_schemas = tuple(ROBOT_COMPATIBLE_FEATURE_SCHEMAS)
        schema_marks = ",".join("?" for _ in compatible_schemas)
        track_where_alias, track_params_alias = _robot_track_sql(source, "sample")
        rows = conn.execute(
            f"""
            SELECT sample.fixture_key,sample.kickoff_timestamp,
                   COALESCE(observation.captured_timestamp,sample.captured_timestamp),
                   sample.result_known_timestamp,
                   COALESCE(observation.features_json,sample.features_json),
                   sample.actual_home_goals,sample.actual_away_goals,
                   sample.candidate_results_json
            FROM robot_learning_samples AS sample
            LEFT JOIN robot_pre_match_observations AS observation
              ON observation.id=(
                  SELECT latest.id
                  FROM robot_pre_match_observations AS latest
                  WHERE latest.fixture_key=sample.fixture_key
                    AND latest.robot_pick_version=sample.robot_pick_version
                    AND latest.captured_timestamp < sample.kickoff_timestamp
                  ORDER BY latest.captured_timestamp DESC,latest.id DESC
                  LIMIT 1
              )
            WHERE sample.actual_home_goals IS NOT NULL
              AND sample.actual_away_goals IS NOT NULL
              AND sample.feature_schema_version IN ({schema_marks})
              AND {track_where_alias}
            ORDER BY sample.kickoff_timestamp,sample.id
            """,
            tuple(compatible_schemas) + tuple(track_params_alias),
        ).fetchall()
        for (
            fixture_key, kickoff, captured, known, features_json,
            goals_h, goals_a, candidates_json,
        ) in rows:
            try:
                features = json.loads(features_json or "{}")
                candidates = json.loads(candidates_json or "[]")
            except (TypeError, ValueError, json.JSONDecodeError):
                continue
            examples.append({
                "fixture_key": str(fixture_key), "kickoff": float(kickoff),
                "captured_at": float(captured), "known_at": float(known),
                "features": features, "home_goals": int(goals_h),
                "away_goals": int(goals_a),
                "candidates": candidates if isinstance(candidates, list) else [],
            })
        artifact = train_autonomous_robot(examples)
        artifact["learning_track"] = track
        artifact["learning_revision_marker"] = signature
        artifact["grading_experience"] = _load_robot_self_grading_experience(
            conn, source
        )
        artifact["grading_experience_samples"] = int(
            artifact["grading_experience"].get("samples") or 0
        )
        fingerprint = hashlib.sha256(
            json.dumps(artifact, ensure_ascii=False, sort_keys=True).encode("utf-8")
        ).hexdigest()
        conn.execute(
            """
            INSERT OR IGNORE INTO robot_model_promotions (
                robot_pick_version,model_version,sample_signature,
                artifact_json,active,created_at
            ) VALUES (?,?,?,?,?,?)
            """,
            (
                ROBOT_PICK_VERSION, ROBOT_MODEL_VERSION,
                signature + ":" + fingerprint[:16],
                json.dumps(artifact, ensure_ascii=False, sort_keys=True),
                int(bool(
                    artifact.get("deployment_eligible")
                    if "deployment_eligible" in artifact
                    else artifact.get("active")
                )), _utc_iso(),
            ),
        )
        conn.commit()
        selected_artifact = _select_autonomous_robot_artifact(
            conn, artifact, source, track, signature,
            grading_experience=artifact["grading_experience"],
        )
        _ROBOT_LEARNING_MARKER_CACHE[track] = {
            "checked_at": time.monotonic(), "value": signature,
        }
        _AUTONOMOUS_ROBOT_CACHE[track] = {
            "signature": signature, "artifact": selected_artifact,
        }
        return selected_artifact
    except Exception as error:
        print(f"⚠️ 자율학습 로봇 모델 준비 실패 · 기초 자율모형 유지: {type(error).__name__}")
        return {
            "model_version": ROBOT_MODEL_VERSION, "active": False, "samples": 0,
            "validation_fixtures": 0, "reason": "학습표본 저장소 확인 대기",
            "learning_track": track,
            "learning_revision_marker": _robot_learning_revision_marker(source),
        }
    finally:
        if conn is not None:
            conn.close()


def save_autonomous_robot_sample(
    source, match_id, fixture_id, league, home_team, away_team, kickoff,
    features, candidates, robot_pick, full_evidence=None,
    lineup_prediction=None, analysis_stage="",
):
    """Persist the current scheduled robot answer plus append-only revisions."""
    if not isinstance(kickoff, datetime):
        raw_kickoff = kickoff
        kickoff = _parse_kst_match_time(raw_kickoff)
        if kickoff is None:
            try:
                kickoff = datetime.fromisoformat(
                    str(raw_kickoff or "").replace("Z", "+00:00")
                )
            except (TypeError, ValueError):
                kickoff = None
    if kickoff is None:
        return False
    if kickoff.tzinfo is None:
        kickoff = kickoff.replace(tzinfo=KST)
    now = datetime.now(timezone.utc)
    kickoff_utc = kickoff.astimezone(timezone.utc)
    if now >= kickoff_utc or not isinstance(features, dict) or not robot_pick:
        return False
    fixture_key = _robot_fixture_key(
        match_id, fixture_id, home_team, away_team, kickoff_utc, source
    )
    full_evidence = full_evidence if isinstance(full_evidence, dict) else {}
    lineup_prediction = (
        lineup_prediction if isinstance(lineup_prediction, dict) else {}
    )
    evidence_json = json.dumps(
        full_evidence, ensure_ascii=False, sort_keys=True, default=str
    )
    feature_json = json.dumps(
        features, ensure_ascii=False, sort_keys=True, default=str
    )
    compact_candidates = []
    for candidate in candidates or []:
        if not isinstance(candidate, dict):
            continue
        compact_candidates.append({
            key: candidate.get(key) for key in (
                "market_key", "selection_side", "raw_pick", "odd", "fair_prob",
                "market_prob", "handicap_base", "totals_base", "robot_probability",
                "is_true_underdog", "is_qualified_underdog",
                "robot_expected_goals", "robot_model_version",
                "robot_learning_revision",
                "robot_pre_grading_probability", "robot_grading_experience_samples",
                "robot_grading_calibration_samples", "robot_grading_calibration_weight",
                "robot_price_skill_segment", "robot_price_skill_samples",
                "robot_price_skill_accuracy", "robot_price_skill_weight",
                "robot_accuracy_goal", "robot_accuracy_goal_policy_version",
                "robot_goal_validation_accuracy", "robot_goal_target_reached",
                "robot_goal_score", "robot_goal_market_samples",
                "robot_goal_market_accuracy", "robot_goal_market_weight",
                "robot_goal_price_segment", "robot_goal_price_samples",
                "robot_goal_price_accuracy", "robot_goal_price_roi",
                "robot_goal_price_weight", "robot_goal_price_roi_adjustment",
                "robot_edge", "robot_ev",
            )
        })
    compact_pick = {
        key: robot_pick.get(key) for key in (
            "market_key", "selection_side", "raw_pick", "odd", "fair_prob",
            "handicap_base", "totals_base", "prob", "robot_probability",
            "is_true_underdog", "is_qualified_underdog",
            "robot_expected_goals", "robot_model_version", "robot_model_active",
            "robot_training_samples", "robot_validation_fixtures",
            "robot_learning_revision",
            "robot_decision_reason", "robot_selection_axis",
            "robot_grading_experience_samples", "robot_grading_calibration_samples",
            "robot_grading_calibration_weight", "robot_minimum_sample_gate",
            "robot_price_skill_segment", "robot_price_skill_samples",
            "robot_price_skill_accuracy", "robot_price_skill_weight",
            "robot_accuracy_goal", "robot_accuracy_goal_policy_version",
            "robot_goal_validation_accuracy", "robot_goal_target_reached",
            "robot_goal_score", "robot_goal_market_samples",
            "robot_goal_market_accuracy", "robot_goal_market_weight",
            "robot_goal_price_segment", "robot_goal_price_samples",
            "robot_goal_price_accuracy", "robot_goal_price_roi",
            "robot_goal_price_weight", "robot_goal_price_roi_adjustment",
            "robot_goal_is_market_quota", "robot_edge", "robot_ev",
        )
    }
    conn = None
    try:
        conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=30)
        conn.execute("PRAGMA busy_timeout = 30000")
        _ensure_autonomous_robot_tables(conn)
        observation_fingerprint = hashlib.sha256(
            (feature_json + "\x1f" + evidence_json).encode("utf-8")
        ).hexdigest()
        conn.execute(
            """
            INSERT OR IGNORE INTO robot_pre_match_observations (
                fixture_key,robot_pick_version,feature_schema_version,
                memory_schema_version,captured_at,captured_timestamp,
                kickoff_timestamp,analysis_stage,features_json,
                full_evidence_json,evidence_fingerprint
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                fixture_key, ROBOT_PICK_VERSION, ROBOT_FEATURE_SCHEMA_VERSION,
                ROBOT_MEMORY_SCHEMA_VERSION, now.isoformat(), now.timestamp(),
                kickoff_utc.timestamp(), str(analysis_stage or ""),
                feature_json, evidence_json, observation_fingerprint,
            ),
        )
        revision_fingerprint = hashlib.sha256(
            (feature_json + "\x1f" + json.dumps(
                compact_candidates, ensure_ascii=False, sort_keys=True
            ) + "\x1f" + json.dumps(
                compact_pick, ensure_ascii=False, sort_keys=True
            )).encode("utf-8")
        ).hexdigest()
        conn.execute(
            """
            INSERT OR IGNORE INTO robot_pick_revision_snapshots (
                fixture_key,source,match_id,api_fixture_id,home_team,away_team,
                kickoff_timestamp,robot_pick_version,robot_model_version,
                captured_at,captured_timestamp,features_json,candidates_json,
                robot_pick_json,revision_fingerprint
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                fixture_key, str(source or "UNKNOWN"), str(match_id),
                int(fixture_id or 0), str(home_team), str(away_team),
                kickoff_utc.timestamp(), ROBOT_PICK_VERSION,
                str(robot_pick.get("robot_model_version") or ROBOT_MODEL_VERSION),
                now.isoformat(), now.timestamp(), feature_json,
                json.dumps(compact_candidates, ensure_ascii=False, sort_keys=True),
                json.dumps(compact_pick, ensure_ascii=False, sort_keys=True),
                revision_fingerprint,
            ),
        )
        conn.execute(
            """
            INSERT OR IGNORE INTO robot_learning_samples (
                fixture_key,source,match_id,api_fixture_id,league,home_team,away_team,
                kickoff_at,kickoff_timestamp,captured_at,captured_timestamp,
                robot_pick_version,feature_schema_version,memory_schema_version,
                features_json,full_evidence_json,lineup_prediction_json,
                candidates_json,robot_pick_json
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                fixture_key, str(source or "UNKNOWN"), str(match_id), int(fixture_id or 0),
                str(league or ""), str(home_team), str(away_team), kickoff_utc.isoformat(),
                kickoff_utc.timestamp(), now.isoformat(), now.timestamp(),
                ROBOT_PICK_VERSION, ROBOT_FEATURE_SCHEMA_VERSION,
                ROBOT_MEMORY_SCHEMA_VERSION, feature_json, evidence_json,
                json.dumps(lineup_prediction, ensure_ascii=False, sort_keys=True, default=str),
                json.dumps(compact_candidates, ensure_ascii=False, sort_keys=True),
                json.dumps(compact_pick, ensure_ascii=False, sort_keys=True),
            ),
        )
        # One row remains the current answer that will be graded. It may move
        # only while the fixture is scheduled; every former answer is already
        # protected above in robot_pick_revision_snapshots.
        conn.execute(
            """
            UPDATE robot_learning_samples
            SET captured_at=?,captured_timestamp=?,feature_schema_version=?,
                memory_schema_version=?,features_json=?,full_evidence_json=?,
                lineup_prediction_json=?,candidates_json=?,robot_pick_json=?
            WHERE fixture_key=? AND robot_pick_version=?
              AND actual_home_goals IS NULL AND kickoff_timestamp>?
            """,
            (
                now.isoformat(), now.timestamp(), ROBOT_FEATURE_SCHEMA_VERSION,
                ROBOT_MEMORY_SCHEMA_VERSION, feature_json, evidence_json,
                json.dumps(lineup_prediction, ensure_ascii=False, sort_keys=True, default=str),
                json.dumps(compact_candidates, ensure_ascii=False, sort_keys=True),
                json.dumps(compact_pick, ensure_ascii=False, sort_keys=True),
                fixture_key, ROBOT_PICK_VERSION, now.timestamp(),
            ),
        )
        conn.commit()
        return True
    except Exception as error:
        print(f"⚠️ 자율학습 로봇 경기 전 표본 저장 실패({match_id}): {error}")
        return False
    finally:
        if conn is not None:
            conn.close()


def _load_frozen_autonomous_robot_sample(match_id, fixture_id=0, source="PROTO"):
    """Read the current scheduled robot decision or last pre-kickoff decision."""
    conn = None
    try:
        conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=30)
        conn.execute("PRAGMA busy_timeout = 30000")
        _ensure_autonomous_robot_tables(conn)
        if int(fixture_id or 0) > 0:
            row = conn.execute(
                """
                SELECT features_json,candidates_json,robot_pick_json,captured_at
                FROM robot_learning_samples
                WHERE api_fixture_id=? AND robot_pick_version=? AND UPPER(source)=?
                ORDER BY id ASC LIMIT 1
                """,
                (int(fixture_id), ROBOT_PICK_VERSION, str(source or "PROTO").upper()),
            ).fetchone()
        else:
            row = conn.execute(
                """
                SELECT features_json,candidates_json,robot_pick_json,captured_at
                FROM robot_learning_samples
                WHERE match_id=? AND robot_pick_version=? AND UPPER(source)=?
                ORDER BY id ASC LIMIT 1
                """,
                (str(match_id), ROBOT_PICK_VERSION, str(source or "PROTO").upper()),
            ).fetchone()
        if not row:
            return None
        try:
            return {
                "features": json.loads(row[0] or "{}"),
                "candidates": json.loads(row[1] or "[]"),
                "pick": json.loads(row[2] or "{}"),
                "captured_at": str(row[3] or ""),
            }
        except (TypeError, ValueError, json.JSONDecodeError):
            return None
    finally:
        if conn is not None:
            conn.close()


def _apply_frozen_toto14_robot(item, match_id):
    """Overlay the current scheduled robot W/D/L table onto one TOTO14 card."""
    if not isinstance(item, dict):
        return item
    match = item.get("match") or {}
    frozen = _load_frozen_autonomous_robot_sample(
        match_id, item.get("api_fixture_id") or 0, "TOTO14"
    )
    if not frozen:
        return item
    candidates = [
        candidate for candidate in frozen.get("candidates") or []
        if isinstance(candidate, dict)
        and str(candidate.get("market_key") or "") == "1x2"
        and str(candidate.get("selection_side") or "") in {"home", "draw", "away"}
    ]
    probabilities = {
        str(candidate.get("selection_side")): float(
            candidate.get("robot_probability")
            if candidate.get("robot_probability") is not None
            else candidate.get("prob") or 0
        )
        for candidate in candidates
    }
    if set(probabilities) != {"home", "draw", "away"}:
        return item
    side = max(("home", "draw", "away"), key=lambda key: probabilities[key])
    mark = {"home": "승", "draw": "무", "away": "패"}[side]
    display = (
        str(match.get("home") or "") + " 승" if mark == "승" else
        str(match.get("away") or "") + " 승" if mark == "패" else "무승부"
    )
    item.update({
        "robot_features": frozen.get("features") or {},
        "robot_candidates": candidates,
        "robot_pick": frozen.get("pick") or {},
        "robot_wdl_probabilities": probabilities,
        "robot_mark": mark,
        "robot_pick_display": display,
        "robot_pick_probability": round(probabilities[side] * 100, 1),
        "robot_pick_version": ROBOT_PICK_VERSION,
        "robot_frozen_at": frozen.get("captured_at") or "",
        "robot_current_pre_kickoff": True,
        # Compatibility key for older app payload readers.
        "robot_first_pick_frozen": True,
    })
    return item


def _compare_robot_lineup_prediction(lineup_prediction, official_lineup):
    if not official_lineup.get("confirmed"):
        return {}
    details = official_lineup.get("details") or {}
    predicted_sides = {
        "home": list(lineup_prediction.get("home_predicted_starting_xi") or []),
        "away": list(lineup_prediction.get("away_predicted_starting_xi") or []),
    }
    team_ids = {
        "home": int(lineup_prediction.get("home_team_id") or 0),
        "away": int(lineup_prediction.get("away_team_id") or 0),
    }
    comparisons = {}
    ordered_fallback = list(details.values())
    for index, side in enumerate(("home", "away")):
        actual_team = details.get(str(team_ids[side])) or (
            ordered_fallback[index] if index < len(ordered_fallback) else {}
        )
        actual_names = [
            str(row.get("name") or "")
            for row in (actual_team.get("start_xi") or [])
            if str(row.get("name") or "").strip()
        ]
        actual_normalized = {_normalize_player_name(name) for name in actual_names}
        predicted_names = predicted_sides[side]
        predicted_normalized = {
            _normalize_player_name(name) for name in predicted_names
        }
        hits = [
            name for name in predicted_names
            if _normalize_player_name(name) in actual_normalized
        ]
        comparisons[side] = {
            "team_id": team_ids[side],
            "predicted_count": len(predicted_names),
            "official_count": len(actual_names),
            "correct_starters": len(hits),
            "accuracy": round(len(hits) / max(1, len(actual_names)), 6),
            "matched_players": hits,
            "missed_official_players": [
                name for name in actual_names
                if _normalize_player_name(name) not in predicted_normalized
            ],
            "formation": actual_team.get("formation") or "",
        }
    return {
        "schema_version": ROBOT_LINEUP_SCHEMA_VERSION,
        "teams": comparisons,
    }


def _grade_autonomous_robot_sample(conn, match_id, fixture_id, goals_h, goals_a):
    _ensure_autonomous_robot_tables(conn)
    known = datetime.now(timezone.utc)
    if int(fixture_id or 0) > 0:
        rows = conn.execute(
            """
            SELECT id,home_team,away_team,robot_pick_json,candidates_json,
                   lineup_prediction_json
            FROM robot_learning_samples
            WHERE api_fixture_id=? AND actual_home_goals IS NULL AND kickoff_timestamp < ?
            """,
            (int(fixture_id), known.timestamp()),
        ).fetchall()
    else:
        rows = conn.execute(
            """
            SELECT id,home_team,away_team,robot_pick_json,candidates_json,
                   lineup_prediction_json
            FROM robot_learning_samples
            WHERE match_id=? AND actual_home_goals IS NULL AND kickoff_timestamp < ?
            """,
            (str(match_id), known.timestamp()),
        ).fetchall()
    official_lineup = {"confirmed": False, "details": {}}
    needs_lineup_answer = any(
        str(row[5] or "").strip() not in {"", "{}", "null"}
        for row in rows
    )
    if int(fixture_id or 0) > 0 and needs_lineup_answer:
        # Core result grading must not wait on one lineup endpoint per finished
        # match. Reuse any already-cached official XI immediately; unresolved
        # answers are fetched later by the bounded reconciliation batch below.
        try:
            with api_cache_only_context(True):
                official_lineup = fetch_lineups_api(
                    int(fixture_id), 24 * 365 * 5, purpose="scoring"
                )
        except Exception:
            official_lineup = {"confirmed": False, "details": {}}
    graded = 0
    for sample_id, home_team, away_team, robot_json, candidates_json, lineup_json in rows:
        try:
            robot_pick = json.loads(robot_json or "{}")
        except (TypeError, ValueError, json.JSONDecodeError):
            robot_pick = {}
        try:
            candidates = json.loads(candidates_json or "[]")
        except (TypeError, ValueError, json.JSONDecodeError):
            candidates = []
        try:
            lineup_prediction = json.loads(lineup_json or "{}")
        except (TypeError, ValueError, json.JSONDecodeError):
            lineup_prediction = {}
        robot_hit = evaluate_single_pick(
            robot_pick.get("raw_pick"), home_team, away_team,
            int(goals_h), int(goals_a),
        )
        candidate_results = []
        for candidate in candidates:
            if not isinstance(candidate, dict):
                continue
            candidate_results.append({
                "market_key": candidate.get("market_key"),
                "selection_side": candidate.get("selection_side"),
                "raw_pick": candidate.get("raw_pick"),
                "robot_probability": candidate.get("robot_probability"),
                "odd": candidate.get("odd"),
                "fair_prob": candidate.get("fair_prob"),
                "robot_edge": candidate.get("robot_edge"),
                "robot_ev": candidate.get("robot_ev"),
                "robot_goal_score": candidate.get("robot_goal_score"),
                "is_true_underdog": bool(candidate.get("is_true_underdog")),
                "independent_support_count": int(
                    candidate.get("independent_support_count") or 0
                ),
                "context_alignment": candidate.get("context_alignment"),
                "is_correct": evaluate_single_pick(
                    candidate.get("raw_pick"), home_team, away_team,
                    int(goals_h), int(goals_a),
                ),
            })
        lineup_comparison = {}
        lineup_known_at = None
        lineup_known_timestamp = None
        if official_lineup.get("confirmed"):
            lineup_comparison = _compare_robot_lineup_prediction(
                lineup_prediction, official_lineup
            )
            lineup_known_at = known.isoformat()
            lineup_known_timestamp = known.timestamp()
        cursor = conn.execute(
            """
            UPDATE robot_learning_samples
            SET actual_home_goals=?,actual_away_goals=?,result_known_at=?,
                result_known_timestamp=?,robot_pick_correct=?,candidate_results_json=?,
                official_lineup_json=?,lineup_comparison_json=?,
                lineup_known_at=?,lineup_known_timestamp=?,
                lineup_retry_attempts=?,lineup_retry_at=?
            WHERE id=? AND actual_home_goals IS NULL
            """,
            (
                int(goals_h), int(goals_a), known.isoformat(), known.timestamp(),
                int(bool(robot_hit)),
                json.dumps(candidate_results, ensure_ascii=False, sort_keys=True),
                json.dumps(
                    official_lineup if official_lineup.get("confirmed") else {},
                    ensure_ascii=False, sort_keys=True,
                ),
                json.dumps(lineup_comparison, ensure_ascii=False, sort_keys=True),
                lineup_known_at, lineup_known_timestamp,
                0 if official_lineup.get("confirmed") else 1,
                0 if official_lineup.get("confirmed") else known.timestamp() + 900.0,
                int(sample_id),
            ),
        )
        graded += int(cursor.rowcount or 0)
    if graded:
        _AUTONOMOUS_ROBOT_CACHE.clear()
        _ROBOT_LEARNING_MARKER_CACHE.clear()
    return graded


def _reconcile_robot_lineup_answers(conn, batch_size=6):
    """Keep seeking missing official XI answers without blocking score grading."""
    _ensure_autonomous_robot_tables(conn)
    now = datetime.now(timezone.utc)
    rows = conn.execute(
        """
        SELECT id,api_fixture_id,lineup_prediction_json,lineup_retry_attempts
        FROM robot_learning_samples
        WHERE actual_home_goals IS NOT NULL
          AND api_fixture_id > 0
          AND lineup_prediction_json NOT IN ('','{}')
          AND (lineup_known_timestamp IS NULL OR official_lineup_json IN ('','{}'))
          AND COALESCE(lineup_retry_at,0) <= ?
        ORDER BY result_known_timestamp,id
        LIMIT ?
        """,
        (now.timestamp(), max(1, int(batch_size))),
    ).fetchall()
    attached = 0
    for sample_id, fixture_id, prediction_json, attempts in rows:
        try:
            prediction = json.loads(prediction_json or "{}")
        except (TypeError, ValueError, json.JSONDecodeError):
            prediction = {}
        try:
            official = fetch_lineups_api(
                int(fixture_id), 24 * 365 * 5, purpose="scoring"
            )
        except Exception as error:
            print(
                f"⚠️ 로봇 공식 선발 정답 재조회 실패({fixture_id}): "
                f"{type(error).__name__}"
            )
            official = {"confirmed": False, "details": {}}
        attempt_count = int(attempts or 0) + 1
        if official.get("confirmed"):
            comparison = _compare_robot_lineup_prediction(prediction, official)
            cursor = conn.execute(
                """
                UPDATE robot_learning_samples
                SET official_lineup_json=?,lineup_comparison_json=?,
                    lineup_known_at=?,lineup_known_timestamp=?,
                    lineup_retry_attempts=?,lineup_retry_at=0
                WHERE id=? AND lineup_known_timestamp IS NULL
                """,
                (
                    json.dumps(official, ensure_ascii=False, sort_keys=True),
                    json.dumps(comparison, ensure_ascii=False, sort_keys=True),
                    now.isoformat(), now.timestamp(), attempt_count, int(sample_id),
                ),
            )
            attached += int(cursor.rowcount or 0)
        else:
            # Retry forever with a restrained exponential backoff; this is an
            # API-safety schedule, never a learning eligibility threshold.
            retry_hours = min(24.0, 0.25 * (2 ** min(7, attempt_count - 1)))
            conn.execute(
                """
                UPDATE robot_learning_samples
                SET lineup_retry_attempts=?,lineup_retry_at=?
                WHERE id=? AND lineup_known_timestamp IS NULL
                """,
                (
                    attempt_count,
                    now.timestamp() + retry_hours * 3600.0,
                    int(sample_id),
                ),
            )
    if rows:
        conn.commit()
    return attached


def select_autonomous_robot_pick(
    picks, confidence, robot_features=None, source="PROTO",
    robot_artifact=None, serving_only=False,
):
    """Return one robot-owned forecast without changing the official pick."""
    available = valid_analysis_candidates(picks)
    if not available:
        return None
    if not isinstance(robot_artifact, dict):
        robot_artifact = _load_autonomous_robot_artifact(
            source, serving_only=serving_only
        )
    has_robot_probabilities = any(
        pick.get("robot_probability") is not None for pick in available
    )
    if isinstance(robot_features, dict) and not has_robot_probabilities:
        available = build_autonomous_robot_candidates(
            available, robot_features, robot_artifact
        )
    selected, reason = autonomous_robot_choice(
        available, confidence, return_reason=True
    )
    selected = dict(selected)
    selected.update({
        "category_key": "robot_independent",
        "category_label": "로봇 독립픽",
        "robot_pick_version": ROBOT_PICK_VERSION,
        "robot_learning_track": _robot_learning_track(source),
        "robot_decision_reason": reason,
        "official_final_pick": False,
        "pre_match_only": True,
        "history_rewrite": False,
        "self_modifying": False,
        "self_learning": bool(isinstance(robot_features, dict) or has_robot_probabilities),
        "robot_learning_active": bool(
            robot_artifact.get("active")
            or int(robot_artifact.get("grading_experience_samples") or 0) > 0
        ),
        "robot_learning_reason": str(robot_artifact.get("reason") or ""),
    })
    return selected


def robot_pick_report(robot_pick, home_team=""):
    if not isinstance(robot_pick, dict):
        return ""
    probability = float(robot_pick.get("prob") or 0)
    odd = float(robot_pick.get("odd") or 0)
    fair = robot_pick.get("fair_prob")
    edge_text = "시장 공정확률 미확인"
    if fair is not None:
        edge_text = (
            f"시장 공정확률 {float(fair) * 100:.1f}% · "
            f"보수적 가치차 {float(robot_pick.get('robust_edge') or 0) * 100:+.1f}%p"
        )
    value_text = f"실제 배당 {odd:.2f}배" if odd > 1 else "실제 배당 미수신"
    detailed_samples = int(robot_pick.get("robot_training_samples") or 0)
    grading_samples = int(robot_pick.get("robot_grading_experience_samples") or 0)
    learning_text = (
        f"온라인 자체학습 적용 · 상세 경기표본 {detailed_samples}경기 · "
        f"기존 채점사례 {grading_samples}개 반영"
        if detailed_samples or grading_samples
        else "아직 종료 채점이 없어 경기 전 전체 근거 기초모형 사용"
    )
    return (
        "[로봇 독립픽] "
        f"{_human_pick_label(robot_pick.get('raw_pick'), home_team)} · "
        f"로봇 자체확률 {probability * 100:.1f}% · {value_text} · {edge_text}. "
        "공식 확률을 재정렬한 값이 아니라 경기 전 원자료에서 로봇이 만든 득점·전 시장 확률로 비교한 답입니다. "
        f"{learning_text}. 목표는 새로 동결되는 실제 픽 누적 70%이며, 같은 버전의 "
        "채점과 시간순 미래검증으로 계산식·시장 선택을 갱신합니다. 첫 채점부터 "
        "학습하되 경기 시작 뒤 자료와 구버전 확률보정은 사용하지 않습니다."
    )


def lineup_prediction_report(
    home_team, away_team, home_prediction, away_prediction,
    home_official=None, away_official=None,
):
    home_official = list(home_official or [])
    away_official = list(away_official or [])
    confirmed = len(home_official) >= 11 and len(away_official) >= 11
    home_active = home_official if confirmed else list(home_prediction or [])
    away_active = away_official if confirmed else list(away_prediction or [])
    status = "공식 선발 발표 반영·재분석" if confirmed else "최근 공식 선발 빈도 기반 예상"
    return (
        f"[예상 선발] {status}. "
        f"{home_team}: {', '.join(map(str, home_active)) or '확보 자료 부족'}. "
        f"{away_team}: {', '.join(map(str, away_active)) or '확보 자료 부족'}. "
        "예상 명단은 확정 발표가 아니며, 공식 11명이 수신되면 예상 명단 대신 공식 명단으로 교체해 "
        "킥오프 전에만 다시 계산합니다."
    )


_PLACEHOLDER_TEAM_NAMES = {
    "", "-", "미정", "미확정", "tbd", "unknown", "홈팀", "원정팀",
    "home", "away", "team1", "team2",
}


def _is_placeholder_team_name(value):
    normalized = re.sub(r"[\s._-]+", "", str(value or "").strip().casefold())
    return normalized in {
        re.sub(r"[\s._-]+", "", name.casefold())
        for name in _PLACEHOLDER_TEAM_NAMES
    }


def _is_placeholder_match(match):
    if not isinstance(match, dict):
        return True
    home = str(match.get("home") or "").strip()
    away = str(match.get("away") or "").strip()
    if _is_placeholder_team_name(home) or _is_placeholder_team_name(away):
        return True
    return re.sub(r"\W+", "", home.casefold()) == re.sub(
        r"\W+", "", away.casefold()
    )


def _prefer_canonical_prediction_rows(rows):
    """Keep WORLD shadow rows stored, but count one official fixture only once."""
    rows = [dict(row) for row in (rows or [])]

    def fixture_id(row):
        try:
            return int(row.get("api_fixture_id") or 0)
        except (TypeError, ValueError):
            return 0

    canonical_fixture_ids = {
        fixture_id(row)
        for row in rows
        if fixture_id(row) > 0
        and int(row.get("is_toto14") or 0) == 0
        and not str(row.get("match_id") or "").startswith("WORLD_")
    }
    return [
        row for row in rows
        if not (
            str(row.get("match_id") or "").startswith("WORLD_")
            and fixture_id(row) in canonical_fixture_ids
        )
    ]


def _build_grading_snapshot():
    """Publish an auditable scorecard from all preserved frozen records.

    Database rows and frozen answers are never rewritten.  The score feed
    includes them from the beginning instead of hiding a prior version behind
    a 0-game reset.
    """
    conn = None
    try:
        conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=30)
        conn.row_factory = sqlite3.Row
        _ensure_prediction_analysis_tables(conn)
        columns = [row[1] for row in conn.execute("PRAGMA table_info(predictions)")]
        if "ev_pick" not in columns:
            return {
                "schema_version": "grading-results.v1",
                "public_history_mode": "all-frozen-prekickoff-records",
                "public_score_version": PUBLIC_SCORE_VERSION,
                "three_engine": _three_engine_grading_payload(conn),
                "finished": [], "pending": [], "generated_at": _utc_iso(),
            }
        all_rows = [
            dict(row) for row in conn.execute(
                "SELECT * FROM predictions WHERE actual_result IN ('FINISHED', 'PENDING')"
            ).fetchall()
        ]
        all_rows = _prefer_canonical_prediction_rows(all_rows)

        # Compatibility fallback for rows created before append-only analysis
        # snapshots existed. New rows always use the first timestamped public
        # snapshot selected below.
        fallback_robot_by_match = {}
        for analysis_row in conn.execute(
            "SELECT match_id, analysis_version, decision_json "
            "FROM prediction_analysis"
        ).fetchall():
            try:
                decision = json.loads(analysis_row["decision_json"] or "{}")
            except (TypeError, ValueError, json.JSONDecodeError):
                continue
            robot = decision.get("robot_pick") or {}
            if (
                not isinstance(robot, dict)
                or str(decision.get("robot_pick_version") or robot.get("robot_pick_version") or "")
                    != ROBOT_PICK_VERSION
                or not str(robot.get("raw_pick") or "").strip()
            ):
                continue
            fallback_robot_by_match[str(analysis_row["match_id"])] = {
                **robot,
                "analysis_version": str(analysis_row["analysis_version"] or ""),
            }

        public_rows = []
        for source in all_rows:
            match_id = str(source.get("match_id") or "")
            is_toto14 = int(source.get("is_toto14") or 0) == 1
            if is_toto14:
                # Toto14 is graded by the same result worker, but it does not
                # belong to the public robot-version reset used by PROTO/WORLD.
                # Publish only completed Toto14 rows so its independent
                # scorecard can count the preserved pre-kickoff ticket.
                if str(source.get("actual_result") or "") == "FINISHED":
                    row = dict(source)
                    row["source_type"] = "TOTO14"
                    public_rows.append(row)
                continue
            bundle = _first_public_pick_bundle(
                conn, match_id, source.get("home_team"), source.get("away_team"),
                source.get("match_time"),
            )
            robot = (
                (bundle or {}).get("robot_pick")
                or fallback_robot_by_match.get(match_id)
            )
            if not robot:
                continue
            row = dict(source)
            if bundle:
                selected = bundle["selected"]
                row.update({
                    "prob_pick": selected.get("raw_pick") or "",
                    "prob_pick_prob": float(selected.get("prob") or 0) * 100.0,
                    "ev_pick": bundle.get("ev_pick") or "",
                    "ev_pick_prob": float(bundle.get("ev_probability") or 0) * 100.0,
                    "public_pick_frozen": True,
                    "public_pick_frozen_at": bundle.get("frozen_at") or "",
                    "public_pick_snapshot_id": bundle.get("snapshot_id"),
                })
            row.update({
                "source_type": "WORLD" if match_id.startswith("WORLD_") else "PROTO",
                "analysis_version": (
                    (bundle or {}).get("analysis_version")
                    or robot.get("analysis_version")
                    or row.get("analysis_version")
                    or ""
                ),
                "robot_pick": robot.get("raw_pick") or "",
                "robot_pick_market": robot.get("market_key") or "",
                "robot_pick_prob": float(
                    robot.get("probability", robot.get("prob", 0)) or 0
                ) * 100.0,
                "robot_pick_odd": float(robot.get("odd") or 0),
                "robot_pick_version": ROBOT_PICK_VERSION,
                "robot_pick_reason": robot.get("selection_reason") or "",
            })
            score_match = re.match(
                r"^\s*(\d+)\s*:\s*(\d+)\s*$", str(row.get("actual_score") or "")
            )
            if row.get("actual_result") == "FINISHED" and score_match:
                goals_h, goals_a = int(score_match.group(1)), int(score_match.group(2))
                row["is_correct_robot"] = int(evaluate_single_pick(
                    row["robot_pick"], row.get("home_team"), row.get("away_team"),
                    goals_h, goals_a,
                ))
                row["robot_actual_score"] = str(row.get("actual_score") or "")
                if bundle:
                    row["is_correct_prob"] = int(evaluate_single_pick(
                        row["prob_pick"], row.get("home_team"), row.get("away_team"),
                        goals_h, goals_a,
                    ))
                    row["is_correct_ev"] = int(evaluate_single_pick(
                        row.get("ev_pick") or "", row.get("home_team"),
                        row.get("away_team"), goals_h, goals_a,
                    ))
            public_rows.append(row)

        finished = [
            row for row in public_rows
            if row.get("actual_result") == "FINISHED"
            and (
                int(row.get("is_toto14") or 0) == 1
                or row.get("is_correct_robot") in (0, 1)
            )
            and str(row.get("prob_pick") or "").strip()
        ]
        pending = [
            row for row in public_rows
            if row.get("actual_result") == "PENDING"
        ]
        queue_exists = conn.execute("SELECT 1 FROM sqlite_master WHERE name='scoring_queue'").fetchone()
        reasons = {r[0]:r[1] for r in conn.execute("SELECT match_id,reason FROM scoring_queue")} if queue_exists else {}
        for row in pending:
            row["grading_wait_reason"] = reasons.get(str(row.get("match_id")),"경기 종료/결과 확인 대기")

        def sort_timestamp(row):
            parsed = _parse_kst_match_time(row.get("match_time"))
            return parsed.timestamp() if parsed else 0

        finished.sort(key=sort_timestamp, reverse=True)
        pending.sort(key=sort_timestamp, reverse=True)
        three_engine = _three_engine_grading_payload(conn)
        return {
            "schema_version": "grading-results.v1",
            "analysis_version": ANALYSIS_VERSION,
            "system_version": SYSTEM_VERSION,
            "public_history_mode": "all-frozen-prekickoff-records",
            "public_score_version": PUBLIC_SCORE_VERSION,
            "public_score_label": "전체 동결픽 누적 공개 성적",
            "legacy_rows_hidden": 0,
            "three_engine": three_engine,
            "finished": finished,
            "pending": pending,
            "generated_at": _utc_iso(),
        }
    except Exception as error:
        print(f"⚠️ 채점 스냅샷 생성 실패: {error}")
        return {"finished": [], "pending": [], "generated_at": _utc_iso(), "error": "grading_snapshot_failed"}
    finally:
        if conn is not None:
            conn.close()


def _latest_local_grading_snapshot(embedded=None):
    """Return the already-published score feed without touching SQLite.

    The Streamlit app prefers ``grading_results.json`` over the dashboard
    embedded copy.  Analysis workers therefore reuse that independent feed
    instead of rebuilding grading from the production DB.
    """
    embedded = embedded if isinstance(embedded, dict) else {}
    snapshot = _read_json("grading_results.json", {})
    if (
        isinstance(snapshot, dict)
        and snapshot.get("schema_version") == "grading-results.v1"
        and not snapshot.get("error")
        and isinstance(snapshot.get("finished"), list)
        and isinstance(snapshot.get("pending"), list)
    ):
        return snapshot
    return embedded


def _refresh_dashboard_grading_snapshot(snapshot=None):
    """Attach an already-built grading feed without a second DB scan.

    ``run_score_job`` has just built and published the authoritative grading
    snapshot.  Reusing that object avoids the former duplicate
    ``_build_grading_snapshot()`` pass that could keep the score worker alive
    for minutes after ``grading_results.json`` was already online.
    """
    dashboard = _read_json("dashboard_data.json", {})
    if not isinstance(dashboard, dict) or not dashboard:
        print("⚠️ 채점 화면 갱신 보류: 기존 대시보드 데이터가 없습니다.")
        return False
    if not isinstance(snapshot, dict):
        snapshot = _latest_local_grading_snapshot(dashboard.get("grading") or {})
    if not isinstance(snapshot, dict) or snapshot.get("error"):
        return False
    dashboard["grading"] = snapshot
    source_meta = dashboard.get("source_meta")
    if not isinstance(source_meta, dict):
        source_meta = {}
        dashboard["source_meta"] = source_meta
    source_meta["grading_generated_at"] = str(snapshot.get("generated_at") or _utc_iso())
    _atomic_write_json("dashboard_data.json", dashboard)
    return True


def _valid_three_way_odds(values):
    try:
        return len(values) == 3 and all(float(value or 0) > 1.0 for value in values)
    except (TypeError, ValueError):
        return False


def _world_fixture_datetime(fixture_data):
    fixture = (fixture_data or {}).get("fixture", {}) or {}
    try:
        timestamp = int(fixture.get("timestamp") or 0)
    except (TypeError, ValueError):
        timestamp = 0
    if timestamp > 0:
        try:
            return datetime.fromtimestamp(timestamp, tz=timezone.utc).astimezone(KST)
        except (OSError, OverflowError, ValueError):
            pass
    raw_date = str(fixture.get("date") or "").strip()
    if raw_date:
        try:
            parsed = datetime.fromisoformat(raw_date.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
            return parsed.astimezone(KST)
        except ValueError:
            pass
    return None


def _world_fixture_candidate(fixture_data, now=None):
    """Turn one provider fixture into a verified WORLD shadow-schedule row."""
    now = (now or datetime.now(KST)).astimezone(KST)
    fixture_data = fixture_data if isinstance(fixture_data, dict) else {}
    fixture = fixture_data.get("fixture", {}) or {}
    league = fixture_data.get("league", {}) or {}
    teams = fixture_data.get("teams", {}) or {}
    home = teams.get("home", {}) or {}
    away = teams.get("away", {}) or {}
    status = fixture.get("status", {}) or {}

    try:
        league_id = int(league.get("id") or 0)
    except (TypeError, ValueError):
        league_id = 0
    if league_id <= 0:
        return None, "INVALID_LEAGUE_ID"

    try:
        fixture_id = int(fixture.get("id") or 0)
    except (TypeError, ValueError):
        fixture_id = 0
    if fixture_id <= 0:
        return None, "INVALID_FIXTURE_ID"

    try:
        home_id = int(home.get("id") or 0)
        away_id = int(away.get("id") or 0)
    except (TypeError, ValueError):
        home_id, away_id = 0, 0
    if home_id <= 0 or away_id <= 0:
        return None, "INVALID_TEAM_ID"
    if home_id == away_id:
        return None, "DUPLICATE_TEAM_ID"

    home_name = str(home.get("name") or "").strip()
    away_name = str(away.get("name") or "").strip()
    tbd_names = {"", "tbd", "to be defined", "winner", "unknown"}
    if home_name.casefold() in tbd_names or away_name.casefold() in tbd_names:
        return None, "TEAM_TBD"

    kickoff = _world_fixture_datetime(fixture_data)
    if kickoff is None:
        return None, "KICKOFF_TBD"

    status_short = str(status.get("short") or "NS").upper().strip()
    if status_short == "TBD":
        return None, "KICKOFF_TBD"
    if status_short in CANCELED_STATUSES | POSTPONED_STATUSES | {"SUSP", "INT"}:
        return None, "CANCELED_OR_POSTPONED"
    if status_short in LIVE_STATUSES | TERMINAL_STATUSES or kickoff <= now:
        return None, "ALREADY_STARTED"
    if status_short != "NS":
        return None, "UNSUPPORTED_STATUS"

    weekday = "월화수목금토일"[kickoff.weekday()]
    match_time = kickoff.strftime(f"%y.%m.%d ({weekday}) %H:%M")
    league_config = WORLD_LEAGUES.get(league_id, {})
    league_display_name = str(
        league_config.get("name") or league.get("name") or "세계 축구"
    )
    fixture_meta = fixture_data.get("fixture", {}) or {}
    venue = fixture_meta.get("venue", {}) or {}
    match = {
        "id": f"WORLD_{fixture_id}",
        "fixture_id": fixture_id,
        "league_id": league_id,
        "season": league.get("season"),
        "league": str(league.get("name") or league_display_name),
        "league_name_ko": league_display_name,
        "country": str(league.get("country") or ""),
        "round": str(league.get("round") or ""),
        "home": home_name,
        "away": away_name,
        "home_name_ko": _world_team_display_name(home_name, home_id),
        "away_name_ko": _world_team_display_name(away_name, away_id),
        "home_team_id": home_id,
        "away_team_id": away_id,
        "home_logo": str(home.get("logo") or ""),
        "away_logo": str(away.get("logo") or ""),
        "city": str(venue.get("city") or ""),
        "referee": str(fixture_meta.get("referee") or ""),
        "match_time": match_time,
        "kickoff_at": kickoff.isoformat(),
        "status": status_short,
    }
    return {
        "source_type": "WORLD",
        "visibility_status": "SHADOW",
        "analysis_status": "PENDING_SHADOW_ANALYSIS",
        "pick_status": "NOT_ANALYZED",
        "identity_verified": True,
        "match": match,
        "api_fixture_id": fixture_id,
        "final_match_time": match_time,
        "timestamp": kickoff.timestamp(),
    }, None


def _has_valid_world_market(snapshot):
    snapshot = snapshot if isinstance(snapshot, dict) else {}
    return bool(
        int(snapshot.get("bookmaker_count") or 0) > 0
        and any(snapshot.get(key) for key in ("1x2", "totals", "handicap"))
    )


def _fair_market_probabilities(market, sides):
    """Remove the bookmaker margin inside one market; never compare raw 2/3-way odds."""
    inverse = []
    for side in sides:
        try:
            odd = float((market or {}).get(side) or 0)
        except (TypeError, ValueError):
            return None
        if odd <= 1.0 or not math.isfinite(odd):
            return None
        inverse.append(1.0 / odd)
    total = sum(inverse)
    if total <= 0:
        return None
    return {side: inverse[index] / total for index, side in enumerate(sides)}


def _world_market_preview_analysis(item, now=None):
    """Give every verified bettable WORLD fixture a transparent pre-analysis pick.

    This is not presented as a Dixon-Coles forecast.  It uses only the already
    collected full-time market median and removes the margin within each
    market. A later full-context run replaces this preview before kickoff.
    """
    item = item if isinstance(item, dict) else {}
    match = item.get("match") or {}
    market_snapshot = item.get("market_snapshot") or {}
    if not _has_valid_world_market(market_snapshot):
        return None
    home = str(match.get("home") or "홈팀")
    away = str(match.get("away") or "원정팀")
    bookmaker_count = int(market_snapshot.get("bookmaker_count") or 0)
    candidate_rows = []
    candidates_by_market = {}

    market_specs = [
        ("1x2", ("home", "draw", "away"), 3, "일반 승무패 시장 선픽"),
        ("handicap", ("home", "draw", "away"), 2, "3방향 핸디캡 시장 선픽"),
        ("totals", ("under", "over"), 1, "언더오버 시장 선픽"),
    ]
    for market_key, sides, sort_id, label in market_specs:
        market = market_snapshot.get(market_key) or {}
        fair = _fair_market_probabilities(market, sides)
        if not fair:
            continue
        line = float(market.get("line") or 0)
        rows = []
        for side in sides:
            if market_key == "1x2":
                raw_pick = home + " 승" if side == "home" else ("무승부" if side == "draw" else away + " 승")
            elif market_key == "handicap":
                raw_pick = (
                    f"[{line:+.1f}] {home} 핸디승" if side == "home"
                    else (f"[{line:+.1f}] 핸디무" if side == "draw" else f"[{line:+.1f}] {home} 핸디패")
                )
            else:
                raw_pick = f"{'언더' if side == 'under' else '오버'} (U/O {line:g})"
            probability = float(fair[side])
            odd = float(market.get(side) or 0)
            row = {
                "market_key": market_key,
                "label": label,
                "raw_pick": raw_pick,
                "selection_side": side,
                "handicap_base": line if market_key == "handicap" else None,
                "sort_id": sort_id,
                "model_probability": probability,
                "raw_model_probability": probability,
                "fair_probability": probability,
                "prob": probability,
                "probability": probability,
                "fair_prob": probability,
                "odd": odd,
                "edge": 0.0,
                "robust_probability": probability,
                "robust_edge": 0.0,
                "robust_ev": probability * odd,
                "balanced_score": probability,
                "safe_score": probability,
                "recommendation_score": probability,
                "market_hit_rate": 0.5,
                "market_history_samples": 0,
                "market_history_scope": "market_preview",
                "learning_weight": 0.0,
                "data_confidence": min(0.58, 0.38 + bookmaker_count * 0.03),
                "error_margin": 0.12,
                "probability_interval": {
                    "low": max(0.0, probability - 0.12),
                    "high": min(1.0, probability + 0.12),
                },
                "selection_warning": "정밀 팀 분석 대기 · 해외시장 기준 선픽",
            }
            rows.append(row)
            candidate_rows.append(row)
        candidates_by_market[market_key] = rows

    if not candidate_rows:
        return None
    preview_confidence = min(0.58, 0.38 + bookmaker_count * 0.03)
    selected = all_evidence_choice(candidate_rows, preview_confidence)
    selected_market = infer_pick_market(selected)
    selected["display"] = _human_pick_label(selected["raw_pick"], home)
    selected["badges"] = []
    preview_confidence = float(selected["data_confidence"])
    robot_pick = select_autonomous_robot_pick(
        candidate_rows, preview_confidence, source="WORLD"
    )
    alphago_pick = _alphago_pick_payload(robot_pick)
    audited_candidates, compact_categories, decision = build_pick_selection_audit(
        candidate_rows,
        {
            "high_probability": selected,
            "honey": None,
            "vip_underdog": None,
        },
        preview_confidence,
        robot_pick=robot_pick,
    )
    compact_selected = dict(compact_categories.get("high_probability") or {})
    compact_selected.update(
        display=selected["display"],
        badges=[],
        probability_interval=dict(selected.get("probability_interval") or {}),
        data_confidence=preview_confidence,
    )
    decision.update({
        "decision_axis": "evidence_ensemble_accuracy_first",
        "selected_market": selected_market,
        "data_confidence": preview_confidence,
        "market_preview": True,
    })
    analyzed_at = (now or datetime.now(KST)).astimezone(KST).isoformat()
    quality_score = min(58, 38 + bookmaker_count * 3)
    market_name = {"1x2": "승무패", "handicap": "3방향 핸디캡", "totals": "언더오버"}[selected_market]
    report = (
        "[시장 기준 선픽] 정밀 팀 전력 분석이 끝나기 전에도 빈 픽을 두지 않기 위해, "
        f"현재 확보된 {bookmaker_count}개 해외업체의 정규시간 {market_name} 중앙배당에서 "
        "마진을 제거한 공정확률로 한 방향을 먼저 제시합니다.\n\n"
        f"[현재 선픽] {selected['display']} · 시장 공정확률 {selected['probability'] * 100:.1f}% · "
        f"중앙배당 {selected['odd']:.2f}배.\n\n"
        "[주의] 이 값은 딕슨-콜스·최근성적·결장·선발을 모두 반영한 정밀 모델 확률이 아닙니다. "
        "정밀분석이 완료되면 같은 경기의 최종픽과 확률로 교체됩니다. "
        "시장 선픽도 2지선다·3지선다 차이를 보정한 확신도 척도로 한 픽만 선택합니다."
    )
    robot_report = robot_pick_report(robot_pick, home)
    if robot_report:
        report += "\n\n" + robot_report
    return {
        "analysis_version": WORLD_MARKET_PREVIEW_VERSION,
        "system_version": SYSTEM_VERSION,
        "analysis_stage": "market-preview",
        "analyzed_at": analyzed_at,
        "frozen_at": None,
        "data_quality_score": quality_score,
        "data_quality_grade": "보조 분석",
        "missing_data": ["정밀 팀 전력 분석 대기", "확정 선발"],
        "lineup_confirmed": False,
        "odds_snapshot": dict(market_snapshot),
        "inputs_snapshot": {},
        "evidence": [{
            "title": "해외시장 선픽",
            "value": f"{bookmaker_count}개 업체 중앙배당 · {market_name} 마진 제거",
        }],
        "candidates": audited_candidates,
        "categories": compact_categories,
        "selected": compact_selected,
        "robot_pick": dict(compact_categories.get("robot_independent") or {}),
        "alphago_pick": alphago_pick,
        "alternative": {},
        "learning_robot": {"applied": False, "reason": "정밀분석 대기"},
        "decision": decision,
        "report": report,
    }


def _ensure_world_market_previews(payload, now=None):
    """R7.12.27: never turn odds-only market data into a customer pick.

    Older saved files can still contain `market-preview` analyses.  Strip only
    those provisional picks while preserving the market snapshot on the match,
    then let the normal deep-analysis queue produce the first publishable pick.
    """
    current = (now or datetime.now(KST)).astimezone(KST)
    changed = []
    for item in (payload or {}).get("matches", []) if isinstance(payload, dict) else []:
        if not isinstance(item, dict):
            continue
        analysis = item.get("analysis") if isinstance(item.get("analysis"), dict) else {}
        stage = str(
            analysis.get("analysis_stage") or item.get("analysis_stage") or ""
        ).strip().casefold()
        if stage != "market-preview":
            continue
        match = item.get("match") or {}
        kickoff = _parse_kst_match_time(
            match.get("match_time") or item.get("final_match_time")
        )
        # Preserve the already collected bookmaker snapshot, but remove the
        # provisional official/robot/AI conclusion.  No retrospective pick.
        if isinstance(analysis.get("odds_snapshot"), dict) and not item.get("market_snapshot"):
            item["market_snapshot"] = dict(analysis.get("odds_snapshot") or {})
        item.pop("analysis", None)
        item["analysis_version"] = ""
        item["system_version"] = SYSTEM_VERSION
        item["analysis_stage"] = ""
        item["analyzed_at"] = None
        item["frozen_at"] = None
        item["data_quality_score"] = 0
        item["data_quality_grade"] = "자료 수집 중"
        item["missing_data"] = ["정밀 팀 분석 대기"]
        item["lineup_confirmed"] = False
        if kickoff and current < kickoff:
            item["analysis_status"] = "PENDING_SHADOW_ANALYSIS"
            item["pick_status"] = "ANALYSIS_PENDING"
        else:
            item["analysis_status"] = "MISSED_PREKICKOFF"
            item["pick_status"] = "NOT_ANALYZED"
        changed.append(item)

    # R7.12.26 이전의 시장 선픽 누적 때문에 WORLD 파일이 설정 상한보다
    # 커졌던 경우, 실제 정밀분석/동결본은 모두 보존하고 미분석 예정경기만
    # 킥오프가 가까운 순서로 현재 일정 상한까지 정리한다.
    matches = (payload or {}).get("matches", []) if isinstance(payload, dict) else []
    if isinstance(matches, list) and len(matches) > WORLD_MAX_SCHEDULE_MATCHES:
        protected = []
        pending = []
        for item in matches:
            analysis = item.get("analysis") if isinstance(item, dict) and isinstance(item.get("analysis"), dict) else {}
            stage = str(analysis.get("analysis_stage") or (item or {}).get("analysis_stage") or "").strip().casefold()
            if analysis and stage != "market-preview":
                protected.append(item)
                continue
            match = (item or {}).get("match") or {}
            kickoff = _parse_kst_match_time(match.get("match_time") or match.get("kickoff_at"))
            if kickoff and kickoff > current:
                pending.append((kickoff, item))
        pending.sort(key=lambda row: row[0])
        pending_limit = max(0, WORLD_MAX_SCHEDULE_MATCHES - len(protected))
        keep_ids = {id(item) for item in protected}
        keep_ids.update(id(item) for _, item in pending[:pending_limit])
        removed = [item for item in matches if id(item) not in keep_ids]
        if removed:
            payload["matches"] = [item for item in matches if id(item) in keep_ids]
            changed.extend(removed)
    return changed


def build_world_schedule_payload(
    fixtures_by_date, now=None, market_snapshots_by_fixture=None
):
    """Build the isolated schedule; production targets only bettable fixtures."""
    now = (now or datetime.now(KST)).astimezone(KST)
    market_filter_enabled = market_snapshots_by_fixture is not None
    market_snapshots_by_fixture = market_snapshots_by_fixture or {}
    matches = []
    seen_fixture_ids = set()
    rejected_counts = {key: 0 for key in WORLD_REJECTION_LABELS}
    rejected_samples = []
    raw_count = 0

    for date_key, fixtures in (fixtures_by_date or {}).items():
        for fixture_data in fixtures or []:
            raw_count += 1
            item, reason = _world_fixture_candidate(fixture_data, now=now)
            if item is not None:
                fixture_id = int(item.get("api_fixture_id") or 0)
                market_snapshot = (
                    market_snapshots_by_fixture.get(fixture_id)
                    or market_snapshots_by_fixture.get(str(fixture_id))
                )
                if market_filter_enabled and not _has_valid_world_market(market_snapshot):
                    reason = "NO_VALID_MARKET"
                    item = None
                elif fixture_id in seen_fixture_ids:
                    reason = "DUPLICATE_FIXTURE"
                    item = None
                else:
                    seen_fixture_ids.add(fixture_id)
                    if _has_valid_world_market(market_snapshot):
                        item["market_snapshot"] = dict(market_snapshot)
            if item is not None:
                matches.append(item)
                continue

            reason = reason or "INVALID_FIXTURE_ID"
            rejected_counts[reason] = int(rejected_counts.get(reason, 0)) + 1
            if len(rejected_samples) < 30:
                fixture_data = fixture_data if isinstance(fixture_data, dict) else {}
                rejected_samples.append({
                    "date": str(date_key),
                    "fixture_id": (fixture_data.get("fixture", {}) or {}).get("id"),
                    "league": (fixture_data.get("league", {}) or {}).get("name"),
                    "home": ((fixture_data.get("teams", {}) or {}).get("home", {}) or {}).get("name"),
                    "away": ((fixture_data.get("teams", {}) or {}).get("away", {}) or {}).get("name"),
                    "reason_code": reason,
                    "reason": WORLD_REJECTION_LABELS.get(reason, reason),
                })

    matches.sort(key=lambda item: (float(item.get("timestamp") or 0), int(item.get("api_fixture_id") or 0)))
    if len(matches) > WORLD_MAX_SCHEDULE_MATCHES:
        overflow = len(matches) - WORLD_MAX_SCHEDULE_MATCHES
        rejected_counts["SCHEDULE_CAP"] += overflow
        matches = matches[:WORLD_MAX_SCHEDULE_MATCHES]

    league_counts = {}
    for item in matches:
        league_name = item.get("match", {}).get("league_name_ko") or item.get("match", {}).get("league")
        league_counts[str(league_name)] = int(league_counts.get(str(league_name), 0)) + 1

    rejected_counts = {
        key: value for key, value in rejected_counts.items() if int(value or 0) > 0
    }
    payload = {
        "schema_version": "world-schedule.v1",
        "source_type": "WORLD",
        "stage": "COLLECTION_ONLY",
        "default_visibility_status": "SHADOW",
        "generated_at": now.isoformat(),
        "scheduled_dates": list((fixtures_by_date or {}).keys()),
        "matches": matches,
        "rejected_summary": [
            {
                "reason_code": key,
                "reason": WORLD_REJECTION_LABELS.get(key, key),
                "count": int(value),
            }
            for key, value in sorted(rejected_counts.items())
        ],
        "rejected_samples": rejected_samples,
        "source_meta": {
            "raw_fixture_count": raw_count,
            "eligible_shadow_count": len(matches),
            "rejected_count": sum(rejected_counts.values()),
            "league_counts": league_counts,
            "selection_rule": "valid_fulltime_bookmaker_market",
            "market_filter_enabled": market_filter_enabled,
            "bettable_fixture_count": len(matches),
            "preferred_league_ids": sorted(WORLD_LEAGUES),
            "schedule_days": WORLD_SCHEDULE_DAYS,
            "analysis_started": False,
            "public_count": 0,
            "api_usage": get_api_usage_status(),
        },
    }
    return _refresh_world_source_meta(payload)


def collect_world_schedule():
    """Refresh the future fixture list even when the heavy odds pass is paused."""
    now = datetime.now(KST)
    previous_payload = _read_json(WORLD_DASHBOARD_FILE, {})
    fixtures_by_date = {}
    market_snapshots_by_fixture = {}
    market_failed_dates = []
    for day_offset in range(WORLD_SCHEDULE_DAYS):
        date_key = (now + timedelta(days=day_offset)).strftime("%Y-%m-%d")
        # The broad fixture list takes a handful of calls and must not be
        # blocked by the separate WORLD deep-analysis budget.  It still obeys
        # the global daily reserve through the normal analysis purpose.
        fixtures = _fetch_date_fixtures_api(date_key, ttl_h=2, purpose="analysis")
        if fixtures is None:
            print(f"❌ 세계경기 일정 수집 실패({date_key}) - 마지막 정상본을 유지합니다.")
            return False
        fixtures_by_date[date_key] = fixtures
        date_markets = _fetch_world_market_snapshots_by_date(date_key)
        if date_markets is None:
            market_failed_dates.append(date_key)
            print(f"⚠️ 세계경기 배당 목록 재시도 대기({date_key})")
            continue
        market_snapshots_by_fixture.update(date_markets)

    payload = build_world_schedule_payload(
        fixtures_by_date,
        now=now,
        # Do not let an odds/API quota pause freeze yesterday's schedule.
        # A fresh no-market schedule is explicitly marked as pending; it never
        # produces a customer pick until the normal full-time market check and
        # pre-kickoff analysis both succeed.
        market_snapshots_by_fixture=(market_snapshots_by_fixture or None),
    )
    _carry_world_shadow_analyses(payload, previous_payload)
    proto_overlaps = _exclude_proto_overlaps(payload)
    preview_items = _ensure_world_market_previews(payload, now=now)
    if preview_items or proto_overlaps:
        _refresh_world_source_meta(payload)
    payload.setdefault("source_meta", {})["market_collection_degraded_dates"] = (
        market_failed_dates
    )
    payload.setdefault("source_meta", {})["market_collection_pending"] = bool(
        not market_snapshots_by_fixture
    )
    _atomic_write_json(WORLD_DASHBOARD_FILE, payload, indent=2)
    source_meta = payload.get("source_meta", {})
    print(
        "🌍 세계경기 1단계 수집 완료: "
        f"수집 목록 {source_meta.get('raw_fixture_count', 0)} / "
        f"배당 확인 {source_meta.get('eligible_shadow_count', 0)} / "
        f"분석 대기 정리 {len(preview_items)} / 제외 {source_meta.get('rejected_count', 0)}"
        f" / 프로토 중복 제외 {proto_overlaps}"
    )
    return True


WORLD_ANALYSIS_FIELDS = (
    "analysis_status", "pick_status", "analysis_version", "system_version", "analysis_stage",
    "analyzed_at", "frozen_at", "data_quality_score", "data_quality_grade",
    "missing_data", "lineup_confirmed", "lineup_attempts", "analysis",
    "preview_learning_saved",
)


def _carry_world_shadow_analyses(payload, previous_payload):
    """Keep pre-kickoff analyses across the six-hour schedule refresh."""
    if not isinstance(payload, dict) or not isinstance(previous_payload, dict):
        return payload
    previous_by_fixture = {
        int(item.get("api_fixture_id") or 0): item
        for item in previous_payload.get("matches", []) or []
        if isinstance(item, dict) and int(item.get("api_fixture_id") or 0) > 0
    }
    for item in payload.get("matches", []) or []:
        previous = previous_by_fixture.get(int(item.get("api_fixture_id") or 0))
        if not previous:
            continue
        old_kickoff = str((previous.get("match") or {}).get("kickoff_at") or "")
        new_kickoff = str((item.get("match") or {}).get("kickoff_at") or "")
        if old_kickoff and new_kickoff and old_kickoff != new_kickoff:
            item["analysis_status"] = "PENDING_SHADOW_ANALYSIS"
            item["schedule_changed_after_analysis"] = True
            continue
        previous_analysis = previous.get("analysis") if isinstance(previous.get("analysis"), dict) else {}
        previous_stage = str(
            previous_analysis.get("analysis_stage") or previous.get("analysis_stage") or ""
        ).strip().casefold()
        # Odds-only previews are not analysis and must not survive a schedule refresh.
        if previous_stage == "market-preview":
            continue
        for field in WORLD_ANALYSIS_FIELDS:
            if field in previous:
                item[field] = previous[field]
    # A schedule refresh drops kicked-off fixtures; retain their frozen cards
    # until an authoritative terminal state reaches LIVE/grading.
    present = {int(item.get("api_fixture_id") or 0) for item in payload.get("matches",[])}
    live = _read_json("live_scores.json",{}) or {}
    now = datetime.now(KST)
    for fixture_id, item in previous_by_fixture.items():
        kickoff = _parse_kst_match_time(item.get("final_match_time") or (item.get("match") or {}).get("match_time"))
        analysis = item.get("analysis") if isinstance(item.get("analysis"), dict) else {}
        analysis_stage = str(analysis.get("analysis_stage") or item.get("analysis_stage") or "").strip().casefold()
        if fixture_id in present or not analysis or analysis_stage == "market-preview" or not kickoff:
            continue
        states = [row for row in live.values() if isinstance(row,dict) and int(row.get("fixture_id") or 0)==fixture_id]
        if any(row.get("final") or str(row.get("status")) in TERMINAL_STATUSES|CANCELED_STATUSES for row in states):
            continue
        if kickoff <= now <= kickoff+timedelta(hours=24):
            payload.setdefault("matches",[]).append(dict(item))
    _refresh_world_source_meta(payload)
    return payload


def _world_median(values):
    ordered = []
    for value in values or []:
        try:
            number = float(value)
        except (TypeError, ValueError):
            continue
        if number > 1.0 and math.isfinite(number):
            ordered.append(number)
    ordered.sort()
    if not ordered:
        return 0.0
    middle = len(ordered) // 2
    if len(ordered) % 2:
        return round(ordered[middle], 3)
    return round((ordered[middle - 1] + ordered[middle]) / 2.0, 3)


def _world_market_snapshot_from_response(odds_rows, fixture_id=0, fetched_at=None):
    """Extract comparable median 1X2, totals and three-way handicap prices."""
    wdl_samples = {"home": [], "draw": [], "away": []}
    totals_by_line = {}
    handicap_by_line = {}
    bookmaker_ids = set()

    def number_from(value):
        matched = re.search(r"([+-]?\d+(?:\.\d+)?)", str(value or ""))
        try:
            return float(matched.group(1)) if matched else None
        except (TypeError, ValueError):
            return None

    def is_fulltime_market(bet_name, base_names):
        """Reject half/team/corner props that reuse over-under or handicap words."""
        name = str(bet_name or "").strip().casefold()
        non_fulltime_markers = (
            "first half", "1st half", "first-half", "1st-half",
            "second half", "2nd half", "second-half", "2nd-half",
            "half time", "halftime", "half-time",
            "home team", "away team", "team total",
            "corner", "booking", "card", "throw-in", "offside",
        )
        if any(marker in name for marker in non_fulltime_markers):
            return False
        return any(
            name == base
            or name.startswith(f"{base} ")
            or name.startswith(f"{base} -")
            for base in base_names
        )

    for odds_row in odds_rows or []:
        for bookmaker in (odds_row or {}).get("bookmakers", []) or []:
            bookmaker_ids.add(str(bookmaker.get("id") or bookmaker.get("name") or len(bookmaker_ids)))
            for bet in bookmaker.get("bets", []) or []:
                bet_name = str(bet.get("name") or "").strip().casefold()
                values = bet.get("values", []) or []
                if bet_name in {"match winner", "1x2", "fulltime result", "full time result"}:
                    found = {}
                    for value in values:
                        label = str(value.get("value") or "").strip().casefold()
                        side = {
                            "home": "home", "1": "home", "draw": "draw", "x": "draw",
                            "away": "away", "2": "away",
                        }.get(label)
                        try:
                            odd = float(value.get("odd") or 0)
                        except (TypeError, ValueError):
                            odd = 0.0
                        if side and odd > 1.0:
                            found[side] = odd
                    if len(found) == 3:
                        for side, odd in found.items():
                            wdl_samples[side].append(odd)
                    continue

                if is_fulltime_market(
                    bet_name,
                    ("goals over/under", "goals over under", "total goals"),
                ):
                    found_by_line = {}
                    for value in values:
                        label = str(value.get("value") or "").strip().casefold()
                        side = "under" if "under" in label else ("over" if "over" in label else "")
                        line = number_from(label)
                        try:
                            odd = float(value.get("odd") or 0)
                        except (TypeError, ValueError):
                            odd = 0.0
                        if side and line is not None and odd > 1.0:
                            found_by_line.setdefault(round(line, 2), {})[side] = odd
                    for line, found in found_by_line.items():
                        if {"under", "over"}.issubset(found):
                            target = totals_by_line.setdefault(line, {"under": [], "over": []})
                            target["under"].append(found["under"])
                            target["over"].append(found["over"])
                    continue

                if not is_fulltime_market(
                    bet_name,
                    ("handicap result", "3 way handicap", "european handicap"),
                ):
                    continue
                # ``3 Way Handicap``의 3은 시장 종류(3방향)이지 실제 기준선이 아니다.
                # 시장명에서 이 고정 문구를 먼저 지워 +3.0 가짜 선으로 해석하지 않는다.
                handicap_name_without_market_count = re.sub(
                    r"\b3\s*way\b", "", bet_name, flags=re.IGNORECASE
                )
                bet_line = number_from(handicap_name_without_market_count)
                label_lines = {
                    round(float(label_line), 2)
                    for value in values
                    for label_line in [number_from(value.get("value"))]
                    if label_line is not None
                }
                shared_line = bet_line
                if shared_line is None and len(label_lines) == 1:
                    shared_line = next(iter(label_lines))
                found_by_line = {}
                for value in values:
                    label = str(value.get("value") or "").strip().casefold()
                    side = (
                        "home" if label.startswith("home") or label == "1"
                        else ("draw" if label.startswith("draw") or label == "x"
                              else ("away" if label.startswith("away") or label == "2" else ""))
                    )
                    label_line = number_from(label)
                    line = label_line if label_line is not None else shared_line
                    try:
                        odd = float(value.get("odd") or 0)
                    except (TypeError, ValueError):
                        odd = 0.0
                    if side and line is not None and odd > 1.0:
                        found_by_line.setdefault(round(float(line), 2), {})[side] = odd
                for line, found in found_by_line.items():
                    if not {"home", "draw", "away"}.issubset(found):
                        continue
                    target = handicap_by_line.setdefault(
                        line, {"home": [], "draw": [], "away": []}
                    )
                    for side in target:
                        target[side].append(found[side])

    result = {
        "fixture_id": int(fixture_id or 0),
        "fetched_at": fetched_at or datetime.now(KST).isoformat(),
        "bookmaker_count": len(bookmaker_ids),
        "bookmaker_ids": sorted(bookmaker_ids),
        "odds_source": "api_football_bookmaker_median",
        "1x2": None,
        "totals": None,
        "handicap": None,
    }
    if all(wdl_samples[side] for side in wdl_samples):
        result["1x2"] = {
            side: _world_median(wdl_samples[side]) for side in ("home", "draw", "away")
        }
        result["1x2"]["sample_count"] = min(
            len(wdl_samples[side]) for side in ("home", "draw", "away")
        )
    complete_totals = [
        (line, values) for line, values in totals_by_line.items()
        if values["under"] and values["over"]
    ]
    if complete_totals:
        def totals_mainline_key(row):
            line, values = row
            under = _world_median(values["under"])
            over = _world_median(values["over"])
            inverse_total = (1.0 / under) + (1.0 / over)
            balance = abs((1.0 / under) / inverse_total - (1.0 / over) / inverse_total)
            coverage = min(len(values["under"]), len(values["over"]))
            return (round(balance, 6), abs(float(line) - 2.5), -coverage)

        line, values = min(
            complete_totals,
            key=totals_mainline_key,
        )
        under = _world_median(values["under"])
        over = _world_median(values["over"])
        inverse_total = (1.0 / under) + (1.0 / over)
        result["totals"] = {
            "line": float(line),
            "under": under,
            "over": over,
            "sample_count": min(len(values["under"]), len(values["over"])),
            "market_balance": round(
                abs((1.0 / under) / inverse_total - (1.0 / over) / inverse_total), 4
            ),
            "selection_method": "balanced_mainline",
        }
    complete_handicaps = [
        (line, values) for line, values in handicap_by_line.items()
        if all(values[side] for side in ("home", "draw", "away"))
        and abs(float(line)) >= 0.25
    ]
    if complete_handicaps:
        def handicap_mainline_key(row):
            line, values = row
            medians = {
                side: _world_median(values[side])
                for side in ("home", "draw", "away")
            }
            inverse_total = sum(1.0 / medians[side] for side in medians)
            probabilities = [(1.0 / medians[side]) / inverse_total for side in medians]
            balance = max(probabilities) - min(probabilities)
            coverage = min(len(values[side]) for side in medians)
            return (round(balance, 6), abs(abs(float(line)) - 1.0), -coverage)

        line, values = min(
            complete_handicaps,
            key=handicap_mainline_key,
        )
        medians = {
            side: _world_median(values[side])
            for side in ("home", "draw", "away")
        }
        inverse_total = sum(1.0 / medians[side] for side in medians)
        probabilities = [(1.0 / medians[side]) / inverse_total for side in medians]
        result["handicap"] = {
            "line": float(line),
            "home": medians["home"],
            "draw": medians["draw"],
            "away": medians["away"],
            "sample_count": min(
                len(values[side]) for side in ("home", "draw", "away")
            ),
            "market_balance": round(max(probabilities) - min(probabilities), 4),
            "selection_method": "balanced_mainline",
        }
    result["available_markets"] = [
        market for market in ("1x2", "totals", "handicap") if result.get(market)
    ]
    return result


def _world_market_map_from_batch_cache(payload):
    snapshots = (payload or {}).get("snapshots") if isinstance(payload, dict) else None
    if not isinstance(snapshots, dict):
        return None
    normalized = {}
    for fixture_id, snapshot in snapshots.items():
        try:
            fixture_key = int(fixture_id)
        except (TypeError, ValueError):
            continue
        if fixture_key > 0 and _has_valid_world_market(snapshot):
            normalized[fixture_key] = dict(snapshot)
    return normalized or None


def _fetch_world_market_snapshots_by_date(date_key):
    """Fetch bookmaker-covered fixtures by date, page once, and cache as a batch."""
    date_key = str(date_key or "").strip()
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date_key):
        return None
    cache_key = f"world_odds_by_date_v1_{date_key}"
    cached_payload = get_db_cache(cache_key, 2)
    cached = _world_market_map_from_batch_cache(cached_payload)
    if cached is not None:
        return cached
    stale_payload = get_db_cache(cache_key, 24)
    stale = _world_market_map_from_batch_cache(stale_payload)
    grouped_rows = {}
    page = 1
    try:
        while page <= WORLD_ODDS_MAX_PAGES_PER_DAY:
            response = api_get(
                "/odds",
                params={
                    "date": date_key,
                    "timezone": "Asia/Seoul",
                    "page": page,
                },
                timeout=15,
                purpose="world",
            )
            payload = response.json() if response.status_code == 200 else {}
            if response.status_code != 200 or payload.get("errors"):
                raise RuntimeError(
                    f"odds HTTP {response.status_code}: {payload.get('errors')}"
                )
            for odds_row in payload.get("response", []) or []:
                try:
                    fixture_id = int(
                        ((odds_row or {}).get("fixture") or {}).get("id") or 0
                    )
                except (TypeError, ValueError):
                    fixture_id = 0
                if fixture_id > 0:
                    grouped_rows.setdefault(fixture_id, []).append(odds_row)

            paging = payload.get("paging") or {}
            current_page = int(paging.get("current") or page)
            total_pages = int(paging.get("total") or current_page)
            if current_page >= total_pages:
                break
            if page >= WORLD_ODDS_MAX_PAGES_PER_DAY:
                raise RuntimeError(
                    f"odds paging safety cap {WORLD_ODDS_MAX_PAGES_PER_DAY}/{total_pages}"
                )
            page = current_page + 1

        fetched_at = datetime.now(KST).isoformat()
        snapshots = {}
        for fixture_id, odds_rows in grouped_rows.items():
            snapshot = _world_market_snapshot_from_response(
                odds_rows, fixture_id=fixture_id, fetched_at=fetched_at
            )
            if _has_valid_world_market(snapshot):
                snapshots[fixture_id] = snapshot
        if not snapshots:
            raise RuntimeError("유효한 정규시간 배당이 0건")
        set_db_cache(
            cache_key,
            {
                "date": date_key,
                "fetched_at": fetched_at,
                "pages": page,
                "snapshots": {str(key): value for key, value in snapshots.items()},
            },
        )
        return snapshots
    except Exception as error:
        print(f"⚠️ 세계경기 날짜별 배당 조회 실패({date_key}): {error}")
        return stale


def fetch_world_market_snapshot(fixture_id, diff_hours):
    fixture_id = int(fixture_id or 0)
    if fixture_id <= 0:
        return None
    ttl_h = 4.0 if diff_hours > 3 else (0.5 if diff_hours > 1 else 0.2)
    # v1은 3 Way 숫자 오인, v2는 전반전 총득점 시장이 섞일 수 있었다.
    # 정규시간 시장 범위를 고친 뒤 새 세대 키로 실제 배당을 다시 받는다.
    cache_key = f"world_market_v3_{fixture_id}"
    cached = get_db_cache(cache_key, ttl_h)
    if isinstance(cached, dict):
        return cached
    stale = get_db_cache(cache_key, 24)
    try:
        response = api_get("/odds", params={"fixture": fixture_id}, timeout=10)
        payload = response.json() if response.status_code == 200 else {}
        if response.status_code != 200 or payload.get("errors"):
            raise RuntimeError(f"odds HTTP {response.status_code}: {payload.get('errors')}")
        snapshot = _world_market_snapshot_from_response(
            payload.get("response", []), fixture_id=fixture_id
        )
        set_db_cache(cache_key, snapshot)
        return snapshot
    except Exception as error:
        print(f"⚠️ 세계경기 배당 조회 실패({fixture_id}): {error}")
        if isinstance(stale, dict):
            preserved = dict(stale)
            preserved["stale"] = True
            return preserved
        return None


def _world_market_snapshot_for_analysis(item, fixture_id, diff_hours, now=None):
    """Reuse the batch quote while fresh; later stages still refresh movement."""
    now = (now or datetime.now(KST)).astimezone(KST)
    ttl_h = 4.0 if diff_hours > 3 else (0.5 if diff_hours > 1 else 0.2)
    preloaded = (item or {}).get("market_snapshot")
    if _has_valid_world_market(preloaded):
        try:
            fetched_at = datetime.fromisoformat(
                str(preloaded.get("fetched_at") or "").replace("Z", "+00:00")
            )
            if fetched_at.tzinfo is None:
                fetched_at = fetched_at.replace(tzinfo=KST)
            age_hours = (
                now - fetched_at.astimezone(KST)
            ).total_seconds() / 3600.0
        except (TypeError, ValueError):
            age_hours = ttl_h + 1.0
        if age_hours <= ttl_h:
            return dict(preloaded)
    return fetch_world_market_snapshot(fixture_id, diff_hours) or {}


def _ensure_odds_movement_table(conn):
    """Persist genuine time-series snapshots without making extra API calls."""
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS odds_movement_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fixture_id INTEGER NOT NULL,
            source_type TEXT NOT NULL,
            analysis_stage TEXT DEFAULT '',
            odds_json TEXT NOT NULL,
            fingerprint TEXT NOT NULL,
            captured_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(fixture_id, source_type, fingerprint)
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_odds_movement_fixture "
        "ON odds_movement_snapshots(fixture_id, source_type, id)"
    )


def _movement_market_probabilities(market_name, market):
    market = market if isinstance(market, dict) else {}
    sides = {
        "1x2": ("home", "draw", "away"),
        "totals": ("under", "over"),
        "handicap": ("home", "draw", "away"),
    }.get(str(market_name), ())
    try:
        odds = [float(market.get(side) or 0) for side in sides]
    except (TypeError, ValueError):
        return {}, []
    if not sides or not all(odd > 1.0 for odd in odds):
        return {}, []
    probabilities = normalize_probabilities([1.0 / odd for odd in odds])
    return dict(zip(sides, probabilities)), odds


def _detect_odds_movement(
    previous, current, opening=None, elapsed_hours=None,
    opening_elapsed_hours=None, analysis_stage="",
):
    """Audit broad bookmaker movement without inventing betting-volume data.

    Price direction, bookmaker breadth, persistence from the first captured
    quote, speed and cross-market agreement are evaluated from already cached
    snapshots.  True reverse-line movement still requires public betting-share
    data, so it is never claimed from prices alone.
    """
    previous = previous if isinstance(previous, dict) else {}
    current = current if isinstance(current, dict) else {}
    opening = opening if isinstance(opening, dict) else {}
    result = {
        "has_history": bool(previous),
        "has_opening": bool(opening),
        "qualified": False,
        "summary": "",
        "signals": [],
        "line_movements": [],
        "cross_market_agreement": False,
        "agreement_sides": [],
        "underdog_move": False,
        "movement_speed_available": bool(elapsed_hours and elapsed_hours > 0),
        "comparable_bookmakers": bool(
            len(set(previous.get("bookmaker_ids") or [])) >= 3
            and set(previous.get("bookmaker_ids") or []) == set(current.get("bookmaker_ids") or [])
        ),
        "analysis_stage": str(analysis_stage or ""),
        "bookmaker_count": int(current.get("bookmaker_count") or 0),
        "bookmaker_ids": sorted(str(value) for value in current.get("bookmaker_ids") or []),
        "timing": "late" if str(analysis_stage or "") in {"T-60-lineup", "T-30-final"} else "regular",
        "reverse_line_movement_confirmed": False,
        "reverse_line_reason": "공개 베팅 비중 자료가 없어 배당 움직임만으로 역행배당을 단정하지 않음",
        "home_bonus": 0.0,
        "away_bonus": 0.0,
    }
    labels = {
        ("1x2", "home"): "홈승",
        ("1x2", "draw"): "무승부",
        ("1x2", "away"): "원정승",
        ("totals", "under"): "언더",
        ("totals", "over"): "오버",
        ("handicap", "home"): "핸디승",
        ("handicap", "draw"): "핸디무",
        ("handicap", "away"): "핸디패",
    }
    summaries = []
    directional_markets = {"home": set(), "away": set()}
    opening_wdl = opening.get("1x2") or previous.get("1x2") or {}
    try:
        underdog_side = (
            "home" if float(opening_wdl.get("home") or 0) > float(opening_wdl.get("away") or 0)
            else ("away" if float(opening_wdl.get("away") or 0) > float(opening_wdl.get("home") or 0) else "")
        )
    except (TypeError, ValueError):
        underdog_side = ""
    result["opening_underdog_side"] = underdog_side
    for market_name in ("1x2", "totals", "handicap"):
        old_market = previous.get(market_name) or {}
        new_market = current.get(market_name) or {}
        if market_name in {"totals", "handicap"}:
            try:
                old_line = float(old_market.get("line"))
                new_line = float(new_market.get("line"))
                line_shift = new_line - old_line
                if abs(line_shift) > 1e-9:
                    old_count = int(old_market.get("sample_count") or previous.get("bookmaker_count") or 0)
                    new_count = int(new_market.get("sample_count") or current.get("bookmaker_count") or 0)
                    if min(old_count, new_count) >= 3 and abs(line_shift) >= 0.25:
                        if market_name == "totals":
                            line_side = "over" if line_shift > 0 else "under"
                            line_label = "오버" if line_shift > 0 else "언더"
                        else:
                            line_side = "home" if line_shift < 0 else "away"
                            line_label = "홈 방향" if line_shift < 0 else "원정 방향"
                            directional_markets[line_side].add("handicap_line")
                        line_signal = {
                            "market": market_name,
                            "side": line_side,
                            "previous_line": old_line,
                            "current_line": new_line,
                            "bookmaker_sample_count": min(old_count, new_count),
                        }
                        result["line_movements"].append(line_signal)
                        summaries.append(
                            f"{line_label} 기준선 {old_line:g}→{new_line:g} "
                            f"({line_signal['bookmaker_sample_count']}개 업체)"
                        )
                    continue
            except (TypeError, ValueError):
                continue
        old_count = int(old_market.get("sample_count") or previous.get("bookmaker_count") or 0)
        new_count = int(new_market.get("sample_count") or current.get("bookmaker_count") or 0)
        if min(old_count, new_count) < 3:
            continue
        old_probs, old_odds = _movement_market_probabilities(market_name, old_market)
        new_probs, new_odds = _movement_market_probabilities(market_name, new_market)
        if not old_probs or not new_probs:
            continue
        opening_market = opening.get(market_name) or {}
        opening_probs, opening_odds = _movement_market_probabilities(
            market_name, opening_market
        )
        for index, side in enumerate(old_probs):
            probability_shift = float(new_probs[side]) - float(old_probs[side])
            odds_drop = float(old_odds[index]) - float(new_odds[index])
            # Both price and margin-free implied probability must move.  A
            # 1.8%p move plus a 0.10 price drop is large enough to track while
            # routine rounding noise is ignored.
            if probability_shift < 0.018 or odds_drop < 0.10:
                continue
            persistent = False
            opening_shift = None
            if opening_probs and side in opening_probs:
                opening_index = list(opening_probs).index(side)
                opening_shift = float(new_probs[side]) - float(opening_probs[side])
                opening_drop = float(opening_odds[opening_index]) - float(new_odds[index])
                persistent = opening_shift >= 0.018 and opening_drop >= 0.10
            speed_pph = (
                probability_shift / float(elapsed_hours)
                if elapsed_hours and float(elapsed_hours) > 0 else None
            )
            strength = "강한" if probability_shift >= 0.04 else "유의미한"
            signal = {
                "market": market_name,
                "side": side,
                "label": labels.get((market_name, side), side),
                "previous_odd": round(float(old_odds[index]), 3),
                "current_odd": round(float(new_odds[index]), 3),
                "implied_probability_shift": round(probability_shift, 4),
                "bookmaker_sample_count": min(old_count, new_count),
                "strength": strength,
                "persistent_from_opening": persistent,
                "opening_probability_shift": (
                    round(opening_shift, 4) if opening_shift is not None else None
                ),
                "probability_shift_per_hour": (
                    round(speed_pph, 4) if speed_pph is not None else None
                ),
            }
            result["signals"].append(signal)
            if market_name in {"1x2", "handicap"} and side in {"home", "away"}:
                directional_markets[side].add(market_name)
            if market_name == "1x2" and side == underdog_side:
                result["underdog_move"] = True
            speed_text = (
                f", 시간당 {speed_pph * 100:+.1f}%p"
                if speed_pph is not None else ""
            )
            persistence_text = ", 시초 대비 지속" if persistent else ""
            summaries.append(
                f"{signal['label']} {signal['previous_odd']:.2f}→{signal['current_odd']:.2f} "
                f"({probability_shift * 100:+.1f}%p{speed_text}, "
                f"{signal['bookmaker_sample_count']}개 업체 중앙값{persistence_text})"
            )
            if market_name == "1x2" and side in {"home", "away"}:
                base_bonus = 0.015 + probability_shift * 0.4
                if persistent:
                    base_bonus += 0.005
                if speed_pph is not None and speed_pph >= 0.01:
                    base_bonus += 0.003
                result[f"{side}_bonus"] = max(
                    float(result[f"{side}_bonus"]), min(0.05, base_bonus)
                )

    agreement_sides = [
        side for side, markets in directional_markets.items()
        if "1x2" in markets and ({"handicap", "handicap_line"} & markets)
    ]
    result["agreement_sides"] = agreement_sides
    result["cross_market_agreement"] = bool(agreement_sides)
    for side in agreement_sides:
        result[f"{side}_bonus"] = min(0.05, float(result[f"{side}_bonus"]) + 0.005)
    if agreement_sides:
        summaries.append(
            "승무패·핸디캡 같은 방향 확인(" + ", ".join(
                "홈" if side == "home" else "원정" for side in agreement_sides
            ) + ")"
        )
    if result["underdog_move"]:
        summaries.append("초기 열세팀 배당 수축 확인")
    result["upset_price_signal_side"] = (
        underdog_side if result["underdog_move"] else ""
    )
    current_wdl = current.get("1x2") or {}
    try:
        result["current_favorite_side"] = min(
            ("home", "draw", "away"),
            key=lambda side: float(current_wdl.get(side) or 999),
        ) if all(float(current_wdl.get(side) or 0) > 1 for side in ("home", "draw", "away")) else ""
    except (TypeError, ValueError):
        result["current_favorite_side"] = ""
    result["qualified"] = bool(result["signals"] or result["line_movements"]) and result["comparable_bookmakers"]
    if not result["comparable_bookmakers"]:
        result["home_bonus"] = result["away_bonus"] = 0.0
        if summaries:
            summaries.append("동일 업체 집합 미확인 · 배당 변화는 참고만 제공")
    result["summary"] = " · ".join(summaries)
    return result


def capture_odds_movement(fixture_id, source_type, analysis_stage, snapshot):
    """Store the current quote and return movement versus the last changed quote."""
    fixture_id = int(fixture_id or 0)
    snapshot = snapshot if isinstance(snapshot, dict) else {}
    if fixture_id <= 0 or not any(snapshot.get(key) for key in ("1x2", "totals", "handicap")):
        return _detect_odds_movement({}, snapshot)
    normalized = {
        key: snapshot.get(key)
        for key in ("bookmaker_count", "bookmaker_ids", "1x2", "totals", "handicap")
        if snapshot.get(key) is not None
    }
    encoded = json.dumps(normalized, ensure_ascii=False, sort_keys=True)
    fingerprint = hashlib.sha256(encoded.encode("utf-8")).hexdigest()
    conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=30)
    try:
        conn.execute("PRAGMA busy_timeout = 30000")
        _ensure_odds_movement_table(conn)
        previous_row = conn.execute(
            """
            SELECT odds_json, captured_at FROM odds_movement_snapshots
            WHERE fixture_id = ? AND source_type = ? AND fingerprint != ?
            ORDER BY id DESC LIMIT 1
            """,
            (fixture_id, str(source_type), fingerprint),
        ).fetchone()
        opening_row = conn.execute(
            """
            SELECT odds_json, captured_at FROM odds_movement_snapshots
            WHERE fixture_id = ? AND source_type = ?
            ORDER BY id ASC LIMIT 1
            """,
            (fixture_id, str(source_type)),
        ).fetchone()
        try:
            previous = json.loads(previous_row[0]) if previous_row else {}
        except (TypeError, ValueError, json.JSONDecodeError):
            previous = {}
        try:
            opening = json.loads(opening_row[0]) if opening_row else {}
        except (TypeError, ValueError, json.JSONDecodeError):
            opening = {}

        def elapsed_since(row):
            if not row or not row[1]:
                return None
            try:
                captured = datetime.fromisoformat(str(row[1]).replace("Z", "+00:00"))
                if captured.tzinfo is None:
                    captured = captured.replace(tzinfo=timezone.utc)
                return max(
                    1.0 / 60.0,
                    (datetime.now(timezone.utc) - captured.astimezone(timezone.utc)).total_seconds() / 3600.0,
                )
            except (TypeError, ValueError):
                return None

        movement = _detect_odds_movement(
            previous, normalized, opening=opening,
            elapsed_hours=elapsed_since(previous_row),
            opening_elapsed_hours=elapsed_since(opening_row),
            analysis_stage=analysis_stage,
        )
        conn.execute(
            """
            INSERT OR IGNORE INTO odds_movement_snapshots (
                fixture_id, source_type, analysis_stage, odds_json, fingerprint
            ) VALUES (?, ?, ?, ?, ?)
            """,
            (fixture_id, str(source_type), str(analysis_stage or ""), encoded, fingerprint),
        )
        conn.commit()
        history = []
        for stage, raw_odds, captured_at in conn.execute(
            """
            SELECT analysis_stage,odds_json,captured_at
            FROM odds_movement_snapshots
            WHERE fixture_id=? AND source_type=?
            ORDER BY id ASC
            """,
            (fixture_id, str(source_type)),
        ).fetchall():
            try:
                quote = json.loads(raw_odds or "{}")
            except (TypeError, ValueError, json.JSONDecodeError):
                continue
            history.append({
                "captured_at": str(captured_at or ""),
                "analysis_stage": str(stage or ""),
                "odds": quote,
            })
        movement["history"] = history
        movement["history_count"] = len(history)
        movement["opening_snapshot"] = history[0] if history else None
        movement["latest_snapshot"] = history[-1] if history else None
        movement["closing_snapshot"] = (
            history[-1]
            if history and str(analysis_stage or "") == "T-30-final"
            else None
        )
        return movement
    except Exception as error:
        print(f"⚠️ 시간대별 해외배당 기록 실패({fixture_id}): {error}")
        return _detect_odds_movement({}, snapshot)
    finally:
        conn.close()


def _observe_locked_pick_market_flow(
    item, source, match_id, fixture_id, league, home_team, away_team,
    kickoff, diff_hours, snapshot=None,
):
    """Append pre-kickoff market evidence for the next robot revision.

    Scheduled picks may refresh as the official formula or robot learns. Once
    kickoff arrives, both displayed picks are immutable and this helper exits.
    """
    item = item if isinstance(item, dict) else {}
    fixture_id = int(fixture_id or 0)
    if fixture_id <= 0 or not item.get("robot_pick"):
        return False
    if not isinstance(kickoff, datetime):
        kickoff = _parse_kst_match_time(kickoff)
    if kickoff is None:
        return False
    if kickoff.tzinfo is None:
        kickoff = kickoff.replace(tzinfo=KST)
    if datetime.now(KST) >= kickoff.astimezone(KST):
        return False
    snapshot = snapshot or fetch_world_market_snapshot(fixture_id, diff_hours)
    if not _has_valid_world_market(snapshot):
        return False
    observation_stage = prediction_stage(diff_hours, bool(item.get("lineup_confirmed")))
    movement = capture_odds_movement(
        fixture_id, str(source or "UNKNOWN"), observation_stage, snapshot
    )
    try:
        full_evidence = json.loads(json.dumps(
            item.get("robot_full_evidence") or {},
            ensure_ascii=False, default=str,
        ))
    except (TypeError, ValueError, json.JSONDecodeError):
        full_evidence = {}
    markets = full_evidence.setdefault("markets", {})
    if not isinstance(markets, dict):
        markets = {}
        full_evidence["markets"] = markets
    markets["current_snapshot"] = snapshot
    markets["time_series_and_reverse_signals"] = movement
    markets["latest_observation_role"] = (
        "closing" if float(diff_hours) <= 0.5 else "intermediate"
    )
    # Existing first-pass inputs are retained as direct features, while every
    # newly observed nested odds field is added automatically.
    robot_features = build_autonomous_robot_features(
        {}, {}, item.get("robot_candidates") or [],
        float(item.get("analysis_confidence") or 0),
        extra=item.get("robot_features") or {},
        all_evidence=full_evidence,
    )
    return save_autonomous_robot_sample(
        str(source or "UNKNOWN"), str(match_id or ""), fixture_id,
        str(league or ""), str(home_team or "홈팀"), str(away_team or "원정팀"),
        kickoff, robot_features, item.get("robot_candidates") or [],
        item.get("robot_pick") or {}, full_evidence=full_evidence,
        lineup_prediction=(
            item.get("robot_lineup_prediction")
            or item.get("lineup_learning") or {}
        ),
        analysis_stage=observation_stage,
    )


def fetch_world_injuries_snapshot(fixture_id, home_id, away_id, league_id, season, ttl_h):
    fixture_id = int(fixture_id or 0)
    team_ids = {int(home_id or 0), int(away_id or 0)}
    default = {
        str(team_id): {
            "count": 0, "ace_missing": False, "ace_names": [],
            "all_names": [], "missing_goals": 0, "records": [],
            "available": False, "source": "none",
        }
        for team_id in team_ids if team_id > 0
    }
    if fixture_id <= 0 or len(default) != 2:
        return default
    cache_key = f"world_injuries_v2_all_names_{fixture_id}"
    cached = get_db_cache(cache_key, ttl_h)
    if isinstance(cached, dict):
        return cached
    stale = get_db_cache(cache_key, max(24, ttl_h))
    try:
        response = api_get("/injuries", params={"fixture": fixture_id}, timeout=10)
        payload = response.json() if response.status_code == 200 else {}
        if response.status_code != 200 or payload.get("errors"):
            raise RuntimeError(f"injuries HTTP {response.status_code}: {payload.get('errors')}")
        names_by_team = {team_id: [] for team_id in team_ids}
        records_by_team = {team_id: [] for team_id in team_ids}
        for row in payload.get("response", []) or []:
            team_id = int((row.get("team") or {}).get("id") or 0)
            player = row.get("player") or {}
            player_name = str(player.get("name") or "").strip()
            if team_id in names_by_team and player_name:
                names_by_team[team_id].append(player_name)
                records_by_team[team_id].append({
                    "player_id": int(player.get("id") or 0),
                    "name": player_name,
                    "type": str(player.get("type") or "").strip(),
                    "reason": str(player.get("reason") or "").strip(),
                })
        key_players = {}
        if any(names_by_team.values()) and league_id and season:
            key_players = fetch_league_key_players(league_id, season)
        result = {}
        for team_id, names in names_by_team.items():
            names = sorted(set(names))
            ace_names = []
            missing_goals = 0
            for name in names:
                normalized = _normalize_player_name(name)
                matched = next((
                    stats for key_name, stats in key_players.items()
                    if stats.get("team_id") in (None, team_id)
                    and (
                        normalized == _normalize_player_name(key_name)
                        or (
                            len(normalized) >= 6
                            and (
                                normalized in _normalize_player_name(key_name)
                                or _normalize_player_name(key_name) in normalized
                            )
                        )
                    )
                ), None)
                if matched or find_protected_star(name):
                    ace_names.append(name)
                    missing_goals += int((matched or {}).get("goals", 0) or 0)
            result[str(team_id)] = {
                "count": len(names),
                "ace_missing": bool(ace_names),
                "ace_names": ace_names,
                "all_names": names,
                "records": records_by_team.get(team_id) or [],
                "missing_goals": missing_goals,
                "available": True,
                "source": "target_fixture",
            }
        set_db_cache(cache_key, result)
        return result
    except Exception as error:
        print(f"⚠️ 세계경기 부상자 조회 실패({fixture_id}): {error}")
        if isinstance(stale, dict):
            return stale
        return default


def _world_analysis_stage(diff_hours):
    if diff_hours <= 0:
        return "LOCKED_AFTER_KICKOFF"
    if diff_hours <= 0.5:
        return "T-30-final"
    if diff_hours <= 1.0:
        return "T-60-lineup"
    if diff_hours <= 3.0:
        return "T-3-refresh"
    if diff_hours <= WORLD_ANALYSIS_HORIZON_HOURS:
        return "PREKICKOFF-initial"
    return "WAITING_ANALYSIS_WINDOW"


def _world_data_quality(match, odds, h_recent, a_recent, h_long, a_long,
                        h_stand, a_stand, injuries, lineup_confirmed):
    score = 0
    missing = []
    if (
        int(match.get("fixture_id") or 0) > 0
        and int(match.get("home_team_id") or 0) > 0
        and int(match.get("away_team_id") or 0) > 0
        and match.get("kickoff_at")
    ):
        score += 15
    else:
        missing.append("경기·팀 신원 또는 시간")

    if odds and odds.get("1x2"):
        score += 15
    else:
        missing.append("승무패 배당")
    if odds and odds.get("totals"):
        score += 5
    else:
        missing.append("언더오버 배당")
    if odds and odds.get("handicap"):
        score += 5
    else:
        missing.append("핸디캡 배당")
    if odds and odds.get("stale"):
        score = max(0, score - 5)
        missing.append("최신 배당")

    recent_sample = min(int(h_recent.get("matches") or 0), int(a_recent.get("matches") or 0))
    long_sample = min(int(h_long.get("home_total") or 0), int(a_long.get("away_total") or 0))
    if recent_sample >= 5 and long_sample >= 3:
        score += 20
    elif recent_sample >= 3:
        score += 12
        missing.append("충분한 최근 경기 표본")
    elif recent_sample > 0:
        score += 6
        missing.append("충분한 최근 경기 표본")
    else:
        missing.append("최근 경기 표본")

    if (
        int(h_stand.get("rank") or 99) != 99
        and int(a_stand.get("rank") or 99) != 99
        and long_sample >= 3
    ):
        score += 15
    elif int(h_stand.get("rank") or 99) != 99 and int(a_stand.get("rank") or 99) != 99:
        score += 8
        missing.append("홈·원정 공격수비 표본")
    else:
        missing.append("순위·홈원정 공격수비")

    if injuries.get("home", {}).get("available") and injuries.get("away", {}).get("available"):
        score += 10
    elif injuries.get("home", {}).get("available") or injuries.get("away", {}).get("available"):
        score += 5
        missing.append("양 팀 전체 부상·징계")
    else:
        missing.append("부상·징계")
    if lineup_confirmed:
        score += 10
    else:
        missing.append("확정 선발명단")
    # 검증된 fixture_id는 종료 후 결과·사건 조회 대상으로 사용할 수 있다.
    if int(match.get("fixture_id") or 0) > 0:
        score += 5
    else:
        missing.append("경기 후 사건·통계 지원")

    score = max(0, min(100, int(score)))
    grade = "정상" if score >= 80 else ("주의" if score >= 60 else "보조 분석")
    return score, grade, list(dict.fromkeys(missing))


def _ensure_world_analysis_table(conn):
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS world_prediction_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fixture_id INTEGER NOT NULL,
            match_id TEXT NOT NULL,
            league_id INTEGER NOT NULL,
            season INTEGER,
            analysis_version TEXT NOT NULL,
            analysis_stage TEXT NOT NULL,
            analysis_day TEXT NOT NULL,
            kickoff_at TEXT NOT NULL,
            analyzed_at TEXT NOT NULL,
            frozen_at TEXT,
            data_quality_score INTEGER NOT NULL,
            odds_json TEXT NOT NULL DEFAULT '{}',
            inputs_json TEXT NOT NULL DEFAULT '{}',
            candidates_json TEXT NOT NULL DEFAULT '[]',
            categories_json TEXT NOT NULL DEFAULT '{}',
            decision_json TEXT NOT NULL DEFAULT '{}',
            report_text TEXT NOT NULL DEFAULT '',
            fingerprint TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(fixture_id, analysis_version, analysis_stage, fingerprint)
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_world_snapshot_day "
        "ON world_prediction_snapshots(analysis_day, league_id, fixture_id)"
    )


def _world_analysis_usage():
    day_key = datetime.now(KST).strftime("%Y-%m-%d")
    conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=30)
    try:
        _ensure_world_analysis_table(conn)
        today_rows = conn.execute(
            "SELECT DISTINCT fixture_id, league_id FROM world_prediction_snapshots "
            "WHERE analysis_day = ?", (day_key,),
        ).fetchall()
        all_rows = conn.execute(
            "SELECT DISTINCT fixture_id FROM world_prediction_snapshots"
        ).fetchall()
        conn.commit()
    finally:
        conn.close()
    today_ids = {int(row[0]) for row in today_rows}
    all_ids = {int(row[0]) for row in all_rows}
    league_counts = {}
    for _, league_id in today_rows:
        league_counts[int(league_id)] = int(league_counts.get(int(league_id), 0)) + 1
    return day_key, today_ids, all_ids, league_counts


def _save_world_analysis_snapshot(match, analysis):
    analysis_version = str(analysis.get("analysis_version") or WORLD_ANALYSIS_VERSION)
    payload_parts = {
        "odds": analysis.get("odds_snapshot") or {},
        "inputs": analysis.get("inputs_snapshot") or {},
        "candidates": analysis.get("candidates") or [],
        "categories": analysis.get("categories") or {},
        "decision": analysis.get("decision") or {},
    }
    encoded = {
        key: json.dumps(value, ensure_ascii=False, sort_keys=True)
        for key, value in payload_parts.items()
    }
    fingerprint = hashlib.sha256(
        "|".join((
            analysis_version, str(analysis.get("analysis_stage") or ""),
            encoded["odds"], encoded["inputs"], encoded["candidates"],
            encoded["categories"], encoded["decision"],
        )).encode("utf-8")
    ).hexdigest()
    conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=30)
    try:
        conn.execute("PRAGMA busy_timeout = 30000")
        _ensure_world_analysis_table(conn)
        conn.execute(
            """
            INSERT OR IGNORE INTO world_prediction_snapshots (
                fixture_id, match_id, league_id, season, analysis_version,
                analysis_stage, analysis_day, kickoff_at, analyzed_at, frozen_at,
                data_quality_score, odds_json, inputs_json, candidates_json,
                categories_json, decision_json, report_text, fingerprint
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                int(match.get("fixture_id") or 0), str(match.get("id") or ""),
                int(match.get("league_id") or 0), match.get("season"), analysis_version,
                str(analysis.get("analysis_stage") or ""),
                datetime.now(KST).strftime("%Y-%m-%d"), str(match.get("kickoff_at") or ""),
                str(analysis.get("analyzed_at") or ""), analysis.get("frozen_at"),
                int(analysis.get("data_quality_score") or 0), encoded["odds"],
                encoded["inputs"], encoded["candidates"], encoded["categories"],
                encoded["decision"], str(analysis.get("report") or ""), fingerprint,
            ),
        )
        conn.commit()
        return True
    finally:
        conn.close()


def _world_learning_candidate(row):
    """Restore a WORLD audit row to the common candidate shape."""
    row = dict(row or {})
    return {
        "market_key": str(row.get("market_key") or ""),
        "label": str(row.get("label") or ""),
        "raw_pick": str(row.get("raw_pick") or ""),
        "selection_side": str(row.get("selection_side") or ""),
        "handicap_base": row.get("handicap_base"),
        "sort_id": int(row.get("sort_id") or 0),
        "prob": float(row.get("model_probability") or 0),
        "raw_model_prob": row.get("raw_model_probability"),
        "fair_prob": row.get("fair_probability"),
        "odd": float(row.get("odd") or 0),
        "edge": float(row.get("edge") or 0),
        "robust_probability": float(row.get("robust_probability") or 0),
        "robust_edge": float(row.get("robust_edge") or 0),
        "robust_ev": float(row.get("robust_ev") or 0),
        "balanced_score": float(row.get("balanced_score") or 0),
        "safe_score": float(row.get("safe_score") or 0),
        "recommendation_score": float(row.get("recommendation_score") or 0),
        "market_hit_rate": float(row.get("market_hit_rate") or 0.5),
        "market_history_samples": int(row.get("market_history_samples") or 0),
        "market_history_scope": str(row.get("market_history_scope") or "global"),
        "learning_weight": float(row.get("learning_weight") or 0),
        "data_confidence": float(row.get("data_confidence") or 0.35),
        "error_margin": float(row.get("error_margin") or 0),
        "probability_interval": dict(row.get("probability_interval") or {}),
        "is_true_underdog": bool(row.get("is_true_underdog")),
        "is_qualified_underdog": bool(row.get("is_qualified_underdog")),
        "support_signals": list(row.get("support_signals") or []),
        "independent_support_count": int(row.get("independent_support_count") or 0),
    }


def _canonical_proto_prediction_match_id(fixture_id):
    """Find the non-WORLD official row for the same verified provider fixture."""
    try:
        fixture_id = int(fixture_id or 0)
    except (TypeError, ValueError):
        return ""
    if fixture_id <= 0:
        return ""
    conn = None
    try:
        conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=15)
        conn.execute("PRAGMA busy_timeout = 15000")
        row = conn.execute(
            """
            SELECT match_id
            FROM predictions
            WHERE api_fixture_id = ? AND is_toto14 = 0
              AND match_id NOT LIKE 'WORLD_%'
            ORDER BY CASE WHEN actual_result = 'PENDING' THEN 0 ELSE 1 END, id DESC
            LIMIT 1
            """,
            (fixture_id,),
        ).fetchone()
        return str(row[0]) if row else ""
    except Exception:
        return ""
    finally:
        if conn is not None:
            conn.close()


def _dashboard_proto_by_fixture():
    dashboard = _read_json("dashboard_data.json", {})
    result = {}
    for item in dashboard.get("proto", []) if isinstance(dashboard, dict) else []:
        if not isinstance(item, dict):
            continue
        try:
            fixture_id = int(
                item.get("api_fixture_id")
                or (item.get("match") or {}).get("api_fixture_id")
                or (item.get("match") or {}).get("fixture_id")
                or 0
            )
        except (TypeError, ValueError):
            fixture_id = 0
        if fixture_id > 0 and fixture_id not in result:
            result[fixture_id] = item
    return result


def _world_analysis_from_proto_item(proto_item, previous_analysis=None):
    """Mirror one canonical Proto answer into WORLD without a second API analysis."""
    previous = dict(previous_analysis or {})
    categories = dict(proto_item.get("pick_categories") or {})
    selected = categories.get("high_probability")
    if not isinstance(selected, dict):
        candidates = [
            row for row in proto_item.get("ev_sorted_picks", [])
            if isinstance(row, dict)
        ]
        selected = max(
            candidates, key=lambda row: float(row.get("prob") or 0)
        ) if candidates else None
    if not isinstance(selected, dict) or not str(selected.get("raw_pick") or "").strip():
        return None
    selected = dict(selected)
    raw_pick = str(selected.get("raw_pick") or "")
    selected["display"] = _human_pick_label(
        raw_pick, (proto_item.get("match") or {}).get("home", "")
    )
    selected["probability"] = float(
        selected.get("prob") or selected.get("probability") or 0
    )
    selected["badges"] = [
        label for key, label in (
            ("honey", "배당가치 우수"),
            ("vip_underdog", "VIP 검증 등급"),
        )
        if str((categories.get(key) or {}).get("raw_pick") or "") == raw_pick
    ]
    robot_pick = dict(proto_item.get("robot_pick") or {})
    if robot_pick:
        robot_pick["display"] = _human_pick_label(
            robot_pick.get("raw_pick"),
            (proto_item.get("match") or {}).get("home", ""),
        )
    alphago_pick = proto_item.get("alphago_pick")
    if not isinstance(alphago_pick, dict):
        alphago_pick = _alphago_pick_payload(robot_pick)
    try:
        quality_score = int(round(float(proto_item.get("data_coverage") or 0) * 100))
    except (TypeError, ValueError):
        quality_score = 0
    quality_score = quality_score or int(previous.get("data_quality_score") or 0)
    quality_grade = "정상" if quality_score >= 80 else ("주의" if quality_score >= 60 else "보조 분석")
    previous.update({
        "analysis_version": str(proto_item.get("analysis_version") or ANALYSIS_VERSION),
        "system_version": SYSTEM_VERSION,
        "analysis_stage": str(proto_item.get("analysis_stage") or "regular"),
        "analyzed_at": str(previous.get("analyzed_at") or _utc_iso()),
        "data_quality_score": quality_score,
        "data_quality_grade": quality_grade,
        "lineup_confirmed": bool(proto_item.get("lineup_confirmed")),
        "categories": categories,
        "selected": selected,
        "legacy_v4_pick": {},
        "robot_pick": robot_pick,
        "alphago_pick": dict(alphago_pick),
        "report": str(
            proto_item.get("detailed_report")
            or proto_item.get("analysis_detail")
            or proto_item.get("story")
            or previous.get("report")
            or ""
        ),
        "canonical_source": "PROTO",
        "canonical_match_id": str((proto_item.get("match") or {}).get("id") or ""),
    })
    return previous


def _sync_world_item_from_proto(item, proto_item):
    analysis = _world_analysis_from_proto_item(proto_item, item.get("analysis"))
    if not analysis:
        return False
    before = json.dumps(item, ensure_ascii=False, sort_keys=True)
    item["analysis"] = analysis
    item["analysis_version"] = analysis["analysis_version"]
    item["system_version"] = SYSTEM_VERSION
    item["analysis_stage"] = analysis["analysis_stage"]
    item["analyzed_at"] = analysis["analyzed_at"]
    item["data_quality_score"] = analysis["data_quality_score"]
    item["data_quality_grade"] = analysis["data_quality_grade"]
    item["lineup_confirmed"] = analysis["lineup_confirmed"]
    item["analysis_status"] = "ANALYZED_SHADOW"
    item["pick_status"] = "CANONICAL_PROTO_PICK"
    item["canonical_match_id"] = analysis["canonical_match_id"]
    return before != json.dumps(item, ensure_ascii=False, sort_keys=True)


def _competition_kind(league_name, match_identity=None):
    text = " ".join((
        str(league_name or ""),
        str((match_identity or {}).get("round") or ""),
        str((match_identity or {}).get("country") or ""),
    )).casefold()
    if any(word in text for word in ("friendly", "친선")):
        return "friendly"
    if any(word in text for word in (
        "champions", "europa", "conference", "libertadores", "sudamericana",
        "afc", "concacaf", "caf", "ofc", "international", "world cup",
    )):
        return "international_club_or_national"
    if any(word in text for word in ("cup", "copa", "fa컵", "리그컵", "coppa", "pokal")):
        return "domestic_cup"
    if any(word in text for word in ("playoff", "play-off", "knockout", "final", "결승")):
        return "playoff_or_knockout"
    return "league_or_other"


def _robot_team_travel_context(team_info, current_match, recent_fixtures, current_role):
    """Summarize only verified itinerary facts already present in fixture data.

    A city change is not presented as a kilometre distance.  Keeping the raw
    cities, countries, dates and home/away roles lets the robot learn which
    itineraries matter for each team/competition once results arrive.
    """
    team_info = team_info if isinstance(team_info, dict) else {}
    current_match = current_match if isinstance(current_match, dict) else {}
    recent_fixtures = [
        row for row in (recent_fixtures or []) if isinstance(row, dict)
    ]
    try:
        team_id = int(team_info.get("id") or 0)
    except (TypeError, ValueError):
        team_id = 0
    venue = team_info.get("venue") or {}
    base_city = str(venue.get("city") or "").strip()
    current_city = str(current_match.get("city") or "").strip()
    current_country = str(current_match.get("country") or "").strip()

    itinerary = []
    for row in recent_fixtures[-8:]:
        fixture = row.get("fixture") or {}
        league = row.get("league") or {}
        teams = row.get("teams") or {}
        home_id = int(((teams.get("home") or {}).get("id") or 0))
        away_id = int(((teams.get("away") or {}).get("id") or 0))
        role = "home" if team_id and home_id == team_id else (
            "away" if team_id and away_id == team_id else "unknown"
        )
        venue_row = fixture.get("venue") or {}
        itinerary.append({
            "fixture_id": int(fixture.get("id") or 0),
            "timestamp": int(fixture.get("timestamp") or 0),
            "date": str(fixture.get("date") or ""),
            "role": role,
            "city": str(venue_row.get("city") or ""),
            "venue_name": str(venue_row.get("name") or ""),
            "country": str(league.get("country") or ""),
            "league_name": str(league.get("name") or ""),
            "opponent_id": (
                away_id if role == "home" else home_id if role == "away" else 0
            ),
        })

    last = itinerary[-1] if itinerary else {}
    consecutive_away = 0
    for row in reversed(itinerary):
        if row.get("role") != "away":
            break
        consecutive_away += 1
    last_five = itinerary[-5:]
    recent_away_count = sum(row.get("role") == "away" for row in last_five)
    last_city = str(last.get("city") or "").strip()
    last_country = str(last.get("country") or "").strip()
    return {
        "team_id": team_id,
        "current_role": str(current_role or ""),
        "verified_base_city": base_city,
        "current_match_city": current_city,
        "current_match_country": current_country,
        "base_city_to_current_city_changed": (
            base_city.casefold() != current_city.casefold()
            if base_city and current_city else None
        ),
        "last_match_city": last_city,
        "last_match_country": last_country,
        "last_city_to_current_city_changed": (
            last_city.casefold() != current_city.casefold()
            if last_city and current_city else None
        ),
        "last_country_to_current_country_changed": (
            last_country.casefold() != current_country.casefold()
            if last_country and current_country else None
        ),
        "consecutive_recent_away_matches": consecutive_away,
        "away_matches_in_last_five": recent_away_count,
        "raw_recent_itinerary": itinerary,
        # Exact kilometres/time zones require verified coordinates.  Unknown
        # values stay unknown instead of becoming a misleading zero.
        "verified_distance_km": None,
        "verified_timezone_shift_hours": None,
    }


def _robot_full_pre_match_evidence(
    source, match_identity, league_name, league_id, season,
    home_info, away_info, home_recent, away_recent,
    home_stats, away_stats, home_long, away_long,
    home_standing, away_standing, home_survival, away_survival,
    injuries, lineup_learning, rest_days, last_fixtures, next_fixtures,
    managers, h2h, environment, odds, odds_movement,
    goal_model_audit, context_audit, confidence,
    quality=None, adjustments=None, supplemental=None,
):
    """Return the robot's complete immutable pre-kickoff memory document.

    Nested payloads are intentionally retained instead of cherry-picking
    numeric fields. The model flattener automatically admits newly added
    provider fields without a new human weighting rule.
    """
    match_identity = dict(match_identity or {})
    league_name = str(league_name or match_identity.get("league") or "")
    last_fixtures = last_fixtures if isinstance(last_fixtures, dict) else {}
    environment = environment if isinstance(environment, dict) else {}
    travel_match = dict(match_identity)
    travel_match["city"] = str(
        travel_match.get("city") or environment.get("city") or ""
    )
    travel_match["country"] = str(
        travel_match.get("country") or environment.get("country") or ""
    )
    evidence = {
        "memory_schema_version": ROBOT_MEMORY_SCHEMA_VERSION,
        "source": str(source or ""),
        "match_identity": match_identity,
        "competition": {
            "league_name": league_name,
            "league_id": int(league_id or 0),
            "season": season,
            "kind": _competition_kind(league_name, match_identity),
            "round": match_identity.get("round"),
            "country": match_identity.get("country"),
        },
        "teams": {"home": home_info or {}, "away": away_info or {}},
        "recent_form": {"home": home_recent or {}, "away": away_recent or {}},
        "recent_match_stats": {"home": home_stats or {}, "away": away_stats or {}},
        "long_term": {"home": home_long or {}, "away": away_long or {}},
        "standings": {"home": home_standing or {}, "away": away_standing or {}},
        "motivation": {
            "home_survival": home_survival or {},
            "away_survival": away_survival or {},
        },
        "h2h_and_matchup": h2h or {},
        "injuries_and_absences": injuries or {},
        "lineup_learning": lineup_learning or {},
        "squads": {
            "home": fetch_team_squad_cached(int((home_info or {}).get("id") or 0)),
            "away": fetch_team_squad_cached(int((away_info or {}).get("id") or 0)),
        },
        "schedule_and_travel": {
            "rest_days": rest_days or {},
            "recent_fixtures": last_fixtures,
            "next_fixtures": next_fixtures or {},
            "home_itinerary": _robot_team_travel_context(
                home_info, travel_match, last_fixtures.get("home") or [], "home"
            ),
            "away_itinerary": _robot_team_travel_context(
                away_info, travel_match, last_fixtures.get("away") or [], "away"
            ),
            # Exact distance is deliberately left unknown until verified
            # coordinates are available; no location is fabricated.
            "travel_distance_km": None,
        },
        "managers": managers or {},
        "environment": environment,
        "markets": {
            "current_snapshot": odds or {},
            "time_series_and_reverse_signals": odds_movement or {},
        },
        "model_context": {
            "goal_model_audit": goal_model_audit or {},
            "context_audit": context_audit or {},
            "data_confidence": confidence,
            "quality": quality or {},
            "adjustments": adjustments or {},
        },
    }
    if isinstance(supplemental, dict):
        evidence["supplemental"] = supplemental
    return evidence


def _save_world_learning_record(match, analysis):
    """Feed WORLD forecasts into the same revision-safe grading pipeline."""
    # A price-only market preview is a provisional display while the complete
    # pre-match pass is pending.  Freezing or grading it would prevent the
    # first full-context official/robot answers from becoming the public picks.
    if str((analysis or {}).get("analysis_stage") or "") == "market-preview":
        return False
    fixture_id = int(match.get("fixture_id") or 0)
    canonical_match_id = _canonical_proto_prediction_match_id(fixture_id)
    if canonical_match_id:
        print(
            f"동일 경기 공식픽 재사용: fixture {fixture_id} -> {canonical_match_id} "
            "(WORLD 중복 채점 저장 생략)"
        )
        return True
    candidates = [
        _world_learning_candidate(row)
        for row in (analysis.get("candidates") or [])
        if isinstance(row, dict)
    ]
    by_pick = {
        (item.get("market_key"), item.get("raw_pick")): item
        for item in candidates
    }
    categories = {}
    for key in ("high_probability", "honey", "vip_underdog"):
        summary = (analysis.get("categories") or {}).get(key) or {}
        source = by_pick.get((
            str(summary.get("market_key") or ""),
            str(summary.get("raw_pick") or ""),
        ))
        categories[key] = ({**source, **summary} if source else None)
    robot_summary = analysis.get("robot_pick") or (
        (analysis.get("categories") or {}).get("robot_independent") or {}
    )
    robot_source = by_pick.get((
        str(robot_summary.get("market_key") or ""),
        str(robot_summary.get("raw_pick") or ""),
    ))
    robot_pick = ({**robot_source, **robot_summary} if robot_source else None)
    selected = categories.get("high_probability")
    if not selected and (analysis.get("selected") or {}).get("recommendation_status") == "WITHHELD":
        selected = dict(analysis["selected"], prob=0.0, raw_pick="")
        categories["high_probability"] = selected
    if not selected:
        return False
    confidence = float(
        selected.get("data_confidence")
        or (float(analysis.get("data_quality_score") or 35) / 100.0)
    )
    odds = analysis.get("odds_snapshot") or {}
    wdl = odds.get("1x2") or {}
    kickoff = _parse_kst_match_time(
        match.get("match_time") or match.get("kickoff_at")
    )
    if kickoff is not None and robot_pick:
        # Every changed pre-kickoff evidence state is appended to the robot's
        # observation and revision memory; the current row moves until kickoff.
        save_autonomous_robot_sample(
            "WORLD", str(match.get("id") or ""), int(match.get("fixture_id") or 0),
            str(match.get("league_name_ko") or match.get("league") or "세계 축구"),
            str(match.get("home") or "홈팀"), str(match.get("away") or "원정팀"),
            kickoff, analysis.get("robot_features") or {},
            analysis.get("robot_candidates") or [], robot_pick,
            full_evidence=analysis.get("robot_full_evidence") or {},
            lineup_prediction=analysis.get("robot_lineup_prediction") or {},
            analysis_stage=str(analysis.get("analysis_stage") or ""),
        )
    prediction_saved = save_dual_predictions_to_local_db(
        str(match.get("id") or ""),
        str(match.get("league_name_ko") or match.get("league") or "세계 축구"),
        str(match.get("home") or "홈팀"),
        str(match.get("away") or "원정팀"),
        str(selected.get("raw_pick") or ""),
        round(float(selected.get("prob") or 0) * 100, 1),
        "",
        0.0,
        float(wdl.get("home") or 0),
        float(wdl.get("draw") or 0),
        float(wdl.get("away") or 0),
        str(match.get("match_time") or ""),
        0,
        int(match.get("fixture_id") or 0),
        str(analysis.get("analysis_stage") or "regular"),
        confidence,
        analysis_version=str(analysis.get("analysis_version") or WORLD_ANALYSIS_VERSION),
    )
    if not prediction_saved:
        return False
    analysis_saved = save_prediction_analysis(
        str(match.get("id") or ""), selected, confidence,
        analysis.get("evidence") or [], candidates,
        str(analysis.get("report") or ""), categories=categories,
        analysis_stage=str(analysis.get("analysis_stage") or "regular"),
        odds_source="world_bookmaker_median",
        analysis_version=str(analysis.get("analysis_version") or WORLD_ANALYSIS_VERSION),
        robot_pick=robot_pick,
        lineup_prediction=(analysis.get("decision") or {}).get("lineup_prediction"),
    )
    if analysis_saved and kickoff is not None:
        save_three_engine_picks(
            "WORLD", str(match.get("id") or ""), int(match.get("fixture_id") or 0),
            str(match.get("league_name_ko") or match.get("league") or "세계 축구"),
            str(match.get("home") or "홈팀"), str(match.get("away") or "원정팀"),
            kickoff, selected, analysis.get("legacy_v4_pick") or {}, robot_pick,
        )
    return analysis_saved


def _analyze_world_match(item, now, market_performance):
    """Analyze WORLD with the same full-context inputs and common selector."""
    match = dict((item or {}).get("match") or {})
    fixture_id = int(match.get("fixture_id") or item.get("api_fixture_id") or 0)
    home_id = int(match.get("home_team_id") or 0)
    away_id = int(match.get("away_team_id") or 0)
    raw_home = str(match.get("home") or "홈팀")
    raw_away = str(match.get("away") or "원정팀")
    home = str(match.get("home_name_ko") or _world_team_display_name(raw_home, home_id) or raw_home)
    away = str(match.get("away_name_ko") or _world_team_display_name(raw_away, away_id) or raw_away)
    league_id = int(match.get("league_id") or 0)
    season = match.get("season")
    kickoff = datetime.fromisoformat(str(match.get("kickoff_at") or "").replace("Z", "+00:00"))
    if kickoff.tzinfo is None:
        kickoff = kickoff.replace(tzinfo=KST)
    kickoff = kickoff.astimezone(KST)
    diff_hours = (kickoff - now).total_seconds() / 3600.0
    analysis_stage = _world_analysis_stage(diff_hours)
    if analysis_stage in {"LOCKED_AFTER_KICKOFF", "WAITING_ANALYSIS_WINDOW"}:
        raise ValueError(f"not analyzable in stage {analysis_stage}")

    heavy_ttl = 24
    # R7.12.31 parity contract: WORLD and PROTO use the same full-context
    # evidence from the first publishable analysis.  Data source may differ
    # (Betman vs overseas bookmaker board), but recent detailed stats, next
    # schedule and lineup-learning inputs are not deferred merely because a
    # WORLD fixture is more than three hours away.
    near_kickoff_context = True
    injury_ttl = 0.5 if diff_hours <= 3 else 12
    odds = _world_market_snapshot_for_analysis(
        item, fixture_id, diff_hours, now=now
    )
    odds_movement = capture_odds_movement(
        fixture_id, "WORLD", analysis_stage, odds
    )
    h_market_bonus = float(odds_movement.get("home_bonus") or 0)
    a_market_bonus = float(odds_movement.get("away_bonus") or 0)
    h_long = fetch_team_long_term_stats_api(home_id, heavy_ttl)
    a_long = fetch_team_long_term_stats_api(away_id, heavy_ttl)
    h_recent = fetch_team_recent_form_metrics(home_id, heavy_ttl)
    a_recent = fetch_team_recent_form_metrics(away_id, heavy_ttl)
    empty_recent_stats = {
        "possession": 50, "shots_on_goal": 4.0, "corners": 4.5,
        "yellow_cards": 1.5, "sample_size": 0, "xg": None,
        "xg_sample_size": 0, "xga": None, "xga_sample_size": 0,
        "field_samples": {}, "source_fixture_ids": [],
    }
    h_stats = (
        fetch_recent_team_stats_api(home_id, heavy_ttl)
        if near_kickoff_context else dict(empty_recent_stats)
    )
    a_stats = (
        fetch_recent_team_stats_api(away_id, heavy_ttl)
        if near_kickoff_context else dict(empty_recent_stats)
    )
    h_stand = fetch_team_standing_api(home_id, heavy_ttl, league_id, season)
    a_stand = fetch_team_standing_api(away_id, heavy_ttl, league_id, season)
    h_survival = calculate_survival_motivation(h_stand)
    a_survival = calculate_survival_motivation(a_stand)
    # 맞대결·감독은 첫 공개픽에서 발견되어야 한다. 이후 경기직전
    # 정보를 알게 되어도 이미 공개된 픽은 바꾸지 않기 때문이다.
    h2h = fetch_fixture_details_api(home_id, away_id, heavy_ttl)
    h_manager = fetch_new_manager_status(home_id, heavy_ttl)
    a_manager = fetch_new_manager_status(away_id, heavy_ttl)
    is_derby = check_derby_match(raw_home, raw_away)
    injury_map = fetch_world_injuries_snapshot(
        fixture_id, home_id, away_id, league_id, season, injury_ttl
    )
    h_inj = injury_map.get(str(home_id), {})
    a_inj = injury_map.get(str(away_id), {})

    # 선발 예측의 첫 단계: 공식 명단을 지어내지 않고, 실제 스쿼드/출전
    # 기록에서 확인된 핵심 후보만 동결 저장한다. 공식 선발이 발표되면 같은
    # 스냅샷에서 일치/누락을 비교해 다음 분석의 학습 자료로 사용한다.
    h_core = get_expected_core_players(home_id, league_id, season)
    a_core = get_expected_core_players(away_id, league_id, season)
    h_predicted_xi, h_lineup_prediction = predict_starting_xi(
        home_id, league_id, season,
        h_inj.get("all_names") or h_inj.get("ace_names") or [],
        historical_lineups=near_kickoff_context,
    )
    a_predicted_xi, a_lineup_prediction = predict_starting_xi(
        away_id, league_id, season,
        a_inj.get("all_names") or a_inj.get("ace_names") or [],
        historical_lineups=near_kickoff_context,
    )
    lineup_data = {"confirmed": False}
    h_missing = []
    a_missing = []
    h_unexpected = []
    a_unexpected = []
    if diff_hours <= 1.0:
        lineup_data = fetch_lineups_api(fixture_id, 0.2)
        if lineup_data.get("confirmed"):
            h_missing = find_missing_core_players(
                sorted(set(h_core + list(h_inj.get("ace_names") or []))),
                lineup_data.get(str(home_id), []),
            )
            a_missing = find_missing_core_players(
                sorted(set(a_core + list(a_inj.get("ace_names") or []))),
                lineup_data.get(str(away_id), []),
            )
            h_injury_names = {
                _normalize_player_name(name) for name in h_inj.get("ace_names", [])
            }
            a_injury_names = {
                _normalize_player_name(name) for name in a_inj.get("ace_names", [])
            }
            h_unexpected = [
                name for name in h_missing
                if _normalize_player_name(name) not in h_injury_names
            ]
            a_unexpected = [
                name for name in a_missing
                if _normalize_player_name(name) not in a_injury_names
            ]
    lineup_confirmed = bool(lineup_data.get("confirmed"))

    h_last = fetch_team_last_match_date_api(home_id, heavy_ttl)
    a_last = fetch_team_last_match_date_api(away_id, heavy_ttl)
    h_rest = calculate_rest_days(h_last.get("date"), match.get("match_time"))
    a_rest = calculate_rest_days(a_last.get("date"), match.get("match_time"))
    h_next = (
        fetch_team_next_fixture_api(home_id, heavy_ttl)
        if near_kickoff_context else {"days_until_next": 99, "is_important": False, "league_name": ""}
    )
    a_next = (
        fetch_team_next_fixture_api(away_id, heavy_ttl)
        if near_kickoff_context else {"days_until_next": 99, "is_important": False, "league_name": ""}
    )
    referee = str(match.get("referee") or "").strip() or None
    city = str(match.get("city") or "").strip()
    weather_condition = fetch_weather_api(city, heavy_ttl) if city else None
    weather_details = fetch_weather_details_api(city, heavy_ttl) if city else {
        "available": False, "condition": "Unknown", "city": ""
    }

    injuries_for_quality = {"home": h_inj, "away": a_inj}
    quality_score, quality_grade, missing_data = _world_data_quality(
        match, odds, h_recent, a_recent, h_long, a_long,
        h_stand, a_stand, injuries_for_quality, lineup_confirmed,
    )
    confidence = calculate_data_confidence(
        {"id": home_id}, {"id": away_id}, fixture_id,
        h_stand, a_stand, h_long, a_long, h_recent, a_recent,
        h_stats, a_stats, h_inj, a_inj, diff_hours, lineup_confirmed,
    )
    confidence = round(
        max(0.35, min(float(confidence), max(0.35, quality_score / 100.0))), 3
    )

    league_name = str(match.get("league_name_ko") or match.get("league") or "")
    h_rank = int(h_stand.get("rank") or 99)
    a_rank = int(a_stand.get("rank") or 99)
    wdl_odds = odds.get("1x2") or {}
    valid_wdl_odds = all(float(wdl_odds.get(side) or 0) > 1.0 for side in ("home", "draw", "away"))

    h_war_pct, h_war_details, _ = calculate_war_penalty(
        home, h_inj.get("ace_names") or [], int(h_inj.get("count") or 0), home_id
    )
    a_war_pct, a_war_details, _ = calculate_war_penalty(
        away, a_inj.get("ace_names") or [], int(a_inj.get("count") or 0), away_id
    )
    h_lineup_penalty = 0.12 if len(h_unexpected) == 1 else (0.20 if len(h_unexpected) >= 2 else 0.0)
    a_lineup_penalty = 0.12 if len(a_unexpected) == 1 else (0.20 if len(a_unexpected) >= 2 else 0.0)
    h_fatigue = (0.15 if h_last.get("is_extreme_fatigue") else 0.08) if h_rest <= 3 else 0.0
    a_fatigue = (0.15 if a_last.get("is_extreme_fatigue") else 0.08) if a_rest <= 3 else 0.0
    h_rotation = 0.10 if h_next.get("is_important") and int(h_next.get("days_until_next") or 99) <= 4 else 0.0
    a_rotation = 0.10 if a_next.get("is_important") and int(a_next.get("days_until_next") or 99) <= 4 else 0.0
    h_team_goals = float(h_stand.get("team_goals") or 0)
    a_team_goals = float(a_stand.get("team_goals") or 0)
    h_one_player = 0.15 if h_team_goals > 0 and float(h_inj.get("missing_goals") or 0) / h_team_goals >= 0.25 else 0.0
    a_one_player = 0.15 if a_team_goals > 0 and float(a_inj.get("missing_goals") or 0) / a_team_goals >= 0.25 else 0.0
    h_total_teams = int(h_stand.get("total_teams") or 20)
    a_total_teams = int(a_stand.get("total_teams") or 20)
    h_played = int(h_stand.get("played") or 0)
    a_played = int(a_stand.get("played") or 0)
    h_late_season = h_played > 0 and h_played / max(1, (h_total_teams - 1) * 2) >= 0.75
    a_late_season = a_played > 0 and a_played / max(1, (a_total_teams - 1) * 2) >= 0.75
    h_vacation = 0.08 if h_late_season and 6 <= h_rank <= max(10, h_total_teams - 4) else 0.0
    a_vacation = 0.08 if a_late_season and 6 <= a_rank <= max(10, a_total_teams - 4) else 0.0
    h_depth = calculate_squad_depth_factor(h_stand)
    a_depth = calculate_squad_depth_factor(a_stand)
    h_penalties = sorted(
        [h_war_pct, h_fatigue, h_rotation, h_lineup_penalty, h_vacation, h_one_player],
        reverse=True,
    )
    a_penalties = sorted(
        [a_war_pct, a_fatigue, a_rotation, a_lineup_penalty, a_vacation, a_one_player],
        reverse=True,
    )
    h_total_penalty = combine_availability_penalties(h_war_pct, h_lineup_penalty, h_one_player, h_fatigue, h_rotation, h_depth)
    a_total_penalty = combine_availability_penalties(a_war_pct, a_lineup_penalty, a_one_player, a_fatigue, a_rotation, a_depth)
    h_rank_bonus = max(-0.18, min(0.18, (a_rank - h_rank) * 0.012)) if 99 not in (h_rank, a_rank) else 0.0
    a_rank_bonus = -h_rank_bonus
    h2h_total = int(h2h.get("total") or 0)
    h_h2h = (
        max(-0.10, min(0.10, ((int(h2h.get("h_wins") or 0) - int(h2h.get("a_wins") or 0)) / h2h_total) * 0.12))
        if h2h_total else 0.0
    )
    a_h2h = -h_h2h
    h_matchup = 0.04 if h2h_total >= 3 and int(h2h.get("h_wins") or 0) / h2h_total >= 0.65 else 0.0
    a_matchup = 0.04 if h2h_total >= 3 and int(h2h.get("a_wins") or 0) / h2h_total >= 0.65 else 0.0
    h_title = 0.06 if 1 <= h_rank <= 3 else 0.0
    a_title = 0.06 if 1 <= a_rank <= 3 else 0.0
    h_manager_buff = 0.08 if h_manager.get("is_new_manager") else 0.0
    a_manager_buff = 0.08 if a_manager.get("is_new_manager") else 0.0
    exp_h, exp_a, goal_model_audit = estimate_match_goals(
        h_long, a_long, h_recent, a_recent, h_stats, a_stats, league_name,
        h_total_penalty, a_total_penalty,
    )
    exp_h, exp_a, goal_model_audit = apply_cached_opponent_model(
        exp_h, exp_a, goal_model_audit, home_id, away_id, league_id, kickoff,
        h_total_penalty, a_total_penalty,
    )
    exp_h, exp_a, context_audit, goal_model_audit = integrate_pre_match_context(
        exp_h, exp_a,
        {
            "h2h": h2h, "home_rank": h_rank, "away_rank": a_rank,
            "home_recent_strength": float(h_recent.get("strength") or 0),
            "away_recent_strength": float(a_recent.get("strength") or 0),
            "recent_available": min(int(h_recent.get("matches") or 0), int(a_recent.get("matches") or 0)) >= 3,
            "home_absence": h_total_penalty, "away_absence": a_total_penalty,
            "home_title": h_title, "away_title": a_title,
            "home_manager": h_manager_buff, "away_manager": a_manager_buff,
            "home_vacation": h_vacation, "away_vacation": a_vacation,
            "home_survival": h_survival, "away_survival": a_survival,
            "home_market": h_market_bonus, "away_market": a_market_bonus,
            "weather": weather_condition, "referee": referee,
            "is_derby": is_derby,
        },
        goal_model_audit,
    )

    totals_odds = odds.get("totals") or {}
    uo_base = float(totals_odds.get("line") or 2.5)
    handicap_odds = odds.get("handicap") or {}
    preliminary = calculate_poisson_probs(exp_h, exp_a, 0.0, uo_base)
    handi_base = handicap_odds.get("line")
    if handi_base is None:
        handi_base = -1.0 if preliminary[0] >= preliminary[2] else 1.0
    handi_base = float(handi_base)
    movement_policy = market_performance.get("_movement_policy") or {}
    movement_adjustment = learned_movement_wdl_adjustment(
        odds_movement, movement_policy, league_name
    )
    probabilities, joint_audit, joint_matrix = coherent_match_forecast(
        exp_h, exp_a, handi_base, uo_base,
        [wdl_odds.get(side) for side in ("home", "draw", "away")], confidence,
        market_performance.get("1x2"), goal_model_audit.get("rho", -.15),
        movement_adjustment, context_audit.get("wdl_log_adjustment"),
    )
    joint_audit["movement_policy"] = {
        key: movement_policy.get(key) for key in
        ("active", "method", "cohort_fixtures", "validation_fixtures",
         "baseline_brier", "corrected_brier", "reason")
    }
    h_win, draw, a_win, prob_u, prob_o, handi_h, handi_d, handi_a = probabilities
    goal_model_audit["joint_forecast"] = joint_audit
    valid_totals_odds = all(float(totals_odds.get(side) or 0) > 1.0 for side in ("under", "over"))
    valid_handicap_odds = all(float(handicap_odds.get(side) or 0) > 1.0 for side in ("home", "draw", "away"))

    wdl_market = normalize_probabilities([
        1.0 / float(wdl_odds["home"]), 1.0 / float(wdl_odds["draw"]), 1.0 / float(wdl_odds["away"]),
    ]) if valid_wdl_odds else [0.0, 0.0, 0.0]
    totals_market = normalize_probabilities([
        1.0 / float(totals_odds["under"]), 1.0 / float(totals_odds["over"]),
    ]) if valid_totals_odds else [0.0, 0.0]
    handicap_market = normalize_probabilities([
        1.0 / float(handicap_odds["home"]), 1.0 / float(handicap_odds["draw"]),
        1.0 / float(handicap_odds["away"]),
    ]) if valid_handicap_odds else [0.0, 0.0, 0.0]
    candidates = [
        {"label": "일반 승무패 예측", "sort_id": 3, "raw_pick": f"{home} 승", "prob": h_win, "odd": float(wdl_odds.get("home") or 0), "market_prob": wdl_market[0], "selection_side": "home"},
        {"label": "일반 승무패 예측", "sort_id": 3, "raw_pick": "무승부", "prob": draw, "odd": float(wdl_odds.get("draw") or 0), "market_prob": wdl_market[1], "selection_side": "draw"},
        {"label": "일반 승무패 예측", "sort_id": 3, "raw_pick": f"{away} 승", "prob": a_win, "odd": float(wdl_odds.get("away") or 0), "market_prob": wdl_market[2], "selection_side": "away"},
        {"label": "핸디캡 예측", "sort_id": 2, "raw_pick": f"[{handi_base:+.1f}] {home} 핸디승", "prob": handi_h, "odd": float(handicap_odds.get("home") or 0), "market_prob": handicap_market[0], "selection_side": "home", "handicap_base": handi_base},
        {"label": "핸디캡 예측", "sort_id": 2, "raw_pick": f"[{handi_base:+.1f}] 핸디무", "prob": handi_d, "odd": float(handicap_odds.get("draw") or 0), "market_prob": handicap_market[1], "selection_side": "draw", "handicap_base": handi_base},
        {"label": "핸디캡 예측", "sort_id": 2, "raw_pick": f"[{handi_base:+.1f}] {home} 핸디패", "prob": handi_a, "odd": float(handicap_odds.get("away") or 0), "market_prob": handicap_market[2], "selection_side": "away", "handicap_base": handi_base},
        {"label": "언더 예측", "sort_id": 1, "raw_pick": f"언더 (U/O {uo_base:g})", "prob": prob_u, "odd": float(totals_odds.get("under") or 0), "market_prob": totals_market[0], "selection_side": "under"},
        {"label": "오버 예측", "sort_id": 1, "raw_pick": f"오버 (U/O {uo_base:g})", "prob": prob_o, "odd": float(totals_odds.get("over") or 0), "market_prob": totals_market[1], "selection_side": "over"},
    ]
    attach_analysis_contracts(candidates, exp_h, exp_a, uo_base, goal_model_audit, joint_matrix)
    calibrate_market_candidates(candidates, market_performance, confidence)
    underdog_side = (
        "home" if float(wdl_odds.get("home") or 0) > float(wdl_odds.get("away") or 0)
        else ("away" if float(wdl_odds.get("away") or 0) > float(wdl_odds.get("home") or 0) else "")
    ) if valid_wdl_odds else ""
    attach_underdog_signals(candidates, home, away, {
        "home_absence": h_total_penalty, "away_absence": a_total_penalty,
        "home_market_bonus": h_market_bonus, "away_market_bonus": a_market_bonus,
        "home_tactical": h_matchup, "away_tactical": a_matchup,
        "home_recent": float(h_recent.get("strength") or 0),
        "away_recent": float(a_recent.get("strength") or 0),
        "home_rest": h_rest if h_rest < 90 else 0,
        "away_rest": a_rest if a_rest < 90 else 0,
        "home_lineup": h_lineup_penalty,
        "away_lineup": a_lineup_penalty,
        "home_rank": h_rank, "away_rank": a_rank,
        "home_title": h_title, "away_title": a_title,
        "home_manager": h_manager_buff, "away_manager": a_manager_buff,
        "home_survival": h_survival, "away_survival": a_survival,
        "home_venue_model": True,
        "context_audit": context_audit,
        "underdog_side": underdog_side,
        "movement": odds_movement,
    })
    annotate_pick_metrics(candidates, confidence)
    categories, _ = select_pick_categories(candidates, confidence)
    lineup_learning = {
        "schema_version": ROBOT_LINEUP_SCHEMA_VERSION,
        "mode": "predicted-xi-then-official-answer-v2",
        "home_team_id": home_id,
        "away_team_id": away_id,
        "not_full_starting_xi": len(h_predicted_xi) < 11 or len(a_predicted_xi) < 11,
        "home_predicted_core": list(h_core),
        "away_predicted_core": list(a_core),
        "home_predicted_starting_xi": list(h_predicted_xi),
        "away_predicted_starting_xi": list(a_predicted_xi),
        "home_official_starters": list(lineup_data.get(str(home_id), []) or []),
        "away_official_starters": list(lineup_data.get(str(away_id), []) or []),
        "home_active_starting_xi": list(lineup_data.get(str(home_id), []) or h_predicted_xi),
        "away_active_starting_xi": list(lineup_data.get(str(away_id), []) or a_predicted_xi),
        "official_details": lineup_data.get("details") or {},
        "home_prediction_audit": h_lineup_prediction,
        "away_prediction_audit": a_lineup_prediction,
        "official_replaced_prediction": lineup_confirmed,
        "home_confirmed_core": [name for name in h_core if name not in h_missing]
        if lineup_confirmed else [],
        "away_confirmed_core": [name for name in a_core if name not in a_missing]
        if lineup_confirmed else [],
    }
    world_full_evidence = _robot_full_pre_match_evidence(
        "WORLD", match, league_name, league_id, season,
        {"id": home_id, "name": home, "raw_name": raw_home, "venue_role": "home"},
        {"id": away_id, "name": away, "raw_name": raw_away, "venue_role": "away"},
        h_recent, a_recent, h_stats, a_stats, h_long, a_long,
        h_stand, a_stand, h_survival, a_survival,
        injuries_for_quality, lineup_learning,
        {"home": h_rest, "away": a_rest},
        {
            "home": fetch_team_recent_fixtures_api(home_id, heavy_ttl),
            "away": fetch_team_recent_fixtures_api(away_id, heavy_ttl),
        },
        {"home": h_next, "away": a_next},
        {"home": h_manager, "away": a_manager}, h2h,
        {
            "city": city, "weather": weather_condition,
            "weather_details": weather_details, "referee": referee,
            "derby": is_derby, "home_venue": True,
        },
        odds, odds_movement, goal_model_audit, context_audit, confidence,
        {"score": quality_score, "grade": quality_grade, "missing": missing_data},
        {
            "home_total_penalty": h_total_penalty,
            "away_total_penalty": a_total_penalty,
            "home_rank_signal": h_rank_bonus, "away_rank_signal": a_rank_bonus,
            "home_matchup_signal": h_matchup, "away_matchup_signal": a_matchup,
            "home_title_signal": h_title, "away_title_signal": a_title,
            "home_market_signal": h_market_bonus, "away_market_signal": a_market_bonus,
        },
    )
    robot_features = build_autonomous_robot_features(
        goal_model_audit, context_audit, candidates, confidence,
        {
            "source_world": 1.0,
            "home_rank": 0 if h_rank == 99 else h_rank,
            "away_rank": 0 if a_rank == 99 else a_rank,
            "home_rank_known": h_rank != 99,
            "away_rank_known": a_rank != 99,
            "home_recent_strength": h_recent.get("strength", 0.0),
            "away_recent_strength": a_recent.get("strength", 0.0),
            "home_rest_days": 0 if h_rest >= 90 else h_rest,
            "away_rest_days": 0 if a_rest >= 90 else a_rest,
            "home_rest_known": h_rest < 90,
            "away_rest_known": a_rest < 90,
            "home_absence": h_total_penalty,
            "away_absence": a_total_penalty,
            "home_lineup_penalty": h_lineup_penalty,
            "away_lineup_penalty": a_lineup_penalty,
            "lineup_confirmed": lineup_confirmed,
            "h2h_total": h2h_total,
            "h2h_home_wins": h2h.get("h_wins", 0),
            "h2h_draws": h2h.get("draws", 0),
            "h2h_away_wins": h2h.get("a_wins", 0),
            "is_derby": is_derby,
            "home_survival_active": bool(h_survival.get("active")),
            "away_survival_active": bool(a_survival.get("active")),
            "home_manager_active": h_manager_buff > 0,
            "away_manager_active": a_manager_buff > 0,
            "home_vacation_active": h_vacation > 0,
            "away_vacation_active": a_vacation > 0,
            "home_market_signal": h_market_bonus > 0,
            "away_market_signal": a_market_bonus > 0,
            "adverse_weather": str(weather_condition or "").casefold() in {"rain", "snow"},
        },
        all_evidence=world_full_evidence,
    )
    # Restored V4 is retired from active calculation. Historical rows remain
    # in SQLite, but no new scheduled match receives a V4 answer.
    legacy_v4_candidates = []
    legacy_v4_pick = {}
    robot_candidates = build_autonomous_robot_candidates(
        candidates, robot_features, _load_autonomous_robot_artifact("WORLD")
    )
    robot_pick = select_autonomous_robot_pick(
        robot_candidates, confidence, robot_features, source="WORLD"
    )
    alphago_pick = _alphago_pick_payload(robot_pick)
    # World VIP is a future paid-grade candidate.  A strong price alone cannot
    # bypass the separately agreed 90/100 input-quality gate.
    if quality_score < 90:
        categories["vip_underdog"] = None
        downgraded_grade = "value" if categories.get("honey") else "standard"
        for category_key in ("high_probability", "honey"):
            if categories.get(category_key):
                categories[category_key]["final_pick_grade"] = downgraded_grade
    selected = categories.get("high_probability")
    tactical_parts = []
    if h_matchup:
        tactical_parts.append(f"{home} 천적 상성")
    if a_matchup:
        tactical_parts.append(f"{away} 천적 상성")
    if is_derby:
        tactical_parts.append("로컬 더비 변동성")
    if h_survival.get("active"):
        tactical_parts.append(f"{home} 강등권 생존 동기")
    if a_survival.get("active"):
        tactical_parts.append(f"{away} 강등권 생존 동기")
    motivation_parts = []
    if h_title: motivation_parts.append(f"{home} 상위권 경쟁")
    if a_title: motivation_parts.append(f"{away} 상위권 경쟁")
    if h_manager_buff: motivation_parts.append(f"{home} 새 감독")
    if a_manager_buff: motivation_parts.append(f"{away} 새 감독")
    if h_vacation: motivation_parts.append(f"{home} 말기 중위권 동기 저하")
    if a_vacation: motivation_parts.append(f"{away} 말기 중위권 동기 저하")
    evidence, coverage = build_analysis_evidence({
        "h_recent": h_recent, "a_recent": a_recent,
        "h_stats": h_stats, "a_stats": a_stats, "h_long": h_long, "a_long": a_long,
        "h_inj": h_inj, "a_inj": a_inj,
        "h2h_total": h2h_total, "h_wins": int(h2h.get("h_wins") or 0),
        "draws": int(h2h.get("draws") or 0), "a_wins": int(h2h.get("a_wins") or 0),
        "home_rank": h_rank, "away_rank": a_rank,
        "h_rest_days": h_rest, "a_rest_days": a_rest,
        "weather": weather_condition,
        "referee": referee,
        "motivation_text": ", ".join(motivation_parts),
        "tactical_text": ", ".join(tactical_parts),
        "movement_text": odds_movement.get("summary") or None,
        "home_id": home_id, "away_id": away_id, "fixture_id": fixture_id,
    })
    if odds.get("available_markets"):
        evidence.append({
            "name": "시장 배당", "weight": 0.25,
            "value": f"{', '.join(odds['available_markets'])} · {int(odds.get('bookmaker_count') or 0)}개 업체 중앙값",
        })
    evidence.append({
        "name": "데이터 품질", "weight": 0.0,
        "value": f"{quality_score}/100 ({quality_grade})",
    })
    candidate_rows, compact_categories, decision = build_pick_selection_audit(
        candidates, categories, confidence, robot_pick=robot_pick,
        lineup_prediction=lineup_learning,
    )
    report = build_detailed_report(
        selected, evidence, confidence, candidates, categories,
        {
            "home": home, "away": away, "exp_h": exp_h, "exp_a": exp_a,
            "weather": weather_condition,
        },
    )
    robot_report = robot_pick_report(robot_pick, home)
    if robot_report:
        report += "\n\n" + robot_report
    analyzed_at = datetime.now(KST).isoformat()
    frozen_at = analyzed_at if analysis_stage == "T-30-final" else None
    selected_summary = dict(compact_categories.get("high_probability") or {})
    selected_summary["display"] = _human_pick_label(selected_summary.get("raw_pick"), home)
    selected_summary["badges"] = [
        label for key, label in (
            ("honey", "배당가치 우수"), ("vip_underdog", "VIP 검증 등급")
        ) if compact_categories.get(key)
    ]
    inputs_snapshot = {
        "home_team_id": home_id, "away_team_id": away_id,
        "match_identity": dict(match),
        "league_id": league_id, "season": season, "fixture_id": fixture_id,
        "kickoff_at": kickoff.isoformat(), "expected_goals": {"home": exp_h, "away": exp_a},
        "goal_model_audit": goal_model_audit,
        "recent": {"home": h_recent, "away": a_recent},
        "recent_match_stats": {"home": h_stats, "away": a_stats},
        "long_term": {"home": h_long, "away": a_long},
        "standings": {"home": h_stand, "away": a_stand},
        "survival_motivation": {"home": h_survival, "away": a_survival},
        "injuries": injuries_for_quality,
        "lineups": {
            "confirmed": lineup_confirmed,
            "home_missing_core": h_missing, "away_missing_core": a_missing,
        },
        "lineup_learning": lineup_learning,
        "rest_days": {"home": h_rest, "away": a_rest},
        "next_fixture": {"home": h_next, "away": a_next},
        "manager": {"home": h_manager, "away": a_manager},
        "environment": {
            "city": city, "weather": weather_condition,
            "weather_details": weather_details, "referee": referee,
            "derby": is_derby,
        },
        "adjustments": {
            "home_penalty": h_total_penalty, "away_penalty": a_total_penalty,
            "home_rank": h_rank_bonus, "away_rank": a_rank_bonus,
            "home_title": h_title, "away_title": a_title,
            "home_manager": h_manager_buff, "away_manager": a_manager_buff,
            "home_market": h_market_bonus, "away_market": a_market_bonus,
            "home_war": h_war_details, "away_war": a_war_details,
        },
        "h2h": h2h, "evidence_coverage": coverage,
        "odds_movement": odds_movement,
        "context_pass": "proto-parity-full-context",
    }
    return {
        "analysis_version": WORLD_ANALYSIS_VERSION,
        "system_version": SYSTEM_VERSION,
        "analysis_stage": analysis_stage,
        "analyzed_at": analyzed_at,
        "frozen_at": frozen_at,
        "data_quality_score": quality_score,
        "data_quality_grade": quality_grade,
        "missing_data": missing_data,
        "lineup_confirmed": lineup_confirmed,
        "odds_snapshot": odds,
        "odds_movement": odds_movement,
        "inputs_snapshot": inputs_snapshot,
        "evidence": evidence,
        "candidates": candidate_rows,
        "categories": compact_categories,
        "selected": selected_summary,
        "legacy_v4_pick": legacy_v4_pick,
        "legacy_v4_candidates": legacy_v4_candidates,
        "robot_pick": dict(compact_categories.get("robot_independent") or {}),
        "alphago_pick": alphago_pick,
        "robot_features": robot_features,
        "robot_full_evidence": world_full_evidence,
        "robot_lineup_prediction": lineup_learning,
        "robot_candidates": robot_candidates,
        "robot_wdl_probabilities": {
            str(candidate.get("selection_side")): round(float(candidate.get("robot_probability") or 0), 8)
            for candidate in robot_candidates
            if candidate.get("market_key") == "1x2"
        },
        "alternative": {},
        "learning_robot": dict(decision.get("learning_robot") or {}),
        "decision": decision,
        "report": report,
    }


def analyze_world_schedule():
    """Run stage 6-2 without exposing any unverified prediction to customers."""
    payload = _read_json(WORLD_DASHBOARD_FILE, {})
    if not isinstance(payload, dict) or not isinstance(payload.get("matches"), list):
        print("⚠️ 세계경기 일정 정상본이 없어 그림자 분석을 건너뜁니다.")
        return False, False
    now = datetime.now(KST)
    canonical_proto_by_fixture = _dashboard_proto_by_fixture()
    proto_overlaps = _exclude_proto_overlaps(
        payload, canonical_proto_by_fixture
    )
    preview_items = _ensure_world_market_previews(payload, now=now)
    day_key, today_ids, all_ids, league_counts = _world_analysis_usage()
    market_performance_cache = {}
    changed = bool(preview_items or proto_overlaps)
    analyzed_now = 0
    errors_now = 0
    quota_paused = False
    soft_paused = False
    world_brake_reason = ""
    due_visited = 0
    analysis_deadline = time.monotonic() + WORLD_ANALYSIS_SOFT_SECONDS
    stage_priority = {
        "T-30-final": 0, "T-60-lineup": 1,
        "T-3-refresh": 2, "PREKICKOFF-initial": 3,
    }
    due_items = []
    market_watch_items = []

    for item in payload.get("matches", []):
        match = item.get("match") or {}
        home_ko = _world_team_display_name(
            match.get("home"), match.get("home_team_id")
        )
        away_ko = _world_team_display_name(
            match.get("away"), match.get("away_team_id")
        )
        if home_ko and match.get("home_name_ko") != home_ko:
            match["home_name_ko"] = home_ko
            changed = True
        if away_ko and match.get("away_name_ko") != away_ko:
            match["away_name_ko"] = away_ko
            changed = True
        try:
            fixture_id = int(match.get("fixture_id") or item.get("api_fixture_id") or 0)
        except (TypeError, ValueError):
            fixture_id = 0
        # Same provider fixture is published and graded only once in Proto.
        # The overlap filter above removes these before any preview/deep calls.
        if fixture_id in canonical_proto_by_fixture:
            continue
        if item.get("analysis"):
            public_analysis = _public_world_analysis_from_first_snapshot(
                match, item.get("analysis") or {}
            )
            if public_analysis != item.get("analysis"):
                item["analysis"] = public_analysis
                changed = True
        try:
            kickoff = datetime.fromisoformat(str(match.get("kickoff_at") or "").replace("Z", "+00:00"))
            if kickoff.tzinfo is None:
                kickoff = kickoff.replace(tzinfo=KST)
            kickoff = kickoff.astimezone(KST)
        except (TypeError, ValueError):
            item["analysis_status"] = "ANALYSIS_ERROR"
            item["analysis_error"] = "킥오프 시간 해석 실패"
            changed = True
            errors_now += 1
            continue
        stage = _world_analysis_stage((kickoff - now).total_seconds() / 3600.0)
        if stage == "WAITING_ANALYSIS_WINDOW":
            if item.get("analysis_status") == "PENDING_SHADOW_ANALYSIS":
                item["analysis_status"] = stage
                changed = True
            continue
        if stage == "LOCKED_AFTER_KICKOFF":
            if str((item.get("analysis") or {}).get("analysis_stage") or "") == "market-preview":
                item["analysis_status"] = "MISSED_PREKICKOFF"
                item["pick_status"] = "PROVISIONAL_PREVIEW_EXPIRED"
                changed = True
            elif not item.get("analysis") and item.get("analysis_status") not in {
                "MISSED_PREKICKOFF", "FROZEN_SHADOW"
            }:
                item["analysis_status"] = "MISSED_PREKICKOFF"
                item["pick_status"] = "NOT_ANALYZED"
                changed = True
            continue
        previous_stage = str(item.get("analysis_stage") or "")
        previous_version = str(
            item.get("analysis_version")
            or (item.get("analysis") or {}).get("analysis_version")
            or ""
        )
        frozen = bool(
            item.get("frozen_at")
            or item.get("analysis_status") == "FROZEN_SHADOW"
        )
        refresh_old_version = _needs_current_analysis_refresh(
            item, kickoff, now, WORLD_ANALYSIS_VERSION
        )
        refresh_robot = _needs_current_robot_refresh(item, kickoff, now, "WORLD")
        lineup_retry_due = bool(
            stage == "T-60-lineup"
            and not item.get("lineup_confirmed")
            and int(item.get("lineup_attempts") or 0) < 2
        )
        refresh_stage = previous_stage != stage
        refresh_current = bool(
            refresh_old_version or refresh_robot or refresh_stage or lineup_retry_due
        )
        if frozen and not refresh_current:
            if (
                fixture_id > 0 and isinstance(item.get("analysis"), dict)
                and 0 < (kickoff - now).total_seconds() / 3600.0
                <= WORLD_MARKET_WATCH_HORIZON_HOURS
            ):
                market_watch_items.append((item, kickoff))
            continue
        if frozen and refresh_current:
            reasons = []
            if refresh_old_version:
                reasons.append("공식 버전")
            if refresh_robot:
                reasons.append("로봇 학습")
            if refresh_stage:
                reasons.append(f"단계 {previous_stage or '미기록'}→{stage}")
            if lineup_retry_due:
                reasons.append("선발 재확인")
            print(
                f"🔄 시작 전 세계분석 갱신: "
                f"{match.get('home')} vs {match.get('away')} · "
                f"{', '.join(reasons)}"
            )
        if (
            previous_stage == stage
            and previous_version == WORLD_ANALYSIS_VERSION
            and not refresh_robot
        ):
            if not (
                stage == "T-60-lineup"
                and not item.get("lineup_confirmed")
                and int(item.get("lineup_attempts") or 0) < 2
            ):
                if (
                    fixture_id > 0 and isinstance(item.get("analysis"), dict)
                    and 0 < (kickoff - now).total_seconds() / 3600.0
                    <= WORLD_MARKET_WATCH_HORIZON_HOURS
                ):
                    market_watch_items.append((item, kickoff))
                continue
        due_items.append((stage_priority.get(stage, 9), float(item.get("timestamp") or 0), stage, item))

    due_items.sort(key=lambda row: (row[0], row[1]))
    world_calls_before = int(get_api_usage_status().get("world_calls") or 0)
    with api_purpose_context("world"):
        for _, _, stage, item in due_items:
            processed_this_pass = analyzed_now + errors_now
            brake_reason = _analysis_pass_brake_reason(
                processed_this_pass, WORLD_ANALYSIS_NEW_MATCHES_PER_PASS,
                analysis_deadline,
            )
            if brake_reason:
                soft_paused = True
                world_brake_reason = brake_reason
                changed = True
                print(
                    "⏸️ WORLD 자동 브레이크: "
                    f"{brake_reason} · 완료 {analyzed_now}경기 / "
                    f"최대 {WORLD_ANALYSIS_NEW_MATCHES_PER_PASS}경기 · 다음 WORLD 차례에서 자동 재개"
                )
                break
            due_visited += 1
            match = item.get("match") or {}
            fixture_id = int(match.get("fixture_id") or item.get("api_fixture_id") or 0)
            league_id = int(match.get("league_id") or 0)
            is_existing = fixture_id in all_ids
            if not is_existing and len(today_ids) >= WORLD_MAX_DEEP_ANALYSES_DAILY:
                if item.get("analysis_status") != "DEFERRED_DAILY_CAP":
                    item["analysis_status"] = "DEFERRED_DAILY_CAP"
                    changed = True
                continue
            if (
                not is_existing
                and int(league_counts.get(league_id, 0)) >= WORLD_MAX_DEEP_ANALYSES_PER_LEAGUE
            ):
                if item.get("analysis_status") != "DEFERRED_LEAGUE_CAP":
                    item["analysis_status"] = "DEFERRED_LEAGUE_CAP"
                    changed = True
                continue
            try:
                league_name = str(
                    match.get("league_name_ko") or match.get("league") or ""
                )
                if league_name not in market_performance_cache:
                    market_performance_cache[league_name] = load_market_performance(
                        league_name, serving_only=MASTER_CACHE_ONLY_SERVING
                    )
                analysis = _analyze_world_match(
                    item, now, market_performance_cache[league_name]
                )
                completed_at = datetime.now(KST)
                if completed_at >= _parse_kst_match_time(match.get("match_time")):
                    item["analysis_status"] = "MISSED_PREKICKOFF"
                    continue  # Do not label a late computation as a frozen forecast.
                analysis["analyzed_at"] = completed_at.isoformat()
                if not _save_world_analysis_snapshot(match, analysis):
                    raise RuntimeError("세계경기 분석 스냅샷 저장 실패")
                if not _save_world_learning_record(match, analysis):
                    raise RuntimeError("세계경기 통합 채점 기록 저장 실패")
                analysis = _public_world_analysis_from_first_snapshot(match, analysis)
                item["analysis"] = analysis
                item["analysis_version"] = str(
                    analysis.get("analysis_version") or WORLD_ANALYSIS_VERSION
                )
                item["system_version"] = str(
                    analysis.get("system_version") or SYSTEM_VERSION
                )
                item["analysis_stage"] = analysis["analysis_stage"]
                item["analyzed_at"] = analysis["analyzed_at"]
                item["frozen_at"] = analysis.get("frozen_at")
                item["data_quality_score"] = analysis["data_quality_score"]
                item["data_quality_grade"] = analysis["data_quality_grade"]
                item["missing_data"] = analysis["missing_data"]
                item["lineup_confirmed"] = analysis["lineup_confirmed"]
                if stage == "T-60-lineup" and not analysis["lineup_confirmed"]:
                    item["lineup_attempts"] = int(item.get("lineup_attempts") or 0) + 1
                item["analysis_status"] = (
                    "FROZEN_SHADOW" if analysis.get("frozen_at") else "ANALYZED_SHADOW"
                )
                item["pick_status"] = "SHADOW_PICK_READY"
                changed = True
                analyzed_now += 1
                today_ids.add(fixture_id)
                all_ids.add(fixture_id)
                league_counts[league_id] = int(league_counts.get(league_id, 0)) + (0 if is_existing else 1)
                # A complete board can take many minutes. Keep bounded local
                # checkpoints so a worker timeout/restart resumes from the last
                # finished pre-kickoff analysis instead of repeating the board.
                if analyzed_now % WORLD_ANALYSIS_CHECKPOINT_EVERY == 0:
                    _refresh_world_source_meta(payload)
                    payload["last_analysis_checkpoint_at"] = datetime.now(KST).isoformat()
                    payload.setdefault("source_meta", {})["analysis_resume_pending_count"] = max(
                        0, len(due_items) - due_visited
                    )
                    _atomic_write_json(WORLD_DASHBOARD_FILE, payload, indent=2)
                    checkpoint_file = _write_world_publication_file()
                    if checkpoint_file is not None:
                        if upload_to_github(
                            checkpoint_file, remote_path=WORLD_DASHBOARD_FILE.name
                        ):
                            print(
                                "⚡ WORLD 우선 게시 체크포인트: "
                                f"정밀분석 {analyzed_now}경기 / 남은 {max(0, len(due_items)-due_visited)}경기"
                            )
                        else:
                            print("⚠️ WORLD 중간 게시 실패 · 로컬 저장본은 보존하고 최종 게시에서 재시도")
                print(
                    f"🧪 세계경기 그림자 분석: {match.get('home')} vs {match.get('away')} · "
                    f"{analysis['selected'].get('display')} "
                    f"{float(analysis['selected'].get('probability') or 0) * 100:.1f}% · "
                    f"품질 {analysis['data_quality_score']}점"
                )
            except ApiQuotaUnavailable as error:
                quota_paused = True
                print(f"⚠️ 세계경기 분석 예산 보호로 중단: {error}")
                break
            except Exception as error:
                errors_now += 1
                item["analysis_status"] = "ANALYSIS_ERROR"
                item["analysis_error"] = f"{type(error).__name__}: {error}"[:500]
                changed = True
                print(f"⚠️ 세계경기 분석 실패({fixture_id}): {type(error).__name__}: {error}")

        # A complete analysis is intentionally not rerun inside the same
        # stage, but the overseas line keeps moving. Append its latest cached
        # or refreshed pre-kickoff state without touching the published pick.
        if not quota_paused:
            for item, kickoff in market_watch_items:
                if time.monotonic() >= analysis_deadline:
                    soft_paused = True
                    changed = True
                    break
                match = item.get("match") or {}
                analysis = item.get("analysis") or {}
                fixture_id = int(match.get("fixture_id") or item.get("api_fixture_id") or 0)
                diff_hours = max(
                    0.0, (kickoff - datetime.now(KST)).total_seconds() / 3600.0
                )
                _observe_locked_pick_market_flow(
                    analysis, "WORLD", str(match.get("id") or ""), fixture_id,
                    str(match.get("league_name_ko") or match.get("league") or "세계 축구"),
                    str(match.get("home") or "홈팀"),
                    str(match.get("away") or "원정팀"), kickoff, diff_hours,
                )

    previous_source_meta = json.dumps(
        payload.get("source_meta", {}), ensure_ascii=False, sort_keys=True
    )
    _refresh_world_source_meta(payload)
    source_meta = payload.setdefault("source_meta", {})
    source_meta.update({
        "analysis_day": day_key,
        "analysis_daily_limit": WORLD_MAX_DEEP_ANALYSES_DAILY,
        "analysis_per_league_limit": WORLD_MAX_DEEP_ANALYSES_PER_LEAGUE,
        "quota_paused": quota_paused,
        "analysis_soft_paused": soft_paused,
        "analysis_brake_reason": str(world_brake_reason or ""),
        "analysis_max_matches_per_pass": WORLD_ANALYSIS_NEW_MATCHES_PER_PASS,
        "analysis_resume_pending_count": max(0, len(due_items) - due_visited),
        "analysis_soft_budget_seconds": WORLD_ANALYSIS_SOFT_SECONDS,
        "api_usage": get_api_usage_status(),
    })
    metadata_changed = previous_source_meta != json.dumps(
        source_meta, ensure_ascii=False, sort_keys=True
    )
    if changed or metadata_changed:
        payload["schema_version"] = "world-shadow.v2"
        payload["stage"] = "SHADOW_ANALYSIS"
        payload["last_analysis_at"] = datetime.now(KST).isoformat()
        _atomic_write_json(WORLD_DASHBOARD_FILE, payload, indent=2)
    world_calls_after = int(get_api_usage_status().get("world_calls") or 0)
    print(
        f"✅ 세계경기 2단계 종료: 이번 분석 {analyzed_now}경기 / 오류 {errors_now} / "
        f"WORLD API {max(0, world_calls_after - world_calls_before)}회"
    )
    return True, bool(changed or metadata_changed)


def calculate_survival_motivation(standing):
    """Model relegation pressure without treating every rank 15+ team alike.

    The boost represents a verified increase in attacking urgency.  A smaller
    opponent-risk term is also returned because a team that must chase points
    can expose space; the old fixed +0.06 only made the weak team stronger.
    """
    standing = standing if isinstance(standing, dict) else {}
    result = {
        "active": False,
        "state": "NOT_APPLICABLE",
        "attack_boost": 0.0,
        "opponent_risk_boost": 0.0,
        "season_progress": 0.0,
        "rank": int(standing.get("rank") or 99),
        "relegation_start_rank": standing.get("relegation_start_rank"),
        "points_to_safety": standing.get("points_to_safety"),
        "points_above_zone": standing.get("points_above_zone"),
        "source": str(standing.get("relegation_zone_source") or "none"),
        "reason": "강등선 자료 없음",
    }
    try:
        rank = int(standing.get("rank") or 99)
        played = max(0, int(standing.get("played") or 0))
        total_teams = max(0, int(standing.get("total_teams") or 0))
        zone_start = int(standing.get("relegation_start_rank") or 0)
    except (TypeError, ValueError):
        return result
    if rank <= 0 or rank == 99 or played <= 0 or total_teams < 8 or zone_start <= 1:
        return result

    # 30경기 미만으로 시즌 전체를 가정하지 않아 소규모·스플릿 리그의
    # 시즌 중반을 막판으로 잘못 판단하는 일을 줄인다.
    estimated_schedule = max(30, (total_teams - 1) * 2)
    progress = min(1.0, played / max(1, estimated_schedule))
    result["season_progress"] = round(progress, 3)

    description = str(standing.get("description") or "").casefold()
    if any(marker in description for marker in ("relegated", "강등 확정", "descendido")):
        result.update({
            "state": "RELEGATION_CONFIRMED",
            "reason": "공식 순위표상 강등 확정으로 생존 버프 미적용",
        })
        return result

    in_zone = rank >= zone_start
    just_above_zone = rank == zone_start - 1
    points_above = standing.get("points_above_zone")
    try:
        points_above = int(points_above) if points_above is not None else None
    except (TypeError, ValueError):
        points_above = None
    at_risk = bool(just_above_zone and points_above is not None and points_above <= 3)
    if not in_zone and not at_risk:
        result.update({"state": "SAFE", "reason": "현재 강등권·강등선 인접 팀 아님"})
        return result
    if progress < 0.55:
        result.update({
            "state": "TOO_EARLY",
            "reason": "시즌 초중반이라 순위만으로 생존 버프 미적용",
        })
        return result

    if progress >= 0.88:
        base_attack, base_risk, state = 0.055, 0.030, "SURVIVAL_MUST_WIN"
    elif progress >= 0.72:
        base_attack, base_risk, state = 0.040, 0.020, "SURVIVAL_PRESSURE"
    else:
        base_attack, base_risk, state = 0.025, 0.012, "SURVIVAL_WATCH"

    points_to_safety = standing.get("points_to_safety")
    try:
        points_to_safety = int(points_to_safety) if points_to_safety is not None else None
    except (TypeError, ValueError):
        points_to_safety = None
    if in_zone and points_to_safety is not None:
        if 1 <= points_to_safety <= 3:
            base_attack += 0.015
        elif 4 <= points_to_safety <= 6:
            base_attack += 0.010
            base_risk += 0.005
        elif points_to_safety >= 7:
            base_risk += 0.010
    if at_risk:
        base_attack *= 0.70
        base_risk *= 0.75

    # 리그 규정 설명에서 직접 찾지 못하고 팀 수로 추정한 강등선은 보수적으로 쓴다.
    if result["source"] != "official_description":
        base_attack *= 0.70
        base_risk *= 0.70

    attack_boost = round(min(0.08, max(0.0, base_attack)), 3)
    opponent_risk = round(min(0.045, max(0.0, base_risk)), 3)
    if in_zone:
        gap_text = (
            f"잔류선까지 {points_to_safety}점"
            if points_to_safety is not None
            else "강등권"
        )
        reason = f"{rank}위·{gap_text}·시즌 {int(progress * 100)}% 진행"
    else:
        reason = f"강등선 바로 위·승점 여유 {points_above}점·시즌 {int(progress * 100)}% 진행"
    result.update({
        "active": True,
        "state": state,
        "attack_boost": attack_boost,
        "opponent_risk_boost": opponent_risk,
        "reason": reason,
    })
    return result


def build_match_importance_profile(home_standing, away_standing, home_next,
                                   away_next, *, is_derby=False):
    """Describe verified stakes and schedule pressure without guessing intent.

    This is a transparent analysis label, not a claim that a club will rest
    players or discard a match.  The pick model may use the existing measured
    rest/rotation penalties, while customers can see why volatility is higher.
    """
    home_survival = calculate_survival_motivation(home_standing)
    away_survival = calculate_survival_motivation(away_standing)
    score, reasons, rotation_teams = 0, [], []
    if is_derby:
        score += 3
        reasons.append("더비 일정")
    for side, standing, survival, next_fixture in (
        ("홈", home_standing or {}, home_survival, home_next or {}),
        ("원정", away_standing or {}, away_survival, away_next or {}),
    ):
        try:
            rank = int(standing.get("rank") or 99)
        except (TypeError, ValueError):
            rank = 99
        if 1 <= rank <= 3:
            score += 2
            reasons.append(f"{side} 상위권 경쟁")
        if survival.get("active"):
            score += 2
            reasons.append(f"{side} 잔류 경쟁")
        try:
            days = int(next_fixture.get("days_until_next") or 99)
        except (TypeError, ValueError):
            days = 99
        if bool(next_fixture.get("is_important")) and days <= 4:
            rotation_teams.append(side)
            reasons.append(f"{side} {days}일 내 다음 중요 일정")
    if score >= 5:
        label, level = "핵심 경쟁 경기", "high"
    elif score >= 2:
        label, level = "순위·일정 주의 경기", "medium"
    else:
        label, level = "일반 리그 일정", "standard"
    return {
        "schema_version": "match-importance.v1",
        "label": label,
        "level": level,
        "score": score,
        "reasons": reasons[:5],
        "rotation_watch": bool(rotation_teams),
        "rotation_watch_teams": rotation_teams,
        "notice": (
            "로테이션 가능성을 단정하지 않으며, 공식 선발 발표 전에는 일정상 주의 신호로만 반영합니다."
            if rotation_teams else "공식 순위·일정 자료 기준의 경기 맥락입니다."
        ),
    }


def calculate_squad_depth_factor(standing):
    """Scale absence damage by relative table position, not a fixed rank 15."""
    standing = standing if isinstance(standing, dict) else {}
    try:
        rank = int(standing.get("rank") or 99)
        total_teams = int(standing.get("total_teams") or 0)
        zone_start = int(standing.get("relegation_start_rank") or 0)
    except (TypeError, ValueError):
        return 1.0
    if rank <= 0 or rank == 99 or total_teams < 8:
        return 1.0
    if rank <= max(3, round(total_teams * 0.25)):
        return 0.5
    if zone_start > 1 and rank >= zone_start:
        return 1.5
    if rank >= max(1, round(total_teams * 0.75)):
        return 1.25
    return 1.0


def _waiting_odds_team_forms(home_info, away_info, ttl_h=24):
    """Return cached recent form for identified teams even before odds arrive."""
    return (
        fetch_team_form_api((home_info or {}).get("id"), ttl_h),
        fetch_team_form_api((away_info or {}).get("id"), ttl_h),
    )


def _needs_current_analysis_refresh(item, kickoff, now, target_version):
    """Refresh only a scheduled card whose official formula version is old."""
    if not isinstance(item, dict) or kickoff is None or now is None:
        return False
    if kickoff.tzinfo is None:
        kickoff = kickoff.replace(tzinfo=KST)
    if now.tzinfo is None:
        now = now.replace(tzinfo=KST)
    if now >= kickoff:
        return False
    analysis = item.get("analysis") if isinstance(item.get("analysis"), dict) else {}
    stored_version = str(
        item.get("analysis_version")
        or analysis.get("analysis_version")
        or item.get("public_pick_analysis_version")
        or analysis.get("public_pick_analysis_version")
        or ""
    )
    return stored_version != str(target_version or "")


def _needs_current_robot_refresh(item, kickoff, now, source="PROTO"):
    """Refresh a scheduled card after the robot receives a new result."""
    if not isinstance(item, dict) or kickoff is None or now is None:
        return False
    if kickoff.tzinfo is None:
        kickoff = kickoff.replace(tzinfo=KST)
    if now.tzinfo is None:
        now = now.replace(tzinfo=KST)
    if now >= kickoff:
        return False
    analysis = item.get("analysis") if isinstance(item.get("analysis"), dict) else {}
    categories = (
        item.get("pick_categories")
        if isinstance(item.get("pick_categories"), dict)
        else item.get("categories")
        if isinstance(item.get("categories"), dict)
        else {}
    )
    analysis_categories = (
        analysis.get("categories")
        if isinstance(analysis.get("categories"), dict) else {}
    )
    decision = item.get("decision") if isinstance(item.get("decision"), dict) else {}
    analysis_decision = (
        analysis.get("decision")
        if isinstance(analysis.get("decision"), dict) else {}
    )
    robot = next((
        value for value in (
            item.get("robot_pick"), analysis.get("robot_pick"),
            categories.get("robot_independent"),
            analysis_categories.get("robot_independent"),
            decision.get("robot_pick"), analysis_decision.get("robot_pick"),
        )
        if isinstance(value, dict) and str(value.get("raw_pick") or "").strip()
    ), {})
    if not robot:
        return True
    stored_pick_version = str(
        robot.get("robot_pick_version")
        or item.get("robot_pick_version")
        or analysis.get("robot_pick_version")
        or ""
    )
    if stored_pick_version != ROBOT_PICK_VERSION:
        return True
    stored_model_version = str(robot.get("robot_model_version") or "")
    if stored_model_version != ROBOT_MODEL_VERSION:
        return True
    current_revision = _robot_learning_revision_marker(source)
    stored_revision = str(robot.get("robot_learning_revision") or "")
    return bool(current_revision and stored_revision != current_revision)


def _scheduled_toto_revision_needs_refresh(item, kickoff, now):
    """Combine formula, robot-learning and evidence-stage refresh rules."""
    if not isinstance(item, dict) or kickoff is None or now is None or now >= kickoff:
        return False
    if _needs_current_analysis_refresh(item, kickoff, now, ANALYSIS_VERSION):
        return True
    if _needs_current_robot_refresh(item, kickoff, now, "TOTO14"):
        return True
    target_stage = prediction_stage(
        (kickoff - now).total_seconds() / 3600.0,
        bool(item.get("lineup_confirmed")),
    )
    stored_stage = str(
        item.get("latest_analysis_stage")
        or item.get("analysis_stage")
        or item.get("frozen_from_stage")
        or ""
    )
    return stored_stage != target_stage


def _locked_proto_item(match, previous=None, locked=True):
    """Read the stored forecast, never regenerate it with post-kickoff inputs."""
    conn = sqlite3.connect(str(_local_path("ai_predictions.db")),timeout=5)
    conn.row_factory = sqlite3.Row
    try:
        row = conn.execute("SELECT * FROM predictions WHERE match_id=?",(str(match.get("id") or ""),)).fetchone()
        if row is None and not locked:
            return None
        if row is None:
            return dict(match=dict(match),final_match_time=match.get("match_time"),
                        ev_sorted_picks=[],pick_categories={},analysis_stage="locked",
                        detailed_report="경기 전 저장된 예측을 찾지 못했습니다. 사후 픽은 만들지 않으며 결과 연결 상태를 확인합니다.")
        row = dict(row)
        if row.get("home_team") != match.get("home") or row.get("away_team") != match.get("away"):
            return None
        item = dict(previous or {})
        item.pop("display_candidates", None)
        item.pop("display_candidates_saved_at", None)
        saved = conn.execute("SELECT * FROM prediction_analysis WHERE match_id=?",(str(row["match_id"]),)).fetchone()
        selected = {
            "raw_pick":row.get("prob_pick") or "", "prob":float(row.get("prob_pick_prob") or 0)/100,
            "official_final_pick":bool(row.get("prob_pick")), "recommendation_status":"SELECTED" if row.get("prob_pick") else "WITHHELD",
        }
        categories = {"high_probability":selected,"honey":None,"vip_underdog":None}
        report = "경기 전 저장한 최종픽을 그대로 유지합니다. 상세 분석 원본은 보관 자료 확인 중입니다."
        stored_stage = "regular"
        odds_source = ""
        if saved is not None and str(saved["selected_pick"] or "") == selected["raw_pick"]:
            saved = dict(saved)
            stored_stage = str(saved.get("stage") or "regular")
            odds_source = str(saved.get("odds_source") or "")
            kickoff = _parse_kst_match_time(row.get("match_time"))
            saved_at = datetime.fromisoformat(str(saved.get("updated_at")).replace("Z", "+00:00"))
            if saved_at.tzinfo is None:
                saved_at = saved_at.replace(tzinfo=timezone.utc)
            if kickoff and saved_at <= kickoff:
                # Read-only display material: never replace a frozen empty
                # official selection with a retrospectively graded prediction.
                item["display_candidates"] = json.loads(saved.get("markets_json") or "[]")
                item["display_candidates_saved_at"] = saved_at.isoformat()
                stored_categories = json.loads(saved.get("categories_json") or "{}")
                high = stored_categories.get("high_probability") or {}
                selected.update(high,prob=float(row.get("prob_pick_prob") or 0)/100)
                for key in categories:
                    value = stored_categories.get(key)
                    if value and value.get("raw_pick") == selected["raw_pick"]:
                        categories[key] = dict(selected,**{k:v for k,v in value.items() if k!="prob"})
                categories["high_probability"] = selected
                report = str(saved.get("report_text") or report)
        item.update(match=dict(match),api_fixture_id=int(row.get("api_fixture_id") or 0),
                    final_match_time=match.get("match_time") or row.get("match_time"),
                    timestamp=parse_match_time(match.get("match_time") or row.get("match_time")).timestamp(),
                    analysis_stage="locked" if locked else stored_stage,
                    latest_analysis_stage=stored_stage,
                    analysis_version=row.get("analysis_version"),
                    odds_source=odds_source or item.get("odds_source") or "",
                    pick_categories=categories,ev_sorted_picks=[selected] if selected["raw_pick"] else [],
                    detailed_report=report,story="",prediction_frozen=bool(locked),
                    public_pick_frozen=bool(locked),
                    public_pick_frozen_at="" if not locked else str(row.get("created_at") or ""))
        return _public_proto_item_from_first_snapshot(match, item, locked=locked)
    finally:
        conn.close()


def _restore_scheduled_proto_cards_from_saved_predictions(
    dashboard_path="dashboard_data.json", betman_path="betman_data.json", now=None,
):
    """Publish already-saved pre-kickoff picks without rerunning analysis.

    Prediction writes and dashboard publication are separate operations.  A
    worker can therefore save a valid answer and fail later while building the
    same dashboard, leaving an old ``analysis_refresh_pending`` card visible.
    This recovery pass is deliberately local and read-only with respect to the
    prediction database: it overlays a same-ID, same-team saved official pick
    onto every still-scheduled Betman card and atomically rewrites only the
    customer dashboard when at least one card changed.

    It does not call any external provider, create a retrospective pick, alter
    odds/probability history, or touch cards whose kickoff has passed.
    """
    payload = _read_json(dashboard_path, {})
    betman_data = _read_json(betman_path, {})
    if not isinstance(payload, dict) or not isinstance(betman_data, dict):
        return 0
    cards = payload.get("proto")
    raw_matches = betman_data.get("proto_matches")
    if not isinstance(cards, list) or not isinstance(raw_matches, list):
        return 0

    now = now or datetime.now(KST)
    live_matches = []
    for raw_match in raw_matches:
        if (
            not isinstance(raw_match, dict)
            or _is_placeholder_match(raw_match)
            or _is_betman_auxiliary_prediction_record(raw_match)
        ):
            continue
        match = dict(raw_match)
        match_id = str(match.get("id") or "")
        home_team = str(match.get("home") or "")
        away_team = str(match.get("away") or "")
        kickoff = _parse_kst_match_time(
            match.get("match_time") or match.get("time")
        )
        if not match_id or not home_team or not away_team or kickoff is None:
            continue
        if kickoff <= now:
            continue
        live_matches.append((match, kickoff))

    card_indexes = {}
    for index, card in enumerate(cards):
        if not isinstance(card, dict):
            continue
        card_match = card.get("match") if isinstance(card.get("match"), dict) else {}
        match_id = str(card_match.get("id") or "")
        if match_id and match_id not in card_indexes:
            card_indexes[match_id] = index

    recovered = 0
    appended = 0
    for match, kickoff in live_matches:
        match_id = str(match.get("id") or "")
        index = card_indexes.get(match_id)
        previous = cards[index] if index is not None and isinstance(cards[index], dict) else {}
        previous_match = previous.get("match") if isinstance(previous.get("match"), dict) else {}

        # Never attach a saved answer to a card merely because an ID string
        # happens to match.  Match ID plus both exact team names are required.
        if index is not None and (
            str(previous_match.get("home") or "") != str(match.get("home") or "")
            or str(previous_match.get("away") or "") != str(match.get("away") or "")
        ):
            continue

        if _proto_item_has_usable_pick(previous, match):
            # A valid pre-kickoff answer may be waiting for a newer team/logo
            # snapshot, but that refresh must never hide the already saved
            # official pick from the customer card.  The next master pass can
            # still enrich it; this recovery only removes the false pending
            # display state.
            if bool(previous.get("analysis_refresh_pending")) or bool(
                previous.get("public_pick_blocked")
            ):
                visible = _preserve_visible_proto_pick_for_retry(
                    match, previous, "scheduled_pick_recovery"
                )
                if visible is not None:
                    cards[index] = visible
                    recovered += 1
            continue

        restored = _locked_proto_item(match, previous=previous, locked=False)
        if not _proto_item_has_usable_pick(restored, match):
            continue

        restored.update({
            "match": dict(match),
            "final_match_time": match.get("match_time") or match.get("time") or "시간 미정",
            "timestamp": kickoff.timestamp(),
            "analysis_refresh_pending": False,
            "public_pick_blocked": False,
            "public_pick_block_reason": "",
            "prediction_frozen": False,
            "public_pick_frozen": False,
            "public_pick_frozen_at": "",
            "scheduled_pick_recovered": True,
            "scheduled_pick_recovery_source": "saved_pre_kick_prediction",
        })
        _hydrate_published_team_data(restored, match)
        if index is None:
            cards.append(restored)
            card_indexes[match_id] = len(cards) - 1
            appended += 1
        else:
            cards[index] = restored
        recovered += 1

    if not recovered:
        return 0
    source_meta = payload.get("source_meta")
    if not isinstance(source_meta, dict):
        source_meta = {}
        payload["source_meta"] = source_meta
    source_meta["scheduled_pick_recovery_count"] = recovered
    source_meta["scheduled_pick_recovery_appended_count"] = appended
    source_meta["scheduled_pick_recovered_at"] = datetime.now(KST).isoformat()
    _atomic_write_json(dashboard_path, payload)
    print(
        f"♻️ 시작 전 저장픽 공통 복구: {recovered}장"
        + (f" (누락 카드 추가 {appended}장)" if appended else "")
    )
    return recovered


def run_scheduled_pick_recovery_job():
    """Run the local-only recovery as a one-shot deploy safety step."""
    recovered = _restore_scheduled_proto_cards_from_saved_predictions()
    if not recovered:
        print("ℹ️ 시작 전 저장픽 공통 복구 대상이 없습니다.")
        _update_collector_status(
            "recovery", "running", last_stage="no_saved_pick_recovery_needed",
        )
        return True
    if not upload_to_github("dashboard_data.json"):
        _update_collector_status(
            "recovery", "running", last_stage="dashboard_publish_failed",
        )
        return False
    _update_collector_status(
        "recovery", "running", last_stage="saved_pick_recovery_published",
        scheduled_pick_recovery_count=recovered,
    )
    return True


def _proto_item_has_usable_pick(item, match):
    if not isinstance(item, dict):
        return False
    item_match = item.get("match") or {}
    if (
        str(item_match.get("home") or "") != str(match.get("home") or "")
        or str(item_match.get("away") or "") != str(match.get("away") or "")
    ):
        return False
    stage = str(
        item.get("analysis_stage") or item.get("latest_analysis_stage") or ""
    ).strip().casefold()
    selected = (item.get("pick_categories") or {}).get("high_probability") or {}
    if stage == "market-preview":
        return False
    if str(selected.get("recommendation_status") or "").upper() == "PREVIEW":
        return False
    return bool(str(selected.get("raw_pick") or "").strip())


def _preserve_visible_proto_pick_for_retry(match, previous=None, reason=""):
    """Keep an existing pre-kickoff pick visible while enrichment retries.

    Team identity, logos and fresh provider data are enrichment work.  A
    temporary API/cache/queue delay must not replace a same-match saved pick
    with a PENDING card or alter its selected candidate.  This helper changes
    only dashboard display state; it never writes prediction history or
    recalculates an official/robot pick.
    """
    if not _proto_item_has_usable_pick(previous, match):
        return None
    # R7.13 deliberately starts a clean evidence season.  A scheduled card
    # made by an older formula or before the shared dossier existed must not
    # remain customer-visible while the new material is still being collected.
    # Started cards are handled by _locked_proto_item and are never changed.
    if str((previous or {}).get("analysis_version") or "") != ANALYSIS_VERSION:
        return None
    preserved = dict(previous)
    final_match_time = match.get("match_time") or match.get("time") or "시간 미정"
    preserved.update({
        "match": dict(match),
        "final_match_time": final_match_time,
        "timestamp": parse_match_time(final_match_time).timestamp(),
        "analysis_refresh_pending": False,
        "public_pick_blocked": False,
        "public_pick_block_reason": "",
        "analysis_refresh_deferred": True,
        "analysis_refresh_deferred_reason": str(reason or "enrichment_retry"),
        "data_warning": (
            "기존 경기 전 분석픽을 유지합니다. 팀 마크·최근 경기 등 추가 자료는 "
            "공용 캐시에서 다음 수집 주기에 보강합니다."
        ),
    })
    _hydrate_published_team_data(preserved, match)
    if not _proto_item_has_three_engine_picks(preserved):
        preserved["robot_analysis_pending"] = True
    return preserved


def _published_team_identity_ready(item, require_fixture=True):
    """Require verified match/team identity before publishing a future pick."""
    if not isinstance(item, dict):
        return False
    try:
        home_id = int(item.get("home_team_id") or 0)
        away_id = int(item.get("away_team_id") or 0)
        fixture_id = int(item.get("api_fixture_id") or 0)
    except (TypeError, ValueError):
        return False
    logos_ready = bool(
        item.get("home_logo") not in (None, "", DEFAULT_LOGO)
        and item.get("away_logo") not in (None, "", DEFAULT_LOGO)
    )
    return bool(
        home_id > 0
        and away_id > 0
        and home_id != away_id
        and logos_ready
        and (fixture_id > 0 or not require_fixture)
    )


def _proto_item_has_three_engine_picks(item):
    """Keep a pre-kickoff pick visible while team profiles are refreshed.

    Team IDs, logos and form are enrichment inputs. They must not turn a
    valid saved public pick back into an empty card.
    """
    if not isinstance(item, dict):
        return False
    official = (item.get("pick_categories") or {}).get("high_probability") or {}
    robot = item.get("robot_pick") or {}
    if not all(isinstance(pick, dict) for pick in (official, robot)):
        return False
    picks_exist = all(
        str(pick.get("raw_pick") or "").strip()
        for pick in (official, robot)
    )
    return bool(
        picks_exist
        and str(item.get("analysis_version") or "") == ANALYSIS_VERSION
        and str(robot.get("robot_pick_version") or "") == ROBOT_PICK_VERSION
    )


def _hydrate_published_team_data(item, match=None):
    """Patch display-only team identity data without changing any saved pick."""
    if not isinstance(item, dict):
        return False, False
    match = dict(match or item.get("match") or {})
    changed = False
    complete = True
    for side, team_field, logo_field, form_field in (
        ("home", "home", "home_logo", "home_form"),
        ("away", "away", "away_logo", "away_form"),
    ):
        team_name = str(match.get(team_field) or "").strip()
        profile = get_cached_team_display_profile(team_name)
        team_id = int((profile or {}).get("id") or 0)
        logo = str((profile or {}).get("logo") or "")
        form = str((profile or {}).get("form") or "").strip()

        if team_id and int(item.get(f"{side}_team_id") or 0) != team_id:
            item[f"{side}_team_id"] = team_id
            changed = True
        if logo and logo != DEFAULT_LOGO and item.get(logo_field) != logo:
            item[logo_field] = logo
            changed = True
        if form and item.get(form_field) != form:
            item[form_field] = form
            changed = True

        if (
            not team_id
            or item.get(logo_field) in (None, "", DEFAULT_LOGO)
            or not str(item.get(form_field) or "").strip()
        ):
            complete = False
    return changed, complete


def _refresh_dashboard_team_profiles(path="dashboard_data.json"):
    """Apply completed retry data to all card copies and persist atomically."""
    payload = _read_json(path, {})
    if not isinstance(payload, dict):
        return 0
    changed_count = 0
    for collection_name in ("proto", "toto14", "top3"):
        items = payload.get(collection_name) or []
        if not isinstance(items, list):
            continue
        for item in items:
            changed, _ = _hydrate_published_team_data(item)
            changed_count += int(changed)
    if changed_count:
        source_meta = payload.setdefault("source_meta", {})
        source_meta["team_profiles_refreshed_at"] = datetime.now(KST).isoformat()
        source_meta["team_profile_card_updates"] = changed_count
        _atomic_write_json(path, payload)
    return changed_count


def _queue_incomplete_dashboard_team_profiles(path="dashboard_data.json"):
    """Reopen every visibly incomplete card without changing its saved pick."""
    payload = _read_json(path, {})
    if not isinstance(payload, dict):
        return 0
    queued = set()
    for collection_name in ("proto", "toto14", "top3"):
        items = payload.get(collection_name) or []
        if not isinstance(items, list):
            continue
        for item in items:
            if not isinstance(item, dict):
                continue
            match = item.get("match") or {}
            if not isinstance(match, dict):
                continue
            _, profile_complete = _hydrate_published_team_data(item, match)
            if profile_complete and _published_team_identity_ready(
                item, require_fixture=False
            ):
                continue
            home_name = str(match.get("home") or "").strip()
            away_name = str(match.get("away") or "").strip()
            match_time = str(
                item.get("final_match_time")
                or match.get("match_time")
                or match.get("time")
                or ""
            )
            retry_key = (home_name, away_name, match_time)
            if not home_name or not away_name or retry_key in queued:
                continue
            if queue_team_identity_retry(
                home_name,
                away_name,
                match_time,
                reason="published_card_identity_logo_or_form_incomplete",
                league_name=match.get("league") or item.get("league") or "",
            ):
                queued.add(retry_key)
    return len(queued)


def _resumable_proto_item(match, previous=None, require_current_stage=False):
    """Restore a pre-kickoff card without repeating its heavy analysis."""
    final_match_time = match.get("match_time") or match.get("time") or "시간 미정"
    candidate = dict(previous) if _proto_item_has_usable_pick(previous, match) else None
    if candidate is None:
        candidate = _locked_proto_item(match, previous, locked=False)
    if not _proto_item_has_usable_pick(candidate, match):
        return None

    match_dt = parse_match_time(final_match_time)
    diff_hours = (match_dt - datetime.now(KST)).total_seconds() / 3600.0
    target_stage = prediction_stage(
        diff_hours, bool(candidate.get("lineup_confirmed"))
    )
    candidate_stage = str(
        candidate.get("latest_analysis_stage")
        or candidate.get("analysis_stage")
        or "regular"
    )
    betman_odds_ready = _valid_three_way_odds([
        match.get("odd_h"), match.get("odd_d"), match.get("odd_a")
    ])
    temporary_odds_stage = candidate_stage in {
        "overseas-preview", "model-only-preview"
    }

    # The odds-source label is not an evidence-completion stage.  R7.12.31
    # compared e.g. ``model-only-preview`` directly with ``regular`` and
    # therefore treated the same already-analysed card as stale on every
    # master pass.  Keep a separate evidence stage so a temporary-odds card
    # is refreshed only when the real pre-match stage advances (T-90/T-60/
    # T-30), Betman odds arrive, or the official/robot revision actually
    # changes.  Existing cards created before this field existed are adopted
    # at the current evidence stage once; the adopted stage is written back to
    # dashboard_data.json on the next checkpoint, so later stage transitions
    # still trigger one legitimate refresh.
    stored_evidence_stage = str(
        candidate.get("analysis_evidence_stage")
        or (target_stage if temporary_odds_stage else candidate_stage)
    )
    stage_refresh_needed = stored_evidence_stage != target_stage
    refresh_now = datetime.now(KST)
    if require_current_stage and (
        stage_refresh_needed
        or (temporary_odds_stage and betman_odds_ready)
        or _needs_current_analysis_refresh(
            candidate, match_dt, refresh_now, ANALYSIS_VERSION
        )
        or _needs_current_robot_refresh(candidate, match_dt, refresh_now, "PROTO")
    ):
        return None

    candidate["analysis_evidence_stage"] = stored_evidence_stage
    candidate["match"] = dict(match)
    candidate["final_match_time"] = final_match_time
    candidate["timestamp"] = match_dt.timestamp()
    candidate["analysis_refresh_pending"] = False
    _hydrate_published_team_data(candidate, match)
    if (
        candidate.get("home_logo") in (None, "", DEFAULT_LOGO)
        or candidate.get("away_logo") in (None, "", DEFAULT_LOGO)
        or not candidate.get("home_form")
        or not candidate.get("away_form")
    ):
        queue_team_identity_retry(
            match.get("home"), match.get("away"), final_match_time,
            reason="published_card_identity_logo_or_form_missing",
            league_name=match.get("league") or "",
        )
    candidate = _public_proto_item_from_first_snapshot(match, candidate, locked=False)
    # The official saved pick must stay visible even if the independent robot
    # revision has not finished.  Robot enrichment can continue in the normal
    # queue, but it may never turn the customer card back into an empty one.
    if not _proto_item_has_three_engine_picks(candidate):
        candidate["robot_analysis_pending"] = True
    return candidate


def _pending_proto_item(match):
    final_match_time = match.get("match_time") or match.get("time") or "시간 미정"
    item = {
        "match": dict(match),
        "final_match_time": final_match_time,
        "timestamp": parse_match_time(final_match_time).timestamp(),
        "home_logo": DEFAULT_LOGO,
        "away_logo": DEFAULT_LOGO,
        "home_form": "",
        "away_form": "",
        "ev_sorted_picks": [],
        "pick_categories": {},
        "analysis_stage": "PENDING_RESUMABLE_ANALYSIS",
        "analysis_refresh_pending": True,
        "public_pick_blocked": True,
        "public_pick_block_reason": "fixture_and_team_identity_required",
        "detailed_report": (
            "전체 경기표를 먼저 공개했습니다. 이 경기는 다음 자동 주기에서 "
            "저장 지점부터 분석합니다. 시작 전에는 최신 공식·로봇픽으로 "
            "갱신하고, 경기 시작 뒤 마지막 경기 전 픽을 고정합니다."
        ),
    }
    _hydrate_published_team_data(item, match)
    return item


def _proto_market_preview_item(match, reason=""):
    """Show a Betman-market preview instead of an empty future card.

    This is a display-only, pre-kickoff fallback. It never calls an API and is
    never frozen or graded as a final prediction; the normal analysis replaces
    it before kickoff as soon as team and fixture enrichment is ready.
    """
    final_match_time = match.get("match_time") or match.get("time") or "시간 미정"
    home_team = str(match.get("home") or "홈팀")
    away_team = str(match.get("away") or "원정팀")
    candidates = []

    def add_three_way(odds, labels, market_label):
        try:
            values = [float(value or 0) for value in odds]
        except (TypeError, ValueError):
            return
        if not _valid_three_way_odds(values):
            return
        inverse = [1.0 / value for value in values]
        total = sum(inverse)
        if total <= 0:
            return
        for index, raw_pick in enumerate(labels):
            fair_prob = inverse[index] / total
            candidates.append({
                "label": market_label,
                "raw_pick": raw_pick,
                "prob": round(fair_prob, 4),
                "probability": round(fair_prob, 4),
                "fair_prob": round(fair_prob, 4),
                "market_prob": round(fair_prob, 4),
                "odd": values[index],
                "safe_score": round(fair_prob, 4),
                "recommendation_score": round(fair_prob, 4),
                "data_confidence": 0.35,
                "selection_warning": "팀 자료 보강 중 · 베트맨 시장 기준 선픽",
                "market_history_scope": "proto_market_preview",
            })

    add_three_way(
        [match.get("odd_h"), match.get("odd_d"), match.get("odd_a")],
        [f"{home_team} 승", "무승부", f"{away_team} 승"],
        "일반 승무패 시장 선픽",
    )
    try:
        handi_base = float(match.get("handi_base") or 0)
    except (TypeError, ValueError):
        handi_base = 0.0
    add_three_way(
        [match.get("handi_h"), match.get("handi_d"), match.get("handi_a")],
        [
            f"[{handi_base:+.1f}] {home_team} 핸디승",
            f"[{handi_base:+.1f}] 핸디무",
            f"[{handi_base:+.1f}] {home_team} 핸디패",
        ],
        "핸디캡 시장 선픽",
    )
    try:
        under_odd = float(match.get("uo_under") or 0)
        over_odd = float(match.get("uo_over") or 0)
        uo_base = float(match.get("uo_base") or 2.5)
    except (TypeError, ValueError):
        under_odd = over_odd = 0.0
        uo_base = 2.5
    if under_odd > 1.0 and over_odd > 1.0:
        total = (1.0 / under_odd) + (1.0 / over_odd)
        if total > 0:
            for raw_pick, odd in (
                (f"언더 (U/O {uo_base:g})", under_odd),
                (f"오버 (U/O {uo_base:g})", over_odd),
            ):
                fair_prob = (1.0 / odd) / total
                candidates.append({
                    "label": "언더오버 시장 선픽",
                    "raw_pick": raw_pick,
                    "prob": round(fair_prob, 4),
                    "probability": round(fair_prob, 4),
                    "fair_prob": round(fair_prob, 4),
                    "market_prob": round(fair_prob, 4),
                    "odd": odd,
                    "safe_score": round(fair_prob, 4),
                    "recommendation_score": round(fair_prob, 4),
                    "data_confidence": 0.35,
                    "selection_warning": "팀 자료 보강 중 · 베트맨 시장 기준 선픽",
                    "market_history_scope": "proto_market_preview",
                })

    if not candidates:
        return _pending_proto_item(match)

    selected = max(
        candidates,
        key=lambda candidate: (
            float(candidate.get("prob") or 0),
            float(candidate.get("odd") or 0),
            str(candidate.get("raw_pick") or ""),
        ),
    )
    official_pick = dict(selected)
    official_pick.update({
        "category_key": "high_probability",
        "official_final_pick": False,
        "recommendation_status": "PREVIEW",
        "pre_match_only": True,
    })
    robot_pick = dict(selected)
    robot_pick.update({
        "robot_pick_version": ROBOT_PICK_VERSION,
        "robot_model_version": ROBOT_MODEL_VERSION,
        "robot_fallback": True,
        "official_final_pick": False,
        "selection_reason": "팀·선발 자료 수집 전 시장 기준 임시 선택",
        "selection_warning": "로봇 정밀분석 대기 · 시장 기준 임시 선택",
    })
    item = {
        "match": dict(match),
        "final_match_time": final_match_time,
        "timestamp": parse_match_time(final_match_time).timestamp(),
        "home_logo": DEFAULT_LOGO,
        "away_logo": DEFAULT_LOGO,
        "home_form": "",
        "away_form": "",
        "ev_sorted_picks": [official_pick],
        "pick_categories": {
            "high_probability": official_pick,
            "honey": None,
            "vip_underdog": None,
            "robot_independent": robot_pick,
        },
        "robot_pick": robot_pick,
        "analysis_stage": "market-preview",
        "latest_analysis_stage": "market-preview",
        "analysis_version": ANALYSIS_VERSION,
        "analysis_refresh_pending": False,
        "public_pick_blocked": False,
        "public_pick_block_reason": "",
        "prediction_frozen": False,
        "odds_source": "betman",
        "data_confidence": 0.35,
        "data_warning": "팀 자료를 보강 중이며, 현재 베트맨 시장 정보로 먼저 표시합니다.",
        "detailed_report": (
            "[시장 기준 선픽] 팀 연결·마크·최근폼 보강이 끝나기 전에도 빈 픽을 "
            "표시하지 않기 위해, 현재 베트맨 시장의 마진 제거 공정확률로 우선 선택했습니다. "
            "정밀 팀 분석이 완료되면 경기 시작 전 최신 공식·로봇 분석으로 교체됩니다."
            + (f" (대기 사유: {reason})" if reason else "")
        ),
    }
    _hydrate_published_team_data(item, match)
    return item


def _proto_can_finish_model_only_analysis(match):
    """Return True only for a no-price card with two already verified teams.

    The master cycle may defer heavy enrichment after its soft time budget.  A
    Betman row whose prices have not opened cannot use the market-preview
    fallback, though.  When both team identities are already in the verified
    cache, the normal model-only path is safe to complete without first
    waiting for another identity retry cycle.  This helper deliberately does
    not search an external API or manufacture an identity.
    """
    if not isinstance(match, dict):
        return False
    if _valid_three_way_odds([
        match.get("odd_h"), match.get("odd_d"), match.get("odd_a"),
    ]):
        return False
    home_id = int(known_team_id(match.get("home")) or 0)
    away_id = int(known_team_id(match.get("away")) or 0)
    return bool(home_id > 0 and away_id > 0 and home_id != away_id)


def _publish_proto_checkpoint(
    dashboard_proto, previous_dashboard, proto_matches, toto_14_matches,
    raw_proto_matches, rejected_placeholder_count, rejected_auxiliary_count,
    rejected_proto_count, resumed_proto_count, analyzed_proto_count,
    deferred_proto_count, proto_market_watch_count, proto_cycle_started,
    proto_brake_reason="",
):
    """Publish the PROTO board before any TOTO14-heavy follow-up can block it.

    The previous current-round TOTO14 cards and grading snapshot are preserved
    verbatim.  This is a presentation checkpoint only: prediction rows, frozen
    picks, grades and model versions are never rewritten here.
    """
    previous_dashboard = previous_dashboard if isinstance(previous_dashboard, dict) else {}
    current_toto_ids = {str(match.get("id") or "") for match in (toto_14_matches or [])}
    previous_toto14 = [
        item for item in (previous_dashboard.get("toto14") or [])
        if isinstance(item, dict)
        and str((item.get("match") or {}).get("id") or "") in current_toto_ids
    ]
    now_ts = datetime.now(KST).timestamp()
    upcoming_proto = [
        item for item in dashboard_proto
        if float(item.get("timestamp") or 0) > now_ts and item.get("ev_sorted_picks")
    ]
    top_3_picks = sorted(
        upcoming_proto,
        key=lambda item: (item.get("reliability_score", 0), item.get("analysis_confidence", 0)),
        reverse=True,
    )[:3]
    # TOP3 has its own score track.  Freeze only a completed pre-kickoff
    # analysis; a market-preview card is useful for display but is not an
    # auditable TOP3 answer yet.  INSERT OR IGNORE keeps the first qualified
    # TOP3 answer immutable once it exists.
    for top3_item in top_3_picks:
        stage = str(top3_item.get("analysis_stage") or "").strip().casefold()
        if stage in {"", "market-preview"} or stage.startswith("pending"):
            continue
        top3_match = top3_item.get("match") or {}
        top3_kickoff = _parse_kst_match_time(top3_match.get("match_time"))
        top3_official = (
            (top3_item.get("pick_categories") or {}).get("high_probability")
            or (top3_item.get("ev_sorted_picks") or [{}])[0]
        )
        top3_robot = top3_item.get("robot_pick") or {}
        if not isinstance(top3_official, dict) or not isinstance(top3_robot, dict):
            continue
        save_three_engine_picks(
            "TOP3", str(top3_match.get("id") or ""),
            int(top3_item.get("api_fixture_id") or 0),
            str(top3_item.get("league") or top3_match.get("league") or "프로토 TOP3"),
            str(top3_match.get("home") or ""), str(top3_match.get("away") or ""),
            top3_kickoff, top3_official,
            top3_item.get("legacy_v4_pick") or {}, top3_robot,
        )
    source_meta = dict(previous_dashboard.get("source_meta") or {})
    source_meta.update({
        "analysis_version": ANALYSIS_VERSION,
        "system_version": SYSTEM_VERSION,
        "underdog_gate_version": UNDERDOG_GATE_VERSION,
        "raw_betman_proto_count": len(raw_proto_matches),
        "rejected_placeholder_count": rejected_placeholder_count,
        "rejected_auxiliary_prediction_count": rejected_auxiliary_count,
        "rejected_proto_count": rejected_proto_count,
        "betman_proto_count": len(proto_matches),
        "display_proto_count": len(dashboard_proto),
        "betman_toto14_count": len(toto_14_matches),
        "display_toto14_count": len(previous_toto14),
        "resumed_proto_count": resumed_proto_count,
        "analyzed_proto_count": analyzed_proto_count,
        "master_analysis_new_matches_per_pass": MASTER_ANALYSIS_NEW_MATCHES_PER_PASS,
        "deferred_proto_count": deferred_proto_count,
        "proto_market_watch_count": proto_market_watch_count,
        "analysis_resume_pending": bool(deferred_proto_count),
        "analysis_brake_reason": str(proto_brake_reason or ""),
        "master_analysis_elapsed_seconds": round(time.monotonic() - proto_cycle_started, 2),
        "proto_parity_ok": len(proto_matches) == len(dashboard_proto),
        "proto_checkpoint": True,
        "api_usage": get_api_usage_status(),
        "generated_at": datetime.now(KST).isoformat(),
    })
    payload = {
        "proto": dashboard_proto,
        "toto14": previous_toto14,
        "grading": previous_dashboard.get("grading") or {},
        "toto14_meta": previous_dashboard.get("toto14_meta") or {},
        "top3": top_3_picks,
        "honey_two_pick": build_honey_two_pick(upcoming_proto),
        "source_meta": source_meta,
    }
    _atomic_write_json("dashboard_data.json", payload)
    published = False
    if MASTER_PROTO_CHECKPOINT_UPLOAD:
        published = bool(upload_to_github("dashboard_data.json"))
    _update_collector_status(
        "master", "running",
        last_stage=("proto_checkpoint_published" if published else "proto_checkpoint_local"),
        proto_checkpoint_analyzed=int(analyzed_proto_count),
        proto_checkpoint_deferred=int(deferred_proto_count),
    )
    print(
        "⚡ PROTO 우선 게시 체크포인트: "
        f"신규 정밀분석 {analyzed_proto_count}건 / 대기 {deferred_proto_count}건 / "
        f"업로드 {'성공' if published else '보류'}"
    )
    return published


def _analysis_pass_brake_reason(processed_count, max_matches, deadline):
    """Return a safe yield reason without turning a batch size into a daily cap."""
    if int(processed_count or 0) >= int(max_matches or 1):
        return "batch_limit"
    if int(processed_count or 0) > 0 and time.monotonic() >= float(deadline):
        return "soft_time_budget"
    if int(processed_count or 0) > 0:
        available_mb = _available_memory_mb()
        if (
            available_mb is not None
            and available_mb < ANALYSIS_PASS_MIN_AVAILABLE_MEMORY_MB
        ):
            return f"low_memory_{int(available_mb)}MB"
    return ""


def build_dashboard_data():
    print(f"\n[🧠 {time.strftime('%Y-%m-%d %H:%M:%S')}] 대시보드 {ANALYSIS_VERSION} 신뢰도 보정 엔진 가동 중...")
    betman_data = _read_json("betman_data.json", {})
    if not isinstance(betman_data, dict):
        print("❌ 베트맨 데이터가 손상되어 대시보드 정상본을 보존합니다.")
        return False
     
    raw_proto_matches = betman_data.get("proto_matches", [])
    rejected_placeholder_count = sum(
        1 for match in raw_proto_matches if _is_placeholder_match(match)
    )
    rejected_auxiliary_count = sum(
        1 for match in raw_proto_matches
        if not _is_placeholder_match(match)
        and _is_betman_auxiliary_prediction_record(match)
    )
    proto_matches = [
        match for match in raw_proto_matches
        if not _is_placeholder_match(match)
        and not _is_betman_auxiliary_prediction_record(match)
    ]
    rejected_proto_count = len(raw_proto_matches) - len(proto_matches)
    if rejected_placeholder_count:
        print(
            f"⚠️ 팀명이 확인되지 않은 가짜 경기 {rejected_placeholder_count}건을 "
            "분석·화면·채점 대상에서 제외했습니다."
        )
    if rejected_auxiliary_count:
        print(
            f"🧹 베트맨 비판매 보조예측 경기 {rejected_auxiliary_count}건을 "
            "현재 프로토 화면에서 제외했습니다."
        )
    toto_14_matches = betman_data.get("toto_14_matches", [])
    if toto_14_matches and not _valid_toto14_round(toto_14_matches):
        toto_14_matches = _select_latest_complete_toto14_round(toto_14_matches)
        print(
            f"⚠️ 승무패 혼합/중복 회차를 제거하고 단일 완본 "
            f"{len(toto_14_matches)}경기만 분석합니다."
        )
    dashboard_proto = []
    dashboard_toto14 = []
    frozen_toto14 = _load_toto14_freezes()
    previous_dashboard = _read_json("dashboard_data.json", {})
    previous_proto = {}
    previous_toto14 = {}
    previous_generated_at = None
    if isinstance(previous_dashboard, dict):
        for item in previous_dashboard.get("proto", []):
            if not isinstance(item, dict) or not isinstance(item.get("match"), dict):
                continue
            previous_proto[str(item["match"].get("id", ""))] = item
        for item in previous_dashboard.get("toto14", []):
            if not isinstance(item, dict) or not isinstance(item.get("match"), dict):
                continue
            previous_toto14[str(item["match"].get("id", ""))] = item
        try:
            previous_generated_at = datetime.fromisoformat(
                str(previous_dashboard.get("source_meta", {}).get("generated_at", "")).replace("Z", "+00:00")
            )
            if previous_generated_at.tzinfo is None:
                previous_generated_at = previous_generated_at.replace(tzinfo=KST)
            previous_generated_at = previous_generated_at.astimezone(KST)
        except (AttributeError, TypeError, ValueError):
            previous_generated_at = None

    # 실제 채점된 시장 기록은 리그별로 한 번씩 읽어 전 세계·프로토가 함께 학습한다.
    market_performance_cache = {}
    toto14_probability_policy = None
    proto_cycle_started = time.monotonic()
    proto_soft_deadline = proto_cycle_started + MASTER_ANALYSIS_SOFT_SECONDS
    resumed_proto_count = 0
    analyzed_proto_count = 0
    deferred_proto_count = 0
    proto_market_watch_count = 0
    proto_brake_reason = ""
    proto_robot_artifact = _load_autonomous_robot_artifact(
        "PROTO", serving_only=MASTER_CACHE_ONLY_SERVING
    )

    # Analyze the nearest kickoff first, then restore Betman's original display
    # order before publishing. This keeps a large future board from delaying a
    # match that starts sooner merely because its sale-row number is larger.
    proto_display_order = {
        str(match.get("id") or ""): index
        for index, match in enumerate(proto_matches)
    }
    proto_processing_matches = sorted(
        proto_matches,
        key=lambda match: (
            _parse_kst_match_time(match.get("match_time") or match.get("time")) is None,
            (
                _parse_kst_match_time(match.get("match_time") or match.get("time"))
                or datetime.max.replace(tzinfo=KST)
            ).timestamp(),
            proto_display_order.get(str(match.get("id") or ""), 10**9),
        ),
    )

    for m in proto_processing_matches:
        home_team, away_team = m["home"], m["away"]
        final_match_time = m.get("match_time") or m.get("time") or "시간 미정"
        m_dt = parse_match_time(final_match_time)
        scheduled = _parse_kst_match_time(final_match_time)
        if scheduled is not None and datetime.now(KST) >= scheduled:
            frozen_item = _locked_proto_item(m,previous_proto.get(str(m.get("id",""))))
            if frozen_item:
                dashboard_proto.append(frozen_item)
            continue  # No odds/injuries/lineups/form API calls after kickoff.

        previous_item = previous_proto.get(str(m.get("id", "")))
        resumed_item = _resumable_proto_item(
            m, previous_item, require_current_stage=True
        )
        if resumed_item is not None:
            resumed_diff_hours = (m_dt - datetime.now(KST)).total_seconds() / 3600.0
            if (
                proto_market_watch_count < 4
                and 0 < resumed_diff_hours <= WORLD_MARKET_WATCH_HORIZON_HOURS
            ):
                _observe_locked_pick_market_flow(
                    resumed_item, "PROTO", str(m.get("id") or ""),
                    int(resumed_item.get("api_fixture_id") or 0),
                    str(resumed_item.get("league") or m.get("league") or "프로토"),
                    home_team, away_team, scheduled, resumed_diff_hours,
                )
                proto_market_watch_count += 1
            dashboard_proto.append(resumed_item)
            resumed_proto_count += 1
            continue

        # 50 is a maximum pass size, never a daily/customer limit.  Yield early
        # only when the current pass reaches its time or memory safety brake;
        # pending cards remain first-class work for the very next master turn.
        brake_reason = _analysis_pass_brake_reason(
            analyzed_proto_count, MASTER_ANALYSIS_NEW_MATCHES_PER_PASS,
            proto_soft_deadline,
        )
        if brake_reason:
            if not proto_brake_reason:
                proto_brake_reason = brake_reason
                print(
                    "⏸️ PROTO 자동 브레이크: "
                    f"{brake_reason} · 완료 {analyzed_proto_count}경기 / "
                    f"최대 {MASTER_ANALYSIS_NEW_MATCHES_PER_PASS}경기 · 다음 주기 즉시 이어서 분석"
                )
            # A pass/time/memory brake is not a reason to hide an already
            # published pre-kickoff answer.  Preserve it exactly and retry
            # enrichment on the next master pass.
            deferred_item = _preserve_visible_proto_pick_for_retry(
                m, previous_item, f"analysis_pass_brake:{brake_reason}"
            )
            if deferred_item is not None:
                dashboard_proto.append(deferred_item)
                deferred_proto_count += 1
                continue
            deferred_item = _resumable_proto_item(
                m, previous_item, require_current_stage=False
            )
            if deferred_item is None:
                deferred_item = _pending_proto_item(m)
                deferred_item["public_pick_block_reason"] = f"analysis_pass_brake:{brake_reason}"
                deferred_item["detailed_report"] = (
                    "해외 API 자료를 공용 캐시에 선수집하고 있으며, 서버 과부하를 막기 위해 "
                    "현재 분석 묶음을 잠시 양보했습니다. 다음 master 차례에서 자동으로 이어서 분석합니다."
                )
            deferred_item["analysis_refresh_pending"] = True
            deferred_item["public_pick_blocked"] = True
            dashboard_proto.append(deferred_item)
            deferred_proto_count += 1
            continue

        # Empty-price rows cannot receive a Betman market preview.  If their
        # team pair is already verified locally, allow the existing model-only
        # analysis below to finish instead of publishing an empty card until a
        # later cycle.  Unknown teams still follow the normal bounded queue.
        shared_dossier = _load_shared_fixture_dossier(m)
        dossier_home = shared_dossier.get("home") if isinstance(shared_dossier, dict) else {}
        dossier_away = shared_dossier.get("away") if isinstance(shared_dossier, dict) else {}
        dossier_identity_ready = bool(
            isinstance(dossier_home, dict) and isinstance(dossier_away, dict)
            and int(dossier_home.get("id") or 0) > 0
            and int(dossier_away.get("id") or 0) > 0
        )
        model_only_recovery = _proto_can_finish_model_only_analysis(m)

        if dossier_identity_ready:
            # The team worker already verified this exact scheduled pair.  Do
            # not make the analysis worker resolve it a second time.
            home_info = dict(dossier_home)
            away_info = dict(dossier_away)
            identity_fixture = int(shared_dossier.get("fixture_id") or 0)
        elif model_only_recovery:
            # This pair was already verified in the local identity cache.  Do
            # not send it back through the match/logo robot merely because a
            # source has not supplied a current fixture or logo yet.  The
            # normal analysis below can use the cached team IDs and will keep
            # the missing fixture explicit instead of leaving the card blank.
            home_info = dict(get_cached_team_display_profile(home_team) or {})
            away_info = dict(get_cached_team_display_profile(away_team) or {})
            home_info["id"] = int(home_info.get("id") or known_team_id(home_team) or 0)
            away_info["id"] = int(away_info.get("id") or known_team_id(away_team) or 0)
            identity_fixture = 0
        else:
            home_info, away_info, identity_fixture = resolve_match_team_pair(
                home_team, away_team, final_match_time, ttl_h=2,
                league_name=m.get("league") or "",
            )
        home_id = int(home_info.get("id") or 0)
        away_id = int(away_info.get("id") or 0)
        identity_ready = bool(
            home_id > 0
            and away_id > 0
            and home_id != away_id
            and (
                model_only_recovery
                or (
                    home_info.get("logo") not in (None, "", DEFAULT_LOGO)
                    and away_info.get("logo") not in (None, "", DEFAULT_LOGO)
                )
            )
        )
        if not identity_ready:
            queue_team_identity_retry(
                home_team, away_team, final_match_time,
                reason="proto_identity_and_logo_required_before_public_pick",
                league_name=m.get("league") or "",
            )
            preserved = _preserve_visible_proto_pick_for_retry(
                m, previous_item, "team_identity_logo_prefetch_pending"
            )
            if preserved is not None:
                dashboard_proto.append(preserved)
                deferred_proto_count += 1
                print(
                    f"♻️ 팀 자료 보강 대기 - 기존 분석픽 유지: "
                    f"{home_team} vs {away_team}"
                )
                continue
            pending = _pending_proto_item(m)
            pending["public_pick_block_reason"] = "team_identity_logo_form_prefetch_pending"
            pending.update({
                "home_team_id": home_id,
                "away_team_id": away_id,
                "api_fixture_id": int(identity_fixture or 0),
                "home_logo": home_info.get("logo") or DEFAULT_LOGO,
                "away_logo": away_info.get("logo") or DEFAULT_LOGO,
                "data_warning": "양 팀 신원·마크·최근 경기 자료를 먼저 확보한 뒤 분석픽을 생성합니다.",
            })
            dashboard_proto.append(pending)
            deferred_proto_count += 1
            continue

        now = datetime.now(timezone(timedelta(hours=9)))
        diff_hours = (m_dt - now).total_seconds() / 3600.0
        odds_ttl = 0.5 if diff_hours <= 2 else 4
        odd_h = float(m.get("odd_h") or 0)
        odd_d = float(m.get("odd_d") or 0)
        odd_a = float(m.get("odd_a") or 0)
        analysis_odds_source = "betman"
        preloaded_os_data = None
        if not _valid_three_way_odds([odd_h, odd_d, odd_a]):
            # 배당이 잠시 비었을 때 같은 경기의 마지막 정상 분석이 있으면
            # 그대로 유지한다. 새 경기라서 계산 근거 자체가 없을 때만 대기한다.
            previous_item = previous_proto.get(str(m.get("id", "")))
            previous_match = previous_item.get("match", {}) if isinstance(previous_item, dict) else {}
            if (
                isinstance(previous_item, dict)
                and previous_match.get("home") == home_team
                and previous_match.get("away") == away_team
                and isinstance(previous_item.get("pick_categories"), dict)
                and previous_item["pick_categories"].get("high_probability")
                and str(previous_item.get("odds_source") or "betman") != "model_only"
                and not _needs_current_analysis_refresh(
                    previous_item, scheduled, datetime.now(KST), ANALYSIS_VERSION
                )
            ):
                preserved = dict(previous_item)
                preserved["match"] = dict(m)
                preserved["final_match_time"] = final_match_time
                preserved["timestamp"] = m_dt.timestamp()
                preserved["odds_temporarily_missing"] = True
                _observe_locked_pick_market_flow(
                    preserved, "PROTO", str(m.get("id") or ""),
                    int(preserved.get("api_fixture_id") or 0),
                    str(preserved.get("league") or m.get("league") or "프로토"),
                    home_team, away_team, scheduled, diff_hours,
                )
                dashboard_proto.append(preserved)
                print(f"⚠️ 배당 일시 누락 - 마지막 정상 분석 유지: {home_team} vs {away_team}")
                continue

            # 신규 경기의 베트맨 배당이 비어 있으면 정확히 연결된 동일 경기의
            # 해외 1X2 중앙값을 먼저 사용한다. 해외배당도 없을 때는 배당을
            # 만들어내지 않고 팀 데이터만으로 확률픽 하나를 계산한다.
            preloaded_os_data = fetch_overseas_odds_and_fixture_api(
                home_info.get("id"), away_info.get("id"), odds_ttl,
                final_match_time, include_odds=True,
            )
            overseas_values = [
                (preloaded_os_data or {}).get("odd_h"),
                (preloaded_os_data or {}).get("odd_d"),
                (preloaded_os_data or {}).get("odd_a"),
            ]
            m = dict(m)
            m["betman_odds_pending"] = True
            if _valid_three_way_odds(overseas_values):
                odd_h, odd_d, odd_a = map(float, overseas_values)
                m.update({
                    "odd_h": odd_h,
                    "odd_d": odd_d,
                    "odd_a": odd_a,
                    "odds_source": "overseas_fallback",
                    "overseas_bookmaker_count": int(
                        (preloaded_os_data or {}).get("bookmaker_count") or 0
                    ),
                })
                analysis_odds_source = "overseas_fallback"
                print(f"🌍 베트맨 배당 대기 - 해외 1X2 임시 분석: {home_team} vs {away_team}")
            else:
                m["odds_source"] = "model_only"
                analysis_odds_source = "model_only"
                print(f"📊 모든 배당 대기 - 팀 데이터 모델 선픽: {home_team} vs {away_team}")
        handi_h = float(m.get("handi_h") or 0)
        handi_d = float(m.get("handi_d") or 0)
        handi_a = float(m.get("handi_a") or 0)
        handi_base = float(m.get("handi_base") or 0)
        uo_under = float(m.get("uo_under") or 0)
        uo_over = float(m.get("uo_over") or 0)
        uo_base = float(m.get("uo_base") or 2.5)

        # 🔥 '시간 미정' 경기들 살리기 위해 예외처리(continue) 삭제!
        heavy_ttl = 24
        inj_ttl = 0.5 if diff_hours <= 1.5 else 12
        lineup_ttl = 0.25 if diff_hours <= 1.5 else 12
         
        os_data = preloaded_os_data or fetch_overseas_odds_and_fixture_api(
            home_info.get("id"), away_info.get("id"), odds_ttl, final_match_time,
            include_odds=(
                0 < diff_hours <= 24
                and not _valid_three_way_odds([odd_h, odd_d, odd_a])
            ),
        )
        api_fixture_id = int((os_data or {}).get("fixture_id") or identity_fixture or 0)
        model_only_verified_pair = bool(
            analysis_odds_source == "model_only"
            and home_id > 0
            and away_id > 0
            and home_id != away_id
        )
        if api_fixture_id <= 0 and not model_only_verified_pair:
            queue_team_identity_retry(
                home_team, away_team, final_match_time,
                reason="proto_fixture_identity_required_before_public_pick",
                league_name=m.get("league") or "",
            )
            preserved = _preserve_visible_proto_pick_for_retry(
                m, previous_item, "fixture_identity_prefetch_pending"
            )
            if preserved is not None:
                dashboard_proto.append(preserved)
                deferred_proto_count += 1
                print(
                    f"♻️ 경기 연결 보강 대기 - 기존 분석픽 유지: "
                    f"{home_team} vs {away_team}"
                )
                continue
            pending = _pending_proto_item(m)
            pending["public_pick_block_reason"] = "fixture_identity_prefetch_pending"
            pending.update({
                "home_team_id": home_id,
                "away_team_id": away_id,
                "api_fixture_id": 0,
                "home_logo": home_info.get("logo") or DEFAULT_LOGO,
                "away_logo": away_info.get("logo") or DEFAULT_LOGO,
                "data_warning": "공식 경기 연결을 먼저 확인한 뒤 분석픽을 생성합니다.",
            })
            dashboard_proto.append(pending)
            deferred_proto_count += 1
            continue
        if model_only_verified_pair and api_fixture_id <= 0:
            # There is no exact external fixture to attach yet, but the two
            # teams are verified and their stored team data can support a real
            # pre-kickoff probability pick.  Keep the missing fixture explicit
            # so neither price value nor a later result link is invented.
            m["fixture_identity_pending"] = True
        match_analysis_started = time.monotonic()
        print(
            f"⚙️ PROTO 정밀분석 시작: {home_team} vs {away_team} "
            f"({analyzed_proto_count + 1}/{MASTER_ANALYSIS_NEW_MATCHES_PER_PASS})"
        )
        analyzed_proto_count += 1
        referee = os_data.get("referee") if os_data else None
        city = os_data.get("city") if os_data else None
        proto_movement = _detect_odds_movement({}, {})
        # Reuse the single overseas quote already fetched by the fixture helper.
        # Capture all markets and bookmaker IDs, never issue a diagnostic request.
        raw_quotes = (os_data or {}).get("odds_response") or []
        if api_fixture_id and raw_quotes:
            quote_snapshot = _world_market_snapshot_from_response(raw_quotes, api_fixture_id)
            set_db_cache(f"world_market_v3_{api_fixture_id}", quote_snapshot)
            proto_movement = capture_odds_movement(
                api_fixture_id, "PROTO", prediction_stage(diff_hours, False), quote_snapshot
            )
        weather_condition = fetch_weather_api(city, odds_ttl)
        weather_details = fetch_weather_details_api(city, odds_ttl)
         
        fixture_details = fetch_fixture_details_api(home_info["id"], away_info["id"], heavy_ttl)
        h_stand = fetch_team_standing_api(home_info.get("id"), heavy_ttl, (os_data or {}).get("league_id"), (os_data or {}).get("season"))
        a_stand = fetch_team_standing_api(away_info.get("id"), heavy_ttl, (os_data or {}).get("league_id"), (os_data or {}).get("season"))
        h_rank, a_rank = h_stand["rank"], a_stand["rank"]
        
        h_manager = fetch_new_manager_status(home_info.get("id"), heavy_ttl)
        a_manager = fetch_new_manager_status(away_info.get("id"), heavy_ttl)
        h_manager_buff = 0.08 if h_manager.get("is_new_manager") else 0.0
        a_manager_buff = 0.08 if a_manager.get("is_new_manager") else 0.0
        is_derby = check_derby_match(home_team, away_team)
         
        h_market_bonus, a_market_bonus = 0.0, 0.0
        if (
            analysis_odds_source == "betman"
            and os_data and os_data.get("odd_h")
            and odd_h > 1.0 and odd_a > 1.0
        ):
            if os_data["odd_h"] < odd_h - 0.15: h_market_bonus = 0.05
            if os_data["odd_a"] < odd_a - 0.15: a_market_bonus = 0.05
        # 같은 경기의 서로 다른 수집 시점에서 여러 업체 중앙값이 함께
        # 움직인 경우만 사용한다. 단일 업체 변동이나 한 번뿐인 조회는 제외한다.
        h_market_bonus = max(
            h_market_bonus, float(proto_movement.get("home_bonus") or 0)
        )
        a_market_bonus = max(
            a_market_bonus, float(proto_movement.get("away_bonus") or 0)
        )
             
        rank_diff_bonus_h = max(-0.18, min(0.18, (a_rank - h_rank) * 0.012)) if 99 not in (h_rank, a_rank) else 0.0
        rank_diff_bonus_a = max(-0.18, min(0.18, (h_rank - a_rank) * 0.012)) if 99 not in (h_rank, a_rank) else 0.0
        
        h_survival = calculate_survival_motivation(h_stand)
        a_survival = calculate_survival_motivation(a_stand)
        
        h_title_buff = 0.06 if 1 <= h_rank <= 3 else 0.0
        a_title_buff = 0.06 if 1 <= a_rank <= 3 else 0.0
        
        h_played = h_stand.get("played", 0)
        h_total_teams = h_stand.get("total_teams", 20)
        h_team_goals = h_stand.get("team_goals", 0)
        is_late_season_h = h_played > 0 and (h_played / max(1, (h_total_teams - 1) * 2)) >= 0.75
        h_vacation = 0.08 if (is_late_season_h and 6 <= h_rank <= max(10, h_total_teams - 4)) else 0.0
        
        a_played = a_stand.get("played", 0)
        a_total_teams = a_stand.get("total_teams", 20)
        a_team_goals = a_stand.get("team_goals", 0)
        is_late_season_a = a_played > 0 and (a_played / max(1, (a_total_teams - 1) * 2)) >= 0.75
        a_vacation = 0.08 if (is_late_season_a and 6 <= a_rank <= max(10, a_total_teams - 4)) else 0.0
         
        h_inj_data = fetch_team_injuries_api(home_info.get("id"), h_stand.get("league_id"), h_stand.get("season"), inj_ttl, api_fixture_id)
        a_inj_data = fetch_team_injuries_api(away_info.get("id"), a_stand.get("league_id"), a_stand.get("season"), inj_ttl, api_fixture_id)
        h_inj_count, a_inj_count = h_inj_data["count"], a_inj_data["count"]
        
        h_missing_goals = h_inj_data.get("missing_goals", 0)
        h_goal_dep_ratio = (h_missing_goals / h_team_goals) if h_team_goals > 0 else 0
        h_oneman_penalty = 0.15 if h_goal_dep_ratio >= 0.25 else 0.0
        
        a_missing_goals = a_inj_data.get("missing_goals", 0)
        a_goal_dep_ratio = (a_missing_goals / a_team_goals) if a_team_goals > 0 else 0
        a_oneman_penalty = 0.15 if a_goal_dep_ratio >= 0.25 else 0.0
        
        h_war_pct, h_war_details, h_war_score = calculate_war_penalty(home_team, h_inj_data["ace_names"], h_inj_count, home_info.get("id"))
        a_war_pct, a_war_details, a_war_score = calculate_war_penalty(away_team, a_inj_data["ace_names"], a_inj_count, away_info.get("id"))

        h_lineup_penalty, a_lineup_penalty = 0.0, 0.0
        h_lineup_msg, a_lineup_msg = "", ""
        lineup_confirmed = False
        lineup_data = {"confirmed": False}
        h_starters, a_starters = [], []
        h_core = get_expected_core_players(
            home_info.get("id"), h_stand.get("league_id"), h_stand.get("season")
        )
        a_core = get_expected_core_players(
            away_info.get("id"), a_stand.get("league_id"), a_stand.get("season")
        )
        h_predicted_xi, h_lineup_prediction = predict_starting_xi(
            home_info.get("id"), h_stand.get("league_id"), h_stand.get("season"),
            h_inj_data.get("all_names") or h_inj_data.get("ace_names") or [],
            historical_lineups=not MASTER_CACHE_ONLY_SERVING,
            cached_learning_only=MASTER_CACHE_ONLY_SERVING,
        )
        a_predicted_xi, a_lineup_prediction = predict_starting_xi(
            away_info.get("id"), a_stand.get("league_id"), a_stand.get("season"),
            a_inj_data.get("all_names") or a_inj_data.get("ace_names") or [],
            historical_lineups=not MASTER_CACHE_ONLY_SERVING,
            cached_learning_only=MASTER_CACHE_ONLY_SERVING,
        )
        if diff_hours <= 1.5:
            lineup_data = fetch_lineups_api(api_fixture_id, lineup_ttl)
            h_starters = lineup_data.get(str(home_info.get("id")), [])
            a_starters = lineup_data.get(str(away_info.get("id")), [])
            lineup_confirmed = bool(lineup_data.get("confirmed"))

            if lineup_confirmed:
                h_missing = find_missing_core_players(sorted(set(h_core + h_inj_data.get("ace_names", []))), h_starters)
                a_missing = find_missing_core_players(sorted(set(a_core + a_inj_data.get("ace_names", []))), a_starters)

                h_injury_names = {_normalize_player_name(name) for name in h_inj_data.get("ace_names", [])}
                a_injury_names = {_normalize_player_name(name) for name in a_inj_data.get("ace_names", [])}
                h_unexpected = [name for name in h_missing if _normalize_player_name(name) not in h_injury_names]
                a_unexpected = [name for name in a_missing if _normalize_player_name(name) not in a_injury_names]
                if h_missing:
                    h_lineup_penalty = 0.12 if len(h_unexpected) == 1 else (0.20 if len(h_unexpected) >= 2 else 0.0)
                    h_lineup_msg = f"🚨 [선발 확인] 홈팀 핵심 {', '.join(h_missing[:3])} 선발 제외"
                if a_missing:
                    a_lineup_penalty = 0.12 if len(a_unexpected) == 1 else (0.20 if len(a_unexpected) >= 2 else 0.0)
                    a_lineup_msg = f"🚨 [선발 확인] 원정팀 핵심 {', '.join(a_missing[:3])} 선발 제외"

        h_last_data = fetch_team_last_match_date_api(home_info.get("id"), heavy_ttl)
        a_last_data = fetch_team_last_match_date_api(away_info.get("id"), heavy_ttl)
        h_rest_days = calculate_rest_days(h_last_data.get("date"), final_match_time)
        a_rest_days = calculate_rest_days(a_last_data.get("date"), final_match_time)
        h_extreme_fatigue, a_extreme_fatigue = h_last_data.get("is_extreme_fatigue"), a_last_data.get("is_extreme_fatigue")
         
        h_next = fetch_team_next_fixture_api(home_info.get("id"), heavy_ttl)
        a_next = fetch_team_next_fixture_api(away_info.get("id"), heavy_ttl)
        match_importance = build_match_importance_profile(
            h_stand, a_stand, h_next, a_next, is_derby=is_derby
        )
        h_long = fetch_team_long_term_stats_api(home_info.get("id"), heavy_ttl)
        a_long = fetch_team_long_term_stats_api(away_info.get("id"), heavy_ttl)
        h_recent = fetch_team_recent_form_metrics(home_info.get("id"), heavy_ttl)
        a_recent = fetch_team_recent_form_metrics(away_info.get("id"), heavy_ttl)
         
        league_n = m.get('league', '')
        if league_n not in market_performance_cache:
            market_performance_cache[league_n] = load_market_performance(
                league_n, serving_only=MASTER_CACHE_ONLY_SERVING
            )
        market_performance = market_performance_cache[league_n]
        h_stats = fetch_recent_team_stats_api(home_info.get("id"), heavy_ttl)
        a_stats = fetch_recent_team_stats_api(away_info.get("id"), heavy_ttl)
        has_market_odds = _valid_three_way_odds([odd_h, odd_d, odd_a])

        h_depth_factor = calculate_squad_depth_factor(h_stand)
        a_depth_factor = calculate_squad_depth_factor(a_stand)

        # 🔥 확률 떡락 방지 (최대 2개 악재만 반영하여 35% 캡 적용)
        h_fatigue_pct = (0.15 if h_extreme_fatigue else 0.08) if h_rest_days <= 3 else 0.0
        a_fatigue_pct = (0.15 if a_extreme_fatigue else 0.08) if a_rest_days <= 3 else 0.0
        h_rot_pct = 0.10 if h_next["is_important"] and h_next["days_until_next"] <= 4 else 0.0
        a_rot_pct = 0.10 if a_next["is_important"] and a_next["days_until_next"] <= 4 else 0.0

        # 주심 성향은 양 팀 전력 패널티가 아니라 카드/변동성 정보로만 사용한다.
        h_penalties = [h_war_pct, h_fatigue_pct, h_rot_pct, h_lineup_penalty, h_vacation, h_oneman_penalty]
        a_penalties = [a_war_pct, a_fatigue_pct, a_rot_pct, a_lineup_penalty, a_vacation, a_oneman_penalty]
        h_penalties.sort(reverse=True)
        a_penalties.sort(reverse=True)
        
        h_total_penalty = combine_availability_penalties(h_war_pct, h_lineup_penalty, h_oneman_penalty, h_fatigue_pct, h_rot_pct, h_depth_factor)
        a_total_penalty = combine_availability_penalties(a_war_pct, a_lineup_penalty, a_oneman_penalty, a_fatigue_pct, a_rot_pct, a_depth_factor)
        
        cross_boost_a = h_total_penalty * 0.4
        cross_boost_h = a_total_penalty * 0.4

        fixture_details = fetch_fixture_details_api(home_info["id"], away_info["id"], heavy_ttl)
        h2h_total = fixture_details.get("total", 0)
        h_wins = fixture_details.get("h_wins", 0)
        h2h_draws = fixture_details.get("draws", 0)
        a_wins = fixture_details.get("a_wins", 0)
        h_h2h_bonus = max(-0.10, min(0.10, ((h_wins - a_wins) / h2h_total) * 0.12)) if h2h_total > 0 else 0
        a_h2h_bonus = -h_h2h_bonus
        
        h_kryptonite, a_kryptonite = 0.0, 0.0
        h_matchup_msg, a_matchup_msg = "", ""
        if h2h_total >= 3:
            if (h_wins / h2h_total) >= 0.65:
                h_kryptonite = 0.04
                h_matchup_msg = f"⚔️ 천적 상성 ({h_wins}승/{h2h_total}전)"
            elif (a_wins / h2h_total) >= 0.65:
                a_kryptonite = 0.04
                a_matchup_msg = f"⚔️ 천적 상성 ({a_wins}승/{h2h_total}전)"

        exp_h, exp_a, goal_model_audit = estimate_match_goals(
            h_long, a_long, h_recent, a_recent, h_stats, a_stats, league_n,
            h_total_penalty, a_total_penalty,
        )
        exp_h, exp_a, goal_model_audit = apply_cached_opponent_model(
            exp_h, exp_a, goal_model_audit, home_info.get("id"), away_info.get("id"),
            (os_data or {}).get("league_id"), m_dt, h_total_penalty, a_total_penalty,
        )
        exp_h, exp_a, context_audit, goal_model_audit = integrate_pre_match_context(
            exp_h, exp_a,
            {
                "h2h": fixture_details, "home_rank": h_rank, "away_rank": a_rank,
                "home_recent_strength": float(h_recent.get("strength") or 0),
                "away_recent_strength": float(a_recent.get("strength") or 0),
                "recent_available": min(int(h_recent.get("matches") or 0), int(a_recent.get("matches") or 0)) >= 3,
                "home_absence": h_total_penalty, "away_absence": a_total_penalty,
                "home_title": h_title_buff, "away_title": a_title_buff,
                "home_manager": h_manager_buff, "away_manager": a_manager_buff,
                "home_vacation": h_vacation, "away_vacation": a_vacation,
                "home_survival": h_survival, "away_survival": a_survival,
                "home_market": h_market_bonus, "away_market": a_market_bonus,
                "weather": weather_condition, "referee": referee,
                "is_derby": is_derby,
            },
            goal_model_audit,
        )

        base_confidence = calculate_data_confidence(
            home_info, away_info, api_fixture_id, h_stand, a_stand, h_long, a_long,
            h_recent, a_recent, h_stats, a_stats, h_inj_data, a_inj_data,
            diff_hours, lineup_confirmed,
        )
        movement_parts = []
        if h_market_bonus > 0:
            movement_parts.append(f"{home_team} 해외 승 배당 하락")
        if a_market_bonus > 0:
            movement_parts.append(f"{away_team} 해외 승 배당 하락")
        if proto_movement.get("summary"):
            movement_parts.append(str(proto_movement["summary"]))
        tactical_parts = [text for text in (h_matchup_msg, a_matchup_msg) if text]
        if is_derby:
            tactical_parts.append("로컬 더비 변동성")
        if h_survival.get("active"):
            tactical_parts.append(f"{home_team} 잔류 경쟁({h_survival['reason']})")
        if a_survival.get("active"):
            tactical_parts.append(f"{away_team} 잔류 경쟁({a_survival['reason']})")
        motivation_parts = []
        if h_title_buff: motivation_parts.append(f"{home_team} 상위권 경쟁")
        if a_title_buff: motivation_parts.append(f"{away_team} 상위권 경쟁")
        if h_manager_buff: motivation_parts.append(f"{home_team} 새 감독")
        if a_manager_buff: motivation_parts.append(f"{away_team} 새 감독")
        if h_vacation: motivation_parts.append(f"{home_team} 말기 중위권 동기 저하")
        if a_vacation: motivation_parts.append(f"{away_team} 말기 중위권 동기 저하")
        evidence, data_coverage = build_analysis_evidence({
            "h_recent": h_recent,
            "a_recent": a_recent,
            "h_stats": h_stats,
            "a_stats": a_stats,
            "h_long": h_long,
            "a_long": a_long,
            "h_inj": h_inj_data,
            "a_inj": a_inj_data,
            "h2h_total": h2h_total,
            "h_wins": h_wins,
            "draws": h2h_draws,
            "a_wins": a_wins,
            "home_rank": h_rank,
            "away_rank": a_rank,
            "h_rest_days": h_rest_days,
            "a_rest_days": a_rest_days,
            "weather": weather_condition if weather_condition not in (None, "", "Unknown") else None,
            "referee": referee,
            "motivation_text": ", ".join(motivation_parts),
            "tactical_text": ", ".join(tactical_parts),
            "movement_text": ", ".join(movement_parts),
            "home_id": home_info.get("id"),
            "away_id": away_info.get("id"),
            "fixture_id": api_fixture_id,
        })
        coverage_confidence = 0.35 + (0.60 * data_coverage)
        analysis_confidence = round(
            max(0.35, min(0.95, (base_confidence * 0.45) + (coverage_confidence * 0.55))),
            3,
        )
        if analysis_odds_source == "overseas_fallback":
            analysis_confidence = round(max(0.35, analysis_confidence * 0.95), 3)
        elif analysis_odds_source == "model_only":
            analysis_confidence = round(max(0.35, analysis_confidence * 0.85), 3)
         
        movement_policy = market_performance.get("_movement_policy") or {}
        movement_adjustment = learned_movement_wdl_adjustment(
            proto_movement, movement_policy, league_n
        )
        probabilities, joint_audit, joint_matrix = coherent_match_forecast(
            exp_h, exp_a, handi_base, uo_base, [odd_h, odd_d, odd_a],
            analysis_confidence, market_performance.get("1x2"), goal_model_audit.get("rho", -.15),
            movement_adjustment, context_audit.get("wdl_log_adjustment"),
        )
        joint_audit["movement_policy"] = {
            key: movement_policy.get(key) for key in
            ("active", "method", "cohort_fixtures", "validation_fixtures",
             "baseline_brier", "corrected_brier", "reason")
        }
        h_win, draw, a_win, prob_u, prob_o, prob_handi_h, prob_handi_d, prob_handi_a = probabilities
        goal_model_audit["joint_forecast"] = joint_audit

        wdl_market = (
            normalize_probabilities([1 / odd_h, 1 / odd_d, 1 / odd_a])
            if has_market_odds else [0.0, 0.0, 0.0]
        )
        underdog_side = (
            "home" if odd_h > odd_a else ("away" if odd_a > odd_h else "")
        ) if has_market_odds else ""
        wdl_cands = [
            {"label": "일반 승무패 예측", "sort_id": 3, "raw_pick": f"{home_team} 승", "html_pick": f"{home_team} 승", "prob": h_win, "ev": h_win * odd_h, "odd": odd_h, "market_prob": wdl_market[0], "selection_side": "home"},
            {"label": "일반 승무패 예측", "sort_id": 3, "raw_pick": "무승부", "html_pick": "무승부", "prob": draw, "ev": draw * odd_d, "odd": odd_d, "market_prob": wdl_market[1], "selection_side": "draw"},
            {"label": "일반 승무패 예측", "sort_id": 3, "raw_pick": f"{away_team} 승", "html_pick": f"{away_team} 승", "prob": a_win, "ev": a_win * odd_a, "odd": odd_a, "market_prob": wdl_market[2], "selection_side": "away"}
        ]
         
        handi_str_raw = f"[{handi_base:+1.1f}] "
        if handi_base < 0:
            h_label = f"🔥 [마핸승] {home_team} ({handi_base:+1.1f})" 
            a_label = f"🛡️ [핸디패] {home_team} 패배 ({handi_base:+1.1f})" 
        else:
            h_label = f"🛡️ [플핸승] {home_team} ({handi_base:+1.1f})"
            a_label = f"🔥 [핸디패] {home_team} 패배 ({handi_base:+1.1f})" 
             
        h_html = f"<span style='color:#00F2FE; font-size:14px; font-weight:900;'>{h_label}</span><br>"
        a_html = f"<span style='color:#00F2FE; font-size:14px; font-weight:900;'>{a_label}</span><br>"
        d_html = f"<span style='color:#00F2FE; font-size:14px; font-weight:900;'>핸디무 ({handi_base:+1.1f})</span><br>"

        handi_cands = []
        handi_has_odds = min(handi_h, handi_d, handi_a) > 1.0
        handi_market = normalize_probabilities(
            [1 / handi_h, 1 / handi_d, 1 / handi_a]
        ) if handi_has_odds else [0, 0, 0]
        if handi_has_odds or abs(handi_base) > 0.001:
            handi_cands = [
                {"label": "핸디캡 예측", "sort_id": 2, "raw_pick": f"{handi_str_raw}{home_team} 핸디승", "html_pick": h_html, "prob": prob_handi_h, "ev": prob_handi_h * handi_h, "odd": handi_h if handi_h > 1.0 else 0.0, "market_prob": handi_market[0], "selection_side": "home", "handicap_base": handi_base},
                {"label": "핸디캡 예측", "sort_id": 2, "raw_pick": f"{handi_str_raw}핸디무", "html_pick": d_html, "prob": prob_handi_d, "ev": prob_handi_d * handi_d, "odd": handi_d if handi_d > 1.0 else 0.0, "market_prob": handi_market[1], "selection_side": "draw", "handicap_base": handi_base},
                {"label": "핸디캡 예측", "sort_id": 2, "raw_pick": f"{handi_str_raw}{home_team} 핸디패", "html_pick": a_html, "prob": prob_handi_a, "ev": prob_handi_a * handi_a, "odd": handi_a if handi_a > 1.0 else 0.0, "market_prob": handi_market[2], "selection_side": "away", "handicap_base": handi_base},
            ]
         
        uo_str_raw = f"(U/O {uo_base})"
        uo_str_html = f"<span style='color:#00F2FE; font-size:14px; font-weight:900;'>[기준 {uo_base}]</span><br>"
        uo_has_odds = uo_under > 1.0 and uo_over > 1.0
        uo_market = normalize_probabilities(
            [1 / uo_under, 1 / uo_over]
        ) if uo_has_odds else [0, 0]
        # 2.5 기준 득점 모델은 배당이 없어도 계산할 수 있다. 따라서 모든
        # 정상 경기에서 교차 시장 대안 후보를 유지하되, 배당이 없으면 가치나
        # VIP 검증에는 사용하지 않는다.
        uo_cands = [
            {"label": "언더 예측", "sort_id": 1, "raw_pick": f"언더 {uo_str_raw}", "html_pick": f"{uo_str_html}⬇️ 언더", "prob": prob_u, "ev": prob_u * uo_under, "odd": uo_under if uo_under > 1.0 else 0.0, "market_prob": uo_market[0], "selection_side": "under"},
            {"label": "오버 예측", "sort_id": 1, "raw_pick": f"오버 {uo_str_raw}", "html_pick": f"{uo_str_html}⬆️ 오버", "prob": prob_o, "ev": prob_o * uo_over, "odd": uo_over if uo_over > 1.0 else 0.0, "market_prob": uo_market[1], "selection_side": "over"},
        ]
         
        # 승무패와 핸디캡은 서로 모순되는 시장이 아니다. 예를 들어 홈팀의
        # 1골 차 승리는 일반 승과 -1.0 핸디무를 동시에 만들 수 있다.
        # 예전의 문자열 기반 "상충 후보" 제거는 실제 정답 후보를 버릴 수
        # 있으므로, 제공된 세 시장의 모든 방향을 같은 출발선에서 비교한다.
        all_market_picks = wdl_cands + handi_cands + uo_cands
        valid_all_picks = all_market_picks
        attach_analysis_contracts(all_market_picks, exp_h, exp_a, uo_base, goal_model_audit, joint_matrix)
        calibrate_market_candidates(
            all_market_picks, market_performance, analysis_confidence
        )
        attach_underdog_signals(
            all_market_picks,
            home_team,
            away_team,
            {
                "home_absence": h_total_penalty,
                "away_absence": a_total_penalty,
                "home_market_bonus": h_market_bonus,
                "away_market_bonus": a_market_bonus,
                "home_tactical": h_kryptonite,
                "away_tactical": a_kryptonite,
                "home_recent": h_recent.get("strength", 0.0),
                "away_recent": a_recent.get("strength", 0.0),
                "home_rest": h_rest_days if h_rest_days < 90 else 0,
                "away_rest": a_rest_days if a_rest_days < 90 else 0,
                "home_lineup": h_lineup_penalty,
                "away_lineup": a_lineup_penalty,
                "home_rank": h_rank,
                "away_rank": a_rank,
                "home_title": h_title_buff,
                "away_title": a_title_buff,
                "home_manager": h_manager_buff,
                "away_manager": a_manager_buff,
                "home_survival": h_survival,
                "away_survival": a_survival,
                "home_venue_model": True,
                "context_audit": context_audit,
                "underdog_side": underdog_side,
                "movement": proto_movement,
            },
        )
        annotate_pick_metrics(all_market_picks, analysis_confidence)
        pick_categories, ev_sorted_picks = select_pick_categories(
            valid_all_picks, analysis_confidence
        )
        lineup_learning = {
            "schema_version": ROBOT_LINEUP_SCHEMA_VERSION,
            "mode": "predicted-xi-then-official-answer-v2",
            "home_team_id": int(home_info.get("id") or 0),
            "away_team_id": int(away_info.get("id") or 0),
            "home_predicted_core": list(h_core),
            "away_predicted_core": list(a_core),
            "home_predicted_starting_xi": list(h_predicted_xi),
            "away_predicted_starting_xi": list(a_predicted_xi),
            "home_official_starters": list(h_starters),
            "away_official_starters": list(a_starters),
            "home_active_starting_xi": list(h_starters or h_predicted_xi),
            "away_active_starting_xi": list(a_starters or a_predicted_xi),
            "official_details": lineup_data.get("details") or {},
            "home_prediction_audit": h_lineup_prediction,
            "away_prediction_audit": a_lineup_prediction,
            "official_replaced_prediction": bool(lineup_confirmed),
        }
        proto_full_evidence = _robot_full_pre_match_evidence(
            "PROTO", m, league_n, (os_data or {}).get("league_id"),
            (os_data or {}).get("season"),
            {**home_info, "display_name": home_team, "venue_role": "home"},
            {**away_info, "display_name": away_team, "venue_role": "away"},
            h_recent, a_recent, h_stats, a_stats, h_long, a_long,
            h_stand, a_stand, h_survival, a_survival,
            {"home": h_inj_data, "away": a_inj_data}, lineup_learning,
            {"home": h_rest_days, "away": a_rest_days},
            {
                "home": fetch_team_recent_fixtures_api(home_info.get("id"), heavy_ttl),
                "away": fetch_team_recent_fixtures_api(away_info.get("id"), heavy_ttl),
            },
            {"home": h_next, "away": a_next},
            {"home": h_manager, "away": a_manager}, fixture_details,
            {
                "city": city, "weather": weather_condition,
                "weather_details": weather_details, "referee": referee,
                "derby": is_derby, "home_venue": True,
            },
            {
                "source": analysis_odds_source,
                "betman": {
                    "home": odd_h, "draw": odd_d, "away": odd_a,
                    "handicap": {"line": handi_base, "home": handi_h, "draw": handi_d, "away": handi_a},
                    "totals": {"line": uo_base, "under": uo_under, "over": uo_over},
                },
                "overseas_fixture_and_quotes": os_data or {},
            },
            proto_movement, goal_model_audit, context_audit,
            analysis_confidence,
            {"coverage": data_coverage, "odds_source": analysis_odds_source},
            {
                "home_total_penalty": h_total_penalty,
                "away_total_penalty": a_total_penalty,
                "home_rank_signal": rank_diff_bonus_h,
                "away_rank_signal": rank_diff_bonus_a,
                "home_matchup_signal": h_kryptonite,
                "away_matchup_signal": a_kryptonite,
                "home_title_signal": h_title_buff,
                "away_title_signal": a_title_buff,
                "home_market_signal": h_market_bonus,
                "away_market_signal": a_market_bonus,
            },
        )
        robot_features = build_autonomous_robot_features(
            goal_model_audit, context_audit, valid_all_picks,
            analysis_confidence,
            {
                "source_proto": 1.0,
                "home_rank": 0 if h_rank == 99 else h_rank,
                "away_rank": 0 if a_rank == 99 else a_rank,
                "home_rank_known": h_rank != 99,
                "away_rank_known": a_rank != 99,
                "home_recent_strength": h_recent.get("strength", 0.0),
                "away_recent_strength": a_recent.get("strength", 0.0),
                "home_rest_days": 0 if h_rest_days >= 90 else h_rest_days,
                "away_rest_days": 0 if a_rest_days >= 90 else a_rest_days,
                "home_rest_known": h_rest_days < 90,
                "away_rest_known": a_rest_days < 90,
                "home_absence": h_total_penalty,
                "away_absence": a_total_penalty,
                "home_lineup_penalty": h_lineup_penalty,
                "away_lineup_penalty": a_lineup_penalty,
                "lineup_confirmed": lineup_confirmed,
                "h2h_total": h2h_total,
                "h2h_home_wins": h_wins,
                "h2h_draws": h2h_draws,
                "h2h_away_wins": a_wins,
                "is_derby": is_derby,
                "home_survival_active": bool(h_survival.get("active")),
                "away_survival_active": bool(a_survival.get("active")),
                "home_manager_active": h_manager_buff > 0,
                "away_manager_active": a_manager_buff > 0,
                "home_vacation_active": h_vacation > 0,
                "away_vacation_active": a_vacation > 0,
                "home_market_signal": h_market_bonus > 0,
                "away_market_signal": a_market_bonus > 0,
                "adverse_weather": str(weather_condition or "").casefold() in {"rain", "snow"},
            },
            all_evidence=proto_full_evidence,
        )
        legacy_v4_candidates = []
        legacy_v4_pick = {}
        robot_candidates = build_autonomous_robot_candidates(
            valid_all_picks, robot_features, proto_robot_artifact
        )
        robot_pick = select_autonomous_robot_pick(
            robot_candidates, analysis_confidence, robot_features,
            source="PROTO", robot_artifact=proto_robot_artifact,
            serving_only=MASTER_CACHE_ONLY_SERVING,
        )
        alphago_pick = _alphago_pick_payload(robot_pick)
        highest_prob_pick = pick_categories["high_probability"]
        honey_pick = pick_categories["honey"]
        vip_underdog_pick = pick_categories["vip_underdog"]

        # 공식 예측과 채점은 한 경기당 최종 추천픽 하나뿐이다. 꿀픽/VIP는
        # 그 동일 픽의 등급이므로 별도 예측 칸에 복제 저장하지 않는다.
        highest_ev_pick = None
        detailed_report = build_detailed_report(
            highest_prob_pick,
            evidence,
            analysis_confidence,
            all_market_picks,
            pick_categories,
            {
                "home": home_team,
                "away": away_team,
                "exp_h": exp_h,
                "exp_a": exp_a,
                "weather": weather_condition,
            },
        )
        detailed_report += "\n\n" + lineup_prediction_report(
            home_team, away_team, h_predicted_xi, a_predicted_xi,
            h_starters, a_starters,
        )
        independent_robot_report = robot_pick_report(robot_pick, home_team)
        if independent_robot_report:
            detailed_report += "\n\n" + independent_robot_report

        badge_templates = {
            "high_probability": "<span style='background:#10B981;color:#fff;padding:3px 8px;border-radius:4px;font-size:12px;font-weight:bold;margin-right:4px;'>🎯 최종 추천픽</span>",
            "honey": "<span style='background:#F59E0B;color:#fff;padding:3px 8px;border-radius:4px;font-size:12px;font-weight:bold;margin-right:4px;'>🍯 배당가치 우수</span>",
            "vip_underdog": "<span style='background:linear-gradient(to right,#FFD700,#F59E0B);color:#000;padding:3px 8px;border-radius:4px;font-size:12px;font-weight:900;margin-right:4px;box-shadow:0 0 5px rgba(255,215,0,.5);'>💎 VIP 검증 등급</span>",
        }
        for pick in valid_all_picks:
            matching_categories = [
                category_key
                for category_key, selected in pick_categories.items()
                if selected and selected.get("raw_pick") == pick.get("raw_pick")
            ]
            if matching_categories:
                badges = "".join(badge_templates[key] for key in matching_categories)
                pick["html_pick"] = (
                    "<div style='margin-bottom:6px;'>" + badges + "</div>"
                    + pick.get("html_pick", "")
                )

        # select_pick_categories는 안전하게 복사본을 반환하므로, 배지를 적용한
        # 원본의 표시 문자열만 다시 동기화합니다.
        for selected in pick_categories.values():
            if not selected:
                continue
            source_pick = next(
                (
                    pick
                    for pick in valid_all_picks
                    if pick.get("raw_pick") == selected.get("raw_pick")
                ),
                None,
            )
            if source_pick:
                selected["html_pick"] = source_pick.get(
                    "html_pick", selected.get("html_pick", "")
                )

        analysis_evidence_stage = prediction_stage(diff_hours, lineup_confirmed)
        analysis_stage = analysis_evidence_stage
        if analysis_odds_source == "overseas_fallback":
            analysis_stage = "overseas-preview"
        elif analysis_odds_source == "model_only":
            analysis_stage = "model-only-preview"
        reliability_score = round(
            (highest_prob_pick.get("safe_score", 0) * 0.75)
            + (highest_prob_pick.get("recommendation_score", 0) * 0.25), 4
        )
        underdog_signal = vip_underdog_pick.get("raw_pick") if vip_underdog_pick else ""
         
        save_dual_predictions_to_local_db(
            m['id'], league_n, home_team, away_team, 
            highest_prob_pick["raw_pick"], round(highest_prob_pick["prob"] * 100, 1), 
            highest_ev_pick["raw_pick"] if highest_ev_pick else "",
            round(highest_ev_pick["prob"] * 100, 1) if highest_ev_pick else 0.0,
            odd_h, odd_d, odd_a, final_match_time, 0, api_fixture_id,
            analysis_stage, analysis_confidence,
        )
        save_prediction_analysis(
            m["id"], highest_prob_pick, analysis_confidence,
            evidence, all_market_picks, detailed_report,
            categories=pick_categories,
            analysis_stage=analysis_stage,
            odds_source=analysis_odds_source,
            robot_pick=robot_pick,
            lineup_prediction=lineup_learning,
        )
        save_three_engine_picks(
            "PROTO", m["id"], api_fixture_id, league_n,
            home_team, away_team, m_dt, highest_prob_pick,
            legacy_v4_pick, robot_pick,
        )
        save_autonomous_robot_sample(
            "PROTO", m["id"], api_fixture_id, league_n,
            home_team, away_team, m_dt, robot_features,
            robot_candidates, robot_pick,
            full_evidence=proto_full_evidence,
            lineup_prediction=lineup_learning,
            analysis_stage=analysis_stage,
        )

        h_form = fetch_team_form_api(home_info.get("id"), heavy_ttl)
        a_form = fetch_team_form_api(away_info.get("id"), heavy_ttl)
        if (
            home_info.get("logo") in (None, "", DEFAULT_LOGO)
            or away_info.get("logo") in (None, "", DEFAULT_LOGO)
            or not h_form or not a_form
        ):
            queue_team_identity_retry(
                home_team, away_team, final_match_time,
                reason="identity_ready_logo_or_recent_form_pending",
                league_name=m.get("league") or "",
            )
        story = "<br><br>".join(
            paragraph.replace("\n", "<br>")
            for paragraph in detailed_report.split("\n\n")
        )
        if analysis_odds_source == "overseas_fallback":
            story = (
                "🌍 <b>[해외 임시배당 분석]</b> 베트맨 승무패 배당 공개 전이라 "
                "동일 경기의 해외 1X2 중앙값으로 먼저 계산했습니다. 베트맨 "
                "배당이 들어오면 자동으로 다시 분석합니다.<br><br>" + story
            )
        elif analysis_odds_source == "model_only":
            story = (
                "📊 <b>[팀 데이터 모델 선픽]</b> 베트맨과 해외배당이 모두 준비되지 "
                "않아 최근 경기·득실·홈원정·선수 정보로 내부 후보를 계산했습니다. "
                "최종 추천은 표시하되, 실제 배당가치·역배 평가는 가격 수신 전까지 보류합니다."
                "<br><br>" + story
            )
        
        if is_derby: story += " ⚔️ [더비 참고] 라이벌 경기 정보만으로 득점·카드 확률을 임의 가산하지 않습니다."
        if h_manager_buff > 0: story += f" 👔 [감독 변경 참고] {home_team}의 최근 감독 변경 확인. 경기력 개선 여부는 미검증입니다."
        if a_manager_buff > 0: story += f" 👔 [감독 변경 참고] {away_team}의 최근 감독 변경 확인. 경기력 개선 여부는 미검증입니다."
        if h_survival.get("active"): story += f" [순위 경쟁 참고] {home_team}: {h_survival['reason']}. 의지·전술 변화를 단정하지 않습니다."
        if a_survival.get("active"): story += f" [순위 경쟁 참고] {away_team}: {a_survival['reason']}. 의지·전술 변화를 단정하지 않습니다."
        if match_importance.get("reasons"):
            story += (
                " [경기 맥락] " + ", ".join(match_importance["reasons"])
                + ". " + str(match_importance.get("notice") or "")
            )

        h_inj_html = _render_team_availability_status(
            h_inj_data, diff_hours, lineup_confirmed, h_lineup_msg
        )
        if h_war_score > 0:
            h_war_text = " / ".join(h_war_details)
            if h_oneman_penalty > 0: h_inj_html += f"<div class='injury-badge' style='background: rgba(220,38,38,0.2); border-color: #EF4444; color: #EF4444;'>🚨 득점루트 붕괴: 팀 득점의 {int(h_goal_dep_ratio*100)}% 이탈</div>"
            elif h_inj_data['ace_missing']: h_inj_html += f"<div class='injury-badge' style='background: rgba(220,38,38,0.2); border-color: #EF4444; color: #EF4444;'>🚨 전력누수(-{h_war_score:.1f}점): {h_war_text}</div>"
            else: h_inj_html += f"<div class='injury-badge'>🏥 전력누수(-{h_war_score:.1f}점): {h_war_text}</div>"
        if h_lineup_msg: h_inj_html += f"<div class='injury-badge' style='background: #EF4444; color: #fff;'>{h_lineup_msg}</div>"
        if h_title_buff > 0: h_inj_html += f"<div class='injury-badge' style='background: rgba(16, 185, 129, 0.2); border-color: #10B981; color: #10B981;'>🏆 우승 경쟁 버프</div>"
        if h_manager_buff > 0: h_inj_html += f"<div class='injury-badge' style='background: rgba(245, 158, 11, 0.2); border-color: #F59E0B; color: #F59E0B;'>👔 새 감독 버프 (부임 {h_manager['days_since_hired']}일차)</div>"
        if h_vacation > 0: h_inj_html += f"<div class='injury-badge' style='background: rgba(100, 116, 139, 0.2); border-color: #64748B; color: #64748B;'>🏖️ 동기부여 상실 (휴가 모드)</div>"
        if h_survival.get("active"): h_inj_html += f"<div class='injury-badge' style='background: rgba(249, 115, 22, 0.18); border-color: #F97316; color: #FB923C;'>🔥 잔류 생존전 · {h_survival['reason']}</div>"
        if h_matchup_msg: h_inj_html += f"<div class='injury-badge' style='background: rgba(59, 130, 246, 0.2); border-color: #3B82F6; color: #3B82F6;'>{h_matchup_msg}</div>"
        if is_derby: h_inj_html += f"<div class='injury-badge' style='background: rgba(239, 68, 68, 0.2); border-color: #EF4444; color: #EF4444;'>⚔️ 치열한 로컬 더비 매치</div>"

        a_inj_html = _render_team_availability_status(
            a_inj_data, diff_hours, lineup_confirmed, a_lineup_msg
        )
        if a_war_score > 0:
            a_war_text = " / ".join(a_war_details)
            if a_oneman_penalty > 0: a_inj_html += f"<div class='injury-badge' style='background: rgba(220,38,38,0.2); border-color: #EF4444; color: #EF4444;'>🚨 득점루트 붕괴: 팀 득점의 {int(a_goal_dep_ratio*100)}% 이탈</div>"
            elif a_inj_data['ace_missing']: a_inj_html += f"<div class='injury-badge' style='background: rgba(220,38,38,0.2); border-color: #EF4444; color: #EF4444;'>🚨 전력누수(-{a_war_score:.1f}점): {a_war_text}</div>"
            else: a_inj_html += f"<div class='injury-badge'>🏥 전력누수(-{a_war_score:.1f}점): {a_war_text}</div>"
        if a_lineup_msg: a_inj_html += f"<div class='injury-badge' style='background: #EF4444; color: #fff;'>{a_lineup_msg}</div>"
        if a_title_buff > 0: a_inj_html += f"<div class='injury-badge' style='background: rgba(16, 185, 129, 0.2); border-color: #10B981; color: #10B981;'>🏆 우승 경쟁 버프</div>"
        if a_manager_buff > 0: a_inj_html += f"<div class='injury-badge' style='background: rgba(245, 158, 11, 0.2); border-color: #F59E0B; color: #F59E0B;'>👔 새 감독 버프 (부임 {a_manager['days_since_hired']}일차)</div>"
        if a_vacation > 0: a_inj_html += f"<div class='injury-badge' style='background: rgba(100, 116, 139, 0.2); border-color: #64748B; color: #64748B;'>🏖️ 동기부여 상실 (휴가 모드)</div>"
        if a_survival.get("active"): a_inj_html += f"<div class='injury-badge' style='background: rgba(249, 115, 22, 0.18); border-color: #F97316; color: #FB923C;'>🔥 잔류 생존전 · {a_survival['reason']}</div>"
        if a_matchup_msg: a_inj_html += f"<div class='injury-badge' style='background: rgba(59, 130, 246, 0.2); border-color: #3B82F6; color: #3B82F6;'>{a_matchup_msg}</div>"
        if is_derby: a_inj_html += f"<div class='injury-badge' style='background: rgba(239, 68, 68, 0.2); border-color: #EF4444; color: #EF4444;'>⚔️ 치열한 로컬 더비 매치</div>"
         
        # A long analysis can cross kickoff even if it started beforehand.
        if datetime.now(KST) >= m_dt:
            frozen_item = _locked_proto_item(m, previous_proto.get(str(m.get("id", ""))))
            if frozen_item:
                dashboard_proto.append(frozen_item)
            continue
        dashboard_proto.append({
            "match": m, "final_match_time": final_match_time, "timestamp": m_dt.timestamp(), "league": league_n,
            "goal_model_audit": goal_model_audit,
            "wdl_forecast": {"probabilities": list(probabilities[:3]),
                             "forecast_model_version": FORECAST_MODEL_VERSION,
                             "generated_at": datetime.now(timezone.utc).isoformat(),
                             "fixture_id": int(api_fixture_id or 0)},
            "api_fixture_id": int(api_fixture_id or 0),
            "home_team_id": int(home_info.get("id") or 0),
            "away_team_id": int(away_info.get("id") or 0),
            "home_logo": home_info.get("logo"), "away_logo": away_info.get("logo"),
            "story": story, "ev_sorted_picks": ev_sorted_picks,
            "pick_categories": pick_categories,
            "legacy_v4_pick": legacy_v4_pick,
            "legacy_v4_candidates": legacy_v4_candidates,
            "robot_pick": robot_pick,
            "alphago_pick": alphago_pick,
            # Private administrator investment selection compares the robot's
            # full pre-kickoff candidate set.  Keep only auditable numeric
            # fields in the dashboard payload; the larger evidence snapshot
            # remains in robot_learning_samples.
            "robot_candidates": [
                {
                    "raw_pick": candidate.get("raw_pick"),
                    "market_key": candidate.get("market_key"),
                    "selection_side": candidate.get("selection_side"),
                    "handicap_base": candidate.get("handicap_base"),
                    "totals_base": candidate.get("totals_base"),
                    "prob": candidate.get("prob"),
                    "robot_probability": candidate.get("robot_probability"),
                    "robot_goal_score": candidate.get("robot_goal_score"),
                    "robot_goal_validation_accuracy": candidate.get(
                        "robot_goal_validation_accuracy"
                    ),
                    "robot_goal_target_reached": bool(
                        candidate.get("robot_goal_target_reached")
                    ),
                    "odd": candidate.get("odd"),
                    "fair_prob": candidate.get("fair_prob"),
                    "robot_edge": candidate.get("robot_edge"),
                    "robot_ev": candidate.get("robot_ev"),
                    "robust_edge": candidate.get("robust_edge"),
                    "robust_ev": candidate.get("robust_ev"),
                    "robot_goal_market_samples": candidate.get(
                        "robot_goal_market_samples"
                    ),
                    "robot_goal_market_accuracy": candidate.get(
                        "robot_goal_market_accuracy"
                    ),
                    "robot_goal_price_samples": candidate.get(
                        "robot_goal_price_samples"
                    ),
                    "robot_goal_price_accuracy": candidate.get(
                        "robot_goal_price_accuracy"
                    ),
                    "robot_goal_price_roi": candidate.get(
                        "robot_goal_price_roi"
                    ),
                    "is_true_underdog": bool(
                        candidate.get("is_true_underdog")
                    ),
                    "robot_model_version": candidate.get("robot_model_version"),
                    "robot_pick_version": ROBOT_PICK_VERSION,
                }
                for candidate in robot_candidates
                if isinstance(candidate, dict)
            ],
            "robot_wdl_probabilities": {
                str(candidate.get("selection_side")): round(float(candidate.get("robot_probability") or 0), 8)
                for candidate in robot_candidates
                if candidate.get("market_key") == "1x2"
            },
            "home_form": h_form, "away_form": a_form,
            "analysis_version": ANALYSIS_VERSION, "analysis_confidence": analysis_confidence,
            "underdog_gate_version": UNDERDOG_GATE_VERSION,
            "analysis_stage": analysis_stage,
            "analysis_evidence_stage": analysis_evidence_stage,
            "reliability_score": reliability_score,
            "odds_source": analysis_odds_source,
            "betman_odds_pending": bool(m.get("betman_odds_pending")),
            "data_coverage": data_coverage,
            "lineup_confirmed": bool(lineup_confirmed),
            "lineup_learning": lineup_learning,
            "probability_error_margin": highest_prob_pick.get("error_margin"),
            "probability_interval": highest_prob_pick.get("probability_interval"),
            "model_probability": highest_prob_pick.get("prob"),
            "fair_market_probability": highest_prob_pick.get("fair_prob"),
            "model_market_edge": highest_prob_pick.get("edge"),
            "used_feature_evidence": evidence,
            "survival_motivation": {"home": h_survival, "away": a_survival},
            "match_importance": match_importance,
            "market_probability_analysis": [
                {
                    "market": infer_pick_market(pick),
                    "pick": pick.get("raw_pick"),
                    "model_probability": pick.get("prob"),
                    "fair_probability": pick.get("fair_prob"),
                    "edge": pick.get("edge"),
                    "market_hit_rate": pick.get("market_hit_rate"),
                    "history_samples": pick.get("market_history_samples"),
                }
                for pick in valid_all_picks
            ],
            "detailed_report": detailed_report,
            "underdog_signal": underdog_signal,
            "h_inj_html": h_inj_html, "a_inj_html": a_inj_html, 
            "h_rest_html": f"<div class='fatigue-badge'>💦 체력 방전</div>" if h_rest_days <= 3 else "", "a_rest_html": f"<div class='fatigue-badge'>💦 체력 방전</div>" if a_rest_days <= 3 else "",
            "h_rank_html": f"<div class='rank-badge'>🏆 순위: {h_rank}위</div>" if h_rank != 99 else "", "a_rank_html": f"<div class='rank-badge'>🏆 순위: {a_rank}위</div>" if a_rank != 99 else ""
        })
        print(
            f"✅ PROTO 정밀분석 완료: {home_team} vs {away_team} "
            f"({time.monotonic() - match_analysis_started:.1f}초)"
        )

    # Scheduled cards use the newest official/robot answer; started cards use
    # the last pre-kickoff answer. Replacements stay in append-only audit tables.
    current_proto = []
    public_now = datetime.now(KST)
    for item in dashboard_proto:
        match = item.get("match") or {}
        kickoff = _parse_kst_match_time(
            item.get("final_match_time") or match.get("match_time")
        )
        current_proto.append(
            _public_proto_item_from_first_snapshot(
                match, item, locked=bool(kickoff and public_now >= kickoff)
            )
        )
    dashboard_proto = current_proto
    dashboard_proto.sort(
        key=lambda item: proto_display_order.get(
            str((item.get("match") or {}).get("id") or ""), 10**9
        )
    )

    if analyzed_proto_count > 0 or deferred_proto_count > 0:
        _publish_proto_checkpoint(
            dashboard_proto, previous_dashboard, proto_matches, toto_14_matches,
            raw_proto_matches, rejected_placeholder_count, rejected_auxiliary_count,
            rejected_proto_count, resumed_proto_count, analyzed_proto_count,
            deferred_proto_count, proto_market_watch_count, proto_cycle_started,
            proto_brake_reason=proto_brake_reason,
        )
        if (
            MASTER_SKIP_TOTO_WHILE_PROTO_BACKLOG
            and analyzed_proto_count > 0
            and deferred_proto_count > 0
        ):
            print(
                "↪️ PROTO 대기 경기가 남아 이번 master는 여기서 양보합니다. "
                f"현재 최대 {MASTER_ANALYSIS_NEW_MATCHES_PER_PASS}경기 묶음/자동 브레이크이며 "
                "남은 시작 전 경기는 다음 master 차례에서 계속 분석합니다. 승무패14 기존 공개본은 보존합니다."
            )
            return True

    double_pick_count = 0
    single_pick_count = 0
    unavailable_pick_count = 0
    suppressed_double_count = 0
    frozen_prediction_count = 0
    total_combinations = 1
    cost_cap_exceeded_by_frozen = False
      
    # PROTO customer picks have already been checkpointed when new work exists.
    # TOTO14 historical policy loading is deliberately deferred so it cannot
    # keep the main customer pick board blank.
    if toto_14_matches:
        toto14_probability_policy = load_toto14_probability_policy()
    else:
        toto14_probability_policy = validate_toto14_probability_policy([])

    for idx, m in enumerate(toto_14_matches, 1):
        home_team, away_team = m["home"], m["away"]
        match_id = f"TOTO14_{m['id']}"
        match_time = m.get("match_time") or "시간 미정"
        now = datetime.now(KST)
        scheduled_dt = _parse_kst_match_time(match_time)
        m_dt = parse_match_time(match_time)
        diff_hours = (m_dt - now).total_seconds() / 3600.0
        frozen_item = None
        migration_fallback = None
        policy_migration = False
        frozen_record = frozen_toto14.get(match_id)
        if (
            isinstance(frozen_record, dict)
            and str(frozen_record.get("home_team")) == str(home_team)
            and str(frozen_record.get("away_team")) == str(away_team)
            and isinstance(frozen_record.get("payload"), dict)
        ):
            frozen_item = dict(frozen_record["payload"])

        kickoff_passed = bool(scheduled_dt and now >= scheduled_dt)
        if (
            frozen_item is not None
            and not kickoff_passed
            and _scheduled_toto_revision_needs_refresh(
                frozen_item, scheduled_dt, now
            )
        ):
            migration_fallback = dict(frozen_item)
            frozen_item = None
            policy_migration = True
            print(
                f"🔄 시작 전 승무패14 최신픽 재분석: "
                f"{home_team} vs {away_team}"
            )
        freeze_needs_persist = False
        previous_item = previous_toto14.get(str(m.get("id", "")))
        previous_match = previous_item.get("match", {}) if isinstance(previous_item, dict) else {}
        previous_is_pre_kickoff = bool(
            isinstance(previous_item, dict)
            and str(previous_match.get("home")) == str(home_team)
            and str(previous_match.get("away")) == str(away_team)
            and previous_generated_at
            and scheduled_dt
            and previous_generated_at <= scheduled_dt
        )
        previous_stage = str(previous_item.get("analysis_stage", "")) if isinstance(previous_item, dict) else ""
        previous_needs_refresh = _scheduled_toto_revision_needs_refresh(
            previous_item, scheduled_dt, now
        )
        if (
            frozen_item is None
            and previous_is_pre_kickoff
            and not previous_needs_refresh
            and _toto14_item_has_usable_pick(
                previous_item, home_team, away_team
            )
        ):
            frozen_item = dict(previous_item)
            frozen_item["frozen_from_stage"] = previous_stage or "regular"
            if kickoff_passed:
                frozen_item["analysis_stage"] = "locked"
            freeze_needs_persist = True

        if frozen_item is None:
            snapshot_item = _locked_toto14_fallback(m)
            snapshot_is_final = bool(
                snapshot_item
                and str(snapshot_item.get("frozen_from_stage", ""))
                in {"T-30-final", "locked"}
            )
            snapshot_needs_refresh = _scheduled_toto_revision_needs_refresh(
                snapshot_item, scheduled_dt, now
            )
            if snapshot_item and not snapshot_needs_refresh and (kickoff_passed or snapshot_is_final):
                frozen_item = snapshot_item
                if not kickoff_passed and snapshot_is_final:
                    frozen_item["analysis_stage"] = snapshot_item["frozen_from_stage"]
                freeze_needs_persist = True

        if frozen_item is None and (kickoff_passed or scheduled_dt is None):
            frozen_item = _unavailable_toto14_item(m)
            freeze_needs_persist = kickoff_passed  # Unknown schedules may recover later.

        # Preserve started tickets, but a scheduled reusable ticket must pass
        # the same identity gate as a newly analysed one.
        if frozen_item is not None and not kickoff_passed and scheduled_dt is not None:
            _hydrate_published_team_data(frozen_item, m)
            if not _published_team_identity_ready(frozen_item):
                queue_team_identity_retry(
                    home_team, away_team, match_time,
                    reason="toto14_frozen_identity_required_before_public_pick",
                    league_name=m.get("league") or "",
                )
                frozen_item = None
                freeze_needs_persist = False

        # A reusable current/locked card needs no new heavy analysis call. A
        # missing ID is repaired by the bounded scoring queue.

        if frozen_item is not None and freeze_needs_persist:
            stored_item = _freeze_toto14_prediction(
                match_id, home_team, away_team, match_time, frozen_item
            )
            frozen_item = stored_item or frozen_item
            frozen_toto14[match_id] = {
                "home_team": home_team,
                "away_team": away_team,
                "payload": frozen_item,
            }

        if frozen_item is not None:
            frozen_item = dict(frozen_item)
            frozen_item["match"] = dict(m)
            frozen_item["prediction_frozen"] = True
            if not kickoff_passed and scheduled_dt is not None:
                _observe_locked_pick_market_flow(
                    frozen_item, "TOTO14", match_id,
                    int(frozen_item.get("api_fixture_id") or 0),
                    "승무패 14경기", home_team, away_team,
                    scheduled_dt, diff_hours,
                )
            picks = _normalize_toto14_picks(
                frozen_item.get("picks")
                or _toto14_picks_from_display(
                    frozen_item.get("best_pick_display"), home_team, away_team
                )
            )
            frozen_item["picks"] = picks
            frozen_item["picks_html"] = _render_toto14_picks_html(picks)
            if len(picks) == 2:
                total_combinations *= 2
                double_pick_count += 1
                if total_combinations > TOTO14_MAX_COMBINATIONS:
                    cost_cap_exceeded_by_frozen = True
            elif len(picks) == 1:
                single_pick_count += 1
            else:
                unavailable_pick_count += 1
            dashboard_toto14.append(frozen_item)
            frozen_prediction_count += 1
            continue

        canonical_toto = _toto14_from_canonical_proto(
            m, dashboard_proto, toto14_probability_policy
        )
        if canonical_toto is not None:
            canonical_toto["_policy_migration"] = policy_migration
            dashboard_toto14.append(canonical_toto)
            total_combinations *= max(1, len(canonical_toto.get("picks") or []))
            continue

        shared_dossier = _load_shared_fixture_dossier(m)
        dossier_home = shared_dossier.get("home") if isinstance(shared_dossier, dict) else {}
        dossier_away = shared_dossier.get("away") if isinstance(shared_dossier, dict) else {}
        if (
            isinstance(dossier_home, dict) and isinstance(dossier_away, dict)
            and int(dossier_home.get("id") or 0) > 0
            and int(dossier_away.get("id") or 0) > 0
        ):
            home_info, away_info = dict(dossier_home), dict(dossier_away)
            identity_fixture = int(shared_dossier.get("fixture_id") or 0)
        else:
            home_info, away_info, identity_fixture = resolve_match_team_pair(
                home_team, away_team, match_time, ttl_h=2,
                league_name=m.get("league") or "",
            )
        if (
            not home_info.get('id')
            or not away_info.get('id')
            or home_info.get('id') == away_info.get('id')
            or home_info.get("logo") in (None, "", DEFAULT_LOGO)
            or away_info.get("logo") in (None, "", DEFAULT_LOGO)
        ):
            queue_team_identity_retry(
                home_team, away_team, match_time,
                reason="toto14_identity_and_logo_required_before_public_pick",
                league_name=m.get("league") or "",
            )
            unavailable = dict(_unavailable_toto14_item(m))
            unavailable["match"] = dict(m)
            unavailable['data_warning'] = (
                '양 팀 신원·마크 확인 대기 · 기본값으로 예측하지 않음'
            )
            dashboard_toto14.append(unavailable)
            continue
        heavy_ttl = 24
        # 경기 직전에는 결장 정보가 자주 바뀌므로 짧게 갱신한다.
        inj_ttl = 0.5 if diff_hours <= 1.5 else 12
        odds_ttl = 0.5 if diff_hours <= 2 else 4
        lineup_ttl = 0.25 if diff_hours <= 1.5 else 12
         
        os_data = fetch_overseas_odds_and_fixture_api(home_info.get("id"), away_info.get("id"), odds_ttl, m.get("match_time") or "시간 미정")
        api_fixture_id = int((os_data or {}).get("fixture_id") or identity_fixture or 0)
        if api_fixture_id <= 0:
            queue_team_identity_retry(
                home_team, away_team, match_time,
                reason="toto14_fixture_identity_required_before_public_pick",
                league_name=m.get("league") or "",
            )
            unavailable = dict(_unavailable_toto14_item(m))
            unavailable["match"] = dict(m)
            unavailable["data_warning"] = (
                "공식 경기 연결 확인 대기 · 기본값으로 예측하지 않음"
            )
            dashboard_toto14.append(unavailable)
            continue
        referee = os_data.get("referee") if os_data else None
        city = os_data.get("city") if os_data else None
        toto_movement = _detect_odds_movement({}, {})
        toto_raw_quotes = (os_data or {}).get("odds_response") or []
        if api_fixture_id and toto_raw_quotes:
            toto_quote_snapshot = _world_market_snapshot_from_response(
                toto_raw_quotes, api_fixture_id
            )
            set_db_cache(f"world_market_v3_{api_fixture_id}", toto_quote_snapshot)
            toto_movement = capture_odds_movement(
                api_fixture_id, "TOTO14", prediction_stage(diff_hours, False),
                toto_quote_snapshot,
            )
        weather_condition = fetch_weather_api(city, odds_ttl)
        weather_details = fetch_weather_details_api(city, odds_ttl)
         
        h_stand = fetch_team_standing_api(home_info.get("id"), heavy_ttl, (os_data or {}).get("league_id"), (os_data or {}).get("season"))
        a_stand = fetch_team_standing_api(away_info.get("id"), heavy_ttl, (os_data or {}).get("league_id"), (os_data or {}).get("season"))
        h_rank, a_rank = h_stand["rank"], a_stand["rank"]
        
        h_manager = fetch_new_manager_status(home_info.get("id"), heavy_ttl)
        a_manager = fetch_new_manager_status(away_info.get("id"), heavy_ttl)
        h_manager_buff = 0.08 if h_manager.get("is_new_manager") else 0.0
        a_manager_buff = 0.08 if a_manager.get("is_new_manager") else 0.0
        is_derby = check_derby_match(home_team, away_team)
        
        if h_rank != 99 and a_rank != 99:
            rank_diff_bonus_h = max(-0.18, min(0.18, (a_rank - h_rank) * 0.012))
            rank_diff_bonus_a = -rank_diff_bonus_h
        else:
            rank_diff_bonus_h = rank_diff_bonus_a = 0.0
        h_survival = calculate_survival_motivation(h_stand)
        a_survival = calculate_survival_motivation(a_stand)
        h_title_buff = 0.06 if 1 <= h_rank <= 3 else 0.0
        a_title_buff = 0.06 if 1 <= a_rank <= 3 else 0.0
        
        h_played = h_stand.get("played", 0)
        h_total_teams = h_stand.get("total_teams", 20)
        h_team_goals = h_stand.get("team_goals", 0)
        is_late_season_h = h_played > 0 and (h_played / max(1, (h_total_teams - 1) * 2)) >= 0.75
        h_vacation = 0.08 if (is_late_season_h and 6 <= h_rank <= max(10, h_total_teams - 4)) else 0.0
        
        a_played = a_stand.get("played", 0)
        a_total_teams = a_stand.get("total_teams", 20)
        a_team_goals = a_stand.get("team_goals", 0)
        is_late_season_a = a_played > 0 and (a_played / max(1, (a_total_teams - 1) * 2)) >= 0.75
        a_vacation = 0.08 if (is_late_season_a and 6 <= a_rank <= max(10, a_total_teams - 4)) else 0.0

        h_inj_data = fetch_team_injuries_api(home_info.get("id"), h_stand.get("league_id"), h_stand.get("season"), inj_ttl, api_fixture_id)
        a_inj_data = fetch_team_injuries_api(away_info.get("id"), a_stand.get("league_id"), a_stand.get("season"), inj_ttl, api_fixture_id)
        h_inj_count, a_inj_count = h_inj_data["count"], a_inj_data["count"]
        
        h_missing_goals = h_inj_data.get("missing_goals", 0)
        h_goal_dep_ratio = (h_missing_goals / h_team_goals) if h_team_goals > 0 else 0
        h_oneman_penalty = 0.15 if h_goal_dep_ratio >= 0.25 else 0.0
        
        a_missing_goals = a_inj_data.get("missing_goals", 0)
        a_goal_dep_ratio = (a_missing_goals / a_team_goals) if a_team_goals > 0 else 0
        a_oneman_penalty = 0.15 if a_goal_dep_ratio >= 0.25 else 0.0
        
        h_war_pct, h_war_details, h_war_score = calculate_war_penalty(home_team, h_inj_data["ace_names"], h_inj_count, home_info.get("id"))
        a_war_pct, a_war_details, a_war_score = calculate_war_penalty(away_team, a_inj_data["ace_names"], a_inj_count, away_info.get("id"))

        h_lineup_penalty, a_lineup_penalty = 0.0, 0.0
        h_lineup_msg, a_lineup_msg = "", ""
        lineup_confirmed = False
        lineup_data = {"confirmed": False, "details": {}}
        h_starters, a_starters = [], []
        h_core = get_expected_core_players(
            home_info.get("id"), h_stand.get("league_id"), h_stand.get("season")
        )
        a_core = get_expected_core_players(
            away_info.get("id"), a_stand.get("league_id"), a_stand.get("season")
        )
        h_predicted_xi, h_lineup_prediction = predict_starting_xi(
            home_info.get("id"), h_stand.get("league_id"), h_stand.get("season"),
            h_inj_data.get("all_names") or h_inj_data.get("ace_names") or [],
        )
        a_predicted_xi, a_lineup_prediction = predict_starting_xi(
            away_info.get("id"), a_stand.get("league_id"), a_stand.get("season"),
            a_inj_data.get("all_names") or a_inj_data.get("ace_names") or [],
        )
        if 0 < diff_hours <= 1.5 and api_fixture_id:
            lineup_data = fetch_lineups_api(api_fixture_id, lineup_ttl)
            lineup_confirmed = bool(lineup_data.get("confirmed"))
            if lineup_confirmed:
                h_starters = lineup_data.get(str(home_info.get("id")), [])
                a_starters = lineup_data.get(str(away_info.get("id")), [])
                h_missing = find_missing_core_players(sorted(set(h_core + h_inj_data.get("ace_names", []))), h_starters)
                a_missing = find_missing_core_players(sorted(set(a_core + a_inj_data.get("ace_names", []))), a_starters)
                h_injury_names = {_normalize_player_name(name) for name in h_inj_data.get("ace_names", [])}
                a_injury_names = {_normalize_player_name(name) for name in a_inj_data.get("ace_names", [])}
                h_unexpected = [name for name in h_missing if _normalize_player_name(name) not in h_injury_names]
                a_unexpected = [name for name in a_missing if _normalize_player_name(name) not in a_injury_names]
                h_lineup_penalty = 0.12 if len(h_unexpected) == 1 else (0.20 if len(h_unexpected) >= 2 else 0.0)
                a_lineup_penalty = 0.12 if len(a_unexpected) == 1 else (0.20 if len(a_unexpected) >= 2 else 0.0)
                if h_missing:
                    h_lineup_msg = f"🚨 [선발 확인] 핵심 {', '.join(h_missing[:3])} 선발 제외"
                if a_missing:
                    a_lineup_msg = f"🚨 [선발 확인] 핵심 {', '.join(a_missing[:3])} 선발 제외"

        h_inj_html = _render_team_availability_status(
            h_inj_data, diff_hours, lineup_confirmed, h_lineup_msg
        )
        a_inj_html = _render_team_availability_status(
            a_inj_data, diff_hours, lineup_confirmed, a_lineup_msg
        )
        if h_war_score > 0:
            h_war_text = " / ".join(h_war_details)
            h_inj_html += f"<div class='injury-badge'>🏥 전력누수(-{h_war_score:.1f}점): {h_war_text}</div>"
        if a_war_score > 0:
            a_war_text = " / ".join(a_war_details)
            a_inj_html += f"<div class='injury-badge'>🏥 전력누수(-{a_war_score:.1f}점): {a_war_text}</div>"
        if h_lineup_msg:
            h_inj_html += f"<div class='injury-badge' style='background:#EF4444; color:#fff;'>{h_lineup_msg}</div>"
        if a_lineup_msg:
            a_inj_html += f"<div class='injury-badge' style='background:#EF4444; color:#fff;'>{a_lineup_msg}</div>"
        if h_survival.get("active"):
            h_inj_html += f"<div class='injury-badge' style='background:rgba(249,115,22,.18); border-color:#F97316; color:#FB923C;'>🔥 잔류 생존전 · {h_survival['reason']}</div>"
        if a_survival.get("active"):
            a_inj_html += f"<div class='injury-badge' style='background:rgba(249,115,22,.18); border-color:#F97316; color:#FB923C;'>🔥 잔류 생존전 · {a_survival['reason']}</div>"

        h_last_data = fetch_team_last_match_date_api(home_info.get("id"), heavy_ttl)
        a_last_data = fetch_team_last_match_date_api(away_info.get("id"), heavy_ttl)
        h_rest_days = calculate_rest_days(h_last_data.get("date"), m.get("match_time"))
        a_rest_days = calculate_rest_days(a_last_data.get("date"), m.get("match_time"))
        h_extreme_fatigue, a_extreme_fatigue = h_last_data.get("is_extreme_fatigue"), a_last_data.get("is_extreme_fatigue")

        h_next = fetch_team_next_fixture_api(home_info.get("id"), heavy_ttl)
        a_next = fetch_team_next_fixture_api(away_info.get("id"), heavy_ttl)
        match_importance = build_match_importance_profile(
            h_stand, a_stand, h_next, a_next, is_derby=is_derby
        )
        h_long = fetch_team_long_term_stats_api(home_info.get("id"), heavy_ttl)
        a_long = fetch_team_long_term_stats_api(away_info.get("id"), heavy_ttl)
        h_recent = fetch_team_recent_form_metrics(home_info.get("id"), heavy_ttl)
        a_recent = fetch_team_recent_form_metrics(away_info.get("id"), heavy_ttl)
         
        league_n_14 = (os_data or {}).get("league_name") or m.get('league', '')
        if league_n_14 not in market_performance_cache:
            market_performance_cache[league_n_14] = load_market_performance(
                league_n_14, serving_only=MASTER_CACHE_ONLY_SERVING
            )
        toto_market_performance = market_performance_cache[league_n_14]
        h_stats = fetch_recent_team_stats_api(home_info.get("id"), heavy_ttl)
        a_stats = fetch_recent_team_stats_api(away_info.get("id"), heavy_ttl)

        h_depth_factor = calculate_squad_depth_factor(h_stand)
        a_depth_factor = calculate_squad_depth_factor(a_stand)
        
        # 중복 악재의 이중 계산을 막고 가장 큰 두 항목만 제한적으로 반영한다.
        h_inj_pct = h_war_pct
        a_inj_pct = a_war_pct
        h_fatigue_pct = (0.15 if h_extreme_fatigue else 0.08) if h_rest_days <= 3 else 0.0
        a_fatigue_pct = (0.15 if a_extreme_fatigue else 0.08) if a_rest_days <= 3 else 0.0
        h_rot_pct = 0.10 if h_next["is_important"] and h_next["days_until_next"] <= 4 else 0.0
        a_rot_pct = 0.10 if a_next["is_important"] and a_next["days_until_next"] <= 4 else 0.0

        h_penalties = [h_inj_pct, h_fatigue_pct, h_rot_pct, h_lineup_penalty, h_vacation, h_oneman_penalty]
        a_penalties = [a_inj_pct, a_fatigue_pct, a_rot_pct, a_lineup_penalty, a_vacation, a_oneman_penalty]
        h_penalties.sort(reverse=True)
        a_penalties.sort(reverse=True)
        
        h_total_penalty = combine_availability_penalties(h_war_pct, h_lineup_penalty, h_oneman_penalty, h_fatigue_pct, h_rot_pct, h_depth_factor)
        a_total_penalty = combine_availability_penalties(a_war_pct, a_lineup_penalty, a_oneman_penalty, a_fatigue_pct, a_rot_pct, a_depth_factor)
        
        cross_boost_a = h_total_penalty * 0.4
        cross_boost_h = a_total_penalty * 0.4

        fixture_details = fetch_fixture_details_api(home_info["id"], away_info["id"], heavy_ttl)
        h2h_total = fixture_details.get("total", 0)
        h_wins = fixture_details.get("h_wins", 0)
        a_wins = fixture_details.get("a_wins", 0)
        h_h2h_bonus = max(-0.10, min(0.10, ((h_wins - a_wins) / h2h_total) * 0.12)) if h2h_total > 0 else 0.0
        a_h2h_bonus = -h_h2h_bonus
        
        h_kryptonite, a_kryptonite = 0.0, 0.0
        if h2h_total >= 3:
            if (h_wins / h2h_total) >= 0.65: h_kryptonite = 0.04
            elif (a_wins / h2h_total) >= 0.65: a_kryptonite = 0.04
         
        exp_h, exp_a, goal_model_audit = estimate_match_goals(
            h_long, a_long, h_recent, a_recent, h_stats, a_stats, league_n_14,
            h_total_penalty, a_total_penalty,
        )
        exp_h, exp_a, goal_model_audit = apply_cached_opponent_model(
            exp_h, exp_a, goal_model_audit, home_info.get("id"), away_info.get("id"),
            (os_data or {}).get("league_id"), m_dt, h_total_penalty, a_total_penalty,
        )

        exp_h, exp_a, toto_context_audit, goal_model_audit = integrate_pre_match_context(
            exp_h, exp_a,
            {
                "h2h": fixture_details, "home_rank": h_rank, "away_rank": a_rank,
                "home_recent_strength": float(h_recent.get("strength") or 0),
                "away_recent_strength": float(a_recent.get("strength") or 0),
                "recent_available": min(int(h_recent.get("matches") or 0), int(a_recent.get("matches") or 0)) >= 3,
                "home_absence": h_total_penalty, "away_absence": a_total_penalty,
                "home_title": h_title_buff, "away_title": a_title_buff,
                "home_manager": h_manager_buff, "away_manager": a_manager_buff,
                "home_vacation": h_vacation, "away_vacation": a_vacation,
                "home_survival": h_survival, "away_survival": a_survival,
                "weather": weather_condition, "referee": referee,
                "is_derby": is_derby,
            },
            goal_model_audit,
        )

        analysis_confidence = calculate_data_confidence(
            home_info, away_info, api_fixture_id, h_stand, a_stand, h_long, a_long,
            h_recent, a_recent, h_stats, a_stats, h_inj_data, a_inj_data,
            diff_hours, lineup_confirmed,
        )
         
        market_odds = []
        if os_data and min(float(os_data.get("odd_h") or 0), float(os_data.get("odd_d") or 0), float(os_data.get("odd_a") or 0)) > 1.0:
            market_odds = [os_data["odd_h"], os_data["odd_d"], os_data["odd_a"]]
        probabilities, joint_audit, _ = coherent_match_forecast(
            exp_h, exp_a, 0, 2.5, market_odds, analysis_confidence,
            toto_market_performance.get("1x2"), goal_model_audit.get("rho", -.15),
            None, toto_context_audit.get("wdl_log_adjustment"),
        )
        raw_h_win, raw_draw, raw_a_win = probabilities[:3]
        h_win, draw, a_win = apply_toto14_probability_policy(
            [raw_h_win, raw_draw, raw_a_win], toto14_probability_policy,
            [m.get("vote_h"), m.get("vote_d"), m.get("vote_a")],
        )
        goal_model_audit["joint_forecast"] = joint_audit
        goal_model_audit["toto14_probability_learning"] = {
            key: toto14_probability_policy.get(key)
            for key in (
                "active", "policy_version", "cohort_fixtures",
                "train_fixtures", "validation_fixtures",
                "baseline_accuracy", "validation_accuracy",
                "baseline_brier", "validation_brier", "reason",
            )
        }

        pct_h = round(h_win * 100, 1)
        pct_d = round(draw * 100, 1)
        pct_a = round(100.0 - pct_h - pct_d, 1)

        probs_dict = {"승": pct_h, "무": pct_d, "패": pct_a}
        robot_wdl_market = (
            normalize_probabilities([
                1.0 / float(market_odds[0]), 1.0 / float(market_odds[1]),
                1.0 / float(market_odds[2]),
            ]) if len(market_odds) == 3 else [0.0, 0.0, 0.0]
        )
        robot_wdl_candidates = [
            {
                "market_key": "1x2", "selection_side": "home",
                "raw_pick": f"{home_team} 승", "prob": raw_h_win,
                "odd": float(market_odds[0]) if len(market_odds) == 3 else 0.0,
                "market_prob": robot_wdl_market[0], "fair_prob": robot_wdl_market[0],
                "settlement_supported": True,
            },
            {
                "market_key": "1x2", "selection_side": "draw",
                "raw_pick": "무승부", "prob": raw_draw,
                "odd": float(market_odds[1]) if len(market_odds) == 3 else 0.0,
                "market_prob": robot_wdl_market[1], "fair_prob": robot_wdl_market[1],
                "settlement_supported": True,
            },
            {
                "market_key": "1x2", "selection_side": "away",
                "raw_pick": f"{away_team} 승", "prob": raw_a_win,
                "odd": float(market_odds[2]) if len(market_odds) == 3 else 0.0,
                "market_prob": robot_wdl_market[2], "fair_prob": robot_wdl_market[2],
                "settlement_supported": True,
            },
        ]
        official_toto_candidates = [
            {**candidate, "prob": calibrated_probability}
            for candidate, calibrated_probability in zip(
                robot_wdl_candidates, (h_win, draw, a_win)
            )
        ]
        official_toto_pick = max(
            official_toto_candidates,
            key=lambda candidate: float(candidate.get("prob") or 0),
        )
        official_toto_pick = dict(
            official_toto_pick,
            official_policy_version=OFFICIAL_PICK_POLICY_VERSION,
            selection_axis="toto14_validated_probability_accuracy",
            selection_reason=(
                "시간순 다음 회차 검증을 통과한 승무패14 확률표에서 가장 높은 단일 방향"
                if toto14_probability_policy.get("active") else
                "승무패14 학습안이 다음 회차 검증을 통과하지 않아 기존 확률표의 가장 높은 단일 방향"
            ),
            toto14_probability_learning_active=bool(
                toto14_probability_policy.get("active")
            ),
            toto14_probability_policy_version=str(
                toto14_probability_policy.get("policy_version") or ""
            ),
        )
        lineup_learning = {
            "schema_version": ROBOT_LINEUP_SCHEMA_VERSION,
            "mode": "predicted-xi-then-official-answer-v2",
            "home_team_id": int(home_info.get("id") or 0),
            "away_team_id": int(away_info.get("id") or 0),
            "home_predicted_core": list(h_core),
            "away_predicted_core": list(a_core),
            "home_predicted_starting_xi": list(h_predicted_xi),
            "away_predicted_starting_xi": list(a_predicted_xi),
            "home_official_starters": list(h_starters),
            "away_official_starters": list(a_starters),
            "home_active_starting_xi": list(h_starters or h_predicted_xi),
            "away_active_starting_xi": list(a_starters or a_predicted_xi),
            "official_details": lineup_data.get("details") or {},
            "home_prediction_audit": h_lineup_prediction,
            "away_prediction_audit": a_lineup_prediction,
            "official_replaced_prediction": bool(lineup_confirmed),
        }
        toto_full_evidence = _robot_full_pre_match_evidence(
            "TOTO14", m, league_n_14, (os_data or {}).get("league_id"),
            (os_data or {}).get("season"),
            {**home_info, "display_name": home_team, "venue_role": "home"},
            {**away_info, "display_name": away_team, "venue_role": "away"},
            h_recent, a_recent, h_stats, a_stats, h_long, a_long,
            h_stand, a_stand, h_survival, a_survival,
            {"home": h_inj_data, "away": a_inj_data}, lineup_learning,
            {"home": h_rest_days, "away": a_rest_days},
            {
                "home": fetch_team_recent_fixtures_api(home_info.get("id"), heavy_ttl),
                "away": fetch_team_recent_fixtures_api(away_info.get("id"), heavy_ttl),
            },
            {"home": h_next, "away": a_next},
            {"home": h_manager, "away": a_manager}, fixture_details,
            {
                "city": city, "weather": weather_condition,
                "weather_details": weather_details, "referee": referee,
                "derby": is_derby, "home_venue": True,
            },
            {"overseas_fixture_and_quotes": os_data or {}, "wdl": market_odds},
            toto_movement, goal_model_audit, toto_context_audit,
            analysis_confidence,
            {"source": "toto14", "vote_percentages": {
                "home": m.get("vote_h"), "draw": m.get("vote_d"), "away": m.get("vote_a"),
            }},
            {
                "home_total_penalty": h_total_penalty,
                "away_total_penalty": a_total_penalty,
                "home_rank_signal": rank_diff_bonus_h,
                "away_rank_signal": rank_diff_bonus_a,
                "home_matchup_signal": h_kryptonite,
                "away_matchup_signal": a_kryptonite,
                "home_title_signal": h_title_buff,
                "away_title_signal": a_title_buff,
            },
        )
        robot_features = build_autonomous_robot_features(
            goal_model_audit, toto_context_audit, robot_wdl_candidates,
            analysis_confidence,
            {
                "source_toto14": 1.0,
                "home_rank": 0 if h_rank == 99 else h_rank,
                "away_rank": 0 if a_rank == 99 else a_rank,
                "home_rank_known": h_rank != 99,
                "away_rank_known": a_rank != 99,
                "home_recent_strength": h_recent.get("strength", 0.0),
                "away_recent_strength": a_recent.get("strength", 0.0),
                "home_rest_days": 0 if h_rest_days >= 90 else h_rest_days,
                "away_rest_days": 0 if a_rest_days >= 90 else a_rest_days,
                "home_rest_known": h_rest_days < 90,
                "away_rest_known": a_rest_days < 90,
                "home_absence": h_total_penalty,
                "away_absence": a_total_penalty,
                "home_lineup_penalty": h_lineup_penalty,
                "away_lineup_penalty": a_lineup_penalty,
                "lineup_confirmed": lineup_confirmed,
                "h2h_total": h2h_total,
                "h2h_home_wins": h_wins,
                "h2h_draws": fixture_details.get("draws", 0),
                "h2h_away_wins": a_wins,
                "is_derby": is_derby,
                "home_survival_active": bool(h_survival.get("active")),
                "away_survival_active": bool(a_survival.get("active")),
                "home_manager_active": h_manager_buff > 0,
                "away_manager_active": a_manager_buff > 0,
                "home_vacation_active": h_vacation > 0,
                "away_vacation_active": a_vacation > 0,
                "home_market_signal": False,
                "away_market_signal": False,
                "adverse_weather": str(weather_condition or "").casefold() in {"rain", "snow"},
            },
            all_evidence=toto_full_evidence,
        )
        legacy_v4_candidates = []
        legacy_v4_pick = {}
        toto14_robot_artifact = _load_autonomous_robot_artifact(
            "TOTO14", serving_only=MASTER_CACHE_ONLY_SERVING
        )
        robot_candidates = build_autonomous_robot_candidates(
            robot_wdl_candidates, robot_features, toto14_robot_artifact,
        )
        robot_pick = select_autonomous_robot_pick(
            robot_candidates, analysis_confidence, robot_features,
            source="TOTO14", robot_artifact=toto14_robot_artifact,
            serving_only=MASTER_CACHE_ONLY_SERVING,
        )
        alphago_pick = _alphago_pick_payload(robot_pick)
        robot_wdl_probabilities = {
            str(candidate.get("selection_side")): float(candidate.get("robot_probability") or 0)
            for candidate in robot_candidates
        }
        robot_side = str((robot_pick or {}).get("selection_side") or "")
        robot_mark = {"home": "승", "draw": "무", "away": "패"}.get(robot_side, "")
        picks, first_pct, double_suppressed = _choose_toto14_picks(
            probs_dict, total_combinations
        )
        disp_texts = []
        for p in picks:
            if p == "승": disp_texts.append(f"{m['home']} 승")
            elif p == "패": disp_texts.append(f"{m['away']} 승")
            else: disp_texts.append("무승부")
        best_pick_display = ", ".join(disp_texts)
        picks_html = _render_toto14_picks_html(picks)
         
        analysis_stage = prediction_stage(diff_hours, lineup_confirmed)
        crossed_kickoff_during_analysis = bool(
            scheduled_dt and datetime.now(KST) >= scheduled_dt
        )
        if crossed_kickoff_during_analysis:
            # Discard every value calculated after the analysis began. Only a
            # snapshot whose timestamp predates kickoff may become the result.
            toto_item = _locked_toto14_fallback(m) or _unavailable_toto14_item(m)
            stored_item = _freeze_toto14_prediction(
                match_id, home_team, away_team, match_time, toto_item
            )
            toto_item = stored_item or toto_item
            toto_item["match"] = dict(m)
            double_suppressed = False
            frozen_prediction_count += 1
        else:
            toto_home_form = fetch_team_form_api(home_info.get("id"), heavy_ttl)
            toto_away_form = fetch_team_form_api(away_info.get("id"), heavy_ttl)
            if (
                home_info.get("logo") in (None, "", DEFAULT_LOGO)
                or away_info.get("logo") in (None, "", DEFAULT_LOGO)
                or not toto_home_form or not toto_away_form
            ):
                queue_team_identity_retry(
                    home_team, away_team, match_time,
                    reason="toto14_identity_logo_or_recent_form_pending",
                    league_name=m.get("league") or "",
                )
            toto_item = {
                "_pending_toto_save": True, "api_fixture_id": api_fixture_id,
                "_policy_migration": policy_migration,
                "home_team_id": int(home_info.get("id") or 0),
                "away_team_id": int(away_info.get("id") or 0),
                "match": m, "home_logo": home_info.get("logo"), "away_logo": away_info.get("logo"),
                "best_pick_display": best_pick_display, "p_h": pct_h, "p_d": pct_d, "p_a": pct_a,
                "analysis_version": ANALYSIS_VERSION, "analysis_confidence": analysis_confidence,
                "goal_model_audit": goal_model_audit,
                "analysis_stage": analysis_stage,
                "survival_motivation": {"home": h_survival, "away": a_survival},
                "match_importance": match_importance,
                "robot_features": robot_features,
                "robot_full_evidence": toto_full_evidence,
                "robot_lineup_prediction": lineup_learning,
                "official_comparison_pick": official_toto_pick,
                "legacy_v4_candidates": legacy_v4_candidates,
                "legacy_v4_pick": legacy_v4_pick,
                "robot_candidates": robot_candidates,
                "robot_wdl_probabilities": robot_wdl_probabilities,
                "robot_pick": robot_pick,
                "alphago_pick": alphago_pick,
                "robot_mark": robot_mark,
                "robot_pick_display": _human_pick_label(
                    (robot_pick or {}).get("raw_pick"), home_team
                ),
                "robot_pick_probability": round(float((robot_pick or {}).get("prob") or 0) * 100, 1),
                "robot_pick_version": ROBOT_PICK_VERSION,
                "picks": picks,
                "picks_html": picks_html, "h_rank_html": f"<div class='rank-badge'>🏆 리그 순위: {h_rank}위</div>" if h_rank != 99 else "", "a_rank_html": f"<div class='rank-badge'>🏆 리그 순위: {a_rank}위</div>" if a_rank != 99 else "",
                "h_inj_html": h_inj_html, "a_inj_html": a_inj_html,
                "home_form": toto_home_form, "away_form": toto_away_form
            }
        final_picks = _normalize_toto14_picks(
            toto_item.get("picks")
            or _toto14_picks_from_display(
                toto_item.get("best_pick_display"), home_team, away_team
            )
        )
        toto_item["picks"] = final_picks
        toto_item["picks_html"] = _render_toto14_picks_html(final_picks)
        if len(final_picks) == 2:
            total_combinations *= 2
            double_pick_count += 1
            if total_combinations > TOTO14_MAX_COMBINATIONS:
                cost_cap_exceeded_by_frozen = True
        elif len(final_picks) == 1:
            single_pick_count += 1
        else:
            unavailable_pick_count += 1
        if double_suppressed:
            suppressed_double_count += 1
        dashboard_toto14.append(toto_item)

    # Identity decoration improves independently from the scheduled pick
    # revision and never changes its saved probability, odds or report.
    for published_item in dashboard_proto:
        _hydrate_published_team_data(published_item)
    for published_item in dashboard_toto14:
        _hydrate_published_team_data(published_item)

    dashboard_toto14 = _finalize_toto14_round(dashboard_toto14)
    toto14_meta = _build_toto14_ticket_meta(
        dashboard_toto14,
        cost_cap_exceeded_by_frozen=cost_cap_exceeded_by_frozen,
    )

    # 종료된 예전 경기가 TOP 3에 다시 등장하지 않도록 아직 시작하지 않은 경기만 선정한다.
    now_ts = datetime.now(timezone(timedelta(hours=9))).timestamp()
    upcoming_proto = [
        item for item in dashboard_proto
        if item.get("timestamp", 0) > now_ts and item.get("ev_sorted_picks")
    ]
    top_3_picks = sorted(
        upcoming_proto,
        key=lambda x: (x.get("reliability_score", 0), x.get("analysis_confidence", 0)),
        reverse=True,
    )[:3]
    honey_two_pick = build_honey_two_pick(upcoming_proto)

    final_output = {
        "proto": dashboard_proto, "toto14": dashboard_toto14,
        # Grading is owned by the independent score worker.  Reuse its latest
        # published feed here; master must never rescan/grade the large DB while
        # customer picks are waiting to be published.
        "grading": _latest_local_grading_snapshot(
            previous_dashboard.get("grading") if isinstance(previous_dashboard, dict) else {}
        ),
        "toto14_meta": toto14_meta,
        "top3": top_3_picks,
        "honey_two_pick": honey_two_pick,
        "source_meta": {
            "analysis_version": ANALYSIS_VERSION,
            "system_version": SYSTEM_VERSION,
            "underdog_gate_version": UNDERDOG_GATE_VERSION,
            "raw_betman_proto_count": len(raw_proto_matches),
            "rejected_placeholder_count": rejected_placeholder_count,
            "rejected_auxiliary_prediction_count": rejected_auxiliary_count,
            "rejected_proto_count": rejected_proto_count,
            "betman_proto_count": len(proto_matches),
            "display_proto_count": len(dashboard_proto),
            "betman_toto14_count": len(toto_14_matches),
            "display_toto14_count": len(dashboard_toto14),
            "resumed_proto_count": resumed_proto_count,
            "analyzed_proto_count": analyzed_proto_count,
            "master_analysis_new_matches_per_pass": MASTER_ANALYSIS_NEW_MATCHES_PER_PASS,
            "deferred_proto_count": deferred_proto_count,
            "proto_market_watch_count": proto_market_watch_count,
            "analysis_resume_pending": bool(deferred_proto_count),
            "master_analysis_elapsed_seconds": round(
                time.monotonic() - proto_cycle_started, 2
            ),
            "proto_parity_ok": len(proto_matches) == len(dashboard_proto),
            "toto14_parity_ok": len(toto_14_matches) == len(dashboard_toto14),
            # Read-only review list for the admin page.  It contains no
            # guessed match; unresolved pairs remain quarantined.
            "team_identity_review": list_team_identity_review_queue(limit=40),
            "api_usage": get_api_usage_status(),
            "generated_at": datetime.now(timezone(timedelta(hours=9))).isoformat(),
        },
    }
    _atomic_write_json("dashboard_data.json", final_output)
    if len(proto_matches) != len(dashboard_proto):
        print(f"❌ 경기 수 불일치: 베트맨 {len(proto_matches)}경기 / 화면 데이터 {len(dashboard_proto)}경기")
    else:
        print(f"✅ 경기 수 일치 확인: 베트맨 = 화면 데이터 {len(dashboard_proto)}경기")
    print(f"✅ 대시보드 데이터 패키징 완료! ({ANALYSIS_VERSION} 과신 방지·핵심선수·신뢰도 적용)")
    return True

def _cached_fixture_identity_board(date_key, purpose="scoring"):
    """Reuse one date board across score/live workers instead of every 5 minutes."""
    date_key = str(date_key or "").strip()
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date_key):
        return []
    cache_key = f"fixture_identity_board_v2_{date_key}"
    cached = get_db_cache(cache_key, FIXTURE_IDENTITY_CACHE_HOURS)
    if isinstance(cached, list):
        return cached

    stale = get_db_cache(cache_key, 24 * 14)
    retry_guard = get_db_cache(
        f"{cache_key}_retry_guard", FIXTURE_IDENTITY_RETRY_HOURS
    )
    if retry_guard is not None:
        return stale if isinstance(stale, list) else []

    try:
        board = _request_fixture_board(
            {"date": date_key, "timezone": "Asia/Seoul"},
            purpose=purpose,
        )
        board = board if isinstance(board, list) else []
        set_db_cache(cache_key, board)
        return board
    except Exception:
        set_db_cache(f"{cache_key}_retry_guard", {"failed": True})
        if isinstance(stale, list):
            print(f"♻️ 경기 신원판 API 오류 - 저장된 정상본 사용({date_key})")
            return stale
        raise


def _stored_team_identity_matches(local_name, stored_name, api_id=0):
    """Exact names/curated aliases or verified IDs, never a fuzzy recovery."""
    def keys(name):
        values = {str(name or "")}
        for english, korean in WORLD_TEAM_NAME_KO_OVERRIDES.items():
            norm = lambda s: re.sub(r"[^a-z0-9가-힣]", "", str(s).casefold())
            if norm(name) in {norm(english), norm(korean)}:
                values.update((english, korean))
        values.add(TEAM_NAME_MAP.get(str(name), ""))
        values.add(MANUAL_TEAM_MAP.get(str(name), ""))
        return {re.sub(r"[^a-z0-9가-힣]", "", v.casefold()) for v in values if v}
    # An explicit provider ID is stronger than a display-name match. Reject a
    # known mismatch before accepting an identical or translated team name.
    explicit_api_id = int(api_id or 0)
    if explicit_api_id:
        expected_id = int(known_team_id(local_name) or 0)
        if expected_id and expected_id != explicit_api_id:
            return False
    if keys(local_name) & keys(stored_name):
        return True
    # Only consult the already verified ID cache when exact/curated names did
    # not settle the identity. This keeps the local grading recovery path free
    # of unnecessary cache work for the common exact-name case.
    expected = known_team_id(local_name)
    actual = int(explicit_api_id or known_team_id(stored_name) or 0)
    return bool(expected and actual and expected == actual)


def _record_fixture_recovery(conn, recovered, source):
    conn.execute("""CREATE TABLE IF NOT EXISTS fixture_identity_recovery_audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT, match_id TEXT, old_fixture_id INTEGER,
        new_fixture_id INTEGER, home_team TEXT, away_team TEXT, match_time TEXT,
        evidence_source TEXT, recorded_at TEXT DEFAULT CURRENT_TIMESTAMP)""")
    for match_id, fixture_id in recovered.items():
        conn.execute("""INSERT INTO fixture_identity_recovery_audit
            (match_id,old_fixture_id,new_fixture_id,home_team,away_team,match_time,evidence_source)
            SELECT match_id,COALESCE(api_fixture_id,0),?,home_team,away_team,match_time,?
            FROM predictions WHERE match_id=? AND COALESCE(api_fixture_id,0)=0""",
            (fixture_id, source, match_id))


def _recover_due_fixture_ids(rows, conn, local_only=False):
    """Recover unresolved fixtures from their scheduled date, including terminal games."""
    # Reuse an already linked canonical/WORLD fixture before fetching another
    # date board. Ordered teams + kickoff still have to match, and ambiguity
    # never silently chooses the first row.
    recovered_local = {}
    known = conn.execute("SELECT home_team,away_team,match_time,api_fixture_id FROM predictions WHERE api_fixture_id > 0").fetchall()
    for row in rows:
        if int(row[6] or 0):
            continue
        match_dt = _parse_kst_match_time(row[5])
        candidates = set()
        for home, away, when, fixture in known:
            known_dt = _parse_kst_match_time(when)
            if (match_dt and known_dt and abs((match_dt-known_dt).total_seconds()) <= 15*60
                    and _stored_team_identity_matches(row[1], home) and _stored_team_identity_matches(row[2], away)):
                candidates.add(int(fixture))
        if len(candidates) == 1:
            recovered_local[str(row[0])] = candidates.pop()
    if recovered_local:
        _record_fixture_recovery(conn, recovered_local, "stored_prediction_ordered_teams_kickoff_15min")
        conn.executemany("UPDATE predictions SET api_fixture_id=? WHERE match_id=? AND COALESCE(api_fixture_id,0)=0",
                         [(fixture, match_id) for match_id, fixture in recovered_local.items()])
        # A saved, exact identity recovery must not remain hidden behind the
        # old external-lookup cooldown.  Only the recovered rows are released.
        if conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='scoring_queue'").fetchone():
            conn.executemany(
                "UPDATE scoring_queue SET retry_at=0,last_attempt=0,reason=? WHERE match_id=?",
                [("저장 자료로 경기 ID 복구 · 결과 확인 대기", match_id)
                 for match_id in recovered_local],
            )
        conn.commit()
        rows = [tuple(row[:6]) + (int(row[6] or 0) or recovered_local.get(str(row[0]), 0),) for row in rows]
    unresolved = [row for row in rows if not int(row[6] or 0)]
    if not unresolved or local_only:
        return rows, len(recovered_local)

    boards = {}
    now = datetime.now(KST)
    date_rows = {}
    for row in unresolved:
        dt = _parse_kst_match_time(row[5])
        if dt is not None:
            date_rows.setdefault(dt.strftime("%Y-%m-%d"), row)
    cursor = get_db_cache("fixture_recovery_date_cursor_v1", 24*365) or {}
    dates = sorted(date_rows)
    start = next((i for i, date in enumerate(dates) if date > str(cursor.get("last_date") or "")), 0)
    ordered_rows = [date_rows[date] for date in dates[start:]+dates[:start]]
    for row in ordered_rows:
        match_dt = _parse_kst_match_time(row[5])
        if match_dt is None:
            continue
        age_hours = (now - match_dt).total_seconds() / 3600
        if age_hours < -LIVE_LOOKAROUND_HOURS:
            continue
        date_key = match_dt.strftime("%Y-%m-%d")
        if date_key in boards:
            continue
        if len(boards) >= 3:
            break  # Bounded identity recovery; remaining dates rotate next run.
        try:
            boards[date_key] = _cached_fixture_identity_board(
                date_key, purpose="scoring"
            )
        except Exception as error:
            print(f"⚠️ 미연결 경기판 조회 실패({date_key}): {error}")
            boards[date_key] = []
    if boards:
        set_db_cache("fixture_recovery_date_cursor_v1", {"last_date": next(reversed(boards))})

    recovered = {}
    for row in unresolved:
        # The scoring row layout is id, home, away, prob, ev, time, fixture.
        match_id, home_team, away_team, match_time = row[0], row[1], row[2], row[5]
        match_dt = _parse_kst_match_time(match_time)
        if match_dt is None:
            continue
        candidates = []
        for item in boards.get(match_dt.strftime("%Y-%m-%d"), []):
            api_dt = _api_fixture_datetime(item)
            if api_dt is None or abs((api_dt - match_dt).total_seconds()) > 15 * 60:
                continue
            teams = item.get("teams", {})
            api_home = teams.get("home", {})
            api_away = teams.get("away", {})
            if not _stored_team_identity_matches(home_team, api_home.get("name"), api_home.get("id")):
                continue
            if not _stored_team_identity_matches(away_team, api_away.get("name"), api_away.get("id")):
                continue
            candidates.append((abs((api_dt - match_dt).total_seconds()), item))
        if not candidates:
            continue
        candidates.sort(key=lambda value: value[0])
        fixture_id = int(candidates[0][1].get("fixture", {}).get("id") or 0)
        if fixture_id and len({int(value[1].get('fixture', {}).get('id') or 0) for value in candidates}) == 1:
            recovered[str(match_id)] = fixture_id

    if recovered:
        _record_fixture_recovery(conn, recovered, "cached_date_board_ordered_teams_kickoff_15min")
        conn.executemany(
            "UPDATE predictions SET api_fixture_id = ? WHERE match_id = ? AND COALESCE(api_fixture_id, 0) = 0",
            [(fixture_id, match_id) for match_id, fixture_id in recovered.items()],
        )
        conn.commit()

    updated = []
    for row in rows:
        fixture_id = int(row[6] or 0) or recovered.get(str(row[0]), 0)
        updated.append(tuple(row[:6]) + (fixture_id,))
    return updated, len(recovered) + len(recovered_local)


def _scoring_row_matches_fixture(row, match_info):
    """Require ordered teams and a tight kickoff window before grading."""
    api_dt = _api_fixture_datetime(match_info)
    local_dt = _parse_kst_match_time(row[5])
    if api_dt is None or local_dt is None:
        return False
    if abs((local_dt - api_dt).total_seconds()) > 3 * 3600:
        return False
    teams = match_info.get("teams", {}) or {}
    api_home = teams.get("home", {}) or {}
    api_away = teams.get("away", {}) or {}
    return (
        _stored_team_identity_matches(row[1], api_home.get("name"), api_home.get("id"))
        and _stored_team_identity_matches(row[2], api_away.get("name"), api_away.get("id"))
    )


def _grade_pending_from_saved_score(conn, row, goals_h, goals_a):
    """Grade one pending frozen pick from an already verified local result."""
    _ensure_postmortem_column(conn)
    match_id, home_team, away_team, prob_pick, ev_pick, _, fixture_id = row
    goals_h, goals_a = int(goals_h), int(goals_a)
    score_str = f"{goals_h}:{goals_a}"
    prob_hit = evaluate_single_pick(prob_pick, home_team, away_team, goals_h, goals_a)
    ev_hit = evaluate_single_pick(ev_pick, home_team, away_team, goals_h, goals_a)
    events = _load_stored_event_timeline(match_id, limit=8)
    ai_note, postmortem_data = generate_real_ai_note(
        fixture_id, goals_h, goals_a, prob_hit, ev_hit,
        has_ev_pick=bool(str(ev_pick or "").strip()), home_team=home_team,
        away_team=away_team, prob_pick=prob_pick, ev_pick=ev_pick,
        event_timeline=events, return_postmortem=True, fetch_official_stats=False,
    )
    cursor = conn.cursor()
    cursor.execute("""
        UPDATE predictions SET actual_score=?,actual_result='FINISHED',
            is_correct_prob=?,is_correct_ev=?,ai_note=?,postmortem_json=?
        WHERE match_id=? AND actual_result='PENDING'
    """, (score_str, prob_hit, ev_hit, ai_note, postmortem_data, match_id))
    if cursor.rowcount != 1:
        return False
    conn.commit()
    try:
        review = _grade_prediction_candidates(
            conn, match_id, home_team, away_team, goals_h, goals_a
        )
        robot_samples_graded = _grade_autonomous_robot_sample(
            conn, match_id, fixture_id, goals_h, goals_a
        )
        if review:
            try:
                payload = json.loads(postmortem_data or "{}")
                payload["candidate_review"] = review
                payload["autonomous_robot_samples_graded"] = robot_samples_graded
                postmortem_data = json.dumps(payload, ensure_ascii=False, sort_keys=True)
            except (TypeError, ValueError, json.JSONDecodeError):
                pass
            review_text = _candidate_review_text(review)
            if review_text:
                ai_note += "\n\n" + review_text
        if events:
            ai_note += "\n\n🎬 주요 사건 기록(최대 8건)\n" + "\n".join(events)
        cursor.execute(
            "UPDATE predictions SET ai_note=?,postmortem_json=? WHERE match_id=? AND actual_result='FINISHED'",
            (ai_note, postmortem_data, match_id),
        )
        conn.commit()
    except Exception as review_error:
        conn.rollback()
        print(f"⚠️ 저장 점수 채점 완료 · 후보 복기 보강 대기: {match_id} ({type(review_error).__name__})")
    _scoring_reason(conn, match_id, "저장된 동일 경기 결과로 채점 완료", 86400)
    return True


def _recover_stored_finished_results(rows, conn):
    """Use only a unique same-fixture local final; never infer a score."""
    finished = conn.execute("""
        SELECT api_fixture_id,home_team,away_team,match_time,actual_score
        FROM predictions
        WHERE actual_result='FINISHED' AND api_fixture_id>0 AND actual_score LIKE '%:%'
    """).fetchall()
    by_fixture = {}
    for fixture, home, away, match_time, score in finished:
        matched = re.match(r"^\s*(\d+)\s*:\s*(\d+)\s*$", str(score or ""))
        if matched:
            by_fixture.setdefault(int(fixture), []).append(
                (home, away, match_time, int(matched.group(1)), int(matched.group(2)))
            )
    remaining, graded = [], 0
    for row in rows:
        fixture = int(row[6] or 0)
        local_dt = _parse_kst_match_time(row[5])
        matches = set()
        for home, away, match_time, goals_h, goals_a in by_fixture.get(fixture, []):
            other_dt = _parse_kst_match_time(match_time)
            if (local_dt and other_dt and abs((local_dt - other_dt).total_seconds()) <= 3 * 3600
                    and _stored_team_identity_matches(row[1], home)
                    and _stored_team_identity_matches(row[2], away)):
                matches.add((goals_h, goals_a))
        if len(matches) == 1 and _grade_pending_from_saved_score(conn, row, *next(iter(matches))):
            graded += 1
        else:
            remaining.append(row)
    return remaining, graded


def _ensure_postmortem_column(conn):
    columns = {row[1] for row in conn.execute("PRAGMA table_info(predictions)")}
    if "postmortem_json" not in columns:
        conn.execute("ALTER TABLE predictions ADD COLUMN postmortem_json TEXT DEFAULT '{}'")
        conn.commit()


def _backfill_candidate_learning(conn, limit=40):
    """Retry optional reviews without refetching results or forecasts."""
    _ensure_prediction_analysis_tables(conn)
    rows = conn.execute("""
        SELECT p.match_id,p.home_team,p.away_team,p.actual_score,p.postmortem_json
        FROM predictions p WHERE p.actual_result='FINISHED'
        AND EXISTS(SELECT 1 FROM prediction_analysis_snapshots s
                   WHERE s.match_id=p.match_id AND length(s.candidates_json)>2)
        AND NOT EXISTS(SELECT 1 FROM prediction_candidate_results r WHERE r.match_id=p.match_id)
        ORDER BY p.rowid DESC LIMIT ?
    """, (limit,)).fetchall()
    count = 0
    for match_id, home, away, score, note in rows:
        scores = re.fullmatch(r'(\d+):(\d+)', str(score))
        if not scores:
            continue
        try:
            review = _grade_prediction_candidates(conn, match_id, home, away, *map(int, scores.groups()))
            if review:
                payload = json.loads(note or '{}')
                payload['candidate_review'] = review
                conn.execute('UPDATE predictions SET postmortem_json=? WHERE match_id=?',
                             (json.dumps(payload, ensure_ascii=False), match_id))
                count += 1
            conn.commit()
        except Exception:
            conn.rollback()
    return count


def _backfill_finished_postmortems(conn, limit=20):
    """Give older graded rows deterministic learning labels in bounded batches.

    Historical repair is useful training material, but it is not allowed to
    delay today's score publication or the next pick-serving master turn.
    """
    _ensure_postmortem_column(conn)
    rows = conn.execute(
        """
        SELECT match_id, home_team, away_team, prob_pick, ev_pick,
               actual_score, is_correct_prob, is_correct_ev, ai_note
        FROM predictions
        WHERE actual_result = 'FINISHED'
          AND COALESCE(NULLIF(postmortem_json, ''), '{}') = '{}'
        ORDER BY rowid DESC LIMIT ?
        """,
        (max(1, int(limit or 1)),),
    ).fetchall()
    updates = []
    for row in rows:
        score_match = re.match(r"^\s*(\d+)\s*:\s*(\d+)\s*$", str(row[5] or ""))
        if not score_match:
            continue
        goals_h, goals_a = int(score_match.group(1)), int(score_match.group(2))
        events = events_from_note(row[8]) or _load_stored_event_timeline(row[0], limit=8)
        payload = build_postmortem(
            home_team=row[1],
            away_team=row[2],
            prob_pick=row[3],
            ev_pick=row[4],
            goals_h=goals_h,
            goals_a=goals_a,
            is_correct_prob=row[6],
            is_correct_ev=row[7],
            has_ev_pick=bool(str(row[4] or "").strip()),
            official_stats=stats_from_note(row[8]),
            event_timeline=events,
        )
        updates.append((postmortem_json(payload), row[0]))
    if updates:
        conn.executemany(
            "UPDATE predictions SET postmortem_json = ? WHERE match_id = ?",
            updates,
        )
        conn.commit()
    return len(updates)


def _is_supported_grade_pick(pick, home_team="", away_team=""):
    """Return True only for an explicit market result the scorer can re-evaluate."""
    text = str(pick or "").strip().upper()
    if not text:
        return False
    if "핸디" in text or "적용 후" in text:
        has_line = bool(
            re.search(r"\[\s*[+-]?\d+(?:\.\d+)?\s*\]", text)
            or re.search(r"[+-]?\d+(?:\.\d+)?\s*(?:적용\s*후|HANDICAP)", text)
        )
        return has_line and bool(re.search(r"(?:핸디|적용\s*후)\s*(승|무|패)", text))
    if "언더" in text or "오버" in text:
        return bool(re.search(r"\d+(?:\.\d+)?", text))
    if "무승부" in text or text in {"무", "DRAW"}:
        return True
    home = str(home_team or "").strip().upper()
    away = str(away_team or "").strip().upper()
    if text == "승" or text == "패":
        return True
    return bool((home and home in text and "승" in text) or (away and away in text and "승" in text))


def _repair_finished_handicap_grades(conn):
    """Recheck supported derived grades; frozen picks, odds and versions stay immutable."""
    _ensure_postmortem_column(conn)
    rows = conn.execute(
        """
        SELECT match_id, home_team, away_team, prob_pick, ev_pick,
               actual_score, is_correct_prob, is_correct_ev, ai_note
        FROM predictions
        WHERE actual_result = 'FINISHED'
          AND (length(trim(COALESCE(prob_pick,''))) > 0
               OR length(trim(COALESCE(ev_pick,''))) > 0)
        """
    ).fetchall()
    repaired_predictions = 0
    for row in rows:
        score_match = re.match(r"^\s*(\d+)\s*:\s*(\d+)\s*$", str(row[5] or ""))
        if not score_match:
            continue
        goals_h, goals_a = int(score_match.group(1)), int(score_match.group(2))
        prob_supported = _is_supported_grade_pick(row[3], row[1], row[2])
        ev_supported = _is_supported_grade_pick(row[4], row[1], row[2])
        if not prob_supported and not ev_supported:
            continue
        prob_hit = (
            int(evaluate_single_pick(row[3], row[1], row[2], goals_h, goals_a))
            if prob_supported else int(row[6] or 0)
        )
        has_ev_pick = bool(str(row[4] or "").strip())
        ev_hit = (
            int(evaluate_single_pick(row[4], row[1], row[2], goals_h, goals_a))
            if ev_supported else int(row[7] or 0)
        )
        if prob_hit == int(row[6] or 0) and ev_hit == int(row[7] or 0):
            continue
        official_stats = stats_from_note(row[8])
        events = events_from_note(row[8]) or _load_stored_event_timeline(row[0], limit=8)
        payload = build_postmortem(
            home_team=row[1], away_team=row[2], prob_pick=row[3], ev_pick=row[4],
            goals_h=goals_h, goals_a=goals_a,
            is_correct_prob=prob_hit, is_correct_ev=ev_hit,
            has_ev_pick=has_ev_pick, official_stats=official_stats,
            event_timeline=events,
        )
        result_parts = [f"최종 추천픽 {'적중' if prob_hit else '미적중'}"]
        if has_ev_pick:
            result_parts.append(
                f"기존 배당형 대안픽 {'적중' if ev_hit else '미적중'}"
            )
        note_parts = [
            f"[채점 결과] {' · '.join(result_parts)}.",
            f"[최종 점수] {goals_h}:{goals_a}.",
        ]
        stats_text = official_stats_text(official_stats)
        if stats_text:
            note_parts.append(f"[공식 경기 통계] {stats_text}.")
        review_text = postmortem_text(payload)
        if review_text:
            note_parts.append(review_text)
        if events:
            note_parts.append("🎬 주요 사건 기록(최대 8건)\n" + "\n".join(events[-8:]))
        conn.execute(
            """
            UPDATE predictions
            SET is_correct_prob = ?, is_correct_ev = ?, ai_note = ?,
                postmortem_json = ?
            WHERE match_id = ? AND actual_result = 'FINISHED'
            """,
            (prob_hit, ev_hit, "\n\n".join(note_parts), postmortem_json(payload), row[0]),
        )
        repaired_predictions += 1

    repaired_candidates = 0
    _ensure_prediction_analysis_tables(conn)
    candidate_rows = conn.execute(
        """
        SELECT result.id, result.raw_pick, result.is_correct,
               prediction.home_team, prediction.away_team, prediction.actual_score
        FROM prediction_candidate_results AS result
        JOIN predictions AS prediction ON prediction.match_id = result.match_id
        WHERE prediction.actual_result = 'FINISHED'
          AND length(trim(COALESCE(result.raw_pick,''))) > 0
        """
    ).fetchall()
    for result_id, raw_pick, old_hit, home_team, away_team, score in candidate_rows:
        score_match = re.match(r"^\s*(\d+)\s*:\s*(\d+)\s*$", str(score or ""))
        if not score_match:
            continue
        if not _is_supported_grade_pick(raw_pick, home_team, away_team):
            continue
        new_hit = int(evaluate_single_pick(
            raw_pick, home_team, away_team,
            int(score_match.group(1)), int(score_match.group(2)),
        ))
        if new_hit != int(old_hit or 0):
            conn.execute(
                "UPDATE prediction_candidate_results SET is_correct = ?, "
                "graded_at = CURRENT_TIMESTAMP WHERE id = ?",
                (new_hit, int(result_id)),
            )
            repaired_candidates += 1
    if repaired_predictions or repaired_candidates:
        conn.commit()
    return repaired_predictions, repaired_candidates


def _grade_prediction_candidates(
    conn, match_id, home_team, away_team, goals_h, goals_a
):
    """Grade the last frozen full-market audit without changing its forecast."""
    _ensure_prediction_analysis_tables(conn)
    forecast = conn.execute("SELECT match_time FROM predictions WHERE match_id=?",(str(match_id),)).fetchone()
    cutoff = _parse_kst_match_time(forecast[0]) if forecast else None
    if cutoff is None:
        return None  # No timestamp proof: do not teach the robot from hindsight.
    cutoff_utc = cutoff.astimezone(timezone.utc).isoformat()
    snapshot = conn.execute(
        """
        SELECT id, analysis_version, stage, candidates_json, evidence_json
        FROM prediction_analysis_snapshots
        WHERE match_id = ? AND julianday(created_at) <= julianday(?)
        ORDER BY id DESC LIMIT 1
        """,
        (str(match_id),cutoff_utc),
    ).fetchone()
    if not snapshot:
        return None
    try:
        candidates = json.loads(snapshot[3] or "[]")
    except (TypeError, ValueError, json.JSONDecodeError):
        return None
    if not isinstance(candidates, list):
        return None
    try:
        evidence = json.loads(snapshot[4] or "[]")
    except (TypeError, ValueError, json.JSONDecodeError):
        evidence = []
    odds_movement_evidence = ""
    for item in evidence if isinstance(evidence, list) else []:
        if not isinstance(item, dict) or str(item.get("name") or "") != "배당 변동":
            continue
        odds_movement_evidence = str(item.get("value") or "").strip()
        if odds_movement_evidence:
            break

    result_rows = []
    for candidate in candidates:
        if not isinstance(candidate, dict):
            continue
        raw_pick = str(candidate.get("raw_pick") or "").strip()
        market_key = str(candidate.get("market_key") or "").strip()
        if not raw_pick or market_key not in MARKET_LABELS:
            continue
        is_correct = int(evaluate_single_pick(
            raw_pick, home_team, away_team, int(goals_h), int(goals_a)
        ))
        selected_as = list(candidate.get("selected_as") or [])
        conn.execute(
            """
            INSERT OR REPLACE INTO prediction_candidate_results (
                match_id, analysis_snapshot_id, analysis_version, stage,
                market_key, raw_pick, model_probability, fair_probability,
                odd, selection_rank, market_rank, selected_as, is_correct,
                actual_score, graded_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            """,
            (
                str(match_id), int(snapshot[0]), str(snapshot[1] or ""),
                str(snapshot[2] or ""), market_key, raw_pick,
                float(candidate.get("model_probability") or 0),
                candidate.get("fair_probability"),
                float(candidate.get("odd") or 0),
                candidate.get("selection_rank"),
                candidate.get("market_rank"),
                json.dumps(selected_as, ensure_ascii=False), is_correct,
                f"{int(goals_h)}:{int(goals_a)}",
            ),
        )
        result_rows.append({
            "market_key": market_key,
            "market_label": MARKET_LABELS[market_key],
            "raw_pick": raw_pick,
            "model_probability": _audit_number(
                candidate.get("model_probability"), 0.0
            ),
            "selection_rank": candidate.get("selection_rank"),
            "selected_as": selected_as,
            "is_correct": is_correct,
        })

    hits = [item for item in result_rows if item["is_correct"] == 1]
    selected = [
        item for item in result_rows if "high_probability" in item["selected_as"]
    ]
    robot_selected = [
        item for item in result_rows if "robot_independent" in item["selected_as"]
    ]
    unselected_hits = [
        item for item in hits if "high_probability" not in item["selected_as"]
    ]
    unselected_hits.sort(
        key=lambda item: (
            float(item.get("model_probability") or 0),
            -(int(item.get("selection_rank") or 999)),
        ),
        reverse=True,
    )
    return {
        "schema_version": PICK_AUDIT_SCHEMA_VERSION,
        "analysis_snapshot_id": int(snapshot[0]),
        "analysis_version": str(snapshot[1] or ""),
        "stage": str(snapshot[2] or ""),
        "graded_candidate_count": len(result_rows),
        "hit_candidate_count": len(hits),
        "selected_pick_hit": bool(selected and selected[0]["is_correct"] == 1),
        "selected_pick": selected[0] if selected else None,
        "robot_pick_hit": bool(
            robot_selected and robot_selected[0]["is_correct"] == 1
        ),
        "robot_pick": robot_selected[0] if robot_selected else None,
        "market_answers": hits,
        "highest_probability_unselected_answer": (
            unselected_hits[0] if unselected_hits else None
        ),
        "odds_movement_evidence": odds_movement_evidence,
    }


def _candidate_review_text(review):
    if not review:
        return ""
    answer = review.get("highest_probability_unselected_answer")
    base = (
        f"[전체 시장 복기] 킥오프 전 동결 후보 "
        f"{int(review.get('graded_candidate_count') or 0)}개를 동일 점수로 채점했습니다."
    )
    movement = str(review.get("odds_movement_evidence") or "").strip()
    movement_note = f" 당시 확인된 해외배당 흐름: {movement}." if movement else ""
    robot_pick = review.get("robot_pick") or {}
    robot_note = (
        f" 로봇 독립픽 {robot_pick.get('market_label')} · {robot_pick.get('raw_pick')}은 "
        f"{'적중' if review.get('robot_pick_hit') else '미적중'}했습니다."
        if robot_pick else ""
    )
    if review.get("selected_pick_hit"):
        return base + " 최종 확률픽이 실제 결과 조건을 충족했습니다." + robot_note + movement_note
    if answer:
        return (
            base
            + f" 확률픽은 미적중했고, 미선택 후보 중 실제 조건을 충족한 "
            f"최상위 방향은 {answer.get('market_label')} · "
            f"{answer.get('raw_pick')}({float(answer.get('model_probability') or 0) * 100:.1f}%)였습니다. "
            "이는 경기 후 확인한 복기 자료이며 과거 예측을 소급 변경하지 않습니다."
            + robot_note
            + movement_note
        )
    return (
        base
        + " 미선택 후보까지 포함해 원인을 다음 도전자 모델의 학습 자료로 보존했습니다."
        + robot_note
        + movement_note
    )


def _ensure_scoring_queue(conn):
    conn.execute("""
        CREATE TABLE IF NOT EXISTS scoring_queue (
            match_id TEXT PRIMARY KEY, reason TEXT, last_attempt REAL DEFAULT 0,
            retry_at REAL DEFAULT 0, attempts INTEGER DEFAULT 0)
    """)
    conn.commit()


def _allocate_toto14_round(items, max_combinations=None):
    """Allocate the existing double-mark budget round-wide, never row-order.

    Only explicitly fresh, pre-kickoff analyses may change. Existing frozen
    marks consume their existing budget and remain byte-for-byte unchanged.
    """
    cap = max_combinations or TOTO14_MAX_COMBINATIONS
    combinations, candidates = 1, []
    for item in items:
        if not item.get('_pending_toto_save'):
            combinations *= max(1, len(item.get('picks') or []))
            continue
        values = {'승': float(item.get('p_h') or 0), '무': float(item.get('p_d') or 0), '패': float(item.get('p_a') or 0)}
        ranked = sorted(values, key=lambda mark: values[mark], reverse=True)
        item['picks'] = ranked[:1]
        item['top_outcome_probability'] = values[ranked[0]]
        item['marking_policy'] = 'round-coverage-marginal-gain-budget8-v2'
        # A round has only three double-mark slots at an 8-combination cap.
        # Allocate them to the largest covered-probability gain, rather than a
        # fixed 7% gap that can waste the budget or depend on row order.
        if values[ranked[0]] > 0 and values[ranked[1]] > 0:
            gain_ratio = (values[ranked[0]] + values[ranked[1]]) / values[ranked[0]]
            uncertainty = 1.0 - values[ranked[0]] / 100.0
            candidates.append((gain_ratio, uncertainty, str(item.get('match', {}).get('id')), item, ranked[1]))
    for _, _, _, item, second in sorted(candidates, key=lambda row: (-row[0], -row[1], row[2])):
        item['double_suppressed'] = combinations * 2 > cap
        if combinations * 2 <= cap:
            item['picks'].append(second)
            combinations *= 2
    return items


def _toto14_mark_from_raw_pick(raw_pick, home_team="", away_team=""):
    """Translate an already-issued 1X2 answer into one Toto mark only."""
    raw = str(raw_pick or "").strip()
    upper = raw.upper()
    if upper in {"H", "HOME"}:
        return "승"
    if upper in {"D", "DRAW"} or "무승부" in raw:
        return "무"
    if upper in {"A", "AWAY"}:
        return "패"
    if away_team and str(away_team) in raw and "승" in raw:
        return "패"
    if home_team and str(home_team) in raw and "승" in raw:
        return "승"
    if raw in {"승", "무", "패"}:
        return raw
    return ""


def _build_toto14_analyst_marks(item):
    """Store separate analyst marks without creating missing answers."""
    item = item if isinstance(item, dict) else {}
    match = item.get("match") or {}
    home, away = str(match.get("home") or ""), str(match.get("away") or "")
    official = _normalize_toto14_picks(item.get("picks") or [])
    robot = _toto14_mark_from_raw_pick(
        (item.get("robot_pick") or {}).get("raw_pick") or item.get("robot_mark"),
        home, away,
    )
    alphago = item.get("alphago_pick") or {}
    v2 = _toto14_mark_from_raw_pick(
        alphago.get("code") or alphago.get("raw_pick"), home, away
    )
    return {
        "official": {"marks": official, "available": bool(official)},
        "robot": {"marks": [robot] if robot else [], "available": bool(robot)},
        "v2": {"marks": [v2] if v2 else [], "available": bool(v2)},
        # V3 is published by its independent learner and attached by app.py;
        # it is intentionally not manufactured by the collector.
        "v3": {"marks": [], "available": False},
    }


def _finalize_toto14_round(items):
    # Discard analyses crossing kickoff before allocating; no past result can
    # influence another game's marks through a rewritten frozen ticket.
    for index, item in enumerate(items):
        if not item.get('_pending_toto_save'):
            continue
        match = item['match']
        kickoff = _parse_kst_match_time(match.get('match_time'))
        identity_ready = _published_team_identity_ready(item)
        if kickoff is None or datetime.now(KST) >= kickoff:
            # Started/unknown-time records keep only their existing pre-kickoff
            # frozen answer. The new identity gate never rewrites history.
            items[index] = _locked_toto14_fallback(match) or _unavailable_toto14_item(match)
        elif not identity_ready:
            queue_team_identity_retry(
                str(match.get("home") or ""), str(match.get("away") or ""),
                str(match.get("match_time") or ""),
                reason="toto14_final_publication_identity_gate",
                league_name=match.get("league") or "",
            )
            items[index] = _unavailable_toto14_item(match)
    _allocate_toto14_round(items)
    for index, item in enumerate(items):
        if not item.pop('_pending_toto_save', False):
            continue
        policy_migration = bool(item.pop('_policy_migration', False))
        match = item['match']
        marks = item['picks']
        display = ', '.join(match['home']+' 승' if mark=='승' else match['away']+' 승' if mark=='패' else '무승부' for mark in marks)
        coverage = sum(float(item.get({'승':'p_h','무':'p_d','패':'p_a'}[mark]) or 0) for mark in marks)
        item.update(best_pick_display=display, picks_html=_render_toto14_picks_html(marks),
                    covered_probability=round(coverage, 1))
        # Every analyst keeps its own 14-match answer.  These are display
        # records only: the official multi-mark ticket above remains the
        # settlement source and no analyst may overwrite another's answer.
        item["analyst_toto14_marks"] = _build_toto14_analyst_marks(item)
        match_id = 'TOTO14_' + str(match['id'])
        kickoff = _parse_kst_match_time(match.get('match_time'))
        if (
            kickoff and datetime.now(KST) < kickoff
            and item.get("robot_pick")
        ):
            save_autonomous_robot_sample(
                "TOTO14", match_id, item.get("api_fixture_id") or 0,
                "승무패 14경기", match["home"], match["away"], kickoff,
                item.get("robot_features") or {},
                item.get("robot_candidates") or [], item.get("robot_pick") or {},
                full_evidence=item.get("robot_full_evidence") or {},
                lineup_prediction=item.get("robot_lineup_prediction") or {},
                analysis_stage=item.get("analysis_stage") or "",
            )
        saved = save_dual_predictions_to_local_db(
            match_id, '승무패 14경기', match['home'], match['away'], display, coverage,
            display, coverage, 0, 0, 0, match.get('match_time'), 1,
            item.get('api_fixture_id') or 0, item.get('analysis_stage') or 'regular',
            item.get('analysis_confidence') or 0)
        if saved and kickoff and item.get("robot_pick"):
            save_three_engine_picks(
                "TOTO14", match_id, item.get("api_fixture_id") or 0,
                "승무패 14경기", match["home"], match["away"], kickoff,
                item.get("official_comparison_pick") or {},
                item.get("legacy_v4_pick") or {}, item.get("robot_pick") or {},
            )
            _apply_frozen_toto14_robot(item, match_id)
        if not saved or not kickoff or datetime.now(KST) >= kickoff:
            items[index] = _locked_toto14_fallback(match) or _unavailable_toto14_item(match)
        elif item.get('analysis_stage') == 'T-30-final' or policy_migration:
            items[index] = _freeze_toto14_prediction(match_id, match['home'], match['away'], match.get('match_time'), item) or item
    return items


def _build_toto14_ticket_meta(items, cost_cap_exceeded_by_frozen=False):
    """Keep calculated cost visible while reporting purchase readiness separately."""
    return toto14_display_meta(items, {
        "max_combinations": TOTO14_MAX_COMBINATIONS,
        "unit_price": TOTO14_UNIT_PRICE,
        "max_budget": TOTO14_MAX_COMBINATIONS * TOTO14_UNIT_PRICE,
        "cost_cap_exceeded_by_frozen": cost_cap_exceeded_by_frozen,
    })


def build_honey_two_pick(items):
    """Build an optional two-match combo only from two qualified final picks."""
    eligible = []
    seen = set()
    for item in items or []:
        match = item.get("match") or {}
        identity = str(item.get("api_fixture_id") or match.get("id") or "")
        categories = item.get("pick_categories") or {}
        final_pick = categories.get("high_probability") or {}
        honey = categories.get("honey") or {}
        if (not identity or identity in seen or not final_pick.get("raw_pick")
                or str(honey.get("raw_pick") or "") != str(final_pick.get("raw_pick") or "")
                or float(final_pick.get("odd") or 0) <= 1):
            continue
        seen.add(identity)
        eligible.append((
            (float(final_pick.get("robust_edge") or 0),
             float(final_pick.get("robust_ev") or 0),
             float(final_pick.get("robust_probability") or final_pick.get("prob") or 0),
             float(item.get("analysis_confidence") or 0)),
            {"fixture_id": identity, "home": str(match.get("home") or ""),
             "away": str(match.get("away") or ""),
             "match_time": str(match.get("match_time") or item.get("final_match_time") or ""),
             "pick": str(final_pick.get("raw_pick") or ""),
             "probability": round(float(final_pick.get("prob") or 0), 6),
             "odd": round(float(final_pick.get("odd") or 0), 3)},
        ))
    selected = [row[1] for row in sorted(eligible, key=lambda row: row[0], reverse=True)[:2]]
    if len(selected) != 2:
        return None
    return {"label": "꿀 2픽 조합", "picks": selected,
            "combined_probability": round(math.prod(row["probability"] for row in selected), 6),
            "combined_odd": round(math.prod(row["odd"] for row in selected), 3),
            "official_single_pick_count": 2,
            "policy": "two-distinct-matches-each-honey-qualified-v1"}


def _scoring_reason(conn, match_id, reason, delay=1800):
    conn.execute("""
        INSERT INTO scoring_queue(match_id,reason,last_attempt,retry_at,attempts)
        VALUES (?,?,?,?,1) ON CONFLICT(match_id) DO UPDATE SET
        reason=excluded.reason,last_attempt=excluded.last_attempt,
        retry_at=excluded.retry_at,attempts=attempts+1
    """, (str(match_id),str(reason),time.time(),time.time()+delay))
    conn.commit()


def _select_scoring_due(rows, conn, now):
    """Reserve a bounded backlog share; old rows never silently age out."""
    _ensure_scoring_queue(conn)
    queue = {r[0]:r[1:] for r in conn.execute("SELECT match_id,last_attempt,retry_at FROM scoring_queue")}
    recent, backlog = [], []
    now_ts = now.timestamp()
    for row in rows:
        kickoff = _parse_kst_match_time(row[5])
        if kickoff is None:
            if str(row[0]) not in queue:
                _scoring_reason(conn,row[0],"경기 시간 확인 필요",86400)
            continue
        # Avoid polling each newly-started game: LIVE worker handles its status.
        if now < kickoff + timedelta(minutes=105):
            continue
        last, retry_at = queue.get(str(row[0]),(0,0))
        if retry_at > now_ts:
            continue
        bucket = backlog if now-kickoff > timedelta(days=7) else recent
        bucket.append((last,kickoff.timestamp(),row))
    recent.sort(key=lambda item:(item[0],-item[1]))
    backlog.sort(key=lambda item:(item[0],item[1]))
    chosen = [entry[2] for entry in recent[:30]] + [entry[2] for entry in backlog[:10]]
    for row in chosen:
        _scoring_reason(conn,row[0],"결과 확인 대기",1800)
    return chosen


def auto_score_matches():
    print(f"\n[🤖 {time.strftime('%Y-%m-%d %H:%M:%S')}] 🔥 불도저 채점 엔진 가동 (정밀 API 고유 ID 추적)...")
    scoring_calls_before = int(get_api_usage_status().get("scoring_calls") or 0)
    conn = None
    try:
        conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=30)
        conn.execute("PRAGMA busy_timeout = 30000")
        repaired_predictions, repaired_candidates = _repair_finished_handicap_grades(conn)
        if repaired_predictions or repaired_candidates:
            print(
                "✅ 종료 경기 판정 재검증 완료: "
                f"공식픽 {repaired_predictions}건 / 시장후보 {repaired_candidates}건 "
                "(예측·확률·버전은 보존)"
            )
        conn.commit()  # Repairs must survive even when no due batches run.
        backfilled_count = _backfill_finished_postmortems(
            conn, limit=SCORE_POSTMORTEM_BACKFILL_BATCH
        )
        candidate_backfilled_count = _backfill_candidate_learning(
            conn, limit=SCORE_CANDIDATE_BACKFILL_BATCH
        )
        conn.commit()  # Release writes before network/cache operations.
        if backfilled_count:
            print(f"✅ 기존 오답노트 학습 태그 보강: {backfilled_count}건")
        if candidate_backfilled_count:
            print(f"✅ 과거 전체후보 학습 보강: {candidate_backfilled_count}건")
        cursor = conn.cursor()
        cursor.execute("""
            SELECT match_id, home_team, away_team, prob_pick, ev_pick,
                   match_time, api_fixture_id
            FROM predictions
            WHERE actual_result = 'PENDING'
        """)
        pending_matches = [
            _scoring_row_from_first_public_snapshot(conn, row)
            for row in cursor.fetchall()
        ]
        api_call_count = 0
        graded_count, result_error_count = 0, 0
        now = datetime.now(KST)
        # Recover exact IDs from already stored canonical/WORLD rows before
        # applying retry_at. This spends no API and fixes the old starvation
        # where an ID-recovery candidate never reached the recovery function.
        _ensure_scoring_queue(conn)
        pending_matches, stored_recovered_count = _recover_due_fixture_ids(
            pending_matches, conn, local_only=True
        )
        due_matches = _select_scoring_due(pending_matches,conn,now)

        due_matches, recovered_count = _recover_due_fixture_ids(due_matches, conn)
        total_recovered = stored_recovered_count + recovered_count
        if total_recovered:
            print(f"✅ 종료 경기 fixture ID 복구: {total_recovered}건")

        # A finished canonical/WORLD row may already hold the verified score.
        # Reuse that immutable result before spending another provider call.
        # Exact fixture, ordered teams and kickoff proximity are mandatory.
        due_matches, locally_graded_count = _recover_stored_finished_results(
            due_matches, conn
        )
        graded_count += locally_graded_count
        if locally_graded_count:
            print(f"✅ 저장된 동일 경기 결과로 미채점 복구: {locally_graded_count}건")

        for row in due_matches:
            if not int(row[6] or 0):
                _scoring_reason(conn,row[0],"경기 ID 미연결 · 날짜/양 팀 확인 필요",7200)

        # One failed batch must not roll back completed batches or stop later runs.
        linked_matches = [row for row in due_matches if int(row[6] or 0)]
        for offset in range(0, len(linked_matches), 20):
            batch = linked_matches[offset:offset + 20]
            fixture_ids = sorted({str(int(row[6])) for row in batch if row[6]})
            if not fixture_ids:
                continue
            try:
                res = api_get(
                    "/fixtures",
                    params={"ids": "-".join(fixture_ids), "timezone": "Asia/Seoul"},
                    timeout=12,
                    purpose="scoring",
                )
                api_call_count += 1
                payload = res.json() if res.status_code == 200 else {}
                if res.status_code != 200 or payload.get("errors"):
                    result_error_count += 1
                    for row in batch:
                        _scoring_reason(conn, row[0], f"결과 수신 실패 · HTTP {res.status_code} · 공급사 오류", 3600)
                    print(f"⚠️ 묶음 채점 API 오류: HTTP {res.status_code} {payload.get('errors', '')}")
                    continue
                fixture_map = {
                    int(item.get("fixture", {}).get("id") or 0): item
                    for item in payload.get("response", [])
                }

                for row in batch:
                    match_id, h_team, a_team, prob_pick, ev_pick, _, fixture_id = row
                    match_info = fixture_map.get(int(fixture_id))
                    if not match_info:
                        _scoring_reason(conn,row[0],"공급사 경기 데이터 미수신",3600)
                        continue
                    if not _scoring_row_matches_fixture(row, match_info):
                        # Never grade a fixture ID that points to another match.
                        # Clearing it lets the date/team recovery path repair it on
                        # the next independent scoring cycle.
                        cursor.execute(
                            "UPDATE predictions SET api_fixture_id = 0 "
                            "WHERE match_id = ? AND actual_result = 'PENDING'",
                            (match_id,),
                        )
                        _scoring_reason(conn,match_id,"경기 ID 불일치 · 재연결 대기",1800)
                        print(f"⚠️ 잘못 연결된 fixture ID 해제: {h_team} vs {a_team}")
                        continue
                    status = match_info.get('fixture', {}).get('status', {}).get('short', '')

                    if status in TERMINAL_STATUSES:
                        final_h = match_info.get('goals', {}).get('home')
                        final_a = match_info.get('goals', {}).get('away')
                        if final_h is None or final_a is None:
                            _scoring_reason(conn,match_id,"종료 점수 미수신",1800)
                            print(f"⚠️ 종료 상태지만 점수가 비어 있어 채점 보류: {h_team} vs {a_team}")
                            continue
                        final_h, final_a = int(final_h), int(final_a)
                        regulation = match_info.get("score", {}).get("fulltime", {}) or {}
                        eval_h = regulation.get("home")
                        eval_a = regulation.get("away")
                        if status in {"AET","PEN"} and (eval_h is None or eval_a is None):
                            _scoring_reason(conn,match_id,"정규시간 점수 미수신 · 연장 결과로 대신 채점하지 않음",3600)
                            continue
                        eval_h = final_h if eval_h is None else int(eval_h)
                        eval_a = final_a if eval_a is None else int(eval_a)
                        score_str = f"{eval_h}:{eval_a}"  # All saved markets settle on regulation time.
                        is_corr_prob = evaluate_single_pick(prob_pick, h_team, a_team, eval_h, eval_a)
                        is_corr_ev = evaluate_single_pick(ev_pick, h_team, a_team, eval_h, eval_a)
                        event_timeline = _load_stored_event_timeline(match_id, limit=8)
                        ai_note, postmortem_data = generate_real_ai_note(
                            fixture_id, eval_h, eval_a, is_corr_prob, is_corr_ev,
                            has_ev_pick=bool(str(ev_pick or "").strip()),
                            home_team=h_team,
                            away_team=a_team,
                            prob_pick=prob_pick,
                            ev_pick=ev_pick,
                            event_timeline=event_timeline,
                            return_postmortem=True,
                            fetch_official_stats=False,
                        )
                        # The verified result must survive optional learning/report
                        # failures, and must not wait for one statistics API per game.
                        cursor.execute("""
                            UPDATE predictions SET actual_score=?, actual_result='FINISHED',
                                is_correct_prob=?, is_correct_ev=?, ai_note=?, postmortem_json=?
                            WHERE match_id=? AND actual_result='PENDING'
                        """, (score_str, is_corr_prob, is_corr_ev, ai_note, postmortem_data, match_id))
                        conn.commit()
                        candidate_review = None
                        robot_samples_graded = 0
                        try:
                            candidate_review = _grade_prediction_candidates(
                                conn, match_id, h_team, a_team, eval_h, eval_a
                            )
                            robot_samples_graded = _grade_autonomous_robot_sample(
                                conn, match_id, fixture_id, eval_h, eval_a
                            )
                            conn.commit()
                        except Exception as review_error:
                            conn.rollback()
                            print(f"⚠️ 결과 저장 완료 · 후보 복기 보강 대기: {match_id} ({type(review_error).__name__})")
                        if candidate_review:
                            try:
                                postmortem_payload = json.loads(postmortem_data or "{}")
                                postmortem_payload["candidate_review"] = candidate_review
                                postmortem_payload["autonomous_robot_samples_graded"] = robot_samples_graded
                                postmortem_data = json.dumps(
                                    postmortem_payload,
                                    ensure_ascii=False,
                                    sort_keys=True,
                                )
                            except (TypeError, ValueError, json.JSONDecodeError):
                                pass
                            review_text = _candidate_review_text(candidate_review)
                            if review_text:
                                ai_note += "\n\n" + review_text
                        if event_timeline:
                            ai_note += "\n\n🎬 주요 사건 기록(최대 8건)\n" + "\n".join(event_timeline)
                        cursor.execute("""
                            UPDATE predictions
                            SET actual_score = ?, actual_result = 'FINISHED',
                                is_correct_prob = ?, is_correct_ev = ?, ai_note = ?,
                                postmortem_json = ?
                            WHERE match_id = ? AND actual_result = 'FINISHED'
                        """, (
                            score_str, is_corr_prob, is_corr_ev, ai_note,
                            postmortem_data, match_id,
                        ))
                        _scoring_reason(conn,match_id,"채점 완료",86400)
                        graded_count += 1
                        print(f"  ✨ [정밀 채점 완료] {h_team} vs {a_team} ({score_str})")
                    elif status in CANCELED_STATUSES:
                        cursor.execute("""
                            UPDATE predictions
                            SET actual_result = 'CANCELED',
                                ai_note = '💡 경기 취소/중단/몰수로 인한 무효 처리'
                            WHERE match_id = ? AND actual_result = 'PENDING'
                        """, (match_id,))
                        _scoring_reason(conn,match_id,"무효 처리",86400)
                        print(f"  ⚠️ [경기 무효 처리] {h_team} vs {a_team}")
                    elif status in POSTPONED_STATUSES:
                        _scoring_reason(conn,match_id,"경기 연기 · 결과 대기",14400)
                        print(f"  ⏸️ [경기 연기 - 추후 재확인] {h_team} vs {a_team}")
                conn.commit()
            except Exception as batch_error:
                result_error_count += 1
                conn.rollback()
                for failed_row in batch:
                    still_pending = conn.execute("SELECT actual_result FROM predictions WHERE match_id=?", (failed_row[0],)).fetchone()
                    if still_pending and still_pending[0] != 'PENDING':
                        continue
                    _scoring_reason(conn,failed_row[0],
                                    "API 예산/연결 확인 필요" if isinstance(batch_error,ApiQuotaUnavailable) else "채점 처리 오류 · 재시도 대기",3600)
                print(f"⚠️ 채점 묶음 처리 실패(다음 주기 재시도): {batch_error}")

        lineup_answers_attached = _reconcile_robot_lineup_answers(
            conn, batch_size=SCORE_LINEUP_RECHECK_BATCH
        )
        if lineup_answers_attached:
            print(
                f"✅ 자율 로봇 공식 선발 11명 정답 연결: {lineup_answers_attached}경기"
            )
        scoring_calls_after = int(get_api_usage_status().get("scoring_calls") or 0)
        _update_collector_status("score", "running", due_count=len(due_matches),
                                 graded_count=graded_count, result_error_count=result_error_count,
                                 results_state="degraded" if result_error_count else "checked")
        scoring_calls_used = max(0, scoring_calls_after - scoring_calls_before)
        print(
            "✅ 스마트 채점 사이클 종료 "
            f"(전체 채점 API {scoring_calls_used}회 / 결과 묶음 {api_call_count}회)"
        )
        return True
    except Exception as error:
        print(f"❌ [관제 봇 떡밥] 채점 중 오류: {error}")
        return False
    finally:
        if conn is not None:
            conn.close()

def _api_fixture_datetime(match_info):
    raw_date = match_info.get("fixture", {}).get("date")
    if not raw_date:
        return None
    try:
        parsed = datetime.fromisoformat(str(raw_date).replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(timezone(timedelta(hours=9)))
    except (TypeError, ValueError):
        return None


def _request_fixture_board(params, purpose="live"):
    """일시적인 API 지연에는 한 번 재시도하고 오류 응답은 데이터로 쓰지 않는다."""
    last_error = None
    for attempt in range(2):
        try:
            response = api_get(
                "/fixtures",
                params=params,
                timeout=12,
                purpose=purpose,
            )
            if response.status_code != 200:
                raise RuntimeError(f"API HTTP {response.status_code}")
            payload = response.json()
            if payload.get("errors"):
                raise RuntimeError(str(payload.get("errors")))
            return payload.get("response", [])
        except (ApiQuotaUnavailable, ApiRateLimited):
            raise
        except Exception as error:
            last_error = error
            if attempt == 0:
                time.sleep(1.5)
    raise RuntimeError(str(last_error or "라이브 API 응답 없음"))


def _event_record(raw_event):
    event_time = raw_event.get("time", {}) or {}
    event_type = str(raw_event.get("type", "") or "")
    detail = str(raw_event.get("detail", "") or "")
    player = raw_event.get("player", {}) or {}
    assist = raw_event.get("assist", {}) or {}
    team = raw_event.get("team", {}) or {}
    elapsed = int(event_time.get("elapsed") or 0)
    extra = int(event_time.get("extra") or 0)
    player_name = str(player.get("name", "") or "")
    assist_name = str(assist.get("name", "") or "")
    team_name = str(team.get("name", "") or "")
    minute = f"{elapsed}+{extra}" if extra else str(elapsed)
    event_key = event_type.casefold()
    detail_key = detail.casefold()
    subject = player_name or team_name or detail

    if event_key == "goal":
        text = f"{minute}분 | ⚽ 득점 | {team_name} | {subject}"
    elif event_key == "card" and ("red" in detail_key or "second yellow" in detail_key):
        text = f"{minute}분 | 🟥 퇴장 | {team_name} | {subject}"
    elif event_key == "card" and "yellow" in detail_key:
        text = f"{minute}분 | 🟨 경고 | {team_name} | {subject}"
    elif event_key in {"subst", "substitution"}:
        change = f"나간 선수: {player_name}"
        if assist_name:
            change += f" / 들어온 선수: {assist_name}"
        text = f"{minute}분 | 🔄 교체 | {team_name} | {change}"
    elif event_key == "var":
        text = f"{minute}분 | 📺 VAR | {team_name} | {detail or subject}"
    elif event_key == "injury" or "injur" in detail_key:
        text = f"{minute}분 | 🚑 부상 | {team_name} | {subject}"
    else:
        return None
    key = "|".join(map(str, (
        elapsed, extra, team.get("id") or team.get("name") or "",
        event_type, detail, player.get("id") or player_name,
    )))
    return {
        "key": key,
        "elapsed": elapsed,
        "extra": extra,
        "type": event_type,
        "detail": detail,
        "player": player_name,
        "team": str(team.get("name", "") or ""),
        "text": text,
    }


def _load_stored_event_timeline(match_id, limit=8):
    try:
        live_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "live_scores.json"
        )
        with open(live_path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        record = payload.get(str(match_id), {}) if isinstance(payload, dict) else {}
        events = record.get("events", []) if isinstance(record, dict) else []
        texts = []
        signatures = set()
        for event in events:
            if not isinstance(event, dict):
                continue
            text = str(event.get("text") or "").strip()
            signature = re.sub(r"[^0-9a-z가-힣]+", "", text.casefold())
            if text and signature and signature not in signatures:
                signatures.add(signature)
                texts.append(text)
        return texts[-max(1, int(limit)):]
    except Exception:
        return []


def _merge_event_history(previous_entries, api_events):
    merged = {}
    for entry in previous_entries or []:
        if not isinstance(entry, dict):
            continue
        key = str(entry.get("key", "") or "")
        if key:
            merged[key] = dict(entry)
    for raw_event in api_events or []:
        normalized = _event_record(raw_event)
        if normalized:
            merged[normalized["key"]] = normalized
    history = sorted(
        merged.values(),
        key=lambda item: (int(item.get("elapsed", 0)), int(item.get("extra", 0)), item.get("key", "")),
    )[-80:]
    latest = history[-1].get("text", "") if history else ""
    return history, latest


def _entry_not_expired(entry, now):
    raw_expiry = entry.get("retain_until") if isinstance(entry, dict) else None
    if not raw_expiry:
        return True
    try:
        expiry = datetime.fromisoformat(str(raw_expiry).replace("Z", "+00:00"))
        if expiry.tzinfo is None:
            expiry = expiry.replace(tzinfo=timezone.utc)
        return now.astimezone(timezone.utc) <= expiry.astimezone(timezone.utc)
    except (TypeError, ValueError):
        return True


def _retention_deadline(anchor=None):
    base = datetime.now(timezone.utc)
    if anchor:
        try:
            parsed = datetime.fromisoformat(str(anchor).replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
            base = parsed.astimezone(timezone.utc)
        except (TypeError, ValueError):
            pass
    return (base + timedelta(hours=LIVE_RETENTION_HOURS)).isoformat(timespec="seconds")


def _row_matches_fixture(row, match_info):
    api_dt = _api_fixture_datetime(match_info)
    local_dt = _parse_kst_match_time(row[4])
    if api_dt is None or local_dt is None:
        return False
    if abs((local_dt - api_dt).total_seconds()) > 3 * 3600:
        return False
    teams = match_info.get("teams", {}) or {}
    api_home = teams.get("home", {}) or {}
    api_away = teams.get("away", {}) or {}
    exact_pair = (
        team_matches_api(row[2], api_home.get("name"), api_home.get("id"))
        and team_matches_api(row[3], api_away.get("name"), api_away.get("id"))
    )
    if exact_pair:
        return True
    # Never let fuzzy text overrule a known provider-ID mismatch.
    for local_name, api_team in ((row[2], api_home), (row[3], api_away)):
        expected_id = int(known_team_id(local_name) or 0)
        candidate_id = int(api_team.get("id") or 0)
        if expected_id and candidate_id and expected_id != candidate_id:
            return False
    home_score = _team_name_match_score(row[2], api_home.get("name"))
    away_score = _team_name_match_score(row[3], api_away.get("name"))
    return min(home_score, away_score) >= 0.84 and home_score + away_score >= 1.75


def _append_published_live_rows(all_rows, dashboard=None, world_dashboard=None):
    """Add published cards missing from the prediction DB to LIVE tracking."""
    rows = list(all_rows or [])
    known_ids = {str(row[0]) for row in rows}
    dashboard = dashboard if isinstance(dashboard, dict) else {}
    for item in dashboard.get("proto", []) or []:
        match = item.get("match") or {}
        match_id = str(match.get("id") or item.get("match_id") or "")
        if not match_id or match_id in known_ids:
            continue
        try:
            fixture_id = int(
                item.get("api_fixture_id")
                or match.get("api_fixture_id")
                or match.get("fixture_id")
                or 0
            )
        except (TypeError, ValueError):
            fixture_id = 0
        rows.append((
            match_id, fixture_id,
            str(match.get("home") or ""), str(match.get("away") or ""),
            str(item.get("final_match_time") or match.get("match_time") or ""),
            "PENDING", "-:-",
        ))
        known_ids.add(match_id)

    world_dashboard = world_dashboard if isinstance(world_dashboard, dict) else {}
    for item in world_dashboard.get("matches", []) or []:
        match = item.get("match") or {}
        match_id = str(match.get("id") or "")
        try:
            fixture_id = int(match.get("fixture_id") or item.get("api_fixture_id") or 0)
        except (TypeError, ValueError):
            fixture_id = 0
        if match_id and match_id not in known_ids and fixture_id:
            rows.append((
                match_id, fixture_id, str(match.get("home") or ""),
                str(match.get("away") or ""), str(match.get("match_time") or ""),
                "PENDING", "-:-",
            ))
            known_ids.add(match_id)
    return rows


def update_live_scores():
    print(f"\n[📡 {time.strftime('%Y-%m-%d %H:%M:%S')}] 실시간 라이브 데이터 업데이트 (5분 주기)...")
    previous = _read_json("live_scores.json", {})
    if not isinstance(previous, dict):
        previous = {}
    conn = None
    try:
        conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=30)
        conn.execute("PRAGMA busy_timeout = 30000")
        cursor = conn.cursor()
        cursor.execute("""
            SELECT match_id, api_fixture_id, home_team, away_team, match_time,
                   actual_result, actual_score
            FROM predictions
            WHERE actual_result IN ('PENDING', 'FINISHED')
        """)
        all_rows = cursor.fetchall()
        # LIVE coverage follows the published boards, not only rows that reached
        # the prediction DB.  Failed analysis/team linkage can recover later.
        all_rows = _append_published_live_rows(
            all_rows,
            dashboard=_read_json("dashboard_data.json", {}),
            world_dashboard=_read_json(WORLD_DASHBOARD_FILE, {}),
        )

        now_kst = datetime.now(KST)
        relevant_rows = []
        for row in all_rows:
            if str(row[5]) == "FINISHED":
                continue
            match_dt = _parse_kst_match_time(row[4])
            if match_dt is None:
                if str(row[0]) in previous:
                    relevant_rows.append(row)
                continue
            delta_hours = (match_dt - now_kst).total_seconds() / 3600
            if -LIVE_RETENTION_HOURS * 2 <= delta_hours <= LIVE_LOOKAROUND_HOURS:
                relevant_rows.append(row)

        rows_by_fixture = {}
        for row in relevant_rows:
            fixture_id = int(row[1] or 0)
            if fixture_id:
                rows_by_fixture.setdefault(fixture_id, []).append(row)

        # live=all is authoritative for current games. Previously tracked IDs are
        # queried too, so the same record can transition to FT instead of vanishing.
        fixture_candidates = {}
        board = _request_fixture_board({"live": "all", "timezone": "Asia/Seoul"})
        for item in board:
            fixture_id = int(item.get("fixture", {}).get("id") or 0)
            if fixture_id:
                fixture_candidates[fixture_id] = item

        tracked_ids = {
            fixture_id for fixture_id, rows in rows_by_fixture.items()
            if any((_parse_kst_match_time(row[4]) or now_kst) <= now_kst+timedelta(minutes=5) for row in rows)
        }
        for value in previous.values():
            if isinstance(value, dict) and not value.get("final") and _entry_not_expired(value,now_kst) and int(value.get("fixture_id") or 0):
                tracked_ids.add(int(value.get("fixture_id")))
        missing_ids = sorted(tracked_ids - set(fixture_candidates))
        for offset in range(0, len(missing_ids), 20):
            ids = missing_ids[offset:offset + 20]
            try:
                tracked_board = _request_fixture_board({
                    "ids": "-".join(map(str, ids)),
                    "timezone": "Asia/Seoul",
                })
                for item in tracked_board:
                    fixture_id = int(item.get("fixture", {}).get("id") or 0)
                    if fixture_id:
                        fixture_candidates[fixture_id] = item
            except Exception as tracked_error:
                print(f"⚠️ 추적 경기 상태 조회 실패(마지막 정상 점수 유지): {tracked_error}")

        # Recover unresolved matches from the scheduled date. Invalid/unknown times
        # never trigger repeated date-board calls.
        recovery_dates = []
        for row in relevant_rows:
            if int(row[1] or 0) or str(row[5]) != "PENDING":
                continue
            match_dt = _parse_kst_match_time(row[4])
            if match_dt is None:
                continue
            date_key = match_dt.strftime("%Y-%m-%d")
            if date_key not in recovery_dates:
                recovery_dates.append(date_key)
        for date_key in recovery_dates[:3]:
            try:
                date_board = _cached_fixture_identity_board(
                    date_key, purpose="live"
                )
                for item in date_board:
                    fixture_id = int(item.get("fixture", {}).get("id") or 0)
                    if fixture_id:
                        fixture_candidates.setdefault(fixture_id, item)
            except Exception as date_error:
                print(f"⚠️ 미연결 경기 복구판 조회 실패({date_key}): {date_error}")

        current_entries = {}
        score_updates = []
        fixture_updates = []
        recovered_links = 0
        used_match_ids = set()
        now_iso = _utc_iso()
        retain_until = _retention_deadline()

        for fixture_id, match_info in fixture_candidates.items():
            fixture = match_info.get("fixture", {}) or {}
            status_info = fixture.get("status", {}) or {}
            status = str(status_info.get("short", "") or "")
            if status not in LIVE_STATUSES | TERMINAL_STATUSES | CANCELED_STATUSES | POSTPONED_STATUSES:
                continue

            matched_rows = []
            for row in rows_by_fixture.get(fixture_id, []):
                if str(row[0]) not in used_match_ids and _row_matches_fixture(row, match_info):
                    matched_rows.append(row)
            matched_ids = {str(row[0]) for row in matched_rows}

            for row in relevant_rows:
                match_id = str(row[0])
                if match_id in matched_ids or match_id in used_match_ids:
                    continue
                if _row_matches_fixture(row, match_info):
                    matched_rows.append(row)
                    matched_ids.add(match_id)
                    if int(row[1] or 0) != fixture_id and str(row[5]) == "PENDING":
                        fixture_updates.append((fixture_id, match_id))
                        recovered_links += 1

            if not matched_rows:
                continue

            goals_h = match_info.get('goals', {}).get('home')
            goals_a = match_info.get('goals', {}).get('away')
            prior_for_fixture = [previous.get(str(row[0]), {}) for row in matched_rows]
            prior_score = next(
                (str(entry.get("score")) for entry in prior_for_fixture if entry.get("score")),
                "- : -",
            )
            if goals_h is None or goals_a is None:
                score_display = prior_score
                score_db = prior_score.replace(" : ", ":")
            else:
                score_db = f"{int(goals_h)}:{int(goals_a)}"
                score_display = score_db.replace(":", " : ")

            prior_history = []
            prior_event = ""
            last_event_fetch = None
            for entry in prior_for_fixture:
                if isinstance(entry.get("events"), list):
                    prior_history.extend(entry.get("events", []))
                if not prior_event and entry.get("event"):
                    prior_event = str(entry.get("event"))
                try:
                    fetched = datetime.fromisoformat(str(entry.get("events_fetched_at") or "").replace("Z", "+00:00"))
                    if fetched.tzinfo is None:
                        fetched = fetched.replace(tzinfo=timezone.utc)
                    if last_event_fetch is None or fetched > last_event_fetch:
                        last_event_fetch = fetched
                except (TypeError, ValueError):
                    pass
            embedded_events = match_info.get("events")
            event_history, event_str = _merge_event_history(
                prior_history,embedded_events if isinstance(embedded_events,list) else []
            )
            event_str = event_str or prior_event

            score_or_status_changed = any(
                str(entry.get("score") or "").replace(" : ", ":") != score_db
                or str(entry.get("status") or "") != status
                for entry in prior_for_fixture if isinstance(entry, dict)
            )
            event_refresh_due = (
                last_event_fetch is None
                or (datetime.now(timezone.utc) - last_event_fetch.astimezone(timezone.utc)).total_seconds() >= 15 * 60
            )
            should_fetch_events = (
        os.getenv("ENABLE_LIVE_EVENTS", "1") == "1"
                and not isinstance(embedded_events,list)
                and (status in LIVE_STATUSES or status in TERMINAL_STATUSES)
                and not (status in TERMINAL_STATUSES and any(entry.get("final") for entry in prior_for_fixture))
                and (not prior_history or score_or_status_changed or event_refresh_due)
            )
            event_fetch_succeeded = False
            if should_fetch_events:
                try:
                    evt_res = api_get(
                        "/fixtures/events",
                        params={"fixture": fixture_id},
                        timeout=8,
                        purpose="live",
                    )
                    evt_payload = evt_res.json() if evt_res.status_code == 200 else {}
                    if evt_res.status_code == 200 and not evt_payload.get("errors"):
                        event_history, latest_event = _merge_event_history(
                            event_history, evt_payload.get("response", [])
                        )
                        event_str = latest_event or event_str
                        event_fetch_succeeded = True
                except Exception as event_error:
                    print(f"⚠️ 라이브 이벤트 조회 실패({fixture_id}): {event_error} (이전 이벤트 유지)")

            is_live = status in LIVE_STATUSES
            is_final = status in TERMINAL_STATUSES or status in CANCELED_STATUSES
            for row in matched_rows:
                match_id = str(row[0])
                used_match_ids.add(match_id)
                prior_entry = previous.get(match_id, {}) if isinstance(previous.get(match_id), dict) else {}
                terminal_at = prior_entry.get("terminal_at")
                if is_final and not terminal_at:
                    terminal_at = now_iso
                entry_retain_until = (
                    _retention_deadline(terminal_at) if is_final else retain_until
                )
                next_entry = {
                    "score": score_display,
                    "event": event_str,
                    "events": event_history,
                    "is_live": is_live,
                    "final": is_final,
                    "stale": False,
                    "status": status,
                    "elapsed": int(status_info.get("elapsed") or 0),
                    "fixture_id": fixture_id,
                    "updated_at": now_iso,
                    "last_seen_at": now_iso,
                    "terminal_at": terminal_at,
                    "retain_until": entry_retain_until,
                    "events_fetched_at": (
                        now_iso if event_fetch_succeeded
                        else prior_entry.get("events_fetched_at")
                    ),
                }
                if is_final and not _entry_not_expired(next_entry, now_kst):
                    continue
                current_entries[match_id] = next_entry
                if goals_h is not None and goals_a is not None:
                    score_updates.append((score_db, match_id))

        if score_updates:
            cursor.executemany(
                "UPDATE predictions SET actual_score = ? WHERE match_id = ? AND actual_result = 'PENDING'",
                score_updates,
            )
        if fixture_updates:
            cursor.executemany(
                "UPDATE predictions SET api_fixture_id = ? WHERE match_id = ? AND actual_result = 'PENDING'",
                fixture_updates,
            )
        if score_updates or fixture_updates:
            conn.commit()

        # Last-known-good merge: a successful but empty/partial board is not proof
        # that a score should disappear. Expiry is the only implicit removal path.
        merged = {}
        for match_id, entry in previous.items():
            if not isinstance(entry, dict) or match_id in current_entries:
                continue
            preserved = dict(entry)
            if not preserved.get("retain_until"):
                preserved["retain_until"] = retain_until
            if not _entry_not_expired(preserved, now_kst):
                continue
            preserved["stale"] = True
            merged[str(match_id)] = preserved
        merged.update(current_entries)

        _atomic_write_json("live_scores.json", merged)
        if recovered_links:
            print(f"✅ 라이브 팀명/시간 자동 연결 복구: {recovered_links}건")
        live_count = sum(1 for value in merged.values() if value.get("is_live") is True)
        final_count = sum(1 for value in merged.values() if value.get("final") is True)
        print(f"✅ 라이브 업데이트 완료! (LIVE {live_count} / 종료 보존 {final_count} / 전체 {len(merged)})")
        return True
    except Exception as error:
        if conn is not None:
            try:
                conn.rollback()
            except Exception:
                pass
        print(f"❌ [관제 봇 떡밥] 라이브 스코어 에러: {error} (마지막 정상 파일 보존)")
        return False
    finally:
        if conn is not None:
            conn.close()

def _parse_odd_buttons(market):
    values = []
    for button in market.select("button.btnChk"):
        odd_node = button.select_one(".db")
        if not odd_node:
            continue
        match = re.search(r'\d+(?:\.\d+)?', odd_node.get_text(" ", strip=True).replace(',', ''))
        if match:
            values.append(float(match.group(0)))
    return values


def parse_betman_proto_html(html):
    """베트맨 프로토 페이지에서 축구 한 경기당 하나의 실제 시장을 추출한다."""
    soup = BeautifulSoup(html, 'html.parser')
    parsed, seen = [], set()

    for row in soup.select(".box-data-group [data-rowname]"):
        row_name = row.get("data-rowname", "")
        if not row_name or row_name in seen:
            continue
        seen.add(row_name)

        team_nodes = row.select(".teams .team")
        if len(team_nodes) < 2:
            continue
        home = team_nodes[0].get_text(" ", strip=True)
        away = team_nodes[1].get_text(" ", strip=True)
        if not home or not away:
            continue

        row_text = row.get_text(" ", strip=True)
        time_match = re.search(r'\d{2}\.\d{2}\s*\([^)]+\)\s*\d{2}:\d{2}', row_text)
        if not time_match:
            continue
        match_time = re.sub(r'\s+', ' ', time_match.group(0)).strip()
        league_node = row.select_one(".competition")
        league = league_node.get_text(" ", strip=True) if league_node else "축구"
        if _is_betman_auxiliary_prediction_record({"league": league}):
            continue

        market_root = row.select_one(".accordion-content")
        if market_root is None:
            market_root = row.find_next_sibling(class_=lambda value: value and "accordion-content" in value)
        if market_root is None:
            parent = row.parent
            market_root = parent.find_next_sibling(class_=lambda value: value and "accordion-content" in value) if parent else None
        if market_root is None:
            parent = row.parent
            market_root = parent.select_one(".accordion-content") if parent else None
        if market_root is None:
            continue

        deadline_match = re.search(r'(\d{2}:\d{2})\s*마감', market_root.get_text(" ", strip=True))
        deadline_time = f"{deadline_match.group(1)} 마감" if deadline_match else ""

        main_market = None
        handicap_market = None
        under_over_market = None
        for market in market_root.select("ul.list-proto-detail > li[data-matchseq]"):
            game_node = market.select_one(".competition-detail .game")
            game_name = re.sub(r'\s+', ' ', game_node.get_text(" ", strip=True)) if game_node else ""
            if game_name == "축구 승무패" and main_market is None:
                main_market = market
            elif game_name == "축구 핸디캡" and handicap_market is None:
                handicap_market = market
            elif game_name == "축구 언더오버" and under_over_market is None:
                under_over_market = market

        if main_market is None:
            continue
        odds_1x2 = _parse_odd_buttons(main_market)
        # Keep the fixture even while Betman is publishing or withdrawing odds.
        # build_dashboard_data already has a waiting-odds representation for zeros.
        if len(odds_1x2) < 3 or min(odds_1x2[:3]) <= 1.0:
            odds_1x2 = [0.0, 0.0, 0.0]

        odds_handi = _parse_odd_buttons(handicap_market) if handicap_market else []
        odds_uo = _parse_odd_buttons(under_over_market) if under_over_market else []
        handicap_text = handicap_market.get_text(" ", strip=True) if handicap_market else ""
        under_over_text = under_over_market.get_text(" ", strip=True) if under_over_market else ""
        handicap_match = re.search(r'H\s*([+-]?\d+(?:\.\d+)?)', handicap_text)
        under_over_match = re.search(r'U/O\s*(\d+(?:\.\d+)?)', under_over_text)
        match_id = str(main_market.get("data-matchseq") or row_name)

        parsed.append({
            "id": match_id,
            "league": league,
            "time": match_time,
            "match_time": match_time,
            "deadline_time": deadline_time,
            "home": home,
            "away": away,
            "odd_h": odds_1x2[0],
            "odd_d": odds_1x2[1],
            "odd_a": odds_1x2[2],
            "handi_h": odds_handi[0] if len(odds_handi) >= 3 else 0.0,
            "handi_d": odds_handi[1] if len(odds_handi) >= 3 else 0.0,
            "handi_a": odds_handi[2] if len(odds_handi) >= 3 else 0.0,
            "handi_base": float(handicap_match.group(1)) if handicap_match else 0.0,
            "uo_under": odds_uo[0] if len(odds_uo) >= 2 else 0.0,
            "uo_over": odds_uo[1] if len(odds_uo) >= 2 else 0.0,
            "uo_base": float(under_over_match.group(1)) if under_over_match else 0.0,
        })
    return parsed


def parse_betman_toto14_html(html, round_id="current"):
    """축구 승무패 표의 공식 행 번호, 팀, 시간, 투표율을 그대로 읽는다."""
    soup = BeautifulSoup(html, 'html.parser')
    parsed = []
    rows = soup.select("table#grid_victory tbody#grid_victory_tbody > tr")
    if not rows:
        # Betman has occasionally omitted the tbody id while keeping the table id.
        rows = soup.select("table#grid_victory tbody > tr")
    try:
        rows = list(rows)
    except TypeError:
        rows = []

    row_values = []
    for row in rows:
        cells = row.find_all("td", recursive=False)
        if len(cells) < 6:
            continue
        teams_box = cells[2].select_one(".vsDIv") or cells[2]
        team_parts = teams_box.find_all("div", recursive=False)
        if len(team_parts) >= 2:
            home = team_parts[0].get_text(" ", strip=True)
            away = re.sub(
                r'^\s*v\s*s\s*', '',
                team_parts[1].get_text(" ", strip=True),
                flags=re.IGNORECASE,
            ).strip()
            team_text = f"{home} vs {away}"
        else:
            team_text = teams_box.get_text(" ", strip=True)
        row_values.append([
            cell.get_text(" ", strip=True) if index != 2 else team_text
            for index, cell in enumerate(cells[:6])
        ])

    # Keep the parser testable and the collector recoverable when BeautifulSoup
    # is temporarily unavailable. This path only extracts the six official
    # table cells; it does not infer or fabricate any fixture data.
    if not row_values:
        def plain_text(fragment):
            fragment = re.sub(r'<(?:br|/p)\s*/?>', ' ', fragment, flags=re.IGNORECASE)
            fragment = re.sub(r'<[^>]+>', ' ', fragment)
            return re.sub(r'\s+', ' ', html_unescape(fragment)).strip()

        table_match = re.search(
            r'<table\b[^>]*id=["\']grid_victory["\'][^>]*>(.*?)</table>',
            str(html or ''), re.IGNORECASE | re.DOTALL,
        )
        table_html = table_match.group(1) if table_match else str(html or '')
        for row_html in re.findall(
            r'<tr\b[^>]*>(.*?)</tr>', table_html, re.IGNORECASE | re.DOTALL
        ):
            cells = re.findall(
                r'<td\b[^>]*>(.*?)</td>', row_html, re.IGNORECASE | re.DOTALL
            )
            if len(cells) >= 6:
                row_values.append([plain_text(cell) for cell in cells[:6]])

    for cells in row_values:
        num_match = re.search(r'(\d+)\s*경기', cells[0])
        if not num_match:
            continue
        num = int(num_match.group(1))

        raw_time = cells[1]
        time_match = re.search(r'(?:\d{2}\.)?(\d{2}\.\d{2}\s*\([^)]+\)\s*\d{2}:\d{2})', raw_time)
        match_time = re.sub(r'\s+', ' ', time_match.group(1)).strip() if time_match else "시간 미정"

        split_teams = re.split(
            r'\s+v\s*s\s+', cells[2], maxsplit=1, flags=re.IGNORECASE
        )
        if len(split_teams) != 2:
            continue
        home, away = (part.strip() for part in split_teams)
        if not home or not away:
            continue

        vote_values = []
        for cell in cells[3:6]:
            vote_match = re.search(r'(\d+(?:\.\d+)?)\s*%', cell)
            vote_values.append(float(vote_match.group(1)) if vote_match else None)

        parsed.append({
            "id": f"{round_id}_{num}",
            "round_id": str(round_id),
            "num": num,
            "league": "축구 승무패",
            "home": home,
            "away": away,
            "match_time": match_time,
            "vote_h": vote_values[0],
            "vote_d": vote_values[1],
            "vote_a": vote_values[2],
        })
    return sorted(parsed, key=lambda item: item["num"])


_BETMAN_WEEKDAYS = ("월", "화", "수", "목", "금", "토", "일")


def _is_betman_auxiliary_prediction_record(record):
    """Identify Betman auxiliary prediction rows that are not sale fixtures."""
    if not isinstance(record, dict):
        return False
    match = record.get("match") if isinstance(record.get("match"), dict) else {}
    values = [
        record.get(key) for key in (
            "league", "leagueShortName", "leagueName", "league_n", "league_name"
        )
    ] + [
        match.get(key) for key in (
            "league", "leagueShortName", "leagueName", "league_n", "league_name"
        )
    ]
    return any(
        "ag예측" in re.sub(r"[\s._-]+", "", str(value or "")).casefold()
        for value in values
    )


def _betman_epoch_text(value):
    """Format Betman's millisecond timestamp in the same KST form as the page."""
    try:
        timestamp = float(value) / 1000.0
        moment = datetime.fromtimestamp(timestamp, KST)
    except (TypeError, ValueError, OSError, OverflowError):
        return "시간 미정"
    return (
        moment.strftime("%y.%m.%d")
        + f" ({_BETMAN_WEEKDAYS[moment.weekday()]}) "
        + moment.strftime("%H:%M")
    )


def _betman_float(value):
    try:
        return float(value or 0)
    except (TypeError, ValueError):
        return 0.0


def _expand_betman_rows(value):
    """Expand Betman's compact {keys, datas} table into ordinary dictionaries."""
    if isinstance(value, list):
        return [row for row in value if isinstance(row, dict)]
    if not isinstance(value, dict):
        return []
    keys = value.get("keys")
    datas = value.get("datas")
    if not isinstance(keys, list) or not isinstance(datas, list):
        return []
    rows = []
    for values in datas:
        if isinstance(values, list):
            rows.append(dict(zip(keys, values)))
    return rows


def parse_betman_proto_json(payload):
    """Parse the same official JSON that Betman's Proto page renders."""
    if not isinstance(payload, dict):
        return []
    rows = [
        row
        for row in _expand_betman_rows(payload.get("compSchedules"))
        if str(row.get("itemCode", "")).upper() == "SC"
        and not _is_betman_auxiliary_prediction_record(row)
    ]
    groups = {}
    for row in rows:
        key = str(row.get("gameKey") or "").strip()
        if not key:
            key = "|".join(
                str(row.get(field) or "")
                for field in ("gameDate", "homeName", "awayName")
            )
        groups.setdefault(key, []).append(row)

    parsed = []
    for group in groups.values():
        main_market = next(
            (row for row in group if str(row.get("betTypId")) == "1"),
            None,
        )
        if main_market is None:
            continue
        home = str(main_market.get("homeName") or "").strip()
        away = str(main_market.get("awayName") or "").strip()
        if not home or not away:
            continue

        handicap_market = next(
            (row for row in group if str(row.get("betTypId")) == "4"),
            None,
        )
        under_over_market = next(
            (row for row in group if str(row.get("betTypId")) == "7"),
            None,
        )
        odds_1x2 = [
            _betman_float(main_market.get("winAllot")),
            _betman_float(main_market.get("drawAllot")),
            _betman_float(main_market.get("loseAllot")),
        ]
        if min(odds_1x2) <= 1.0:
            odds_1x2 = [0.0, 0.0, 0.0]

        match_time = _betman_epoch_text(main_market.get("gameDate"))
        deadline_text = _betman_epoch_text(main_market.get("endDate"))
        deadline_time = ""
        if deadline_text != "시간 미정":
            deadline_time = f"{deadline_text[-5:]} 마감"

        parsed.append({
            "id": str(main_market.get("matchSeq") or ""),
            "league": str(
                main_market.get("leagueShortName")
                or main_market.get("leagueName")
                or "축구"
            ).strip(),
            "time": match_time,
            "match_time": match_time,
            "deadline_time": deadline_time,
            "home": home,
            "away": away,
            "odd_h": odds_1x2[0],
            "odd_d": odds_1x2[1],
            "odd_a": odds_1x2[2],
            "handi_h": _betman_float((handicap_market or {}).get("winAllot")),
            "handi_d": _betman_float((handicap_market or {}).get("drawAllot")),
            "handi_a": _betman_float((handicap_market or {}).get("loseAllot")),
            # winHandi is the exact H value printed by Betman's own JavaScript.
            "handi_base": _betman_float((handicap_market or {}).get("winHandi")),
            "uo_under": _betman_float((under_over_market or {}).get("winAllot")),
            "uo_over": _betman_float((under_over_market or {}).get("loseAllot")),
            # For U/O, Betman also renders winHandi as the displayed goal line.
            "uo_base": _betman_float((under_over_market or {}).get("winHandi")),
        })
    return sorted(parsed, key=lambda item: int(item["id"]) if item["id"].isdigit() else 0)


def parse_betman_toto14_json(payload, round_id="current"):
    """Parse the official Toto14 schedule and convert vote counts to percentages."""
    if not isinstance(payload, dict):
        return []
    schedules = payload.get("schedulesList")
    if not isinstance(schedules, list):
        return []
    vote_status = payload.get("voteStatus") or {}
    vote_rows = vote_status.get("homeVoteStatusList") or []
    parsed = []
    for index, schedule_row in enumerate(schedules):
        if not isinstance(schedule_row, dict):
            continue
        try:
            number = int(schedule_row.get("matchSeq"))
        except (TypeError, ValueError):
            continue
        home = str(schedule_row.get("homeName") or "").strip()
        away = str(schedule_row.get("awayName") or "").strip()
        if not home or not away:
            continue

        counts = []
        vote_row = vote_rows[index] if index < len(vote_rows) else {}
        away_votes = vote_row.get("awayVoteStatusList") if isinstance(vote_row, dict) else []
        for vote in (away_votes or [])[:3]:
            counts.append(_betman_float(vote.get("voteCount") if isinstance(vote, dict) else 0))
        while len(counts) < 3:
            counts.append(0.0)
        total_votes = sum(counts)
        percentages = (
            [round(value * 100.0 / total_votes, 1) for value in counts]
            if total_votes > 0
            else [None, None, None]
        )

        raw_time = str(schedule_row.get("gameDateStr") or "").strip()
        match_time = re.sub(r"\s+", " ", raw_time) if raw_time else ""
        if not re.search(r"\d{2}\.\d{2}.*\d{2}:\d{2}", match_time):
            match_time = _betman_epoch_text(schedule_row.get("gameDate"))
        parsed.append({
            "id": f"{round_id}_{number}",
            "round_id": str(round_id),
            "num": number,
            "league": "축구 승무패",
            "home": home,
            "away": away,
            "match_time": match_time,
            "vote_h": percentages[0],
            "vote_d": percentages[1],
            "vote_a": percentages[2],
        })
    return sorted(parsed, key=lambda item: item["num"])


def _valid_toto14_round(records):
    if not isinstance(records, list) or len(records) != 14:
        return False
    round_ids = set()
    numbers = []
    record_ids = set()
    for record in records:
        if not isinstance(record, dict):
            return False
        if not record.get("id") or not record.get("home") or not record.get("away"):
            return False
        try:
            numbers.append(int(record.get("num")))
        except (TypeError, ValueError):
            return False
        round_ids.add(str(record.get("round_id", "")))
        record_ids.add(str(record["id"]))
    return (
        len(round_ids) == 1
        and len(record_ids) == 14
        and sorted(numbers) == list(range(1, 15))
    )


BETMAN_BASE_URL = os.getenv("BETMAN_BASE_URL", "https://www.betman.co.kr").rstrip("/")
BETMAN_HUB_URL = urljoin(
    BETMAN_BASE_URL + "/",
    "main/mainPage/gamebuy/buyableGameList.do",
)

BETMAN_REQUEST_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151 Safari/537.36"
    ),
    "Accept-Language": "ko-KR,ko;q=0.9,en;q=0.7",
    # Betman closes these responses itself. Explicitly closing avoids reusing a
    # half-closed keep-alive socket, which caused intermittent EC2 resets.
    "Connection": "close",
}


def _betman_request(session, method, url, attempts=3, **kwargs):
    """Make a small official Betman request with restrained reset/timeout retries."""
    last_error = None
    for attempt in range(max(1, attempts)):
        try:
            request_method = getattr(session, method.lower())
            response = request_method(url, **kwargs)
            response.raise_for_status()
            return response
        except requests.RequestException as error:
            last_error = error
            if attempt + 1 >= attempts:
                break
            time.sleep(2 ** attempt)
    raise last_error or RuntimeError(f"베트맨 {method.upper()} 요청 실패: {url}")


def _betman_sale_end_epoch(value):
    """Return a comparable epoch for Betman's mixed sale-end formats."""
    text = re.sub(r"\D", "", str(value or ""))
    if not text:
        return 0.0
    # Some Betman deployments return a calendar timestamp rather than epoch
    # milliseconds.  Parse that before applying the epoch conversion below.
    date_formats = {
        8: "%Y%m%d",
        10: "%Y%m%d%H",
        12: "%Y%m%d%H%M",
        14: "%Y%m%d%H%M%S",
    }
    date_format = date_formats.get(len(text))
    if date_format and text.startswith(("19", "20")):
        try:
            return datetime.strptime(text, date_format).replace(tzinfo=KST).timestamp()
        except ValueError:
            return 0.0
    try:
        number = float(text)
    except ValueError:
        return 0.0
    if number > 10_000_000_000:
        number /= 1000.0
    return number if number > 0 else 0.0


def _betman_round_number(target):
    try:
        return int(str((target or {}).get("gm_ts") or "0"))
    except (TypeError, ValueError):
        return 0


def _ordered_betman_round_targets(rows, gm_id, base_url=BETMAN_BASE_URL, now=None):
    """Order current sale rounds before distant or expired rounds.

    The old max(sale_end) policy could select a future round with no populated
    fixtures while the currently saleable round sat earlier in the list.
    """
    targets = [
        target
        for target in (_betman_round_target(row, base_url) for row in (rows or []))
        if target and target["gm_id"] == gm_id
    ]
    if not targets:
        return []
    now_epoch = (now or datetime.now(KST)).timestamp()
    selectable = [
        target for target in targets
        if target.get("sale_end_epoch", 0.0) >= now_epoch - BETMAN_SALE_END_GRACE_SECONDS
    ]
    if selectable:
        return sorted(
            selectable,
            key=lambda item: (item.get("sale_end_epoch", float("inf")), _betman_round_number(item)),
        )
    unknown = [target for target in targets if not target.get("sale_end_epoch")]
    expired = [target for target in targets if target.get("sale_end_epoch")]
    return sorted(unknown, key=_betman_round_number) + sorted(
        expired,
        key=lambda item: (item.get("sale_end_epoch", 0.0), _betman_round_number(item)),
        reverse=True,
    )


def _betman_round_target(row, base_url=BETMAN_BASE_URL):
    """Validate a Betman round-list row and build its direct game-slip URL."""
    if not isinstance(row, dict):
        return None
    gm_id = str(row.get("gmId", "")).strip()
    gm_ts = str(row.get("gmTs", "")).strip()
    if not re.fullmatch(r"G\d{3}", gm_id) or not gm_ts.isdigit():
        return None
    sale_end = row.get("saleEndDate")
    return {
        "gm_id": gm_id,
        "gm_ts": gm_ts,
        "display_round": str(row.get("gmOsidTs", "") or gm_ts),
        "sale_end": str(sale_end or ""),
        "sale_end_epoch": _betman_sale_end_epoch(sale_end),
        "url": urljoin(
            base_url.rstrip("/") + "/",
            f"main/mainPage/gamebuy/gameSlip.do?gmId={gm_id}&gmTs={gm_ts}",
        ),
    }


def _fetch_betman_round_targets(session=None):
    """Read current Proto/Toto round IDs without rendering Betman's heavy hub.

    Betman's hub fills its tables through this JSON endpoint. Reading that
    endpoint first is much lighter and avoids the EC2 Edge timeout that occurs
    while the hub is still loading third-party scripts and assets.
    """
    owned_session = session is None
    session = session or requests.Session()
    common_headers = BETMAN_REQUEST_HEADERS
    try:
        # The first GET establishes the anonymous session cookie expected by
        # the JSON endpoint. It does not wait for any browser-side assets.
        hub_response = _betman_request(
            session,
            "get",
            BETMAN_HUB_URL,
            headers=common_headers,
            timeout=(10, 30),
        )
        # requests follows official redirects. Build every later address from
        # the final host, rather than assuming Betman's domain never changes.
        resolved_base_url = urljoin(hub_response.url, "/").rstrip("/")
        round_list_url = urljoin(
            resolved_base_url + "/",
            "buyPsblGame/inqBuyAbleGameInfoList.do",
        )
        payload = {"_sbmInfo": {"_sbmInfo": {"debugMode": "false"}}}
        response = _betman_request(
            session,
            "post",
            round_list_url,
            json=payload,
            headers={
                **common_headers,
                "Referer": BETMAN_HUB_URL,
                "X-Requested-With": "XMLHttpRequest",
                "Accept": "application/json, text/javascript, */*; q=0.01",
            },
            timeout=(10, 30),
        )
        result = response.json()
        if not isinstance(result, dict):
            raise RuntimeError("베트맨 회차 조회 응답이 JSON 객체가 아님")
        status = result.get("rsMsg") or {}
        if status and status.get("statusCode") not in (None, "S"):
            raise RuntimeError(f"베트맨 회차 조회 상태 오류: {status.get('statusCode')}")

        proto_candidates = _ordered_betman_round_targets(
            result.get("protoGames"), "G101", resolved_base_url
        )
        toto_candidates = _ordered_betman_round_targets(
            result.get("totoGames"), "G011", resolved_base_url
        )

        return {
            "proto": proto_candidates[0] if proto_candidates else None,
            "toto14": toto_candidates[0] if toto_candidates else None,
            "proto_candidates": proto_candidates[:BETMAN_ROUND_CANDIDATE_LIMIT],
            "toto14_candidates": toto_candidates[:BETMAN_ROUND_CANDIDATE_LIMIT],
        }
    finally:
        if owned_session:
            session.close()


def _fetch_betman_game_data(session, target):
    """Read the official JSON used by a Proto or Toto14 game-slip page."""
    if not isinstance(target, dict) or not target.get("gm_id") or not target.get("gm_ts"):
        raise RuntimeError("베트맨 경기 회차 주소가 없음")
    target_url = str(target.get("url") or BETMAN_HUB_URL)
    base_url = urljoin(target_url, "/").rstrip("/")
    endpoint = urljoin(base_url + "/", "buyPsblGame/gameInfoInq.do")
    payload = {
        "gmId": str(target["gm_id"]),
        "gmTs": str(target["gm_ts"]),
        "gameYear": "",
        "_sbmInfo": {"_sbmInfo": {"debugMode": "false"}},
    }
    response = _betman_request(
        session,
        "post",
        endpoint,
        json=payload,
        headers={
            **BETMAN_REQUEST_HEADERS,
            "Referer": target_url,
            "Origin": base_url,
            "X-Requested-With": "XMLHttpRequest",
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "Content-Type": "application/json; charset=UTF-8",
        },
        timeout=(10, 30),
    )
    result = response.json()
    if not isinstance(result, dict):
        raise RuntimeError("베트맨 경기 응답이 JSON 객체가 아님")
    status = result.get("rsMsg") or {}
    if status and status.get("statusCode") not in (None, "S"):
        raise RuntimeError(f"베트맨 경기 조회 상태 오류: {status.get('statusCode')}")
    return result


def _select_latest_complete_toto14_round(records):
    groups = {}
    order = {}
    for index, record in enumerate(records or []):
        if not isinstance(record, dict):
            continue
        round_id = str(record.get("round_id", "") or "")
        if not round_id:
            match = re.match(r"(.+)_\d+$", str(record.get("id", "")))
            round_id = match.group(1) if match else ""
        if not round_id:
            continue
        record_id = str(record.get("id", "") or "")
        if not record_id:
            continue
        groups.setdefault(round_id, {})[record_id] = record
        order[round_id] = index
    valid = {
        round_id: sorted(group.values(), key=lambda item: int(item.get("num", 0)))
        for round_id, group in groups.items()
        if _valid_toto14_round(list(group.values()))
    }
    if not valid:
        return []

    def sort_key(round_id):
        digits = re.findall(r"\d+", round_id)
        numeric = int(digits[-1]) if digits else -1
        return numeric, order.get(round_id, -1)

    return list(valid[max(valid, key=sort_key)])


def _accept_alert(driver):
    try:
        driver.switch_to.alert.accept()
    except Exception:
        pass


def _browser_arguments():
    # Betman renders a large JavaScript game table.  Artificially capping the
    # renderer at 256 MB and two processes made Edge 151 disconnect its
    # renderer (InvalidSessionId / tab crashed) on the EC2 collector.
    return [
        '--headless=new', '--no-sandbox', '--disable-dev-shm-usage',
        '--disable-gpu', '--disable-extensions',
        '--disable-background-networking', '--disable-component-update',
        '--disable-default-apps', '--disable-sync', '--metrics-recording-only',
        '--no-first-run',
        '--window-size=1365,900', '--blink-settings=imagesEnabled=false',
        '--disable-features=Translate,BackForwardCache,OptimizationHints,MediaRouter',
    ]


def _chrome_options(binary=None):
    options = ChromeOptions()
    for argument in _browser_arguments():
        options.add_argument(argument)
    if binary:
        options.binary_location = binary
    options.page_load_strategy = 'eager'
    return options


def _edge_options(binary=None):
    options = EdgeOptions()
    for argument in _browser_arguments():
        options.add_argument(argument)
    if binary:
        options.binary_location = binary
    options.page_load_strategy = 'eager'
    return options


def _create_webdriver():
    """Prefer provisioned Chromium; keep Edge only as a compatibility fallback."""
    errors = []
    browser_binary = os.getenv("CHROME_BINARY", "").strip() or next(
        (path for path in (
            shutil.which("chromium"), shutil.which("chromium-browser"),
            shutil.which("google-chrome"), shutil.which("google-chrome-stable"),
            shutil.which("chrome"),
        ) if path),
        None,
    )
    driver_binary = os.getenv("CHROMEDRIVER_PATH", "").strip() or shutil.which("chromedriver")

    attempts = []
    if driver_binary:
        attempts.append((
            f"Chromium ({driver_binary})",
            lambda: webdriver.Chrome(
                service=ChromeService(executable_path=driver_binary),
                options=_chrome_options(browser_binary),
            ),
        ))
    attempts.append((
        "Chromium/Selenium Manager",
        lambda: webdriver.Chrome(options=_chrome_options(browser_binary)),
    ))
    if ChromeDriverManager is not None and os.getenv("DISABLE_DRIVER_DOWNLOAD", "0") != "1":
        attempts.append((
            "Chromium/webdriver-manager",
            lambda: webdriver.Chrome(
                service=ChromeService(ChromeDriverManager().install()),
                options=_chrome_options(browser_binary),
            ),
        ))

    edge_binary = os.getenv("EDGE_BINARY", "").strip() or shutil.which("microsoft-edge") or shutil.which("msedge")
    allow_edge = edge_binary or os.name == "nt" or os.getenv("ALLOW_EDGE_FALLBACK", "0") == "1"
    if allow_edge:
        attempts.append((
            "Microsoft Edge/Selenium Manager fallback",
            lambda: webdriver.Edge(options=_edge_options(edge_binary)),
        ))
    if EdgeChromiumDriverManager is not None and allow_edge:
        attempts.append((
            "Microsoft Edge/webdriver-manager fallback",
            lambda: webdriver.Edge(
                service=EdgeService(EdgeChromiumDriverManager().install()),
                options=_edge_options(edge_binary),
            ),
        ))

    for label, factory in attempts:
        try:
            driver = factory()
            driver.set_page_load_timeout(90)
            driver.set_script_timeout(45)
            print(f"✅ 브라우저 시작: {label}")
            return driver
        except Exception as error:
            errors.append(f"{label}: {type(error).__name__}: {error}")
    raise RuntimeError(" / ".join(errors) or "사용 가능한 Chromium/Edge 드라이버 없음")


def _wait_for_stable_rows(driver, selector, timeout=18, stable_samples=3):
    deadline = time.monotonic() + timeout
    previous_count = -1
    stable_count = 0
    latest_count = 0
    while time.monotonic() < deadline:
        latest_count = len(driver.find_elements(By.CSS_SELECTOR, selector))
        if latest_count > 0 and latest_count == previous_count:
            stable_count += 1
            if stable_count >= stable_samples:
                return True, latest_count
        else:
            stable_count = 0
            previous_count = latest_count
        time.sleep(1)
    return False, latest_count


def _betman_link_target(element, base_url):
    """Return the real game-slip URL hidden in either href or JavaScript."""
    candidates = [
        (element.get_attribute("href") or "").strip(),
        (element.get_attribute("onclick") or "").strip(),
    ]
    for candidate in candidates:
        if not candidate:
            continue
        if not candidate.lower().startswith(("javascript:", "#")):
            return urljoin(base_url, candidate)
        # The hub currently exposes links like:
        # javascript:leftA.checkLeftSlipData(5,'/main/.../gameSlip.do?...')
        embedded = re.search(
            r"['\"]((?:https?://[^'\"]+|/[^'\"]*gameSlip\.do\?[^'\"]+))['\"]",
            candidate,
            re.IGNORECASE,
        )
        if embedded:
            return urljoin(base_url, embedded.group(1).replace("&amp;", "&"))
    return None


def _open_link_target(driver, element, base_url):
    """새 창 여부와 관계없이 베트맨 경기표 링크의 실제 주소로 이동한다."""
    target_url = _betman_link_target(element, base_url)
    if target_url:
        driver.get(target_url)
        return target_url

    previous_handles = set(driver.window_handles)
    driver.execute_script("arguments[0].click();", element)
    try:
        WebDriverWait(driver, 8).until(
            lambda current: len(set(current.window_handles) - previous_handles) > 0
        )
        new_handles = list(set(driver.window_handles) - previous_handles)
        if new_handles:
            driver.switch_to.window(new_handles[-1])
    except Exception:
        # 같은 창에서 자바스크립트로 이동하는 링크도 있으므로 그대로 계속한다.
        pass
    return driver.current_url or ""


def _scrape_with_fresh_browser(label, operation):
    last_error = None
    for attempt in range(2):
        driver = None
        try:
            driver = _create_webdriver()
            return operation(driver)
        except Exception as error:
            last_error = error
            print(f"❌ {label} 수집 실패({attempt + 1}/2): {type(error).__name__}: {error}")
        finally:
            if driver is not None:
                try:
                    driver.quit()
                    print("🧹 브라우저 프로세스 정상 종료 완료.")
                except Exception:
                    pass
        # Cleanup must finish before the next WebDriver starts.  Starting the
        # retry while Edge renderer children are still exiting can make the
        # next session inherit the same renderer-disconnect failure.
        if attempt == 0:
            time.sleep(5)
    raise RuntimeError(str(last_error or f"{label} 수집 실패"))


def _load_pending_match_ids():
    try:
        conn = sqlite3.connect(str(_local_path("ai_predictions.db")), timeout=15)
        try:
            return {
                str(row[0])
                for row in conn.execute(
                    "SELECT match_id FROM predictions WHERE actual_result = 'PENDING'"
                ).fetchall()
            }
        finally:
            conn.close()
    except Exception:
        return set()


def _record_is_still_active(record, pending_ids, prefix=""):
    match_id = f"{prefix}{record.get('id', '')}"
    match_dt = _parse_kst_match_time(record.get("match_time") or record.get("time"))
    if match_dt is not None:
        return datetime.now(KST) <= match_dt + timedelta(hours=2 + LIVE_RETENTION_HOURS)
    # Unknown kickoff records get the DB state as a conservative fallback, but
    # dated stale rounds cannot grow the retained pool forever merely because a
    # fixture has not been graded yet.
    return match_id in pending_ids


def _merge_active_records(fresh, previous, pending_ids, prefix=""):
    merged = []
    seen = set()
    for record in fresh:
        if not prefix and _is_betman_auxiliary_prediction_record(record):
            continue
        match_id = str(record.get("id", ""))
        if not match_id or match_id in seen:
            continue
        seen.add(match_id)
        merged.append(record)
    for record in previous:
        if not prefix and _is_betman_auxiliary_prediction_record(record):
            continue
        match_id = str(record.get("id", ""))
        if not match_id or match_id in seen:
            continue
        if _record_is_still_active(record, pending_ids, prefix=prefix):
            retained = dict(record)
            retained["retained_from_last_good"] = True
            merged.append(retained)
            seen.add(match_id)
    return merged


def _valid_scrape_records(records):
    if not isinstance(records, list):
        return False
    ids = []
    for record in records:
        if not isinstance(record, dict):
            return False
        if not record.get("id") or not record.get("home") or not record.get("away"):
            return False
        ids.append(str(record["id"]))
    return len(ids) == len(set(ids))


def _has_upcoming_betman_record(records, now=None):
    """Reject a valid-looking but already-expired sale board."""
    now = now or datetime.now(KST)
    for record in records or []:
        if not isinstance(record, dict):
            continue
        kickoff = _parse_kst_match_time(record.get("match_time") or record.get("time"))
        if kickoff is not None and kickoff >= now - timedelta(minutes=5):
            return True
    return False


def _proto_collection_accepted(
    records, stable, old_active_count, previous_round_id, current_round_id,
    allow_limited=False,
):
    """Allow a smaller board only when it is an actually new sale round."""
    if not records or not stable or not _valid_scrape_records(records):
        return False
    if allow_limited or len(records) >= PROTO_MIN_SCRAPE_ROWS:
        return True
    if old_active_count < PROTO_MIN_SCRAPE_ROWS:
        return True
    previous_round_id = str(previous_round_id or "")
    current_round_id = str(current_round_id or "")
    return bool(current_round_id and current_round_id != previous_round_id)


def _persist_betman_collection_failure(old_data, proto_error, toto_error):
    """Keep last known records intact but leave a visible, timestamped cause."""
    payload = dict(old_data) if isinstance(old_data, dict) else {}
    source_status = payload.get("source_status")
    source_status = dict(source_status) if isinstance(source_status, dict) else {}
    attempted_at = datetime.now(KST).isoformat(timespec="seconds")
    for source_name, error_text, count_key in (
        ("proto", proto_error, "proto_matches"),
        ("toto14", toto_error, "toto_14_matches"),
    ):
        status = source_status.get(source_name)
        status = dict(status) if isinstance(status, dict) else {}
        status.update({
            "fresh": False,
            "last_attempt_at": attempted_at,
            "last_failure_at": attempted_at,
            "last_error": str(error_text or "새 회차를 확인하지 못함")[:1000],
            "published_count": len(payload.get(count_key) or []),
        })
        source_status[source_name] = status
    payload["source_status"] = source_status
    payload["collection_diagnostic"] = {
        "attempted_at": attempted_at,
        "status": "NO_FRESH_ROUND_PUBLISHED",
        "proto_error": str(proto_error or "")[:1000],
        "toto14_error": str(toto_error or "")[:1000],
        "retained_records_unchanged": True,
    }
    _atomic_write_json("betman_data.json", payload, indent=2)


def scrape_betman():
    print(f"\n[🔄 {time.strftime('%Y-%m-%d %H:%M:%S')}] 베트맨 실제 경기/배당 수집 가동...")
    hub_url = BETMAN_HUB_URL
    old_data = _read_json("betman_data.json", {})
    if not isinstance(old_data, dict):
        old_data = {}
    old_proto = old_data.get("proto_matches", []) if isinstance(old_data.get("proto_matches"), list) else []
    old_toto14_primary = old_data.get("toto_14_matches", []) if isinstance(old_data.get("toto_14_matches"), list) else []
    old_toto14_retained = old_data.get("toto_14_retained_matches", []) if isinstance(old_data.get("toto_14_retained_matches"), list) else []
    old_toto14_by_id = {}
    for record in old_toto14_primary + old_toto14_retained:
        if isinstance(record, dict) and record.get("id"):
            old_toto14_by_id[str(record["id"])] = record
    old_toto14 = list(old_toto14_by_id.values())

    proto_stable = False
    toto_stable = False
    matches = []
    matches_14 = []
    proto_error = "프로토 현재 회차를 확인하지 못함"
    toto_error = "승무패 현재 회차를 확인하지 못함"

    round_targets = {}
    betman_session = requests.Session()
    try:
        round_targets = _fetch_betman_round_targets(betman_session)
        proto_round = (round_targets.get("proto") or {}).get("display_round", "-")
        toto_round = (round_targets.get("toto14") or {}).get("display_round", "-")
        print(f"✅ 베트맨 현재 회차 직접 확인: 프로토 {proto_round} / 승무패 {toto_round}")
    except Exception as error:
        # Keep the old hub navigation as a safety fallback if Betman changes
        # the lightweight endpoint in the future.
        print(f"⚠️ 베트맨 회차 직접 조회 실패, 기존 화면 탐색으로 전환: {error}")

    # A reset while reading the round list must not prevent a direct data retry
    # for the last confirmed round. Toto14 records already carry their official
    # gmTs; V7 also stores both source round IDs after every successful cycle.
    saved_source_status = old_data.get("source_status", {})
    if not isinstance(saved_source_status, dict):
        saved_source_status = {}
    if not round_targets.get("proto"):
        saved_proto_status = saved_source_status.get("proto", {})
        saved_proto_round = (
            str(saved_proto_status.get("round_id") or "")
            if isinstance(saved_proto_status, dict)
            else ""
        )
        if saved_proto_round.isdigit():
            round_targets["proto"] = _betman_round_target({
                "gmId": "G101",
                "gmTs": saved_proto_round,
                "gmOsidTs": saved_proto_round,
            })
            print(f"↪️ 저장된 프로토 {saved_proto_round}회차로 공식 JSON 재시도")
    if not round_targets.get("toto14"):
        saved_toto_status = saved_source_status.get("toto14", {})
        saved_toto_round = (
            str(saved_toto_status.get("round_id") or "")
            if isinstance(saved_toto_status, dict)
            else ""
        )
        if not saved_toto_round:
            complete_old_toto = _select_latest_complete_toto14_round(old_toto14)
            old_round_ids = {
                str(record.get("round_id") or "")
                for record in complete_old_toto
                if isinstance(record, dict)
            }
            if len(old_round_ids) == 1:
                saved_toto_round = next(iter(old_round_ids))
        if saved_toto_round.isdigit():
            round_targets["toto14"] = _betman_round_target({
                "gmId": "G011",
                "gmTs": saved_toto_round,
                "gmOsidTs": saved_toto_round,
            })
            print(f"↪️ 저장된 승무패 {saved_toto_round}회차로 공식 JSON 재시도")

    # Betman's browser page renders these two payloads through AJAX. Reading
    # them directly avoids Edge renderer crashes and does not depend on DOM or
    # on the game-slip URL shape. Each source is accepted independently.
    if round_targets.get("proto"):
        try:
            candidate_targets = list(round_targets.get("proto_candidates") or [])
            if not candidate_targets:
                candidate_targets = [round_targets["proto"]]
            attempts = []
            for target in candidate_targets[:BETMAN_ROUND_CANDIDATE_LIMIT]:
                try:
                    proto_payload = _fetch_betman_game_data(betman_session, target)
                    candidate_matches = parse_betman_proto_json(proto_payload)
                    if not _valid_scrape_records(candidate_matches):
                        raise RuntimeError(
                            f"정상 축구 경기 없음: {len(candidate_matches)}건"
                        )
                    if not _has_upcoming_betman_record(candidate_matches):
                        raise RuntimeError("축구 경기가 모두 시작 또는 마감됨")
                    matches = candidate_matches
                    proto_stable = True
                    round_targets["proto"] = target
                    print(
                        "✅ 공식 JSON 프로토 축구 경기 추출: "
                        f"{len(matches)}경기 / {target.get('display_round', '-')}회차 "
                        "(브라우저 미사용)"
                    )
                    break
                except Exception as candidate_error:
                    attempts.append(
                        f"{target.get('display_round', '-')}: {candidate_error}"
                    )
            if not proto_stable:
                raise RuntimeError(" / ".join(attempts) or "공식 프로토 JSON 수집 실패")
        except Exception as error:
            matches = []
            proto_stable = False
            proto_error = str(error)
            print(f"⚠️ 공식 JSON 프로토 조회 실패, 브라우저 1회 대체: {error}")

    if round_targets.get("toto14"):
        try:
            toto_target = round_targets["toto14"]
            toto_payload = _fetch_betman_game_data(betman_session, toto_target)
            round_id = str(toto_target.get("gm_ts") or toto_target.get("display_round"))
            matches_14 = parse_betman_toto14_json(toto_payload, round_id)
            toto_stable = _valid_toto14_round(matches_14)
            if not toto_stable:
                raise RuntimeError(f"공식 승무패 JSON이 14경기 완본 아님: {len(matches_14)}건")
            print(
                "✅ 공식 JSON 승무패 "
                f"{toto_target.get('display_round', round_id)}회차 추출: 14경기 (브라우저 미사용)"
            )
        except Exception as error:
            matches_14 = []
            toto_stable = False
            toto_error = str(error)
            print(f"⚠️ 공식 JSON 승무패 조회 실패, 브라우저 1회 대체: {error}")
    betman_session.close()

    def scrape_proto_page(driver):
        proto_target = round_targets.get("proto") or {}
        proto_target_url = proto_target.get("url")
        if proto_target_url:
            print(f"➡️ 프로토 {proto_target.get('display_round', '-')}회차 직접 접속")
            driver.get(proto_target_url)
            _accept_alert(driver)
        else:
            driver.get(hub_url)
            _accept_alert(driver)
            # We navigate with the href itself, so visibility/clickability is
            # not required and can be blocked by Betman's loading overlay.
            proto_btn = WebDriverWait(driver, 35).until(EC.presence_of_element_located((
                By.XPATH,
                "//a[contains(normalize-space(.), '프로토 승부식') and contains(normalize-space(.), '회차')]",
            )))
            proto_target_url = _open_link_target(driver, proto_btn, hub_url)
        proto_row_selector = ".box-data-group [data-rowname]"
        try:
            WebDriverWait(driver, 45).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, proto_row_selector))
            )
        except Exception as error:
            row_count = len(driver.find_elements(By.CSS_SELECTOR, proto_row_selector))
            raise RuntimeError(
                "프로토 경기행 대기 실패 "
                f"(행={row_count}, 현재주소={driver.current_url or '-'}, "
                f"직접주소={proto_target_url or '-'}, 제목={driver.title or '-'})"
            ) from error
        for _ in range(20):
            visible_more = [button for button in driver.find_elements(
                By.XPATH,
                "//*[self::button or self::a][contains(normalize-space(.), '더보기')]",
            ) if button.is_displayed()]
            if not visible_more:
                break
            driver.execute_script("arguments[0].click();", visible_more[0])
            time.sleep(0.8)
        stable, _ = _wait_for_stable_rows(driver, proto_row_selector)
        if not stable:
            raise RuntimeError("프로토 행 개수가 제한시간 안에 안정되지 않음")
        return parse_betman_proto_html(driver.page_source), stable

    def scrape_toto_page(driver):
        toto_target = round_targets.get("toto14") or {}
        target_url = toto_target.get("url")
        round_hints = [
            toto_target.get("gm_ts", ""),
            toto_target.get("display_round", ""),
            target_url or "",
        ]
        if target_url:
            print(f"➡️ 승무패 {toto_target.get('display_round', '-')}회차 직접 접속")
            driver.get(target_url)
            _accept_alert(driver)
        else:
            driver.get(hub_url)
            _accept_alert(driver)
            toto_btn = WebDriverWait(driver, 45).until(EC.presence_of_element_located((
                By.XPATH,
                "//a[contains(normalize-space(.), '축구 승무패') and contains(normalize-space(.), '회차')]",
            )))
            round_hints.extend([
                toto_btn.get_attribute("href") or "",
                toto_btn.get_attribute("onclick") or "",
                toto_btn.text or "",
            ])
            target_url = _open_link_target(driver, toto_btn, hub_url)
        row_selector = "table#grid_victory tbody tr, #grid_victory_tbody > tr"
        try:
            WebDriverWait(driver, 60).until(
                lambda current: len(current.find_elements(By.CSS_SELECTOR, row_selector)) >= 14
            )
        except Exception as error:
            row_count = len(driver.find_elements(By.CSS_SELECTOR, row_selector))
            raise RuntimeError(
                "승무패 표 14행 대기 실패 "
                f"(행={row_count}, 현재주소={driver.current_url or '-'}, "
                f"직접주소={target_url or '-'}, 제목={driver.title or '-'})"
            ) from error
        stable, _ = _wait_for_stable_rows(
            driver,
            row_selector,
            timeout=30,
            stable_samples=2,
        )
        round_hints.append(driver.current_url or "")
        round_id = None
        for hint in round_hints:
            round_match = re.search(r'gmTs\s*[=:]\s*["\']?(\d+)', str(hint), re.IGNORECASE)
            if not round_match:
                round_match = re.search(r'(\d+)\s*회차', str(hint))
            if round_match:
                round_id = round_match.group(1)
                break
        if not round_id:
            raise RuntimeError("승무패 회차 ID를 확인할 수 없어 기존 동결본을 보호합니다.")
        parsed = parse_betman_toto14_html(driver.page_source, round_id)
        if not stable or not _valid_toto14_round(parsed):
            raise RuntimeError(f"승무패 완본 미확인: 안정={stable}, 행={len(parsed)}")
        return parsed, stable, round_id

    try:
        if not proto_stable:
            matches, proto_stable = _scrape_with_fresh_browser("프로토 승부식", scrape_proto_page)
        proto_limit = 0
        if os.getenv("ALLOW_PROTO_LIMIT", "0") == "1":
            try:
                proto_limit = max(0, int(os.getenv("MAX_PROTO_MATCHES", "0")))
            except ValueError:
                proto_limit = 0
        if proto_limit:
            matches = matches[:proto_limit]
        print(f"✅ 프로토 실제 축구 경기 발견: {len(matches)}경기")
    except Exception as error:
        proto_error = str(error)
        print(f"❌ 프로토 최종 수집 실패: {error}")

    try:
        if not toto_stable:
            matches_14, toto_stable, round_id = _scrape_with_fresh_browser("축구 승무패", scrape_toto_page)
        else:
            round_id = str((round_targets.get("toto14") or {}).get("gm_ts") or "current")
        print(f"✅ 축구 승무패 {round_id}회차 추출: {len(matches_14)}경기")
    except Exception as error:
        toto_error = str(error)
        print(f"❌ 축구 승무패 최종 수집 실패: {error}")

    pending_ids = _load_pending_match_ids()
    old_active_proto = [
        item for item in old_proto if _record_is_still_active(item, pending_ids)
    ]
    old_source_status = old_data.get("source_status", {})
    old_proto_status = (
        old_source_status.get("proto", {}) if isinstance(old_source_status, dict) else {}
    )
    old_proto_status = old_proto_status if isinstance(old_proto_status, dict) else {}
    current_proto_round = str((round_targets.get("proto") or {}).get("gm_ts") or "")
    proto_accepted = _proto_collection_accepted(
        matches,
        proto_stable,
        len(old_active_proto),
        old_proto_status.get("round_id"),
        current_proto_round,
        allow_limited=os.getenv("ALLOW_PROTO_LIMIT", "0") == "1",
    )
    if matches and proto_stable and not proto_accepted:
        print(
            f"⚠️ 동일 회차 프로토 급감({len(matches)}건)을 부분 수집으로 판정해 정상본을 유지합니다."
        )

    # A football pools round is complete only with fourteen unique rows.
    toto_accepted = bool(
        matches_14 and toto_stable and _valid_toto14_round(matches_14)
    )
    if matches_14 and not toto_accepted:
        print(f"⚠️ 승무패가 14경기 완본이 아니어서({len(matches_14)}건) 정상본을 유지합니다.")

    fresh_proto = matches if proto_accepted else []
    fresh_toto14 = matches_14 if toto_accepted else []
    final_proto = _merge_active_records(fresh_proto, old_proto, pending_ids)
    # A complete new pools round supersedes older rounds. Mixing retained rows
    # from another round produced 28+ cards and exponential phantom cost.
    final_toto14 = (
        sorted(fresh_toto14, key=lambda item: int(item.get("num", 0)))
        if toto_accepted
        else _select_latest_complete_toto14_round(old_toto14)
    )
    final_toto14_ids = {str(item.get("id")) for item in final_toto14}
    retained_toto14 = [
        dict(item, retained_from_last_good=True)
        for item in old_toto14
        if str(item.get("id")) not in final_toto14_ids
        and _record_is_still_active(item, pending_ids, prefix="TOTO14_")
    ]

    if not proto_accepted:
        print("⚠️ 이번 프로토 수집을 채택하지 않고 마지막 정상/진행 기록을 보존합니다.")
    if not toto_accepted:
        print("⚠️ 이번 승무패 수집을 채택하지 않고 마지막 정상/진행 기록을 보존합니다.")
    if not proto_accepted and not toto_accepted:
        _persist_betman_collection_failure(old_data, proto_error, toto_error)
        print("❌ 새 완전 데이터가 없어 대시보드 재분석을 중단합니다.")
        return False

    now_iso = datetime.now(KST).isoformat(timespec="seconds")
    old_source_status = old_data.get("source_status", {})
    if not isinstance(old_source_status, dict):
        old_source_status = {}
    old_proto_status = old_source_status.get("proto", {})
    old_toto_status = old_source_status.get("toto14", {})
    if not isinstance(old_proto_status, dict):
        old_proto_status = {}
    if not isinstance(old_toto_status, dict):
        old_toto_status = {}
    result = {
        "proto_matches": final_proto,
        "toto_14_matches": final_toto14,
        "toto_14_retained_matches": retained_toto14,
        "collected_at": now_iso,
        "source_status": {
            "proto": {
                "fresh": proto_accepted,
                "fresh_count": len(matches),
                "published_count": len(final_proto),
                "round_id": (
                    (round_targets.get("proto") or {}).get("gm_ts")
                    if proto_accepted
                    else old_proto_status.get("round_id")
                ),
                "last_success_at": now_iso if proto_accepted else old_proto_status.get("last_success_at"),
                "last_attempt_at": now_iso,
                "last_error": "" if proto_accepted else proto_error[:1000],
            },
            "toto14": {
                "fresh": toto_accepted,
                "fresh_count": len(matches_14),
                "published_count": len(final_toto14),
                "retained_lifecycle_count": len(retained_toto14),
                "round_id": (
                    (round_targets.get("toto14") or {}).get("gm_ts")
                    if toto_accepted
                    else old_toto_status.get("round_id")
                ),
                "last_success_at": now_iso if toto_accepted else old_toto_status.get("last_success_at"),
                "last_attempt_at": now_iso,
                "last_error": "" if toto_accepted else toto_error[:1000],
            },
        },
    }
    _atomic_write_json("betman_data.json", result, indent=2)
    print(f"✅ 수집 완료: 프로토 {len(final_proto)}경기 / 승무패 {len(final_toto14)}경기")
    return True

def run_live_score_job():
    success = update_live_scores()
    if not success:
        return False
    published = upload_to_github("live_scores.json")
    if published:
        _update_collector_status("live", "running", last_stage="complete")
    return published


def run_master_job():
    scraped = bool(scrape_betman())
    built = False
    if scraped:
        try:
            with api_cache_only_context(MASTER_CACHE_ONLY_SERVING):
                built = bool(build_dashboard_data())
        except Exception as error:
            # A valid prediction may already have been committed before a
            # later dashboard-only step failed.  Continue to the local
            # recovery below so that saved pre-kickoff answers are never
            # stranded behind a transient presentation failure.
            print(
                "⚠️ 전체 분석 후반 오류 - 저장된 시작 전 픽 공통 복구를 계속합니다: "
                f"{type(error).__name__}: {error}"
            )
    else:
        print("⚠️ 베트맨 새 수집 실패 - 마지막 정상본의 저장픽 복구만 확인합니다.")

    recovered = _restore_scheduled_proto_cards_from_saved_predictions()
    if not built and not recovered:
        return False
    # Customer JSON is the live product output.  A private DB backup warning
    # must not suppress a freshly completed analysis from the website.
    if not upload_to_github("dashboard_data.json"):
        _update_collector_status(
            "master", "running", last_stage="dashboard_publish_failed"
        )
        return False
    # The dedicated team worker owns identity/logo/form retries. Keeping this
    # work out of master returns the production DB slot immediately after the
    # customer board is published. It can be re-enabled explicitly for repair.
    if MASTER_INLINE_TEAM_RETRY:
        try:
            seeded_cards = _queue_incomplete_dashboard_team_profiles()
            retry_summary = process_team_identity_retry_queue(
                limit=TEAM_IDENTITY_RETRY_BATCH
            )
            repaired_cards = _refresh_dashboard_team_profiles()
            if repaired_cards and not upload_to_github("dashboard_data.json"):
                print("⚠️ 팀 자료 화면 갱신 업로드 실패(다음 전담 주기에서 계속)")
            if retry_summary.get("processed") or retry_summary.get("pending"):
                print(
                    "🔎 팀 자료 재탐색: "
                    f"이번 {retry_summary.get('processed', 0)}건 / "
                    f"완료 {retry_summary.get('resolved', 0)}건 / "
                    f"계속 대기 {retry_summary.get('pending', 0)}건 / "
                    f"화면 재등록 {seeded_cards}건 / 화면 갱신 {repaired_cards}장"
                )
        except Exception as error:
            print(f"⚠️ 팀 자료 재탐색 작업 오류(다음 주기 계속): {error}")
    else:
        print("⚡ 팀 재탐색은 전담 team worker로 분리 · master 즉시 반환")
    backup_requested = _request_db_backup("master")
    _update_collector_status(
        "master",
        "running",
        db_backup_requested=backup_requested,
        last_stage="complete",
    )
    return True


def _prefetch_core_marker_key(source, match):
    """Return a stable, non-public queue marker for one upcoming fixture.

    This marker never represents a pick or an analysis result.  It records
    only that the shared slow-changing team dossier was successfully warmed,
    so the next pass can spend its bounded work on the remaining fixtures.
    """
    match = match if isinstance(match, dict) else {}
    try:
        fixture_id = int(match.get("fixture_id") or match.get("api_fixture_id") or 0)
    except (TypeError, ValueError):
        fixture_id = 0
    if fixture_id > 0:
        return f"prefetch_core_ready_v1_{str(source or 'unknown').lower()}_{fixture_id}"
    identity = "|".join([
        str(source or "unknown").strip().casefold(),
        str(match.get("home") or "").strip().casefold(),
        str(match.get("away") or "").strip().casefold(),
        str(match.get("match_time") or match.get("kickoff_at") or "").strip(),
    ])
    digest = hashlib.sha256(identity.encode("utf-8")).hexdigest()[:24]
    return f"prefetch_core_ready_v1_identity_{digest}"


def _shared_dossier_key(match):
    """Return one source-independent key for the same scheduled fixture.

    PROTO and TOTO14 may publish different ticket rows for one real match.  A
    source name must therefore never be part of this key: otherwise both
    screens can accidentally warm the same overseas material independently.
    """
    match = match if isinstance(match, dict) else {}
    kickoff = _parse_kst_match_time(
        match.get("match_time") or match.get("time") or match.get("kickoff_at")
    )
    kickoff_key = kickoff.strftime("%Y-%m-%dT%H:%M") if kickoff else str(
        match.get("match_time") or match.get("time") or match.get("kickoff_at") or ""
    ).strip()
    identity = "|".join([
        str(match.get("home") or "").strip().casefold(),
        str(match.get("away") or "").strip().casefold(),
        kickoff_key,
    ])
    digest = hashlib.sha256(identity.encode("utf-8")).hexdigest()[:24]
    return f"shared_fixture_dossier_v1_{digest}"


def _load_shared_fixture_dossier(match):
    dossier = get_db_cache(_shared_dossier_key(match), SHARED_DOSSIER_TTL_HOURS)
    return dossier if isinstance(dossier, dict) else {}


def _store_shared_fixture_dossier(match, *, sources, home_info, away_info,
                                  fixture_id, league_id, season, kickoff,
                                  deep_refresh_due, evidence):
    """Persist the exact prefetch material without initiating an API request."""
    prior = _load_shared_fixture_dossier(match)
    prior_sources = prior.get("sources") if isinstance(prior, dict) else []
    merged_sources = sorted({
        str(source).upper() for source in list(prior_sources or []) + list(sources or [])
        if str(source).strip()
    })
    payload = {
        "schema_version": "shared-fixture-dossier.v1",
        "key": _shared_dossier_key(match),
        "sources": merged_sources,
        "home": dict(home_info or {}),
        "away": dict(away_info or {}),
        "fixture_id": int(fixture_id or 0),
        "league_id": int(league_id or 0),
        "season": int(season or 0),
        "kickoff_at": kickoff.isoformat() if isinstance(kickoff, datetime) else "",
        "core_ready": True,
        "deep_refresh_ready": bool(deep_refresh_due),
        "evidence": evidence if isinstance(evidence, dict) else {},
        "warmed_at": datetime.now(KST).isoformat(),
    }
    return set_db_cache(_shared_dossier_key(match), payload)


def _prefetch_core_is_ready(source, match):
    marker = get_db_cache(
        _prefetch_core_marker_key(source, match),
        DATA_PREFETCH_COMPLETION_TTL_HOURS,
    )
    return isinstance(marker, dict) and bool(marker.get("core_ready"))


def _mark_prefetch_core_ready(source, match, *, home_id, away_id, kickoff):
    return set_db_cache(
        _prefetch_core_marker_key(source, match),
        {
            "core_ready": True,
            "source": str(source or ""),
            "home_team_id": int(home_id or 0),
            "away_team_id": int(away_id or 0),
            "kickoff_at": kickoff.isoformat() if isinstance(kickoff, datetime) else "",
            "warmed_at": datetime.now(KST).isoformat(),
        },
    )


def _prefetch_upcoming_analysis_inputs(limit=DATA_PREFETCH_MATCH_LIMIT):
    """Warm reusable overseas data before any pick engine needs it.

    This job deliberately does not create a prediction.  From T-72 it resolves
    the shared, slow-changing team dossier (identity/logo, form source and H2H).
    From T-30 it additionally refreshes volatile/detailed evidence (market,
    standings, squad, injuries and lineup).  Official, robot, V2 and V3 then
    read the same evidence without four independent overseas-data jobs.
    """
    now = datetime.now(KST)
    horizon = now + timedelta(hours=DATA_PREFETCH_EARLY_HORIZON_HOURS)
    candidates = []

    betman = _read_json("betman_data.json", {}) or {}
    for match in betman.get("proto_matches", []) or []:
        if not isinstance(match, dict) or _is_placeholder_match(match):
            continue
        kickoff = _parse_kst_match_time(match.get("match_time") or match.get("time"))
        if not kickoff or not (now < kickoff <= horizon):
            continue
        candidates.append((kickoff, "analysis", {"match": match, "source": "PROTO"}))

    for match in betman.get("toto_14_matches", []) or []:
        if not isinstance(match, dict) or _is_placeholder_match(match):
            continue
        kickoff = _parse_kst_match_time(match.get("match_time") or match.get("time"))
        if not kickoff or not (now < kickoff <= horizon):
            continue
        candidates.append((kickoff, "analysis", {"match": match, "source": "TOTO14"}))

    # WORLD is commercially paused.  Do not even place stale WORLD rows in
    # this queue: its old dashboard must never spend an API slot intended for
    # PROTO LIVE or TOTO14.

    sources_by_dossier = {}
    for _kickoff, _purpose, entry in candidates:
        dossier_key = _shared_dossier_key(entry.get("match") or {})
        sources_by_dossier.setdefault(dossier_key, set()).add(
            str(entry.get("source") or "").upper()
        )
    for _kickoff, _purpose, entry in candidates:
        entry["shared_sources"] = sorted(
            sources_by_dossier.get(_shared_dossier_key(entry.get("match") or {}), set())
        )

    def prefetch_priority(row):
        kickoff, _, entry = row
        match = entry.get("match") or {}
        hours_to_kickoff = max(0.0, (kickoff - now).total_seconds() / 3600.0)
        core_ready = _prefetch_core_is_ready(entry.get("source"), match)
        # The closest fixtures must keep receiving volatile lineup/market
        # refreshes.  After that, choose never-warmed fixtures before revisiting
        # an already prepared dossier, which gives every scheduled fixture a
        # turn instead of repeatedly stopping at the first 50 by kickoff time.
        if hours_to_kickoff <= DATA_PREFETCH_CRITICAL_HOURS:
            tier = 0
        elif not core_ready:
            tier = 1
        elif hours_to_kickoff <= DATA_PREFETCH_HORIZON_HOURS:
            tier = 2
        else:
            tier = 3
        return tier, kickoff

    candidates.sort(key=prefetch_priority)
    seen = set()
    processed = teams_warmed = identities_missing = quota_paused = 0
    core_newly_warmed = core_already_ready = 0
    early_core_matches = deep_matches = 0
    errors = []

    for kickoff, purpose, entry in candidates:
        if processed >= max(1, int(limit or 1)):
            break
        usage = get_api_usage_status()
        provider_remaining = usage.get("provider_remaining")
        if usage.get("quota_exhausted") or (
            provider_remaining is not None and int(provider_remaining) <= max(API_LIVE_RESERVE, API_WORLD_MIN_REMAINING)
        ):
            quota_paused = 1
            break

        match = entry.get("match") or {}
        core_ready_before = _prefetch_core_is_ready(entry.get("source"), match)
        home_name = str(match.get("home") or "").strip()
        away_name = str(match.get("away") or "").strip()
        hours_to_kickoff = (kickoff - now).total_seconds() / 3600.0
        deep_refresh_due = hours_to_kickoff <= DATA_PREFETCH_HORIZON_HOURS
        # The same official fixture can appear in PROTO and TOTO14.  Prefetch
        # its provider evidence once, then let every analyst reuse it.
        key = (
            home_name.casefold(), away_name.casefold(), kickoff.isoformat(),
        )
        if key in seen:
            continue
        seen.add(key)
        processed += 1
        if deep_refresh_due:
            deep_matches += 1
        else:
            early_core_matches += 1

        try:
            fixture_id = int(match.get("fixture_id") or entry.get("item", {}).get("api_fixture_id") or 0)
            league_id = int(match.get("league_id") or 0)
            season = int(match.get("season") or 0)
            home_id = int(match.get("home_team_id") or 0)
            away_id = int(match.get("away_team_id") or 0)

            with api_purpose_context(purpose):
                if entry.get("source") in {"PROTO", "TOTO14"}:
                    home_info, away_info, identity_fixture = resolve_match_team_pair(
                        home_name, away_name,
                        match.get("match_time") or match.get("time") or "",
                        ttl_h=2, league_name=match.get("league") or "",
                    )
                    home_id = int((home_info or {}).get("id") or 0)
                    away_id = int((away_info or {}).get("id") or 0)
                    fixture_id = int(
                        ((identity_fixture or {}).get("fixture") or {}).get("id")
                        if isinstance(identity_fixture, dict) else (identity_fixture or 0)
                    )
                    if isinstance(identity_fixture, dict):
                        fixture_id = int(
                            (identity_fixture.get("fixture") or {}).get("id")
                            or fixture_id or 0
                        )
                        league_id = int(
                            (identity_fixture.get("league") or {}).get("id")
                            or league_id or 0
                        )
                        season = int(
                            (identity_fixture.get("league") or {}).get("season")
                            or season or 0
                        )
                    if home_id and away_id:
                        # Date-fixture identity data already gives the early
                        # pass the correct pair/logo/competition.  Do not spend
                        # a volatile odds request until the normal T-30 refresh.
                        if deep_refresh_due:
                            need_overseas_odds = not _valid_three_way_odds([
                                match.get("odd_h"), match.get("odd_d"), match.get("odd_a")
                            ])
                            fixture_info = fetch_overseas_odds_and_fixture_api(
                                home_id, away_id, 2,
                                match.get("match_time") or match.get("time") or "",
                                include_odds=need_overseas_odds,
                            ) or {}
                            fixture_id = int(fixture_info.get("fixture_id") or fixture_id or 0)
                            league_id = int(fixture_info.get("league_id") or league_id or 0)
                            season = int(fixture_info.get("season") or season or 0)
                if home_id <= 0 or away_id <= 0 or home_id == away_id:
                    identities_missing += 1
                    if home_name and away_name:
                        queue_team_identity_retry(
                            home_name, away_name,
                            match.get("match_time") or match.get("time") or "",
                            reason="data_prefetch_identity_required",
                            league_name=match.get("league") or match.get("league_name_ko") or "",
                        )
                    continue

                # From T-72, warm the common team record once.  These helpers
                # share the recent-fixtures cache, so this is normally one
                # provider request per distinct team plus one H2H request.
                team_evidence = {}
                for team_id in (home_id, away_id):
                    team_evidence[str(team_id)] = {
                        "recent_fixtures": fetch_team_recent_fixtures_api(team_id, DATA_PREFETCH_TEAM_TTL_HOURS),
                        "form": fetch_team_form_api(team_id, DATA_PREFETCH_TEAM_TTL_HOURS),
                        "long_term": fetch_team_long_term_stats_api(team_id, DATA_PREFETCH_TEAM_TTL_HOURS),
                        "recent_metrics": fetch_team_recent_form_metrics(team_id, DATA_PREFETCH_TEAM_TTL_HOURS),
                        "last_match": fetch_team_last_match_date_api(team_id, DATA_PREFETCH_TEAM_TTL_HOURS),
                    }
                    if deep_refresh_due:
                        team_evidence[str(team_id)].update({
                            "next_fixture": fetch_team_next_fixture_api(team_id, DATA_PREFETCH_TEAM_TTL_HOURS),
                            "recent_stats": fetch_recent_team_stats_api(team_id, DATA_PREFETCH_TEAM_TTL_HOURS),
                        })
                        fetch_team_squad_cached(team_id)
                        team_evidence[str(team_id)]["manager"] = fetch_new_manager_status(team_id, 24)
                    teams_warmed += 1

                # Standings/key-player information changes often enough to
                # wait for the normal T-30 refresh.  Core history is already
                # available to all analyst engines from the early pass.
                standings_evidence = {}
                key_players = []
                if deep_refresh_due and league_id and season:
                    # One shared standings table plus league key-player cache feeds
                    # rank/motivation, injury impact and predicted-XI context.
                    standings_evidence = {
                        "home": fetch_team_standing_api(home_id, 12, league_id, season),
                        "away": fetch_team_standing_api(away_id, 12, league_id, season),
                    }
                    key_players = fetch_league_key_players(league_id, season)
                h2h_evidence = fetch_fixture_details_api(home_id, away_id, 24)
                injury_evidence = {}
                lineup_evidence = {}

                if deep_refresh_due and fixture_id and hours_to_kickoff <= 24:
                    injury_ttl = 3 if hours_to_kickoff <= 3 else 8
                    injury_evidence = {
                        "home": fetch_team_injuries_api(home_id, league_id, season, injury_ttl, fixture_id),
                        "away": fetch_team_injuries_api(away_id, league_id, season, injury_ttl, fixture_id),
                    }
                    if hours_to_kickoff <= 2:
                        lineup_evidence = fetch_lineups_api(fixture_id, 0.25, purpose=purpose)

                _store_shared_fixture_dossier(
                    match,
                    sources=entry.get("shared_sources") or [entry.get("source")],
                    home_info=home_info if entry.get("source") in {"PROTO", "TOTO14"} else {"id": home_id},
                    away_info=away_info if entry.get("source") in {"PROTO", "TOTO14"} else {"id": away_id},
                    fixture_id=fixture_id, league_id=league_id, season=season,
                    kickoff=kickoff, deep_refresh_due=deep_refresh_due,
                    evidence={
                        "teams": team_evidence,
                        "standings": standings_evidence,
                        "league_key_players": key_players,
                        "h2h": h2h_evidence,
                        "injuries": injury_evidence,
                        "lineups": lineup_evidence,
                    },
                )

                marked = all(_mark_prefetch_core_ready(
                    source, match,
                    home_id=home_id, away_id=away_id, kickoff=kickoff,
                ) for source in (entry.get("shared_sources") or [entry.get("source")]))
                if marked:
                    if core_ready_before:
                        core_already_ready += 1
                    else:
                        core_newly_warmed += 1
        except (ApiQuotaUnavailable, ApiRateLimited) as error:
            quota_paused = 1
            errors.append(f"quota:{error}")
            break
        except Exception as error:
            errors.append(f"{entry.get('source')}:{type(error).__name__}:{error}")

    return {
        "processed": processed,
        "teams_warmed": teams_warmed,
        "identities_missing": identities_missing,
        "early_core_matches": early_core_matches,
        "deep_matches": deep_matches,
        "core_newly_warmed": core_newly_warmed,
        "core_already_ready": core_already_ready,
        "early_horizon_hours": DATA_PREFETCH_EARLY_HORIZON_HOURS,
        "deep_horizon_hours": DATA_PREFETCH_HORIZON_HOURS,
        "quota_paused": quota_paused,
        "errors": errors[:5],
    }


def run_team_identity_job():
    """Prefetch shared evidence, then repair unresolved team profiles."""
    prefetch = _prefetch_upcoming_analysis_inputs(limit=DATA_PREFETCH_MATCH_LIMIT)
    seeded_cards = _queue_incomplete_dashboard_team_profiles()
    summary = process_team_identity_retry_queue(limit=TEAM_IDENTITY_RETRY_BATCH)
    repaired_cards = _refresh_dashboard_team_profiles()
    if repaired_cards and not upload_to_github("dashboard_data.json"):
        return False
    _update_collector_status(
        "team",
        "running",
        last_stage="complete",
        team_retry_processed=int(summary.get("processed") or 0),
        team_retry_resolved=int(summary.get("resolved") or 0),
        team_retry_pending=int(summary.get("pending") or 0),
        team_retry_due=int(summary.get("due") or 0),
        team_retry_seeded=int(seeded_cards),
        team_profile_card_updates=int(repaired_cards),
        data_prefetch_matches=int(prefetch.get("processed") or 0),
        data_prefetch_teams=int(prefetch.get("teams_warmed") or 0),
        data_prefetch_identity_missing=int(prefetch.get("identities_missing") or 0),
        data_prefetch_early_core_matches=int(prefetch.get("early_core_matches") or 0),
        data_prefetch_deep_matches=int(prefetch.get("deep_matches") or 0),
        data_prefetch_core_newly_warmed=int(prefetch.get("core_newly_warmed") or 0),
        data_prefetch_core_already_ready=int(prefetch.get("core_already_ready") or 0),
        data_prefetch_early_horizon_hours=int(prefetch.get("early_horizon_hours") or 0),
        data_prefetch_deep_horizon_hours=int(prefetch.get("deep_horizon_hours") or 0),
        data_prefetch_quota_paused=bool(prefetch.get("quota_paused")),
        data_prefetch_errors=list(prefetch.get("errors") or []),
    )
    if prefetch.get("processed"):
        print(
            "⚡ 분석자료 선수집 완료: "
            f"경기 {prefetch.get('processed', 0)}건 / "
            f"팀 캐시 {prefetch.get('teams_warmed', 0)}건 / "
            f"신규 공용자료 {prefetch.get('core_newly_warmed', 0)}건 / "
            f"재확인 {prefetch.get('core_already_ready', 0)}건 / "
            f"신원 대기 {prefetch.get('identities_missing', 0)}건"
        )
    if summary.get("processed") or summary.get("pending") or repaired_cards:
        print(
            "🔎 팀 전담 재탐색 완료: "
            f"이번 {summary.get('processed', 0)}건 / "
            f"성공 {summary.get('resolved', 0)}건 / "
            f"계속 대기 {summary.get('pending', 0)}건 / "
            f"화면 재등록 {seeded_cards}건 / 화면 갱신 {repaired_cards}장"
        )
    return True


def run_score_job():
    score_started = time.monotonic()
    success = auto_score_matches()
    if not success:
        return False
    scoring_seconds = time.monotonic() - score_started

    # Build the public grading feed once.  The old path rebuilt the same large
    # snapshot a second time merely to embed it into dashboard_data.json, which
    # kept this MAIN_DB worker alive and prevented master from receiving the DB
    # turn even after the visible grading feed was already published.
    snapshot_started = time.monotonic()
    snapshot = _build_grading_snapshot()
    if snapshot.get("error"):
        _update_collector_status("score", "running", last_stage="snapshot_failed")
        return False
    snapshot_seconds = time.monotonic() - snapshot_started
    snapshot["schema_version"] = "grading-results.v1"
    _atomic_write_json("grading_results.json", snapshot)
    if not upload_to_github("grading_results.json"):
        _update_collector_status("score", "running", last_stage="grading_publish_failed")
        return False
    _update_collector_status(
        "score", "running", last_stage="grading_published",
        grading_published_at=snapshot.get("generated_at"),
        scoring_seconds=round(scoring_seconds, 2),
        grading_snapshot_seconds=round(snapshot_seconds, 2),
    )

    # Legacy dashboard embedding is local-only and reuses the exact same object;
    # no second SQLite scan/grade pass is allowed on the score worker.  The web
    # already prefers grading_results.json, so failure here never invalidates the
    # successfully published score feed.
    embedded = _refresh_dashboard_grading_snapshot(snapshot)
    if not embedded:
        print("⚠️ 대시보드 채점 임베드 갱신은 보류 · 독립 grading_results.json은 정상 유지")
    backup_requested = _request_db_backup("score")
    total_seconds = time.monotonic() - score_started
    _update_collector_status(
        "score", "running", db_backup_requested=backup_requested,
        last_stage="complete",
        score_total_seconds=round(total_seconds, 2),
    )
    print(
        "⚡ score 즉시 반환 준비: "
        f"채점 {scoring_seconds:.1f}초 / 성적표 {snapshot_seconds:.1f}초 / "
        f"전체 {total_seconds:.1f}초 · 중복 성적표 재생성 없음"
    )
    return True


def _world_schedule_refresh_due(now=None):
    """Refresh the broad schedule slowly while allowing frequent cached analysis."""
    now = now or datetime.now(KST)
    payload = _read_json(WORLD_DASHBOARD_FILE, {})
    matches = [
        item for item in (payload or {}).get("matches", []) or []
        if isinstance(item, dict)
    ]
    has_upcoming = False
    for item in matches:
        match = item.get("match") or {}
        kickoff = _parse_kst_match_time(
            item.get("final_match_time") or match.get("match_time")
        )
        if kickoff is None and match.get("kickoff_at"):
            try:
                kickoff = datetime.fromisoformat(
                    str(match.get("kickoff_at")).replace("Z", "+00:00")
                )
                if kickoff.tzinfo is None:
                    kickoff = kickoff.replace(tzinfo=KST)
                kickoff = kickoff.astimezone(KST)
            except (TypeError, ValueError):
                kickoff = None
        if kickoff is not None and kickoff > now:
            has_upcoming = True
            break
    if not has_upcoming:
        return True
    generated_at = str((payload or {}).get("generated_at") or "")
    if not generated_at:
        return True
    try:
        generated = datetime.fromisoformat(generated_at.replace("Z", "+00:00"))
        if generated.tzinfo is None:
            generated = generated.replace(tzinfo=KST)
        return (now - generated.astimezone(KST)).total_seconds() >= (
            WORLD_SCHEDULE_REFRESH_HOURS * 3600
        )
    except (TypeError, ValueError):
        return True


def run_world_job():
    """Run independently so WORLD failures never block PROTO/LIVE/scoring."""
    if not WORLD_FEATURE_ENABLED:
        _update_collector_status(
            "world", "success", last_stage="disabled_for_proto_toto14_focus",
            world_feature_enabled=False,
        )
        print("⏸️ WORLD 전체경기 수집·분석은 정지됨 · 프로토 LIVE/승무패14에 자원 집중")
        return True
    # A local WORLD purpose record must not hide every fixture when the
    # provider itself still reports daily headroom.  The status call is cached
    # and only made after the internal WORLD brake is reached.
    world_usage = get_api_usage_status()
    if int(world_usage.get("world_calls") or 0) >= int(API_WORLD_DAILY_LIMIT):
        provider_status = refresh_provider_usage_status()
        if provider_status is not None:
            print(
                "🔎 WORLD 내부 사용량 재확인: "
                f"공급사 오늘 {provider_status.get('current', '?')}회 / "
                f"잔여 {provider_status.get('remaining', '?')}회"
            )
        else:
            print("⚠️ WORLD 내부 사용량 재확인 실패 · 기존 안전 차단을 유지합니다.")
    schedule_refreshed = False
    if _world_schedule_refresh_due():
        schedule_refreshed = bool(collect_world_schedule())
        if not schedule_refreshed:
            print("↩️ 세계경기 마지막 정상 일정으로 분석 대기열을 계속 진행합니다.")
        else:
            # Schedule discovery must reach Streamlit before the slower
            # full-context analysis begins.  The admin board can then show
            # fresh waiting rows, while the public visibility gate below
            # still prevents a pending row from becoming a customer pick.
            if not _publish_world_dashboard("최신 일정·배당 대기열"):
                _update_collector_status(
                    "world", "running", last_stage="world_schedule_publish_failed"
                )
                return False

    analysis_ok, analysis_changed = analyze_world_schedule()
    if not analysis_ok:
        return False

    if analysis_changed:
        if not _publish_world_dashboard("분석 체크포인트"):
            _update_collector_status(
                "world", "running", last_stage="world_dashboard_publish_failed"
            )
            return False
    if analysis_changed:
        # WORLD owns world_dashboard publication only.  The five-minute score
        # worker is the single owner of grading_results.json, so WORLD must not
        # rescan/grade the large production DB after a long analysis pass.  This
        # shortens main-DB occupancy and lets queued customer-pick master work
        # start promptly.  New WORLD rows are picked up by the next score cycle.
        backup_requested = _request_db_backup("world")
        _update_collector_status(
            "world",
            "running",
            db_backup_requested=backup_requested,
            grading_deferred_to_score=True,
            last_stage="complete",
        )
        print(
            "⚡ WORLD 분석 게시 완료 · 공통 채점 성적표는 전담 score worker가 다음 주기에 갱신"
        )
    else:
        _update_collector_status("world", "running", last_stage="complete")
    return True


def _initialize_db_safely(force_init=False):
    # Every recurring child normally returns here after a bounded read-only
    # schema preflight. The scheduler alone performs schema creation once.
    if not force_init and _validate_sqlite_file("ai_predictions.db"):
        return True
    fd, lock_path = _try_acquire_lock("db-init", stale_after=180, wait_seconds=45)
    if fd is None:
        return _validate_sqlite_file("ai_predictions.db")
    try:
        if not force_init and _validate_sqlite_file("ai_predictions.db"):
            return True
        init_cache_db()
        return _validate_sqlite_file("ai_predictions.db")
    finally:
        _release_lock(fd, lock_path)


JOB_FUNCTIONS = {
    "master": run_master_job,
    "recovery": run_scheduled_pick_recovery_job,
    "live": run_live_score_job,
    "score": run_score_job,
    "world": run_world_job,
    "team": run_team_identity_job,
    "backup": run_db_backup_job,
}
JOB_TIMEOUTS = {
    "master": max(600, min(1200, int(os.getenv("MASTER_JOB_TIMEOUT_SECONDS", "900")))),
    "recovery": max(60, int(os.getenv("RECOVERY_JOB_TIMEOUT_SECONDS", "180"))),
    "live": max(90, int(os.getenv("LIVE_JOB_TIMEOUT_SECONDS", "180"))),
    "score": max(120, int(os.getenv("SCORE_JOB_TIMEOUT_SECONDS", "600"))),
    "world": max(600, min(1800, int(os.getenv("WORLD_JOB_TIMEOUT_SECONDS", "1200")))),
    "team": max(180, int(os.getenv("TEAM_JOB_TIMEOUT_SECONDS", "600"))),
    "backup": max(1800, int(os.getenv("BACKUP_JOB_TIMEOUT_SECONDS", "7200"))),
}


def _publish_status():
    try:
        return upload_to_github(STATUS_FILE, remote_path=STATUS_FILE.name)
    except Exception as error:
        print(f"⚠️ 수집기 상태 게시 실패: {error}")
        return False


def _execute_job(job_name):
    timeout = JOB_TIMEOUTS[job_name]
    with _job_lock(job_name, stale_after=timeout + 120) as acquired:
        if not acquired:
            print(f"⏭️ {job_name} 작업이 이미 실행 중이어서 중복 실행을 건너뜁니다.")
            return 0
        started = time.monotonic()
        run_id = os.getenv("DJ_JOB_RUN_ID") or f"{job_name}-{time.time_ns()}"
        _update_collector_status(
            job_name, "running", _new_run=True, run_id=run_id,
            last_stage="initializing",
        )
        _publish_status()
        try:
            if not _initialize_db_safely():
                raise RuntimeError("ai_predictions.db 초기화/검증 실패")
            _update_collector_status(
                job_name, "running", run_id=run_id, last_stage="executing"
            )
            success = JOB_FUNCTIONS[job_name]()
            duration = round(time.monotonic() - started, 2)
            if success is False:
                raise RuntimeError(f"{job_name} 작업이 정상 결과를 게시하지 못함")
            _update_collector_status(
                job_name, "success", run_id=run_id, duration_seconds=duration
            )
            _publish_status()
            return 0
        except Exception as error:
            duration = round(time.monotonic() - started, 2)
            error_text = f"{type(error).__name__}: {error}"
            print(f"❌ {job_name} 작업 실패: {error_text}")
            traceback.print_exc()
            _update_collector_status(
                job_name,
                "failed",
                run_id=run_id,
                duration_seconds=duration,
                last_error=error_text[:1000],
            )
            _publish_status()
            return 1


_JOB_PROCESSES = {}
_PENDING_JOBS = {}
MAX_CONCURRENT_WORKERS = max(
    1, min(3, int(os.getenv("MAX_CONCURRENT_WORKERS", "2")))
)
MIN_AVAILABLE_MEMORY_MB = max(
    64, min(512, int(os.getenv("MIN_AVAILABLE_MEMORY_MB", "180")))
)
# These jobs either scan, update, checkpoint, or snapshot ai_predictions.db.
# On the 1 GiB production host only one may run at a time.  The team identity
# job uses the small runtime DB and may occupy the second worker slot.
MAIN_DB_JOBS = frozenset({"live", "score", "master", "recovery", "world", "backup"})
JOB_PRIORITY = {
    "live": 0,
    "score": 1,
    "recovery": 2,
    "team": 3,
    "master": 4,
    "world": 4,
    "backup": 5,
}
PENDING_JOB_AGE_SECONDS = max(
    600, min(3600, int(os.getenv("PENDING_JOB_AGE_SECONDS", "1800")))
)
# master must not sit behind newly recurring LIVE/score requests forever. Once
# it has waited three minutes it receives the next free main-DB turn. The short
# per-pass batch above then gives the DB slot back quickly.
MASTER_PRIORITY_AGE_SECONDS = max(
    60, min(600, int(os.getenv("MASTER_PRIORITY_AGE_SECONDS", "180")))
)
WORLD_PRIORITY_AGE_SECONDS = max(
    120, min(900, int(os.getenv("WORLD_PRIORITY_AGE_SECONDS", "180")))
)


def _available_memory_mb():
    """Return Linux MemAvailable without spawning another process."""
    try:
        with open("/proc/meminfo", "r", encoding="utf-8") as handle:
            for line in handle:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) / 1024.0
    except (OSError, ValueError, IndexError):
        return None
    return None


def _active_job_names():
    return {
        name
        for name, info in _JOB_PROCESSES.items()
        if info["process"].poll() is None
    }


def _start_isolated_job(job_name):
    existing = _JOB_PROCESSES.get(job_name)
    if existing and existing["process"].poll() is None:
        return False

    run_id = f"{job_name}-{time.time_ns()}"
    command = [sys.executable, "-u", str(Path(__file__).resolve()), "--mode", job_name]
    popen_kwargs = {
        "cwd": str(APP_DIR),
        "env": {
            **os.environ,
            "PYTHONUNBUFFERED": "1",
            "DJ_JOB_RUN_ID": run_id,
        },
    }
    if os.name == "nt":
        popen_kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    else:
        popen_kwargs["start_new_session"] = True
    try:
        process = subprocess.Popen(command, **popen_kwargs)
    except Exception as error:
        error_text = f"{type(error).__name__}: {error}"
        print(f"❌ {job_name} 분리 작업 시작 실패: {error_text}")
        _update_collector_status(job_name, "failed", last_error=error_text[:1000])
        return False
    _JOB_PROCESSES[job_name] = {
        "process": process,
        "started": time.monotonic(),
        "timeout": JOB_TIMEOUTS[job_name],
        "overlap_skips": 0,
        "run_id": run_id,
    }
    _update_collector_status(
        job_name, "running", _new_run=True, run_id=run_id,
        child_pid=process.pid, last_stage="starting",
    )
    print(f"🚀 분리 작업 시작: {job_name} (PID {process.pid})")
    return True


def _pending_sort_key(job_name, now):
    requested_at = float(_PENDING_JOBS[job_name])
    waited = max(0.0, now - requested_at)
    # The analysis pass is short/batched, so give it the next DB turn after a
    # brief wait instead of making it lose to every new five-minute LIVE/score
    # request. WORLD gets a slower fairness boost; the generic starvation guard
    # remains the final fallback for every job.
    if job_name == "master" and waited >= MASTER_PRIORITY_AGE_SECONDS:
        return (0, requested_at, 0)
    if job_name == "world" and waited >= WORLD_PRIORITY_AGE_SECONDS:
        return (0, requested_at, 0)
    if waited >= PENDING_JOB_AGE_SECONDS:
        return (0, requested_at, 1)
    return (1, JOB_PRIORITY.get(job_name, 99), requested_at)


def _drain_pending_jobs():
    started_any = False
    while _PENDING_JOBS:
        active = _active_job_names()
        if len(active) >= MAX_CONCURRENT_WORKERS:
            break
        if active:
            available_mb = _available_memory_mb()
            if available_mb is not None and available_mb < MIN_AVAILABLE_MEMORY_MB:
                break
        main_db_busy = bool(active & MAIN_DB_JOBS)
        eligible = [
            name for name in _PENDING_JOBS
            if name not in active
            and not (name in MAIN_DB_JOBS and main_db_busy)
        ]
        if not eligible:
            break
        now = time.monotonic()
        job_name = min(eligible, key=lambda name: _pending_sort_key(name, now))
        if not _start_isolated_job(job_name):
            break
        _PENDING_JOBS.pop(job_name, None)
        started_any = True
    return started_any


def _launch_isolated_job(job_name):
    existing = _JOB_PROCESSES.get(job_name)
    if existing and existing["process"].poll() is None:
        _update_collector_status(
            job_name,
            "running",
            child_pid=existing["process"].pid,
            elapsed_seconds=round(time.monotonic() - existing["started"], 1),
            overlap_skips=int(existing.get("overlap_skips", 0)) + 1,
        )
        existing["overlap_skips"] = int(existing.get("overlap_skips", 0)) + 1
        print(f"⏭️ {job_name} 이전 실행이 남아 있어 이번 주기를 겹치지 않습니다.")
        return False
    if job_name not in _PENDING_JOBS:
        _PENDING_JOBS[job_name] = time.monotonic()
        print(f"🕒 작업 대기열 등록: {job_name}")
    return _drain_pending_jobs()


def _terminate_process_tree(process):
    if process.poll() is not None:
        return
    try:
        if os.name != "nt":
            os.killpg(process.pid, signal.SIGTERM)
        else:
            subprocess.run(
                ["taskkill", "/PID", str(process.pid), "/T", "/F"],
                check=False,
                capture_output=True,
                timeout=10,
            )
        process.wait(timeout=8)
    except Exception:
        try:
            if os.name != "nt":
                os.killpg(process.pid, signal.SIGKILL)
            else:
                process.kill()
        except Exception:
            pass


def _reap_job_processes():
    now = time.monotonic()
    for job_name, info in list(_JOB_PROCESSES.items()):
        process = info["process"]
        elapsed = now - info["started"]
        return_code = process.poll()
        if return_code is None and elapsed > info["timeout"]:
            print(f"❌ {job_name} 작업 제한시간 초과({int(elapsed)}초) - 프로세스 트리 종료")
            _terminate_process_tree(process)
            _update_collector_status(
                job_name,
                "failed",
                child_pid=process.pid,
                run_id=info.get("run_id"),
                duration_seconds=round(elapsed, 1),
                last_error=f"hard timeout after {int(elapsed)} seconds",
            )
            _publish_status()
            _JOB_PROCESSES.pop(job_name, None)
        elif return_code is not None:
            if return_code != 0:
                _update_collector_status(
                    job_name,
                    "failed",
                    child_pid=process.pid,
                    run_id=info.get("run_id"),
                    duration_seconds=round(elapsed, 1),
                    last_error=f"worker exited with code {return_code}",
                )
            else:
                print(
                    f"✅ 분리 작업 종료: {job_name} (PID {process.pid}, "
                    f"{elapsed:.1f}초) · 다음 대기작업에 DB 차례 반환"
                )
            _JOB_PROCESSES.pop(job_name, None)
    _drain_pending_jobs()


def _heartbeat_active_jobs():
    now = time.monotonic()
    for job_name, info in list(_JOB_PROCESSES.items()):
        process = info["process"]
        if process.poll() is None:
            _update_collector_status(
                job_name,
                "running",
                child_pid=process.pid,
                run_id=info.get("run_id"),
                elapsed_seconds=round(now - info["started"], 1),
                overlap_skips=int(info.get("overlap_skips", 0)),
            )


def run_scheduler():
    os.chdir(APP_DIR)
    scheduler_run_id = f"scheduler-{time.time_ns()}"
    _update_collector_status(
        "scheduler", "running", _new_run=True, run_id=scheduler_run_id,
        supervisor_pid=os.getpid(), last_stage="initializing",
    )
    download_latest_db_from_github()
    if not _initialize_db_safely(force_init=True):
        raise RuntimeError("수집기 DB 초기화 실패")

    schedule.clear()
    # Requests start immediately only when the low-memory/main-DB admission
    # rules allow it. Remaining work stays queued and is drained after reaping.
    _launch_isolated_job("live")
    _launch_isolated_job("score")
    _launch_isolated_job("master")
    if WORLD_FEATURE_ENABLED:
        _launch_isolated_job("world")
    _launch_isolated_job("team")
    schedule.every(5).minutes.do(_launch_isolated_job, "live")
    schedule.every(5).minutes.do(_launch_isolated_job, "score")
    # A large board can need several resumable passes. The overlap guard keeps
    # one worker at a time while a five-minute tick starts the next pass soon.
    schedule.every(5).minutes.do(_launch_isolated_job, "master")
    if WORLD_FEATURE_ENABLED:
        schedule.every(WORLD_ANALYSIS_INTERVAL_MINUTES).minutes.do(
            _launch_isolated_job, "world"
        )
    schedule.every(5).minutes.do(_launch_isolated_job, "team")
    schedule.every(DB_BACKUP_INTERVAL_MINUTES).minutes.do(
        _launch_isolated_job, "backup"
    )

    print(
        "\n🚀 [감시 스케줄러] master/live/score/world/team/backup 분리 · 중복 방지 · "
        f"WORLD {'활성' if WORLD_FEATURE_ENABLED else '정지'} · "
        f"DB 백업 {DB_BACKUP_INTERVAL_MINUTES}분"
    )
    last_heartbeat = 0.0
    while True:
        try:
            schedule.run_pending()
            _reap_job_processes()
            if time.monotonic() - last_heartbeat >= 30:
                _heartbeat_active_jobs()
                _update_collector_status(
                    "scheduler",
                    "running",
                    run_id=scheduler_run_id,
                    supervisor_pid=os.getpid(),
                    active_jobs={
                        name: info["process"].pid
                        for name, info in _JOB_PROCESSES.items()
                        if info["process"].poll() is None
                    },
                    pending_jobs=sorted(_PENDING_JOBS),
                    max_concurrent_workers=MAX_CONCURRENT_WORKERS,
                    min_available_memory_mb=MIN_AVAILABLE_MEMORY_MB,
                )
                last_heartbeat = time.monotonic()
            time.sleep(2)
        except KeyboardInterrupt:
            print("수집기 종료 신호를 받았습니다.")
            for info in list(_JOB_PROCESSES.values()):
                _terminate_process_tree(info["process"])
            _update_collector_status("scheduler", "stopped")
            return 0
        except Exception as error:
            print(f"⚠️ 스케줄러 루프 오류(계속 실행): {type(error).__name__}: {error}")
            _update_collector_status("scheduler", "running", last_error=str(error)[:1000])
            time.sleep(5)


def main(argv=None):
    parser = argparse.ArgumentParser(description="D.J SPORTS collector")
    parser.add_argument(
        "--mode",
        choices=("scheduler", "master", "recovery", "live", "score", "world", "team", "backup"),
        default="scheduler",
        help="scheduler supervises isolated workers; other modes run one job once",
    )
    args = parser.parse_args(argv)
    os.chdir(APP_DIR)
    if args.mode == "scheduler":
        try:
            with _job_lock("scheduler", stale_after=86400) as acquired:
                if not acquired:
                    print("⏭️ 수집기 스케줄러가 이미 실행 중입니다.")
                    return 0
                return run_scheduler()
        except Exception as error:
            _update_collector_status(
                "scheduler", "failed", last_error=f"{type(error).__name__}: {error}"[:1000]
            )
            traceback.print_exc()
            return 1
    return _execute_job(args.mode)


def _exit_one_shot_worker(exit_code):
    # Some imported networking/browser libraries keep non-daemon cleanup or
    # buffered I/O alive after the one-shot result was already published.
    # Flush the observable result, then terminate only this isolated child.
    try:
        sys.stdout.flush()
        sys.stderr.flush()
    finally:
        os._exit(int(exit_code))


if __name__ == "__main__":
    code = main()
    requested_mode = "scheduler"
    for index, argument in enumerate(sys.argv[1:]):
        if argument.startswith("--mode="):
            requested_mode = argument.split("=", 1)[1]
        elif argument == "--mode" and index + 2 <= len(sys.argv[1:]):
            requested_mode = sys.argv[index + 2]
    if requested_mode != "scheduler":
        _exit_one_shot_worker(code)
    raise SystemExit(code)
